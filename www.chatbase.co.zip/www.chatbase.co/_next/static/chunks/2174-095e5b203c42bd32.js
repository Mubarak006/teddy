"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2174], {
        55946: function(t, e, i) {
            i.d(e, {
                s: function() {
                    return r
                }
            });
            var n = i(43198);
            class r {
                constructor(t) {
                    this.stop = () => this.runAll("stop"), this.animations = t.filter(Boolean)
                }
                then(t, e) {
                    return Promise.all(this.animations).then(t).catch(e)
                }
                getAll(t) {
                    return this.animations[0][t]
                }
                setAll(t, e) {
                    for (let i = 0; i < this.animations.length; i++) this.animations[i][t] = e
                }
                attachTimeline(t, e) {
                    let i = this.animations.map(i => (0, n.t)() && i.attachTimeline ? i.attachTimeline(t) : e(i));
                    return () => {
                        i.forEach((t, e) => {
                            t && t(), this.animations[e].stop()
                        })
                    }
                }
                get time() {
                    return this.getAll("time")
                }
                set time(t) {
                    this.setAll("time", t)
                }
                get speed() {
                    return this.getAll("speed")
                }
                set speed(t) {
                    this.setAll("speed", t)
                }
                get startTime() {
                    return this.getAll("startTime")
                }
                get duration() {
                    let t = 0;
                    for (let e = 0; e < this.animations.length; e++) t = Math.max(t, this.animations[e].duration);
                    return t
                }
                runAll(t) {
                    this.animations.forEach(e => e[t]())
                }
                flatten() {
                    this.runAll("flatten")
                }
                play() {
                    this.runAll("play")
                }
                pause() {
                    this.runAll("pause")
                }
                cancel() {
                    this.runAll("cancel")
                }
                complete() {
                    this.runAll("complete")
                }
            }
        },
        82993: function(t, e, i) {
            i.d(e, {
                D: function() {
                    return o
                }
            });
            var n = i(60689),
                r = i(3078),
                s = i(23999);

            function o(t, e, i) {
                let o = (0, s.i)(t) ? t : (0, r.BX)(t);
                return o.start((0, n.v)("", o, e, i)), o.animation
            }
        },
        31268: function(t, e, i) {
            i.d(e, {
                w: function() {
                    return r
                }
            });
            var n = i(76376);
            let r = (t, e, i = 10) => {
                let r = "",
                    s = Math.max(Math.round(e / i), 2);
                for (let e = 0; e < s; e++) r += t((0, n.Y)(0, s - 1, e)) + ", ";
                return `linear(${r.substring(0,r.length-2)})`
            }
        },
        37246: function(t, e, i) {
            i.d(e, {
                S: function() {
                    return f
                }
            });
            var n = i(31268),
                r = i(56717),
                s = i(87093),
                o = i(98751),
                a = i(59111);
            let l = {
                stiffness: 100,
                damping: 10,
                mass: 1,
                velocity: 0,
                duration: 800,
                bounce: .3,
                visualDuration: .3,
                restSpeed: {
                    granular: .01,
                    default: 2
                },
                restDelta: {
                    granular: .005,
                    default: .5
                },
                minDuration: .01,
                maxDuration: 10,
                minDamping: .05,
                maxDamping: 1
            };

            function u(t, e) {
                return t * Math.sqrt(1 - e * e)
            }
            var h = i(30431);
            let c = ["duration", "bounce"],
                d = ["stiffness", "damping", "mass"];

            function p(t, e) {
                return e.some(e => void 0 !== t[e])
            }

            function f(t = l.visualDuration, e = l.bounce) {
                let i;
                let f = "object" != typeof t ? {
                        visualDuration: t,
                        keyframes: [0, 1],
                        bounce: e
                    } : t,
                    {
                        restSpeed: m,
                        restDelta: v
                    } = f,
                    g = f.keyframes[0],
                    y = f.keyframes[f.keyframes.length - 1],
                    x = {
                        done: !1,
                        value: g
                    },
                    {
                        stiffness: w,
                        damping: P,
                        mass: T,
                        duration: b,
                        velocity: S,
                        isResolvedFromDuration: A
                    } = function(t) {
                        let e = {
                            velocity: l.velocity,
                            stiffness: l.stiffness,
                            damping: l.damping,
                            mass: l.mass,
                            isResolvedFromDuration: !1,
                            ...t
                        };
                        if (!p(t, d) && p(t, c)) {
                            if (t.visualDuration) {
                                let i = 2 * Math.PI / (1.2 * t.visualDuration),
                                    n = i * i,
                                    r = 2 * (0, a.u)(.05, 1, 1 - t.bounce) * Math.sqrt(n);
                                e = { ...e,
                                    mass: l.mass,
                                    stiffness: n,
                                    damping: r
                                }
                            } else {
                                let i = function({
                                    duration: t = l.duration,
                                    bounce: e = l.bounce,
                                    velocity: i = l.velocity,
                                    mass: n = l.mass
                                }) {
                                    let s, h;
                                    (0, o.K)(t <= (0, r.w)(l.maxDuration), "Spring duration must be 10 seconds or less");
                                    let c = 1 - e;
                                    c = (0, a.u)(l.minDamping, l.maxDamping, c), t = (0, a.u)(l.minDuration, l.maxDuration, (0, r.X)(t)), c < 1 ? (s = e => {
                                        let n = e * c,
                                            r = n * t;
                                        return .001 - (n - i) / u(e, c) * Math.exp(-r)
                                    }, h = e => {
                                        let n = e * c * t,
                                            r = Math.pow(c, 2) * Math.pow(e, 2) * t,
                                            o = u(Math.pow(e, 2), c);
                                        return (n * i + i - r) * Math.exp(-n) * (-s(e) + .001 > 0 ? -1 : 1) / o
                                    }) : (s = e => -.001 + Math.exp(-e * t) * ((e - i) * t + 1), h = e => t * t * (i - e) * Math.exp(-e * t));
                                    let d = function(t, e, i) {
                                        let n = i;
                                        for (let i = 1; i < 12; i++) n -= t(n) / e(n);
                                        return n
                                    }(s, h, 5 / t);
                                    if (t = (0, r.w)(t), isNaN(d)) return {
                                        stiffness: l.stiffness,
                                        damping: l.damping,
                                        duration: t
                                    }; {
                                        let e = Math.pow(d, 2) * n;
                                        return {
                                            stiffness: e,
                                            damping: 2 * c * Math.sqrt(n * e),
                                            duration: t
                                        }
                                    }
                                }(t);
                                (e = { ...e,
                                    ...i,
                                    mass: l.mass
                                }).isResolvedFromDuration = !0
                            }
                        }
                        return e
                    }({ ...f,
                        velocity: -(0, r.X)(f.velocity || 0)
                    }),
                    D = S || 0,
                    V = P / (2 * Math.sqrt(w * T)),
                    M = y - g,
                    E = (0, r.X)(Math.sqrt(w / T)),
                    C = 5 > Math.abs(M);
                if (m || (m = C ? l.restSpeed.granular : l.restSpeed.default), v || (v = C ? l.restDelta.granular : l.restDelta.default), V < 1) {
                    let t = u(E, V);
                    i = e => y - Math.exp(-V * E * e) * ((D + V * E * M) / t * Math.sin(t * e) + M * Math.cos(t * e))
                } else if (1 === V) i = t => y - Math.exp(-E * t) * (M + (D + E * M) * t);
                else {
                    let t = E * Math.sqrt(V * V - 1);
                    i = e => {
                        let i = Math.exp(-V * E * e),
                            n = Math.min(t * e, 300);
                        return y - i * ((D + V * E * M) * Math.sinh(n) + t * M * Math.cosh(n)) / t
                    }
                }
                let R = {
                    calculatedDuration: A && b || null,
                    next: t => {
                        let e = i(t);
                        if (A) x.done = t >= b;
                        else {
                            let n = 0;
                            V < 1 && (n = 0 === t ? (0, r.w)(D) : (0, s.P)(i, t, e));
                            let o = Math.abs(n) <= m,
                                a = Math.abs(y - e) <= v;
                            x.done = o && a
                        }
                        return x.value = x.done ? y : e, x
                    },
                    toString: () => {
                        let t = Math.min((0, h.i)(R), h.E),
                            e = (0, n.w)(e => R.next(t * e).value, t, 30);
                        return t + "ms " + e
                    }
                };
                return R
            }
        },
        30431: function(t, e, i) {
            i.d(e, {
                E: function() {
                    return n
                },
                i: function() {
                    return r
                }
            });
            let n = 2e4;

            function r(t) {
                let e = 0,
                    i = t.next(e);
                for (; !i.done && e < n;) e += 50, i = t.next(e);
                return e >= n ? 1 / 0 : e
            }
        },
        48833: function(t, e, i) {
            i.d(e, {
                x: function() {
                    return n
                }
            });

            function n(t) {
                return "function" == typeof t
            }
        },
        87093: function(t, e, i) {
            i.d(e, {
                P: function() {
                    return r
                }
            });
            var n = i(51116);

            function r(t, e, i) {
                let r = Math.max(e - 5, 0);
                return (0, n.R)(i - t(r), e - r)
            }
        },
        60689: function(t, e, i) {
            i.d(e, {
                v: function() {
                    return tp
                }
            });
            var n = i(56717),
                r = i(8834);
            let s = {
                    type: "spring",
                    stiffness: 500,
                    damping: 25,
                    restSpeed: 10
                },
                o = t => ({
                    type: "spring",
                    stiffness: 550,
                    damping: 0 === t ? 2 * Math.sqrt(550) : 30,
                    restSpeed: 10
                }),
                a = {
                    type: "keyframes",
                    duration: .8
                },
                l = {
                    type: "keyframes",
                    ease: [.25, .1, .35, 1],
                    duration: .3
                },
                u = (t, {
                    keyframes: e
                }) => e.length > 2 ? a : r.G.has(t) ? t.startsWith("scale") ? o(e[1]) : s : l;
            var h = i(2259),
                c = i(24118);
            let d = {
                    current: !1
                },
                p = t => null !== t;

            function f(t, {
                repeat: e,
                repeatType: i = "loop"
            }, n) {
                let r = t.filter(p),
                    s = e && "loop" !== i && e % 2 == 1 ? 0 : r.length - 1;
                return s && void 0 !== n ? n : r[s]
            }
            var m = i(45414),
                v = i(56277);
            let g = (t, e, i) => (((1 - 3 * i + 3 * e) * t + (3 * i - 6 * e)) * t + 3 * e) * t;

            function y(t, e, i, n) {
                if (t === e && i === n) return v.Z;
                let r = e => (function(t, e, i, n, r) {
                    let s, o;
                    let a = 0;
                    do(s = g(o = e + (i - e) / 2, n, r) - t) > 0 ? i = o : e = o; while (Math.abs(s) > 1e-7 && ++a < 12);
                    return o
                })(e, 0, 1, t, i);
                return t => 0 === t || 1 === t ? t : g(r(t), e, n)
            }
            var x = i(87457),
                w = i(63627);
            let P = y(.33, 1.53, .69, .99),
                T = (0, w.M)(P),
                b = (0, x.o)(T),
                S = t => (t *= 2) < 1 ? .5 * T(t) : .5 * (2 - Math.pow(2, -10 * (t - 1)));
            var A = i(26378),
                D = i(94238),
                V = i(48833),
                M = i(40504),
                E = i(39545),
                C = i(98751),
                R = i(83206);
            let k = (t, e) => "zIndex" !== e && !!("number" == typeof t || Array.isArray(t) || "string" == typeof t && (R.P.test(t) || "0" === t) && !t.startsWith("url("));
            class j {
                constructor({
                    autoplay: t = !0,
                    delay: e = 0,
                    type: i = "keyframes",
                    repeat: n = 0,
                    repeatDelay: r = 0,
                    repeatType: s = "loop",
                    ...o
                }) {
                    this.isStopped = !1, this.hasAttemptedResolve = !1, this.createdAt = M.X.now(), this.options = {
                        autoplay: t,
                        delay: e,
                        type: i,
                        repeat: n,
                        repeatDelay: r,
                        repeatType: s,
                        ...o
                    }, this.updateFinishedPromise()
                }
                calcStartTime() {
                    return this.resolvedAt && this.resolvedAt - this.createdAt > 40 ? this.resolvedAt : this.createdAt
                }
                get resolved() {
                    return this._resolved || this.hasAttemptedResolve || (0, E.m)(), this._resolved
                }
                onKeyframesResolved(t, e) {
                    this.resolvedAt = M.X.now(), this.hasAttemptedResolve = !0;
                    let {
                        name: i,
                        type: n,
                        velocity: r,
                        delay: s,
                        onComplete: o,
                        onUpdate: a,
                        isGenerator: l
                    } = this.options;
                    if (!l && ! function(t, e, i, n) {
                            let r = t[0];
                            if (null === r) return !1;
                            if ("display" === e || "visibility" === e) return !0;
                            let s = t[t.length - 1],
                                o = k(r, e),
                                a = k(s, e);
                            return (0, C.K)(o === a, `You are trying to animate ${e} from "${r}" to "${s}". ${r} is not an animatable value - to enable this animation set ${r} to a value animatable to ${s} via the \`style\` property.`), !!o && !!a && (function(t) {
                                let e = t[0];
                                if (1 === t.length) return !0;
                                for (let i = 0; i < t.length; i++)
                                    if (t[i] !== e) return !0
                            }(t) || ("spring" === i || (0, V.x)(i)) && n)
                        }(t, i, n, r)) {
                        if (d.current || !s) {
                            null == a || a(f(t, this.options, e)), null == o || o(), this.resolveFinishedPromise();
                            return
                        }
                        this.options.duration = 0
                    }
                    let u = this.initPlayback(t, e);
                    !1 !== u && (this._resolved = {
                        keyframes: t,
                        finalKeyframe: e,
                        ...u
                    }, this.onPostResolved())
                }
                onPostResolved() {}
                then(t, e) {
                    return this.currentFinishedPromise.then(t, e)
                }
                flatten() {
                    this.options.type = "keyframes", this.options.ease = "linear"
                }
                updateFinishedPromise() {
                    this.currentFinishedPromise = new Promise(t => {
                        this.resolveFinishedPromise = t
                    })
                }
            }
            var L = i(37246),
                F = i(87093);

            function B({
                keyframes: t,
                velocity: e = 0,
                power: i = .8,
                timeConstant: n = 325,
                bounceDamping: r = 10,
                bounceStiffness: s = 500,
                modifyTarget: o,
                min: a,
                max: l,
                restDelta: u = .5,
                restSpeed: h
            }) {
                let c, d;
                let p = t[0],
                    f = {
                        done: !1,
                        value: p
                    },
                    m = t => void 0 !== a && t < a || void 0 !== l && t > l,
                    v = t => void 0 === a ? l : void 0 === l ? a : Math.abs(a - t) < Math.abs(l - t) ? a : l,
                    g = i * e,
                    y = p + g,
                    x = void 0 === o ? y : o(y);
                x !== y && (g = x - p);
                let w = t => -g * Math.exp(-t / n),
                    P = t => x + w(t),
                    T = t => {
                        let e = w(t),
                            i = P(t);
                        f.done = Math.abs(e) <= u, f.value = f.done ? x : i
                    },
                    b = t => {
                        m(f.value) && (c = t, d = (0, L.S)({
                            keyframes: [f.value, v(f.value)],
                            velocity: (0, F.P)(P, t, f.value),
                            damping: r,
                            stiffness: s,
                            restDelta: u,
                            restSpeed: h
                        }))
                    };
                return b(0), {
                    calculatedDuration: null,
                    next: t => {
                        let e = !1;
                        return (d || void 0 !== c || (e = !0, T(t), b(t)), void 0 !== c && t >= c) ? d.next(t - c) : (e || T(t), f)
                    }
                }
            }
            let O = y(.42, 0, 1, 1),
                $ = y(0, 0, .58, 1),
                W = y(.42, 0, .58, 1);
            var U = i(81477);
            let I = t => Array.isArray(t) && "number" == typeof t[0],
                N = {
                    linear: v.Z,
                    easeIn: O,
                    easeInOut: W,
                    easeOut: $,
                    circIn: A.Z7,
                    circInOut: A.X7,
                    circOut: A.Bn,
                    backIn: T,
                    backInOut: b,
                    backOut: P,
                    anticipate: S
                },
                X = t => {
                    if (I(t)) {
                        (0, C.k)(4 === t.length, "Cubic bezier arrays must contain four numerical values.");
                        let [e, i, n, r] = t;
                        return y(e, i, n, r)
                    }
                    return "string" == typeof t ? ((0, C.k)(void 0 !== N[t], `Invalid easing type '${t}'`), N[t]) : t
                };
            var Y = i(88843),
                z = i(46261);

            function K({
                duration: t = 300,
                keyframes: e,
                times: i,
                ease: n = "easeInOut"
            }) {
                let r = (0, U.N)(n) ? n.map(X) : X(n),
                    s = {
                        done: !1,
                        value: e[0]
                    },
                    o = (i && i.length === e.length ? i : (0, z.Y)(e)).map(e => e * t),
                    a = (0, Y.s)(o, e, {
                        ease: Array.isArray(r) ? r : e.map(() => r || W).splice(0, e.length - 1)
                    });
                return {
                    calculatedDuration: t,
                    next: e => (s.value = a(e), s.done = e >= t, s)
                }
            }
            var H = i(56920),
                Z = i(12006),
                q = i(30431),
                G = i(59111);
            let _ = t => {
                    let e = ({
                        timestamp: e
                    }) => t(e);
                    return {
                        start: () => m.Wi.update(e, !0),
                        stop: () => (0, m.Pn)(e),
                        now: () => m.frameData.isProcessing ? m.frameData.timestamp : M.X.now()
                    }
                },
                J = {
                    decay: B,
                    inertia: B,
                    tween: K,
                    keyframes: K,
                    spring: L.S
                },
                Q = t => t / 100;
            class tt extends j {
                constructor(t) {
                    super(t), this.holdTime = null, this.cancelTime = null, this.currentTime = 0, this.playbackSpeed = 1, this.pendingPlayState = "running", this.startTime = null, this.state = "idle", this.stop = () => {
                        if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                        this.teardown();
                        let {
                            onStop: t
                        } = this.options;
                        t && t()
                    };
                    let {
                        name: e,
                        motionValue: i,
                        element: n,
                        keyframes: r
                    } = this.options, s = (null == n ? void 0 : n.KeyframeResolver) || E.e;
                    this.resolver = new s(r, (t, e) => this.onKeyframesResolved(t, e), e, i, n), this.resolver.scheduleResolve()
                }
                flatten() {
                    super.flatten(), this._resolved && Object.assign(this._resolved, this.initPlayback(this._resolved.keyframes))
                }
                initPlayback(t) {
                    let e, i;
                    let {
                        type: n = "keyframes",
                        repeat: r = 0,
                        repeatDelay: s = 0,
                        repeatType: o,
                        velocity: a = 0
                    } = this.options, l = (0, V.x)(n) ? n : J[n] || K;
                    l !== K && "number" != typeof t[0] && (e = (0, H.z)(Q, (0, Z.C)(t[0], t[1])), t = [0, 100]);
                    let u = l({ ...this.options,
                        keyframes: t
                    });
                    "mirror" === o && (i = l({ ...this.options,
                        keyframes: [...t].reverse(),
                        velocity: -a
                    })), null === u.calculatedDuration && (u.calculatedDuration = (0, q.i)(u));
                    let {
                        calculatedDuration: h
                    } = u, c = h + s;
                    return {
                        generator: u,
                        mirroredGenerator: i,
                        mapPercentToKeyframes: e,
                        calculatedDuration: h,
                        resolvedDuration: c,
                        totalDuration: c * (r + 1) - s
                    }
                }
                onPostResolved() {
                    let {
                        autoplay: t = !0
                    } = this.options;
                    this.play(), "paused" !== this.pendingPlayState && t ? this.state = this.pendingPlayState : this.pause()
                }
                tick(t, e = !1) {
                    let {
                        resolved: i
                    } = this;
                    if (!i) {
                        let {
                            keyframes: t
                        } = this.options;
                        return {
                            done: !0,
                            value: t[t.length - 1]
                        }
                    }
                    let {
                        finalKeyframe: n,
                        generator: r,
                        mirroredGenerator: s,
                        mapPercentToKeyframes: o,
                        keyframes: a,
                        calculatedDuration: l,
                        totalDuration: u,
                        resolvedDuration: h
                    } = i;
                    if (null === this.startTime) return r.next(0);
                    let {
                        delay: c,
                        repeat: d,
                        repeatType: p,
                        repeatDelay: m,
                        onUpdate: v
                    } = this.options;
                    this.speed > 0 ? this.startTime = Math.min(this.startTime, t) : this.speed < 0 && (this.startTime = Math.min(t - u / this.speed, this.startTime)), e ? this.currentTime = t : null !== this.holdTime ? this.currentTime = this.holdTime : this.currentTime = Math.round(t - this.startTime) * this.speed;
                    let g = this.currentTime - c * (this.speed >= 0 ? 1 : -1),
                        y = this.speed >= 0 ? g < 0 : g > u;
                    this.currentTime = Math.max(g, 0), "finished" === this.state && null === this.holdTime && (this.currentTime = u);
                    let x = this.currentTime,
                        w = r;
                    if (d) {
                        let t = Math.min(this.currentTime, u) / h,
                            e = Math.floor(t),
                            i = t % 1;
                        !i && t >= 1 && (i = 1), 1 === i && e--, (e = Math.min(e, d + 1)) % 2 && ("reverse" === p ? (i = 1 - i, m && (i -= m / h)) : "mirror" === p && (w = s)), x = (0, G.u)(0, 1, i) * h
                    }
                    let P = y ? {
                        done: !1,
                        value: a[0]
                    } : w.next(x);
                    o && (P.value = o(P.value));
                    let {
                        done: T
                    } = P;
                    y || null === l || (T = this.speed >= 0 ? this.currentTime >= u : this.currentTime <= 0);
                    let b = null === this.holdTime && ("finished" === this.state || "running" === this.state && T);
                    return b && void 0 !== n && (P.value = f(a, this.options, n)), v && v(P.value), b && this.finish(), P
                }
                get duration() {
                    let {
                        resolved: t
                    } = this;
                    return t ? (0, n.X)(t.calculatedDuration) : 0
                }
                get time() {
                    return (0, n.X)(this.currentTime)
                }
                set time(t) {
                    t = (0, n.w)(t), this.currentTime = t, null !== this.holdTime || 0 === this.speed ? this.holdTime = t : this.driver && (this.startTime = this.driver.now() - t / this.speed)
                }
                get speed() {
                    return this.playbackSpeed
                }
                set speed(t) {
                    let e = this.playbackSpeed !== t;
                    this.playbackSpeed = t, e && (this.time = (0, n.X)(this.currentTime))
                }
                play() {
                    if (this.resolver.isScheduled || this.resolver.resume(), !this._resolved) {
                        this.pendingPlayState = "running";
                        return
                    }
                    if (this.isStopped) return;
                    let {
                        driver: t = _,
                        onPlay: e,
                        startTime: i
                    } = this.options;
                    this.driver || (this.driver = t(t => this.tick(t))), e && e();
                    let n = this.driver.now();
                    null !== this.holdTime ? this.startTime = n - this.holdTime : this.startTime ? "finished" === this.state && (this.startTime = n) : this.startTime = null != i ? i : this.calcStartTime(), "finished" === this.state && this.updateFinishedPromise(), this.cancelTime = this.startTime, this.holdTime = null, this.state = "running", this.driver.start()
                }
                pause() {
                    var t;
                    if (!this._resolved) {
                        this.pendingPlayState = "paused";
                        return
                    }
                    this.state = "paused", this.holdTime = null !== (t = this.currentTime) && void 0 !== t ? t : 0
                }
                complete() {
                    "running" !== this.state && this.play(), this.pendingPlayState = this.state = "finished", this.holdTime = null
                }
                finish() {
                    this.teardown(), this.state = "finished";
                    let {
                        onComplete: t
                    } = this.options;
                    t && t()
                }
                cancel() {
                    null !== this.cancelTime && this.tick(this.cancelTime), this.teardown(), this.updateFinishedPromise()
                }
                teardown() {
                    this.state = "idle", this.stopDriver(), this.resolveFinishedPromise(), this.updateFinishedPromise(), this.startTime = this.cancelTime = null, this.resolver.cancel()
                }
                stopDriver() {
                    this.driver && (this.driver.stop(), this.driver = void 0)
                }
                sample(t) {
                    return this.startTime = 0, this.tick(t, !0)
                }
            }
            let te = new Set(["opacity", "clipPath", "filter", "transform"]);
            var ti = i(31268),
                tn = i(64043);
            let tr = {
                    linearEasing: void 0
                },
                ts = function(t, e) {
                    let i = (0, tn.X)(t);
                    return () => {
                        var t;
                        return null !== (t = tr[e]) && void 0 !== t ? t : i()
                    }
                }(() => {
                    try {
                        document.createElement("div").animate({
                            opacity: 0
                        }, {
                            easing: "linear(0, 1)"
                        })
                    } catch (t) {
                        return !1
                    }
                    return !0
                }, "linearEasing"),
                to = ([t, e, i, n]) => `cubic-bezier(${t}, ${e}, ${i}, ${n})`,
                ta = {
                    linear: "linear",
                    ease: "ease",
                    easeIn: "ease-in",
                    easeOut: "ease-out",
                    easeInOut: "ease-in-out",
                    circIn: to([0, .65, .55, 1]),
                    circOut: to([.55, 0, 1, .45]),
                    backIn: to([.31, .01, .66, -.59]),
                    backOut: to([.33, 1.53, .69, .99])
                };

            function tl(t, e) {
                t.timeline = e, t.onfinish = null
            }
            let tu = (0, tn.X)(() => Object.hasOwnProperty.call(Element.prototype, "animate")),
                th = {
                    anticipate: S,
                    backInOut: b,
                    circInOut: A.X7
                };
            class tc extends j {
                constructor(t) {
                    super(t);
                    let {
                        name: e,
                        motionValue: i,
                        element: n,
                        keyframes: r
                    } = this.options;
                    this.resolver = new D.s(r, (t, e) => this.onKeyframesResolved(t, e), e, i, n), this.resolver.scheduleResolve()
                }
                initPlayback(t, e) {
                    var i, n;
                    let {
                        duration: r = 300,
                        times: s,
                        ease: o,
                        type: a,
                        motionValue: l,
                        name: u,
                        startTime: h
                    } = this.options;
                    if (!(null === (i = l.owner) || void 0 === i ? void 0 : i.current)) return !1;
                    if ("string" == typeof o && ts() && o in th && (o = th[o]), n = this.options, (0, V.x)(n.type) || "spring" === n.type || ! function t(e) {
                            return !!("function" == typeof e && ts() || !e || "string" == typeof e && (e in ta || ts()) || I(e) || Array.isArray(e) && e.every(t))
                        }(n.ease)) {
                        let {
                            onComplete: e,
                            onUpdate: i,
                            motionValue: n,
                            element: l,
                            ...u
                        } = this.options, h = function(t, e) {
                            let i = new tt({ ...e,
                                    keyframes: t,
                                    repeat: 0,
                                    delay: 0,
                                    isGenerator: !0
                                }),
                                n = {
                                    done: !1,
                                    value: t[0]
                                },
                                r = [],
                                s = 0;
                            for (; !n.done && s < 2e4;) r.push((n = i.sample(s)).value), s += 10;
                            return {
                                times: void 0,
                                keyframes: r,
                                duration: s - 10,
                                ease: "linear"
                            }
                        }(t, u);
                        1 === (t = h.keyframes).length && (t[1] = t[0]), r = h.duration, s = h.times, o = h.ease, a = "keyframes"
                    }
                    let c = function(t, e, i, {
                        delay: n = 0,
                        duration: r = 300,
                        repeat: s = 0,
                        repeatType: o = "loop",
                        ease: a = "easeInOut",
                        times: l
                    } = {}) {
                        let u = {
                            [e]: i
                        };
                        l && (u.offset = l);
                        let h = function t(e, i) {
                            if (e) return "function" == typeof e && ts() ? (0, ti.w)(e, i) : I(e) ? to(e) : Array.isArray(e) ? e.map(e => t(e, i) || ta.easeOut) : ta[e]
                        }(a, r);
                        return Array.isArray(h) && (u.easing = h), t.animate(u, {
                            delay: n,
                            duration: r,
                            easing: Array.isArray(h) ? "linear" : h,
                            fill: "both",
                            iterations: s + 1,
                            direction: "reverse" === o ? "alternate" : "normal"
                        })
                    }(l.owner.current, u, t, { ...this.options,
                        duration: r,
                        times: s,
                        ease: o
                    });
                    return c.startTime = null != h ? h : this.calcStartTime(), this.pendingTimeline ? (tl(c, this.pendingTimeline), this.pendingTimeline = void 0) : c.onfinish = () => {
                        let {
                            onComplete: i
                        } = this.options;
                        l.set(f(t, this.options, e)), i && i(), this.cancel(), this.resolveFinishedPromise()
                    }, {
                        animation: c,
                        duration: r,
                        times: s,
                        type: a,
                        ease: o,
                        keyframes: t
                    }
                }
                get duration() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    let {
                        duration: e
                    } = t;
                    return (0, n.X)(e)
                }
                get time() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    let {
                        animation: e
                    } = t;
                    return (0, n.X)(e.currentTime || 0)
                }
                set time(t) {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return;
                    let {
                        animation: i
                    } = e;
                    i.currentTime = (0, n.w)(t)
                }
                get speed() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 1;
                    let {
                        animation: e
                    } = t;
                    return e.playbackRate
                }
                set speed(t) {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return;
                    let {
                        animation: i
                    } = e;
                    i.playbackRate = t
                }
                get state() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return "idle";
                    let {
                        animation: e
                    } = t;
                    return e.playState
                }
                get startTime() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return null;
                    let {
                        animation: e
                    } = t;
                    return e.startTime
                }
                attachTimeline(t) {
                    if (this._resolved) {
                        let {
                            resolved: e
                        } = this;
                        if (!e) return v.Z;
                        let {
                            animation: i
                        } = e;
                        tl(i, t)
                    } else this.pendingTimeline = t;
                    return v.Z
                }
                play() {
                    if (this.isStopped) return;
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e
                    } = t;
                    "finished" === e.playState && this.updateFinishedPromise(), e.play()
                }
                pause() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e
                    } = t;
                    e.pause()
                }
                stop() {
                    if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                    this.resolveFinishedPromise(), this.updateFinishedPromise();
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e,
                        keyframes: i,
                        duration: r,
                        type: s,
                        ease: o,
                        times: a
                    } = t;
                    if ("idle" === e.playState || "finished" === e.playState) return;
                    if (this.time) {
                        let {
                            motionValue: t,
                            onUpdate: e,
                            onComplete: l,
                            element: u,
                            ...h
                        } = this.options, c = new tt({ ...h,
                            keyframes: i,
                            duration: r,
                            type: s,
                            ease: o,
                            times: a,
                            isGenerator: !0
                        }), d = (0, n.w)(this.time);
                        t.setWithVelocity(c.sample(d - 10).value, c.sample(d).value, 10)
                    }
                    let {
                        onStop: l
                    } = this.options;
                    l && l(), this.cancel()
                }
                complete() {
                    let {
                        resolved: t
                    } = this;
                    t && t.animation.finish()
                }
                cancel() {
                    let {
                        resolved: t
                    } = this;
                    t && t.animation.cancel()
                }
                static supports(t) {
                    let {
                        motionValue: e,
                        name: i,
                        repeatDelay: n,
                        repeatType: r,
                        damping: s,
                        type: o
                    } = t;
                    return tu() && i && te.has(i) && e && e.owner && e.owner.current instanceof HTMLElement && !e.owner.getProps().onUpdate && !n && "mirror" !== r && 0 !== s && "inertia" !== o
                }
            }
            var td = i(55946);
            let tp = (t, e, i, r = {}, s, o) => a => {
                let l = (0, h.e)(r, t) || {},
                    p = l.delay || r.delay || 0,
                    {
                        elapsed: v = 0
                    } = r;
                v -= (0, n.w)(p);
                let g = {
                    keyframes: Array.isArray(i) ? i : [null, i],
                    ease: "easeOut",
                    velocity: e.getVelocity(),
                    ...l,
                    delay: -v,
                    onUpdate: t => {
                        e.set(t), l.onUpdate && l.onUpdate(t)
                    },
                    onComplete: () => {
                        a(), l.onComplete && l.onComplete()
                    },
                    name: t,
                    motionValue: e,
                    element: o ? void 0 : s
                };
                ! function({
                    when: t,
                    delay: e,
                    delayChildren: i,
                    staggerChildren: n,
                    staggerDirection: r,
                    repeat: s,
                    repeatType: o,
                    repeatDelay: a,
                    from: l,
                    elapsed: u,
                    ...h
                }) {
                    return !!Object.keys(h).length
                }(l) && (g = { ...g,
                    ...u(t, g)
                }), g.duration && (g.duration = (0, n.w)(g.duration)), g.repeatDelay && (g.repeatDelay = (0, n.w)(g.repeatDelay)), void 0 !== g.from && (g.keyframes[0] = g.from);
                let y = !1;
                if (!1 !== g.type && (0 !== g.duration || g.repeatDelay) || (g.duration = 0, 0 !== g.delay || (y = !0)), (d.current || c.c.skipAnimations) && (y = !0, g.duration = 0, g.delay = 0), y && !o && void 0 !== e.get()) {
                    let t = f(g.keyframes, l);
                    if (void 0 !== t) return m.Wi.update(() => {
                        g.onUpdate(t), g.onComplete()
                    }), new td.s([])
                }
                return !o && tc.supports(g) ? new tc(g) : new tt(g)
            }
        },
        28500: function(t, e, i) {
            i.d(e, {
                w: function() {
                    return h
                }
            });
            var n = i(8834),
                r = i(60689),
                s = i(48771),
                o = i(2259),
                a = i(34005),
                l = i(1327),
                u = i(45414);

            function h(t, e, {
                delay: i = 0,
                transitionOverride: h,
                type: c
            } = {}) {
                var d;
                let {
                    transition: p = t.getDefaultTransition(),
                    transitionEnd: f,
                    ...m
                } = e;
                h && (p = h);
                let v = [],
                    g = c && t.animationState && t.animationState.getState()[c];
                for (let e in m) {
                    let s = t.getValue(e, null !== (d = t.latestValues[e]) && void 0 !== d ? d : null),
                        h = m[e];
                    if (void 0 === h || g && function({
                            protectedKeys: t,
                            needsAnimating: e
                        }, i) {
                            let n = t.hasOwnProperty(i) && !0 !== e[i];
                            return e[i] = !1, n
                        }(g, e)) continue;
                    let c = {
                            delay: i,
                            ...(0, o.e)(p || {}, e)
                        },
                        f = !1;
                    if (window.MotionHandoffAnimation) {
                        let i = (0, a.s)(t);
                        if (i) {
                            let t = window.MotionHandoffAnimation(i, e, u.Wi);
                            null !== t && (c.startTime = t, f = !0)
                        }
                    }(0, l.K)(t, e), s.start((0, r.v)(e, s, h, t.shouldReduceMotion && n.G.has(e) ? {
                        type: !1
                    } : c, t, f));
                    let y = s.animation;
                    y && v.push(y)
                }
                return f && Promise.all(v).then(() => {
                    u.Wi.update(() => {
                        f && (0, s.C)(t, f)
                    })
                }), v
            }
        },
        63466: function(t, e, i) {
            i.d(e, {
                d: function() {
                    return a
                }
            });
            var n = i(67043),
                r = i(28500);

            function s(t, e, i = {}) {
                var a;
                let l = (0, n.x)(t, e, "exit" === i.type ? null === (a = t.presenceContext) || void 0 === a ? void 0 : a.custom : void 0),
                    {
                        transition: u = t.getDefaultTransition() || {}
                    } = l || {};
                i.transitionOverride && (u = i.transitionOverride);
                let h = l ? () => Promise.all((0, r.w)(t, l, i)) : () => Promise.resolve(),
                    c = t.variantChildren && t.variantChildren.size ? (n = 0) => {
                        let {
                            delayChildren: r = 0,
                            staggerChildren: a,
                            staggerDirection: l
                        } = u;
                        return function(t, e, i = 0, n = 0, r = 1, a) {
                            let l = [],
                                u = (t.variantChildren.size - 1) * n,
                                h = 1 === r ? (t = 0) => t * n : (t = 0) => u - t * n;
                            return Array.from(t.variantChildren).sort(o).forEach((t, n) => {
                                t.notify("AnimationStart", e), l.push(s(t, e, { ...a,
                                    delay: i + h(n)
                                }).then(() => t.notify("AnimationComplete", e)))
                            }), Promise.all(l)
                        }(t, e, r + n, a, l, i)
                    } : () => Promise.resolve(),
                    {
                        when: d
                    } = u;
                if (!d) return Promise.all([h(), c(i.delay)]); {
                    let [t, e] = "beforeChildren" === d ? [h, c] : [c, h];
                    return t().then(() => e())
                }
            }

            function o(t, e) {
                return t.sortNodePosition(e)
            }

            function a(t, e, i = {}) {
                let o;
                if (t.notify("AnimationStart", e), Array.isArray(e)) o = Promise.all(e.map(e => s(t, e, i)));
                else if ("string" == typeof e) o = s(t, e, i);
                else {
                    let s = "function" == typeof e ? (0, n.x)(t, e, i.custom) : e;
                    o = Promise.all((0, r.w)(t, s, i))
                }
                return o.then(() => {
                    t.notify("AnimationComplete", e)
                })
            }
        },
        61750: function(t, e, i) {
            i.d(e, {
                M: function() {
                    return n
                }
            });
            let n = "data-" + (0, i(17444).D)("framerAppearId")
        },
        34005: function(t, e, i) {
            i.d(e, {
                s: function() {
                    return r
                }
            });
            var n = i(61750);

            function r(t) {
                return t.props[n.M]
            }
        },
        2259: function(t, e, i) {
            i.d(e, {
                e: function() {
                    return n
                }
            });

            function n(t, e) {
                return t ? t[e] || t.default || t : void 0
            }
        },
        20569: function(t, e, i) {
            i.d(e, {
                H: function() {
                    return n
                }
            });

            function n(t) {
                return null !== t && "object" == typeof t && "function" == typeof t.start
            }
        },
        44944: function(t, e, i) {
            i.d(e, {
                C: function() {
                    return n
                }
            });
            let n = t => Array.isArray(t)
        },
        58881: function(t, e, i) {
            i.d(e, {
                p: function() {
                    return n
                }
            });
            let n = (0, i(2265).createContext)({})
        },
        45750: function(t, e, i) {
            i.d(e, {
                _: function() {
                    return n
                }
            });
            let n = (0, i(2265).createContext)({
                transformPagePoint: t => t,
                isStatic: !1,
                reducedMotion: "never"
            })
        },
        64252: function(t, e, i) {
            i.d(e, {
                O: function() {
                    return n
                }
            });
            let n = (0, i(2265).createContext)(null)
        },
        26378: function(t, e, i) {
            i.d(e, {
                Bn: function() {
                    return o
                },
                X7: function() {
                    return a
                },
                Z7: function() {
                    return s
                }
            });
            var n = i(87457),
                r = i(63627);
            let s = t => 1 - Math.sin(Math.acos(t)),
                o = (0, r.M)(s),
                a = (0, n.o)(s)
        },
        87457: function(t, e, i) {
            i.d(e, {
                o: function() {
                    return n
                }
            });
            let n = t => e => e <= .5 ? t(2 * e) / 2 : (2 - t(2 * (1 - e))) / 2
        },
        63627: function(t, e, i) {
            i.d(e, {
                M: function() {
                    return n
                }
            });
            let n = t => e => 1 - t(1 - e)
        },
        81477: function(t, e, i) {
            i.d(e, {
                N: function() {
                    return n
                }
            });
            let n = t => Array.isArray(t) && "number" != typeof t[0]
        },
        85005: function(t, e, i) {
            i.d(e, {
                Z: function() {
                    return s
                }
            });
            var n = i(24118);
            let r = ["read", "resolveKeyframes", "update", "preRender", "render", "postRender"];

            function s(t, e) {
                let i = !1,
                    s = !0,
                    o = {
                        delta: 0,
                        timestamp: 0,
                        isProcessing: !1
                    },
                    a = () => i = !0,
                    l = r.reduce((t, e) => (t[e] = function(t) {
                        let e = new Set,
                            i = new Set,
                            n = !1,
                            r = !1,
                            s = new WeakSet,
                            o = {
                                delta: 0,
                                timestamp: 0,
                                isProcessing: !1
                            };

                        function a(e) {
                            s.has(e) && (l.schedule(e), t()), e(o)
                        }
                        let l = {
                            schedule: (t, r = !1, o = !1) => {
                                let a = o && n ? e : i;
                                return r && s.add(t), a.has(t) || a.add(t), t
                            },
                            cancel: t => {
                                i.delete(t), s.delete(t)
                            },
                            process: t => {
                                if (o = t, n) {
                                    r = !0;
                                    return
                                }
                                n = !0, [e, i] = [i, e], i.clear(), e.forEach(a), n = !1, r && (r = !1, l.process(t))
                            }
                        };
                        return l
                    }(a), t), {}),
                    {
                        read: u,
                        resolveKeyframes: h,
                        update: c,
                        preRender: d,
                        render: p,
                        postRender: f
                    } = l,
                    m = () => {
                        let r = n.c.useManualTiming ? o.timestamp : performance.now();
                        i = !1, o.delta = s ? 1e3 / 60 : Math.max(Math.min(r - o.timestamp, 40), 1), o.timestamp = r, o.isProcessing = !0, u.process(o), h.process(o), c.process(o), d.process(o), p.process(o), f.process(o), o.isProcessing = !1, i && e && (s = !1, t(m))
                    },
                    v = () => {
                        i = !0, s = !0, o.isProcessing || t(m)
                    };
                return {
                    schedule: r.reduce((t, e) => {
                        let n = l[e];
                        return t[e] = (t, e = !1, r = !1) => (i || v(), n.schedule(t, e, r)), t
                    }, {}),
                    cancel: t => {
                        for (let e = 0; e < r.length; e++) l[r[e]].cancel(t)
                    },
                    state: o,
                    steps: l
                }
            }
        },
        45414: function(t, e, i) {
            i.d(e, {
                Pn: function() {
                    return s
                },
                Wi: function() {
                    return r
                },
                frameData: function() {
                    return o
                },
                yL: function() {
                    return a
                }
            });
            var n = i(56277);
            let {
                schedule: r,
                cancel: s,
                state: o,
                steps: a
            } = (0, i(85005).Z)("undefined" != typeof requestAnimationFrame ? requestAnimationFrame : n.Z, !0)
        },
        40504: function(t, e, i) {
            let n;
            i.d(e, {
                X: function() {
                    return a
                }
            });
            var r = i(24118),
                s = i(45414);

            function o() {
                n = void 0
            }
            let a = {
                now: () => (void 0 === n && a.set(s.frameData.isProcessing || r.c.useManualTiming ? s.frameData.timestamp : performance.now()), n),
                set: t => {
                    n = t, queueMicrotask(o)
                }
            }
        },
        35938: function(t, e, i) {
            i.d(e, {
                featureDefinitions: function() {
                    return r
                }
            });
            let n = {
                    animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
                    exit: ["exit"],
                    drag: ["drag", "dragControls"],
                    focus: ["whileFocus"],
                    hover: ["whileHover", "onHoverStart", "onHoverEnd"],
                    tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
                    pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
                    inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
                    layout: ["layout", "layoutId"]
                },
                r = {};
            for (let t in n) r[t] = {
                isEnabled: e => n[t].some(t => !!e[t])
            }
        },
        77556: function(t, e, i) {
            i.d(e, {
                j: function() {
                    return s
                }
            });
            var n = i(98639),
                r = i(8834);

            function s(t, {
                layout: e,
                layoutId: i
            }) {
                return r.G.has(t) || t.startsWith("origin") || (e || void 0 !== i) && (!!n.P[t] || "opacity" === t)
            }
        },
        82063: function(t, e, i) {
            function n({
                top: t,
                left: e,
                right: i,
                bottom: n
            }) {
                return {
                    x: {
                        min: e,
                        max: i
                    },
                    y: {
                        min: t,
                        max: n
                    }
                }
            }

            function r({
                x: t,
                y: e
            }) {
                return {
                    top: e.min,
                    right: t.max,
                    bottom: e.max,
                    left: t.min
                }
            }

            function s(t, e) {
                if (!e) return t;
                let i = e({
                        x: t.left,
                        y: t.top
                    }),
                    n = e({
                        x: t.right,
                        y: t.bottom
                    });
                return {
                    top: i.y,
                    left: i.x,
                    bottom: n.y,
                    right: n.x
                }
            }
            i.d(e, {
                d7: function() {
                    return s
                },
                i8: function() {
                    return n
                },
                z2: function() {
                    return r
                }
            })
        },
        47227: function(t, e, i) {
            i.d(e, {
                D2: function() {
                    return d
                },
                YY: function() {
                    return u
                },
                am: function() {
                    return h
                },
                o2: function() {
                    return l
                },
                q2: function() {
                    return s
                }
            });
            var n = i(96781),
                r = i(12787);

            function s(t, e, i) {
                return i + e * (t - i)
            }

            function o(t, e, i, n, r) {
                return void 0 !== r && (t = n + r * (t - n)), n + i * (t - n) + e
            }

            function a(t, e = 0, i = 1, n, r) {
                t.min = o(t.min, e, i, n, r), t.max = o(t.max, e, i, n, r)
            }

            function l(t, {
                x: e,
                y: i
            }) {
                a(t.x, e.translate, e.scale, e.originPoint), a(t.y, i.translate, i.scale, i.originPoint)
            }

            function u(t, e, i, n = !1) {
                let s, o;
                let a = i.length;
                if (a) {
                    e.x = e.y = 1;
                    for (let u = 0; u < a; u++) {
                        o = (s = i[u]).projectionDelta;
                        let {
                            visualElement: a
                        } = s.options;
                        (!a || !a.props.style || "contents" !== a.props.style.display) && (n && s.options.layoutScroll && s.scroll && s !== s.root && d(t, {
                            x: -s.scroll.offset.x,
                            y: -s.scroll.offset.y
                        }), o && (e.x *= o.x.scale, e.y *= o.y.scale, l(t, o)), n && (0, r.ud)(s.latestValues) && d(t, s.latestValues))
                    }
                    e.x < 1.0000000000001 && e.x > .999999999999 && (e.x = 1), e.y < 1.0000000000001 && e.y > .999999999999 && (e.y = 1)
                }
            }

            function h(t, e) {
                t.min = t.min + e, t.max = t.max + e
            }

            function c(t, e, i, r, s = .5) {
                let o = (0, n.t)(t.min, t.max, s);
                a(t, e, i, o, r)
            }

            function d(t, e) {
                c(t.x, e.x, e.scaleX, e.scale, e.originX), c(t.y, e.y, e.scaleY, e.scale, e.originY)
            }
        },
        96674: function(t, e, i) {
            i.d(e, {
                dO: function() {
                    return o
                },
                wc: function() {
                    return r
                }
            });
            let n = () => ({
                    translate: 0,
                    scale: 1,
                    origin: 0,
                    originPoint: 0
                }),
                r = () => ({
                    x: n(),
                    y: n()
                }),
                s = () => ({
                    min: 0,
                    max: 0
                }),
                o = () => ({
                    x: s(),
                    y: s()
                })
        },
        98639: function(t, e, i) {
            i.d(e, {
                B: function() {
                    return r
                },
                P: function() {
                    return n
                }
            });
            let n = {};

            function r(t) {
                Object.assign(n, t)
            }
        },
        12787: function(t, e, i) {
            function n(t) {
                return void 0 === t || 1 === t
            }

            function r({
                scale: t,
                scaleX: e,
                scaleY: i
            }) {
                return !n(t) || !n(e) || !n(i)
            }

            function s(t) {
                return r(t) || o(t) || t.z || t.rotate || t.rotateX || t.rotateY || t.skewX || t.skewY
            }

            function o(t) {
                var e, i;
                return (e = t.x) && "0%" !== e || (i = t.y) && "0%" !== i
            }
            i.d(e, {
                D_: function() {
                    return o
                },
                Lj: function() {
                    return r
                },
                ud: function() {
                    return s
                }
            })
        },
        50813: function(t, e, i) {
            i.d(e, {
                J: function() {
                    return s
                },
                z: function() {
                    return o
                }
            });
            var n = i(82063),
                r = i(47227);

            function s(t, e) {
                return (0, n.i8)((0, n.d7)(t.getBoundingClientRect(), e))
            }

            function o(t, e, i) {
                let n = s(t, i),
                    {
                        scroll: o
                    } = e;
                return o && ((0, r.am)(n.x, o.offset.x), (0, r.am)(n.y, o.offset.y)), n
            }
        },
        84426: function(t, e, i) {
            i.d(e, {
                l: function() {
                    return M
                }
            });
            var n = i(44563);
            let r = {
                    current: null
                },
                s = {
                    current: !1
                };
            var o = i(34081),
                a = i(3078),
                l = i(23999),
                u = i(8834),
                h = i(17743),
                c = i(31297),
                d = i(35938),
                p = i(37003),
                f = i(39545),
                m = i(4946),
                v = i(13697),
                g = i(33964),
                y = i(83206),
                x = i(38580),
                w = i(55113);
            let P = [...x.$, g.$, y.P],
                T = t => P.find((0, w.l)(t));
            var b = i(25861),
                S = i(96674),
                A = i(40504),
                D = i(45414);
            let V = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"];
            class M {
                scrapeMotionValuesFromProps(t, e, i) {
                    return {}
                }
                constructor({
                    parent: t,
                    props: e,
                    presenceContext: i,
                    reducedMotionConfig: n,
                    blockInitialAnimation: r,
                    visualState: s
                }, o = {}) {
                    this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = new Map, this.KeyframeResolver = f.e, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
                        this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
                    }, this.renderScheduledAt = 0, this.scheduleRender = () => {
                        let t = A.X.now();
                        this.renderScheduledAt < t && (this.renderScheduledAt = t, D.Wi.render(this.render, !1, !0))
                    };
                    let {
                        latestValues: a,
                        renderState: u
                    } = s;
                    this.latestValues = a, this.baseTarget = { ...a
                    }, this.initialValues = e.initial ? { ...a
                    } : {}, this.renderState = u, this.parent = t, this.props = e, this.presenceContext = i, this.depth = t ? t.depth + 1 : 0, this.reducedMotionConfig = n, this.options = o, this.blockInitialAnimation = !!r, this.isControllingVariants = (0, h.G)(e), this.isVariantNode = (0, h.M)(e), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = !!(t && t.current);
                    let {
                        willChange: c,
                        ...d
                    } = this.scrapeMotionValuesFromProps(e, {}, this);
                    for (let t in d) {
                        let e = d[t];
                        void 0 !== a[t] && (0, l.i)(e) && e.set(a[t], !1)
                    }
                }
                mount(t) {
                    this.current = t, p.R.set(t, this), this.projection && !this.projection.instance && this.projection.mount(t), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((t, e) => this.bindToMotionValue(e, t)), s.current || function() {
                        if (s.current = !0, n.j) {
                            if (window.matchMedia) {
                                let t = window.matchMedia("(prefers-reduced-motion)"),
                                    e = () => r.current = t.matches;
                                t.addListener(e), e()
                            } else r.current = !1
                        }
                    }(), this.shouldReduceMotion = "never" !== this.reducedMotionConfig && ("always" === this.reducedMotionConfig || r.current), this.parent && this.parent.children.add(this), this.update(this.props, this.presenceContext)
                }
                unmount() {
                    for (let t in p.R.delete(this.current), this.projection && this.projection.unmount(), (0, D.Pn)(this.notifyUpdate), (0, D.Pn)(this.render), this.valueSubscriptions.forEach(t => t()), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent && this.parent.children.delete(this), this.events) this.events[t].clear();
                    for (let t in this.features) {
                        let e = this.features[t];
                        e && (e.unmount(), e.isMounted = !1)
                    }
                    this.current = null
                }
                bindToMotionValue(t, e) {
                    let i;
                    this.valueSubscriptions.has(t) && this.valueSubscriptions.get(t)();
                    let n = u.G.has(t),
                        r = e.on("change", e => {
                            this.latestValues[t] = e, this.props.onUpdate && D.Wi.preRender(this.notifyUpdate), n && this.projection && (this.projection.isTransformDirty = !0)
                        }),
                        s = e.on("renderRequest", this.scheduleRender);
                    window.MotionCheckAppearSync && (i = window.MotionCheckAppearSync(this, t, e)), this.valueSubscriptions.set(t, () => {
                        r(), s(), i && i(), e.owner && e.stop()
                    })
                }
                sortNodePosition(t) {
                    return this.current && this.sortInstanceNodePosition && this.type === t.type ? this.sortInstanceNodePosition(this.current, t.current) : 0
                }
                updateFeatures() {
                    let t = "animation";
                    for (t in d.featureDefinitions) {
                        let e = d.featureDefinitions[t];
                        if (!e) continue;
                        let {
                            isEnabled: i,
                            Feature: n
                        } = e;
                        if (!this.features[t] && n && i(this.props) && (this.features[t] = new n(this)), this.features[t]) {
                            let e = this.features[t];
                            e.isMounted ? e.update() : (e.mount(), e.isMounted = !0)
                        }
                    }
                }
                triggerBuild() {
                    this.build(this.renderState, this.latestValues, this.props)
                }
                measureViewportBox() {
                    return this.current ? this.measureInstanceViewportBox(this.current, this.props) : (0, S.dO)()
                }
                getStaticValue(t) {
                    return this.latestValues[t]
                }
                setStaticValue(t, e) {
                    this.latestValues[t] = e
                }
                update(t, e) {
                    (t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = t, this.prevPresenceContext = this.presenceContext, this.presenceContext = e;
                    for (let e = 0; e < V.length; e++) {
                        let i = V[e];
                        this.propEventSubscriptions[i] && (this.propEventSubscriptions[i](), delete this.propEventSubscriptions[i]);
                        let n = t["on" + i];
                        n && (this.propEventSubscriptions[i] = this.on(i, n))
                    }
                    this.prevMotionValues = function(t, e, i) {
                        for (let n in e) {
                            let r = e[n],
                                s = i[n];
                            if ((0, l.i)(r)) t.addValue(n, r);
                            else if ((0, l.i)(s)) t.addValue(n, (0, a.BX)(r, {
                                owner: t
                            }));
                            else if (s !== r) {
                                if (t.hasValue(n)) {
                                    let e = t.getValue(n);
                                    !0 === e.liveStyle ? e.jump(r) : e.hasAnimated || e.set(r)
                                } else {
                                    let e = t.getStaticValue(n);
                                    t.addValue(n, (0, a.BX)(void 0 !== e ? e : r, {
                                        owner: t
                                    }))
                                }
                            }
                        }
                        for (let n in i) void 0 === e[n] && t.removeValue(n);
                        return e
                    }(this, this.scrapeMotionValuesFromProps(t, this.prevProps, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue()
                }
                getProps() {
                    return this.props
                }
                getVariant(t) {
                    return this.props.variants ? this.props.variants[t] : void 0
                }
                getDefaultTransition() {
                    return this.props.transition
                }
                getTransformPagePoint() {
                    return this.props.transformPagePoint
                }
                getClosestVariantNode() {
                    return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
                }
                addVariantChild(t) {
                    let e = this.getClosestVariantNode();
                    if (e) return e.variantChildren && e.variantChildren.add(t), () => e.variantChildren.delete(t)
                }
                addValue(t, e) {
                    let i = this.values.get(t);
                    e !== i && (i && this.removeValue(t), this.bindToMotionValue(t, e), this.values.set(t, e), this.latestValues[t] = e.get())
                }
                removeValue(t) {
                    this.values.delete(t);
                    let e = this.valueSubscriptions.get(t);
                    e && (e(), this.valueSubscriptions.delete(t)), delete this.latestValues[t], this.removeValueFromRenderState(t, this.renderState)
                }
                hasValue(t) {
                    return this.values.has(t)
                }
                getValue(t, e) {
                    if (this.props.values && this.props.values[t]) return this.props.values[t];
                    let i = this.values.get(t);
                    return void 0 === i && void 0 !== e && (i = (0, a.BX)(null === e ? void 0 : e, {
                        owner: this
                    }), this.addValue(t, i)), i
                }
                readValue(t, e) {
                    var i;
                    let n = void 0 === this.latestValues[t] && this.current ? null !== (i = this.getBaseTargetFromProps(this.props, t)) && void 0 !== i ? i : this.readValueFromInstance(this.current, t, this.options) : this.latestValues[t];
                    return null != n && ("string" == typeof n && ((0, m.P)(n) || (0, v.W)(n)) ? n = parseFloat(n) : !T(n) && y.P.test(e) && (n = (0, b.T)(t, e)), this.setBaseTarget(t, (0, l.i)(n) ? n.get() : n)), (0, l.i)(n) ? n.get() : n
                }
                setBaseTarget(t, e) {
                    this.baseTarget[t] = e
                }
                getBaseTarget(t) {
                    var e;
                    let i;
                    let {
                        initial: n
                    } = this.props;
                    if ("string" == typeof n || "object" == typeof n) {
                        let r = (0, c.o)(this.props, n, null === (e = this.presenceContext) || void 0 === e ? void 0 : e.custom);
                        r && (i = r[t])
                    }
                    if (n && void 0 !== i) return i;
                    let r = this.getBaseTargetFromProps(this.props, t);
                    return void 0 === r || (0, l.i)(r) ? void 0 !== this.initialValues[t] && void 0 === i ? void 0 : this.baseTarget[t] : r
                }
                on(t, e) {
                    return this.events[t] || (this.events[t] = new o.L), this.events[t].add(e)
                }
                notify(t, ...e) {
                    this.events[t] && this.events[t].notify(...e)
                }
            }
        },
        82174: function(t, e, i) {
            i.d(e, {
                E: function() {
                    return ip
                }
            });
            var n, r, s, o = i(20569),
                a = i(44944);

            function l(t, e) {
                if (!Array.isArray(e)) return !1;
                let i = e.length;
                if (i !== t.length) return !1;
                for (let n = 0; n < i; n++)
                    if (e[n] !== t[n]) return !1;
                return !0
            }
            var u = i(74115),
                h = i(67043),
                c = i(72589),
                d = i(63466);
            let p = c.V.length,
                f = [...c.e].reverse(),
                m = c.e.length;

            function v(t = !1) {
                return {
                    isActive: t,
                    protectedKeys: {},
                    needsAnimating: {},
                    prevResolvedValues: {}
                }
            }

            function g() {
                return {
                    animate: v(!0),
                    whileInView: v(),
                    whileHover: v(),
                    whileTap: v(),
                    whileDrag: v(),
                    whileFocus: v(),
                    exit: v()
                }
            }
            class y {
                constructor(t) {
                    this.isMounted = !1, this.node = t
                }
                update() {}
            }
            class x extends y {
                constructor(t) {
                    super(t), t.animationState || (t.animationState = function(t) {
                        let e = e => Promise.all(e.map(({
                                animation: e,
                                options: i
                            }) => (0, d.d)(t, e, i))),
                            i = g(),
                            n = !0,
                            r = e => (i, n) => {
                                var r;
                                let s = (0, h.x)(t, n, "exit" === e ? null === (r = t.presenceContext) || void 0 === r ? void 0 : r.custom : void 0);
                                if (s) {
                                    let {
                                        transition: t,
                                        transitionEnd: e,
                                        ...n
                                    } = s;
                                    i = { ...i,
                                        ...n,
                                        ...e
                                    }
                                }
                                return i
                            };

                        function s(s) {
                            let {
                                props: h
                            } = t, d = function t(e) {
                                if (!e) return;
                                if (!e.isControllingVariants) {
                                    let i = e.parent && t(e.parent) || {};
                                    return void 0 !== e.props.initial && (i.initial = e.props.initial), i
                                }
                                let i = {};
                                for (let t = 0; t < p; t++) {
                                    let n = c.V[t],
                                        r = e.props[n];
                                    ((0, u.$)(r) || !1 === r) && (i[n] = r)
                                }
                                return i
                            }(t.parent) || {}, v = [], g = new Set, y = {}, x = 1 / 0;
                            for (let e = 0; e < m; e++) {
                                var w;
                                let c = f[e],
                                    p = i[c],
                                    m = void 0 !== h[c] ? h[c] : d[c],
                                    P = (0, u.$)(m),
                                    T = c === s ? p.isActive : null;
                                !1 === T && (x = e);
                                let b = m === d[c] && m !== h[c] && P;
                                if (b && n && t.manuallyAnimateOnMount && (b = !1), p.protectedKeys = { ...y
                                    }, !p.isActive && null === T || !m && !p.prevProp || (0, o.H)(m) || "boolean" == typeof m) continue;
                                let S = (w = p.prevProp, "string" == typeof m ? m !== w : !!Array.isArray(m) && !l(m, w)),
                                    A = S || c === s && p.isActive && !b && P || e > x && P,
                                    D = !1,
                                    V = Array.isArray(m) ? m : [m],
                                    M = V.reduce(r(c), {});
                                !1 === T && (M = {});
                                let {
                                    prevResolvedValues: E = {}
                                } = p, C = { ...E,
                                    ...M
                                }, R = e => {
                                    A = !0, g.has(e) && (D = !0, g.delete(e)), p.needsAnimating[e] = !0;
                                    let i = t.getValue(e);
                                    i && (i.liveStyle = !1)
                                };
                                for (let t in C) {
                                    let e = M[t],
                                        i = E[t];
                                    if (!y.hasOwnProperty(t))((0, a.C)(e) && (0, a.C)(i) ? l(e, i) : e === i) ? void 0 !== e && g.has(t) ? R(t) : p.protectedKeys[t] = !0 : null != e ? R(t) : g.add(t)
                                }
                                p.prevProp = m, p.prevResolvedValues = M, p.isActive && (y = { ...y,
                                    ...M
                                }), n && t.blockInitialAnimation && (A = !1);
                                let k = !(b && S) || D;
                                A && k && v.push(...V.map(t => ({
                                    animation: t,
                                    options: {
                                        type: c
                                    }
                                })))
                            }
                            if (g.size) {
                                let e = {};
                                g.forEach(i => {
                                    let n = t.getBaseTarget(i),
                                        r = t.getValue(i);
                                    r && (r.liveStyle = !0), e[i] = null != n ? n : null
                                }), v.push({
                                    animation: e
                                })
                            }
                            let P = !!v.length;
                            return n && (!1 === h.initial || h.initial === h.animate) && !t.manuallyAnimateOnMount && (P = !1), n = !1, P ? e(v) : Promise.resolve()
                        }
                        return {
                            animateChanges: s,
                            setActive: function(e, n) {
                                var r;
                                if (i[e].isActive === n) return Promise.resolve();
                                null === (r = t.variantChildren) || void 0 === r || r.forEach(t => {
                                    var i;
                                    return null === (i = t.animationState) || void 0 === i ? void 0 : i.setActive(e, n)
                                }), i[e].isActive = n;
                                let o = s(e);
                                for (let t in i) i[t].protectedKeys = {};
                                return o
                            },
                            setAnimateFunction: function(i) {
                                e = i(t)
                            },
                            getState: () => i,
                            reset: () => {
                                i = g(), n = !0
                            }
                        }
                    }(t))
                }
                updateAnimationControlsSubscription() {
                    let {
                        animate: t
                    } = this.node.getProps();
                    (0, o.H)(t) && (this.unmountControls = t.subscribe(this.node))
                }
                mount() {
                    this.updateAnimationControlsSubscription()
                }
                update() {
                    let {
                        animate: t
                    } = this.node.getProps(), {
                        animate: e
                    } = this.node.prevProps || {};
                    t !== e && this.updateAnimationControlsSubscription()
                }
                unmount() {
                    var t;
                    this.node.animationState.reset(), null === (t = this.unmountControls) || void 0 === t || t.call(this)
                }
            }
            let w = 0;
            class P extends y {
                constructor() {
                    super(...arguments), this.id = w++
                }
                update() {
                    if (!this.node.presenceContext) return;
                    let {
                        isPresent: t,
                        onExitComplete: e
                    } = this.node.presenceContext, {
                        isPresent: i
                    } = this.node.prevPresenceContext || {};
                    if (!this.node.animationState || t === i) return;
                    let n = this.node.animationState.setActive("exit", !t);
                    e && !t && n.then(() => e(this.id))
                }
                mount() {
                    let {
                        register: t
                    } = this.node.presenceContext || {};
                    t && (this.unmount = t(this.id))
                }
                unmount() {}
            }
            var T = i(56277),
                b = i(98751),
                S = i(41904);

            function A(t) {
                return {
                    point: {
                        x: t.pageX,
                        y: t.pageY
                    }
                }
            }
            let D = t => e => (0, S.DJ)(e) && t(e, A(e));
            var V = i(56717);

            function M(t, e, i, n = {
                passive: !0
            }) {
                return t.addEventListener(e, i, n), () => t.removeEventListener(e, i)
            }

            function E(t, e, i, n) {
                return M(t, e, D(i), n)
            }
            var C = i(56920);
            let R = (t, e) => Math.abs(t - e);
            var k = i(45414);
            class j {
                constructor(t, e, {
                    transformPagePoint: i,
                    contextWindow: n,
                    dragSnapToOrigin: r = !1
                } = {}) {
                    if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.updatePoint = () => {
                            var t, e;
                            if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let i = B(this.lastMoveEventInfo, this.history),
                                n = null !== this.startEvent,
                                r = (t = i.offset, e = {
                                    x: 0,
                                    y: 0
                                }, Math.sqrt(R(t.x, e.x) ** 2 + R(t.y, e.y) ** 2) >= 3);
                            if (!n && !r) return;
                            let {
                                point: s
                            } = i, {
                                timestamp: o
                            } = k.frameData;
                            this.history.push({ ...s,
                                timestamp: o
                            });
                            let {
                                onStart: a,
                                onMove: l
                            } = this.handlers;
                            n || (a && a(this.lastMoveEvent, i), this.startEvent = this.lastMoveEvent), l && l(this.lastMoveEvent, i)
                        }, this.handlePointerMove = (t, e) => {
                            this.lastMoveEvent = t, this.lastMoveEventInfo = L(e, this.transformPagePoint), k.Wi.update(this.updatePoint, !0)
                        }, this.handlePointerUp = (t, e) => {
                            this.end();
                            let {
                                onEnd: i,
                                onSessionEnd: n,
                                resumeAnimation: r
                            } = this.handlers;
                            if (this.dragSnapToOrigin && r && r(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let s = B("pointercancel" === t.type ? this.lastMoveEventInfo : L(e, this.transformPagePoint), this.history);
                            this.startEvent && i && i(t, s), n && n(t, s)
                        }, !(0, S.DJ)(t)) return;
                    this.dragSnapToOrigin = r, this.handlers = e, this.transformPagePoint = i, this.contextWindow = n || window;
                    let s = L(A(t), this.transformPagePoint),
                        {
                            point: o
                        } = s,
                        {
                            timestamp: a
                        } = k.frameData;
                    this.history = [{ ...o,
                        timestamp: a
                    }];
                    let {
                        onSessionStart: l
                    } = e;
                    l && l(t, B(s, this.history)), this.removeListeners = (0, C.z)(E(this.contextWindow, "pointermove", this.handlePointerMove), E(this.contextWindow, "pointerup", this.handlePointerUp), E(this.contextWindow, "pointercancel", this.handlePointerUp))
                }
                updateHandlers(t) {
                    this.handlers = t
                }
                end() {
                    this.removeListeners && this.removeListeners(), (0, k.Pn)(this.updatePoint)
                }
            }

            function L(t, e) {
                return e ? {
                    point: e(t.point)
                } : t
            }

            function F(t, e) {
                return {
                    x: t.x - e.x,
                    y: t.y - e.y
                }
            }

            function B({
                point: t
            }, e) {
                return {
                    point: t,
                    delta: F(t, O(e)),
                    offset: F(t, e[0]),
                    velocity: function(t, e) {
                        if (t.length < 2) return {
                            x: 0,
                            y: 0
                        };
                        let i = t.length - 1,
                            n = null,
                            r = O(t);
                        for (; i >= 0 && (n = t[i], !(r.timestamp - n.timestamp > (0, V.w)(.1)));) i--;
                        if (!n) return {
                            x: 0,
                            y: 0
                        };
                        let s = (0, V.X)(r.timestamp - n.timestamp);
                        if (0 === s) return {
                            x: 0,
                            y: 0
                        };
                        let o = {
                            x: (r.x - n.x) / s,
                            y: (r.y - n.y) / s
                        };
                        return o.x === 1 / 0 && (o.x = 0), o.y === 1 / 0 && (o.y = 0), o
                    }(e, 0)
                }
            }

            function O(t) {
                return t[t.length - 1]
            }

            function $(t) {
                return t && "object" == typeof t && Object.prototype.hasOwnProperty.call(t, "current")
            }
            var W = i(76376),
                U = i(96781);

            function I(t) {
                return t.max - t.min
            }

            function N(t, e, i, n = .5) {
                t.origin = n, t.originPoint = (0, U.t)(e.min, e.max, t.origin), t.scale = I(i) / I(e), t.translate = (0, U.t)(i.min, i.max, t.origin) - t.originPoint, (t.scale >= .9999 && t.scale <= 1.0001 || isNaN(t.scale)) && (t.scale = 1), (t.translate >= -.01 && t.translate <= .01 || isNaN(t.translate)) && (t.translate = 0)
            }

            function X(t, e, i, n) {
                N(t.x, e.x, i.x, n ? n.originX : void 0), N(t.y, e.y, i.y, n ? n.originY : void 0)
            }

            function Y(t, e, i) {
                t.min = i.min + e.min, t.max = t.min + I(e)
            }

            function z(t, e, i) {
                t.min = e.min - i.min, t.max = t.min + I(e)
            }

            function K(t, e, i) {
                z(t.x, e.x, i.x), z(t.y, e.y, i.y)
            }
            var H = i(59111);

            function Z(t, e, i) {
                return {
                    min: void 0 !== e ? t.min + e : void 0,
                    max: void 0 !== i ? t.max + i - (t.max - t.min) : void 0
                }
            }

            function q(t, e) {
                let i = e.min - t.min,
                    n = e.max - t.max;
                return e.max - e.min < t.max - t.min && ([i, n] = [n, i]), {
                    min: i,
                    max: n
                }
            }

            function G(t, e, i) {
                return {
                    min: _(t, e),
                    max: _(t, i)
                }
            }

            function _(t, e) {
                return "number" == typeof t ? t : t[e] || 0
            }
            var J = i(96674);

            function Q(t) {
                return [t("x"), t("y")]
            }
            var tt = i(50813),
                te = i(82063),
                ti = i(27492),
                tn = i(60689);
            let tr = ({
                current: t
            }) => t ? t.ownerDocument.defaultView : null;
            var ts = i(1327);
            let to = new WeakMap;
            class ta {
                constructor(t) {
                    this.openDragLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
                        x: 0,
                        y: 0
                    }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = (0, J.dO)(), this.visualElement = t
                }
                start(t, {
                    snapToCursor: e = !1
                } = {}) {
                    let {
                        presenceContext: i
                    } = this.visualElement;
                    if (i && !1 === i.isPresent) return;
                    let {
                        dragSnapToOrigin: n
                    } = this.getProps();
                    this.panSession = new j(t, {
                        onSessionStart: t => {
                            let {
                                dragSnapToOrigin: i
                            } = this.getProps();
                            i ? this.pauseAnimation() : this.stopAnimation(), e && this.snapToCursor(A(t).point)
                        },
                        onStart: (t, e) => {
                            let {
                                drag: i,
                                dragPropagation: n,
                                onDragStart: r
                            } = this.getProps();
                            if (i && !n && (this.openDragLock && this.openDragLock(), this.openDragLock = (0, S.KV)(i), !this.openDragLock)) return;
                            this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), Q(t => {
                                let e = this.getAxisMotionValue(t).get() || 0;
                                if (ti.aQ.test(e)) {
                                    let {
                                        projection: i
                                    } = this.visualElement;
                                    if (i && i.layout) {
                                        let n = i.layout.layoutBox[t];
                                        if (n) {
                                            let t = I(n);
                                            e = parseFloat(e) / 100 * t
                                        }
                                    }
                                }
                                this.originPoint[t] = e
                            }), r && k.Wi.postRender(() => r(t, e)), (0, ts.K)(this.visualElement, "transform");
                            let {
                                animationState: s
                            } = this.visualElement;
                            s && s.setActive("whileDrag", !0)
                        },
                        onMove: (t, e) => {
                            let {
                                dragPropagation: i,
                                dragDirectionLock: n,
                                onDirectionLock: r,
                                onDrag: s
                            } = this.getProps();
                            if (!i && !this.openDragLock) return;
                            let {
                                offset: o
                            } = e;
                            if (n && null === this.currentDirection) {
                                this.currentDirection = function(t, e = 10) {
                                    let i = null;
                                    return Math.abs(t.y) > e ? i = "y" : Math.abs(t.x) > e && (i = "x"), i
                                }(o), null !== this.currentDirection && r && r(this.currentDirection);
                                return
                            }
                            this.updateAxis("x", e.point, o), this.updateAxis("y", e.point, o), this.visualElement.render(), s && s(t, e)
                        },
                        onSessionEnd: (t, e) => this.stop(t, e),
                        resumeAnimation: () => Q(t => {
                            var e;
                            return "paused" === this.getAnimationState(t) && (null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.play())
                        })
                    }, {
                        transformPagePoint: this.visualElement.getTransformPagePoint(),
                        dragSnapToOrigin: n,
                        contextWindow: tr(this.visualElement)
                    })
                }
                stop(t, e) {
                    let i = this.isDragging;
                    if (this.cancel(), !i) return;
                    let {
                        velocity: n
                    } = e;
                    this.startAnimation(n);
                    let {
                        onDragEnd: r
                    } = this.getProps();
                    r && k.Wi.postRender(() => r(t, e))
                }
                cancel() {
                    this.isDragging = !1;
                    let {
                        projection: t,
                        animationState: e
                    } = this.visualElement;
                    t && (t.isAnimationBlocked = !1), this.panSession && this.panSession.end(), this.panSession = void 0;
                    let {
                        dragPropagation: i
                    } = this.getProps();
                    !i && this.openDragLock && (this.openDragLock(), this.openDragLock = null), e && e.setActive("whileDrag", !1)
                }
                updateAxis(t, e, i) {
                    let {
                        drag: n
                    } = this.getProps();
                    if (!i || !tl(t, n, this.currentDirection)) return;
                    let r = this.getAxisMotionValue(t),
                        s = this.originPoint[t] + i[t];
                    this.constraints && this.constraints[t] && (s = function(t, {
                        min: e,
                        max: i
                    }, n) {
                        return void 0 !== e && t < e ? t = n ? (0, U.t)(e, t, n.min) : Math.max(t, e) : void 0 !== i && t > i && (t = n ? (0, U.t)(i, t, n.max) : Math.min(t, i)), t
                    }(s, this.constraints[t], this.elastic[t])), r.set(s)
                }
                resolveConstraints() {
                    var t;
                    let {
                        dragConstraints: e,
                        dragElastic: i
                    } = this.getProps(), n = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : null === (t = this.visualElement.projection) || void 0 === t ? void 0 : t.layout, r = this.constraints;
                    e && $(e) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : e && n ? this.constraints = function(t, {
                        top: e,
                        left: i,
                        bottom: n,
                        right: r
                    }) {
                        return {
                            x: Z(t.x, i, r),
                            y: Z(t.y, e, n)
                        }
                    }(n.layoutBox, e) : this.constraints = !1, this.elastic = function(t = .35) {
                        return !1 === t ? t = 0 : !0 === t && (t = .35), {
                            x: G(t, "left", "right"),
                            y: G(t, "top", "bottom")
                        }
                    }(i), r !== this.constraints && n && this.constraints && !this.hasMutatedConstraints && Q(t => {
                        !1 !== this.constraints && this.getAxisMotionValue(t) && (this.constraints[t] = function(t, e) {
                            let i = {};
                            return void 0 !== e.min && (i.min = e.min - t.min), void 0 !== e.max && (i.max = e.max - t.min), i
                        }(n.layoutBox[t], this.constraints[t]))
                    })
                }
                resolveRefConstraints() {
                    var t;
                    let {
                        dragConstraints: e,
                        onMeasureDragConstraints: i
                    } = this.getProps();
                    if (!e || !$(e)) return !1;
                    let n = e.current;
                    (0, b.k)(null !== n, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.");
                    let {
                        projection: r
                    } = this.visualElement;
                    if (!r || !r.layout) return !1;
                    let s = (0, tt.z)(n, r.root, this.visualElement.getTransformPagePoint()),
                        o = {
                            x: q((t = r.layout.layoutBox).x, s.x),
                            y: q(t.y, s.y)
                        };
                    if (i) {
                        let t = i((0, te.z2)(o));
                        this.hasMutatedConstraints = !!t, t && (o = (0, te.i8)(t))
                    }
                    return o
                }
                startAnimation(t) {
                    let {
                        drag: e,
                        dragMomentum: i,
                        dragElastic: n,
                        dragTransition: r,
                        dragSnapToOrigin: s,
                        onDragTransitionEnd: o
                    } = this.getProps(), a = this.constraints || {};
                    return Promise.all(Q(o => {
                        if (!tl(o, e, this.currentDirection)) return;
                        let l = a && a[o] || {};
                        s && (l = {
                            min: 0,
                            max: 0
                        });
                        let u = {
                            type: "inertia",
                            velocity: i ? t[o] : 0,
                            bounceStiffness: n ? 200 : 1e6,
                            bounceDamping: n ? 40 : 1e7,
                            timeConstant: 750,
                            restDelta: 1,
                            restSpeed: 10,
                            ...r,
                            ...l
                        };
                        return this.startAxisValueAnimation(o, u)
                    })).then(o)
                }
                startAxisValueAnimation(t, e) {
                    let i = this.getAxisMotionValue(t);
                    return (0, ts.K)(this.visualElement, t), i.start((0, tn.v)(t, i, 0, e, this.visualElement, !1))
                }
                stopAnimation() {
                    Q(t => this.getAxisMotionValue(t).stop())
                }
                pauseAnimation() {
                    Q(t => {
                        var e;
                        return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.pause()
                    })
                }
                getAnimationState(t) {
                    var e;
                    return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.state
                }
                getAxisMotionValue(t) {
                    let e = `_drag${t.toUpperCase()}`,
                        i = this.visualElement.getProps();
                    return i[e] || this.visualElement.getValue(t, (i.initial ? i.initial[t] : void 0) || 0)
                }
                snapToCursor(t) {
                    Q(e => {
                        let {
                            drag: i
                        } = this.getProps();
                        if (!tl(e, i, this.currentDirection)) return;
                        let {
                            projection: n
                        } = this.visualElement, r = this.getAxisMotionValue(e);
                        if (n && n.layout) {
                            let {
                                min: i,
                                max: s
                            } = n.layout.layoutBox[e];
                            r.set(t[e] - (0, U.t)(i, s, .5))
                        }
                    })
                }
                scalePositionWithinConstraints() {
                    if (!this.visualElement.current) return;
                    let {
                        drag: t,
                        dragConstraints: e
                    } = this.getProps(), {
                        projection: i
                    } = this.visualElement;
                    if (!$(e) || !i || !this.constraints) return;
                    this.stopAnimation();
                    let n = {
                        x: 0,
                        y: 0
                    };
                    Q(t => {
                        let e = this.getAxisMotionValue(t);
                        if (e && !1 !== this.constraints) {
                            let i = e.get();
                            n[t] = function(t, e) {
                                let i = .5,
                                    n = I(t),
                                    r = I(e);
                                return r > n ? i = (0, W.Y)(e.min, e.max - n, t.min) : n > r && (i = (0, W.Y)(t.min, t.max - r, e.min)), (0, H.u)(0, 1, i)
                            }({
                                min: i,
                                max: i
                            }, this.constraints[t])
                        }
                    });
                    let {
                        transformTemplate: r
                    } = this.visualElement.getProps();
                    this.visualElement.current.style.transform = r ? r({}, "") : "none", i.root && i.root.updateScroll(), i.updateLayout(), this.resolveConstraints(), Q(e => {
                        if (!tl(e, t, null)) return;
                        let i = this.getAxisMotionValue(e),
                            {
                                min: r,
                                max: s
                            } = this.constraints[e];
                        i.set((0, U.t)(r, s, n[e]))
                    })
                }
                addListeners() {
                    if (!this.visualElement.current) return;
                    to.set(this.visualElement, this);
                    let t = E(this.visualElement.current, "pointerdown", t => {
                            let {
                                drag: e,
                                dragListener: i = !0
                            } = this.getProps();
                            e && i && this.start(t)
                        }),
                        e = () => {
                            let {
                                dragConstraints: t
                            } = this.getProps();
                            $(t) && t.current && (this.constraints = this.resolveRefConstraints())
                        },
                        {
                            projection: i
                        } = this.visualElement,
                        n = i.addEventListener("measure", e);
                    i && !i.layout && (i.root && i.root.updateScroll(), i.updateLayout()), k.Wi.read(e);
                    let r = M(window, "resize", () => this.scalePositionWithinConstraints()),
                        s = i.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e
                        }) => {
                            this.isDragging && e && (Q(e => {
                                let i = this.getAxisMotionValue(e);
                                i && (this.originPoint[e] += t[e].translate, i.set(i.get() + t[e].translate))
                            }), this.visualElement.render())
                        });
                    return () => {
                        r(), t(), n(), s && s()
                    }
                }
                getProps() {
                    let t = this.visualElement.getProps(),
                        {
                            drag: e = !1,
                            dragDirectionLock: i = !1,
                            dragPropagation: n = !1,
                            dragConstraints: r = !1,
                            dragElastic: s = .35,
                            dragMomentum: o = !0
                        } = t;
                    return { ...t,
                        drag: e,
                        dragDirectionLock: i,
                        dragPropagation: n,
                        dragConstraints: r,
                        dragElastic: s,
                        dragMomentum: o
                    }
                }
            }

            function tl(t, e, i) {
                return (!0 === e || e === t) && (null === i || i === t)
            }
            class tu extends y {
                constructor(t) {
                    super(t), this.removeGroupControls = T.Z, this.removeListeners = T.Z, this.controls = new ta(t)
                }
                mount() {
                    let {
                        dragControls: t
                    } = this.node.getProps();
                    t && (this.removeGroupControls = t.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || T.Z
                }
                unmount() {
                    this.removeGroupControls(), this.removeListeners()
                }
            }
            let th = t => (e, i) => {
                t && k.Wi.postRender(() => t(e, i))
            };
            class tc extends y {
                constructor() {
                    super(...arguments), this.removePointerDownListener = T.Z
                }
                onPointerDown(t) {
                    this.session = new j(t, this.createPanHandlers(), {
                        transformPagePoint: this.node.getTransformPagePoint(),
                        contextWindow: tr(this.node)
                    })
                }
                createPanHandlers() {
                    let {
                        onPanSessionStart: t,
                        onPanStart: e,
                        onPan: i,
                        onPanEnd: n
                    } = this.node.getProps();
                    return {
                        onSessionStart: th(t),
                        onStart: th(e),
                        onMove: i,
                        onEnd: (t, e) => {
                            delete this.session, n && k.Wi.postRender(() => n(t, e))
                        }
                    }
                }
                mount() {
                    this.removePointerDownListener = E(this.node.current, "pointerdown", t => this.onPointerDown(t))
                }
                update() {
                    this.session && this.session.updateHandlers(this.createPanHandlers())
                }
                unmount() {
                    this.removePointerDownListener(), this.session && this.session.end()
                }
            }
            var td = i(57437),
                tp = i(2265),
                tf = i(64252),
                tm = i(58881);
            let tv = (0, tp.createContext)({}),
                tg = {
                    hasAnimatedSinceResize: !0,
                    hasEverUpdated: !1
                };

            function ty(t, e) {
                return e.max === e.min ? 0 : t / (e.max - e.min) * 100
            }
            let tx = {
                correct: (t, e) => {
                    if (!e.target) return t;
                    if ("string" == typeof t) {
                        if (!ti.px.test(t)) return t;
                        t = parseFloat(t)
                    }
                    let i = ty(t, e.target.x),
                        n = ty(t, e.target.y);
                    return `${i}% ${n}%`
                }
            };
            var tw = i(83206),
                tP = i(98639);
            let {
                schedule: tT,
                cancel: tb
            } = (0, i(85005).Z)(queueMicrotask, !1);
            class tS extends tp.Component {
                componentDidMount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: i,
                        layoutId: n
                    } = this.props, {
                        projection: r
                    } = t;
                    (0, tP.B)(tD), r && (e.group && e.group.add(r), i && i.register && n && i.register(r), r.root.didUpdate(), r.addEventListener("animationComplete", () => {
                        this.safeToRemove()
                    }), r.setOptions({ ...r.options,
                        onExitComplete: () => this.safeToRemove()
                    })), tg.hasEverUpdated = !0
                }
                getSnapshotBeforeUpdate(t) {
                    let {
                        layoutDependency: e,
                        visualElement: i,
                        drag: n,
                        isPresent: r
                    } = this.props, s = i.projection;
                    return s && (s.isPresent = r, n || t.layoutDependency !== e || void 0 === e ? s.willUpdate() : this.safeToRemove(), t.isPresent === r || (r ? s.promote() : s.relegate() || k.Wi.postRender(() => {
                        let t = s.getStack();
                        t && t.members.length || this.safeToRemove()
                    }))), null
                }
                componentDidUpdate() {
                    let {
                        projection: t
                    } = this.props.visualElement;
                    t && (t.root.didUpdate(), tT.postRender(() => {
                        !t.currentAnimation && t.isLead() && this.safeToRemove()
                    }))
                }
                componentWillUnmount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: i
                    } = this.props, {
                        projection: n
                    } = t;
                    n && (n.scheduleCheckAfterUnmount(), e && e.group && e.group.remove(n), i && i.deregister && i.deregister(n))
                }
                safeToRemove() {
                    let {
                        safeToRemove: t
                    } = this.props;
                    t && t()
                }
                render() {
                    return null
                }
            }

            function tA(t) {
                let [e, i] = function() {
                    let t = (0, tp.useContext)(tf.O);
                    if (null === t) return [!0, null];
                    let {
                        isPresent: e,
                        onExitComplete: i,
                        register: n
                    } = t, r = (0, tp.useId)();
                    (0, tp.useEffect)(() => n(r), []);
                    let s = (0, tp.useCallback)(() => i && i(r), [r, i]);
                    return !e && i ? [!1, s] : [!0]
                }(), n = (0, tp.useContext)(tm.p);
                return (0, td.jsx)(tS, { ...t,
                    layoutGroup: n,
                    switchLayoutGroup: (0, tp.useContext)(tv),
                    isPresent: e,
                    safeToRemove: i
                })
            }
            let tD = {
                borderRadius: { ...tx,
                    applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
                },
                borderTopLeftRadius: tx,
                borderTopRightRadius: tx,
                borderBottomLeftRadius: tx,
                borderBottomRightRadius: tx,
                boxShadow: {
                    correct: (t, {
                        treeScale: e,
                        projectionDelta: i
                    }) => {
                        let n = tw.P.parse(t);
                        if (n.length > 5) return t;
                        let r = tw.P.createTransformer(t),
                            s = "number" != typeof n[0] ? 1 : 0,
                            o = i.x.scale * e.x,
                            a = i.y.scale * e.y;
                        n[0 + s] /= o, n[1 + s] /= a;
                        let l = (0, U.t)(o, a, .5);
                        return "number" == typeof n[2 + s] && (n[2 + s] /= l), "number" == typeof n[3 + s] && (n[3 + s] /= l), r(n)
                    }
                }
            };
            var tV = i(34081),
                tM = i(26378);
            let tE = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
                tC = tE.length,
                tR = t => "string" == typeof t ? parseFloat(t) : t,
                tk = t => "number" == typeof t || ti.px.test(t);

            function tj(t, e) {
                return void 0 !== t[e] ? t[e] : t.borderRadius
            }
            let tL = tB(0, .5, tM.Bn),
                tF = tB(.5, .95, T.Z);

            function tB(t, e, i) {
                return n => n < t ? 0 : n > e ? 1 : i((0, W.Y)(t, e, n))
            }

            function tO(t, e) {
                t.min = e.min, t.max = e.max
            }

            function t$(t, e) {
                tO(t.x, e.x), tO(t.y, e.y)
            }

            function tW(t, e) {
                t.translate = e.translate, t.scale = e.scale, t.originPoint = e.originPoint, t.origin = e.origin
            }
            var tU = i(47227);

            function tI(t, e, i, n, r) {
                return t -= e, t = (0, tU.q2)(t, 1 / i, n), void 0 !== r && (t = (0, tU.q2)(t, 1 / r, n)), t
            }

            function tN(t, e, [i, n, r], s, o) {
                ! function(t, e = 0, i = 1, n = .5, r, s = t, o = t) {
                    if (ti.aQ.test(e) && (e = parseFloat(e), e = (0, U.t)(o.min, o.max, e / 100) - o.min), "number" != typeof e) return;
                    let a = (0, U.t)(s.min, s.max, n);
                    t === s && (a -= e), t.min = tI(t.min, e, i, a, r), t.max = tI(t.max, e, i, a, r)
                }(t, e[i], e[n], e[r], e.scale, s, o)
            }
            let tX = ["x", "scaleX", "originX"],
                tY = ["y", "scaleY", "originY"];

            function tz(t, e, i, n) {
                tN(t.x, e, tX, i ? i.x : void 0, n ? n.x : void 0), tN(t.y, e, tY, i ? i.y : void 0, n ? n.y : void 0)
            }
            var tK = i(2259);

            function tH(t) {
                return 0 === t.translate && 1 === t.scale
            }

            function tZ(t) {
                return tH(t.x) && tH(t.y)
            }

            function tq(t, e) {
                return t.min === e.min && t.max === e.max
            }

            function tG(t, e) {
                return Math.round(t.min) === Math.round(e.min) && Math.round(t.max) === Math.round(e.max)
            }

            function t_(t, e) {
                return tG(t.x, e.x) && tG(t.y, e.y)
            }

            function tJ(t) {
                return I(t.x) / I(t.y)
            }

            function tQ(t, e) {
                return t.translate === e.translate && t.scale === e.scale && t.originPoint === e.originPoint
            }
            var t0 = i(69013);
            class t1 {
                constructor() {
                    this.members = []
                }
                add(t) {
                    (0, t0.y4)(this.members, t), t.scheduleRender()
                }
                remove(t) {
                    if ((0, t0.cl)(this.members, t), t === this.prevLead && (this.prevLead = void 0), t === this.lead) {
                        let t = this.members[this.members.length - 1];
                        t && this.promote(t)
                    }
                }
                relegate(t) {
                    let e;
                    let i = this.members.findIndex(e => t === e);
                    if (0 === i) return !1;
                    for (let t = i; t >= 0; t--) {
                        let i = this.members[t];
                        if (!1 !== i.isPresent) {
                            e = i;
                            break
                        }
                    }
                    return !!e && (this.promote(e), !0)
                }
                promote(t, e) {
                    let i = this.lead;
                    if (t !== i && (this.prevLead = i, this.lead = t, t.show(), i)) {
                        i.instance && i.scheduleRender(), t.scheduleRender(), t.resumeFrom = i, e && (t.resumeFrom.preserveOpacity = !0), i.snapshot && (t.snapshot = i.snapshot, t.snapshot.latestValues = i.animationValues || i.latestValues), t.root && t.root.isUpdating && (t.isLayoutDirty = !0);
                        let {
                            crossfade: n
                        } = t.options;
                        !1 === n && i.hide()
                    }
                }
                exitAnimationComplete() {
                    this.members.forEach(t => {
                        let {
                            options: e,
                            resumingFrom: i
                        } = t;
                        e.onExitComplete && e.onExitComplete(), i && i.options.onExitComplete && i.options.onExitComplete()
                    })
                }
                scheduleRender() {
                    this.members.forEach(t => {
                        t.instance && t.scheduleRender(!1)
                    })
                }
                removeLeadSnapshot() {
                    this.lead && this.lead.snapshot && (this.lead.snapshot = void 0)
                }
            }
            var t5 = i(12787);
            let t2 = (t, e) => t.depth - e.depth;
            class t4 {
                constructor() {
                    this.children = [], this.isDirty = !1
                }
                add(t) {
                    (0, t0.y4)(this.children, t), this.isDirty = !0
                }
                remove(t) {
                    (0, t0.cl)(this.children, t), this.isDirty = !0
                }
                forEach(t) {
                    this.isDirty && this.children.sort(t2), this.isDirty = !1, this.children.forEach(t)
                }
            }
            var t3 = i(4581),
                t9 = i(23999);

            function t6(t) {
                let e = (0, t9.i)(t) ? t.get() : t;
                return (0, t3.p)(e) ? e.toValue() : e
            }
            var t7 = i(40504),
                t8 = i(94239),
                et = i(82993),
                ee = i(34005);
            let ei = {
                    type: "projectionFrame",
                    totalNodes: 0,
                    resolvedTargetDeltas: 0,
                    recalculatedProjection: 0
                },
                en = "undefined" != typeof window && void 0 !== window.MotionDebug,
                er = ["", "X", "Y", "Z"],
                es = {
                    visibility: "hidden"
                },
                eo = 0;

            function ea(t, e, i, n) {
                let {
                    latestValues: r
                } = e;
                r[t] && (i[t] = r[t], e.setStaticValue(t, 0), n && (n[t] = 0))
            }

            function el({
                attachResizeListener: t,
                defaultParent: e,
                measureScroll: i,
                checkIsScrollRoot: n,
                resetTransform: r
            }) {
                return class {
                    constructor(t = {}, i = null == e ? void 0 : e()) {
                        this.id = eo++, this.animationId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
                            x: 1,
                            y: 1
                        }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                            this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
                        }, this.updateProjection = () => {
                            this.projectionUpdateScheduled = !1, en && (ei.totalNodes = ei.resolvedTargetDeltas = ei.recalculatedProjection = 0), this.nodes.forEach(ec), this.nodes.forEach(ey), this.nodes.forEach(ex), this.nodes.forEach(ed), en && window.MotionDebug.record(ei)
                        }, this.resolvedRelativeTargetAt = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = t, this.root = i ? i.root || i : this, this.path = i ? [...i.path, i] : [], this.parent = i, this.depth = i ? i.depth + 1 : 0;
                        for (let t = 0; t < this.path.length; t++) this.path[t].shouldResetTransform = !0;
                        this.root === this && (this.nodes = new t4)
                    }
                    addEventListener(t, e) {
                        return this.eventHandlers.has(t) || this.eventHandlers.set(t, new tV.L), this.eventHandlers.get(t).add(e)
                    }
                    notifyListeners(t, ...e) {
                        let i = this.eventHandlers.get(t);
                        i && i.notify(...e)
                    }
                    hasListeners(t) {
                        return this.eventHandlers.has(t)
                    }
                    mount(e, i = this.root.hasTreeAnimated) {
                        if (this.instance) return;
                        this.isSVG = (0, t8.v)(e), this.instance = e;
                        let {
                            layoutId: n,
                            layout: r,
                            visualElement: s
                        } = this.options;
                        if (s && !s.current && s.mount(e), this.root.nodes.add(this), this.parent && this.parent.children.add(this), i && (r || n) && (this.isLayoutDirty = !0), t) {
                            let i;
                            let n = () => this.root.updateBlockedByResize = !1;
                            t(e, () => {
                                this.root.updateBlockedByResize = !0, i && i(), i = function(t, e) {
                                    let i = t7.X.now(),
                                        n = ({
                                            timestamp: e
                                        }) => {
                                            let r = e - i;
                                            r >= 250 && ((0, k.Pn)(n), t(r - 250))
                                        };
                                    return k.Wi.read(n, !0), () => (0, k.Pn)(n)
                                }(n, 0), tg.hasAnimatedSinceResize && (tg.hasAnimatedSinceResize = !1, this.nodes.forEach(eg))
                            })
                        }
                        n && this.root.registerSharedNode(n, this), !1 !== this.options.animate && s && (n || r) && this.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e,
                            hasRelativeTargetChanged: i,
                            layout: n
                        }) => {
                            if (this.isTreeAnimationBlocked()) {
                                this.target = void 0, this.relativeTarget = void 0;
                                return
                            }
                            let r = this.options.transition || s.getDefaultTransition() || eA,
                                {
                                    onLayoutAnimationStart: o,
                                    onLayoutAnimationComplete: a
                                } = s.getProps(),
                                l = !this.targetLayout || !t_(this.targetLayout, n) || i,
                                u = !e && i;
                            if (this.options.layoutRoot || this.resumeFrom && this.resumeFrom.instance || u || e && (l || !this.currentAnimation)) {
                                this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0), this.setAnimationOrigin(t, u);
                                let e = { ...(0, tK.e)(r, "layout"),
                                    onPlay: o,
                                    onComplete: a
                                };
                                (s.shouldReduceMotion || this.options.layoutRoot) && (e.delay = 0, e.type = !1), this.startAnimation(e)
                            } else e || eg(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                            this.targetLayout = n
                        })
                    }
                    unmount() {
                        this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
                        let t = this.getStack();
                        t && t.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, (0, k.Pn)(this.updateProjection)
                    }
                    blockUpdate() {
                        this.updateManuallyBlocked = !0
                    }
                    unblockUpdate() {
                        this.updateManuallyBlocked = !1
                    }
                    isUpdateBlocked() {
                        return this.updateManuallyBlocked || this.updateBlockedByResize
                    }
                    isTreeAnimationBlocked() {
                        return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
                    }
                    startUpdate() {
                        !this.isUpdateBlocked() && (this.isUpdating = !0, this.nodes && this.nodes.forEach(ew), this.animationId++)
                    }
                    getTransformTemplate() {
                        let {
                            visualElement: t
                        } = this.options;
                        return t && t.getProps().transformTemplate
                    }
                    willUpdate(t = !0) {
                        if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
                            this.options.onExitComplete && this.options.onExitComplete();
                            return
                        }
                        if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && function t(e) {
                                if (e.hasCheckedOptimisedAppear = !0, e.root === e) return;
                                let {
                                    visualElement: i
                                } = e.options;
                                if (!i) return;
                                let n = (0, ee.s)(i);
                                if (window.MotionHasOptimisedAnimation(n, "transform")) {
                                    let {
                                        layout: t,
                                        layoutId: i
                                    } = e.options;
                                    window.MotionCancelOptimisedAnimation(n, "transform", k.Wi, !(t || i))
                                }
                                let {
                                    parent: r
                                } = e;
                                r && !r.hasCheckedOptimisedAppear && t(r)
                            }(this), this.root.isUpdating || this.root.startUpdate(), this.isLayoutDirty) return;
                        this.isLayoutDirty = !0;
                        for (let t = 0; t < this.path.length; t++) {
                            let e = this.path[t];
                            e.shouldResetTransform = !0, e.updateScroll("snapshot"), e.options.layoutRoot && e.willUpdate(!1)
                        }
                        let {
                            layoutId: e,
                            layout: i
                        } = this.options;
                        if (void 0 === e && !i) return;
                        let n = this.getTransformTemplate();
                        this.prevTransformTemplateValue = n ? n(this.latestValues, "") : void 0, this.updateSnapshot(), t && this.notifyListeners("willUpdate")
                    }
                    update() {
                        if (this.updateScheduled = !1, this.isUpdateBlocked()) {
                            this.unblockUpdate(), this.clearAllSnapshots(), this.nodes.forEach(ef);
                            return
                        }
                        this.isUpdating || this.nodes.forEach(em), this.isUpdating = !1, this.nodes.forEach(ev), this.nodes.forEach(eu), this.nodes.forEach(eh), this.clearAllSnapshots();
                        let t = t7.X.now();
                        k.frameData.delta = (0, H.u)(0, 1e3 / 60, t - k.frameData.timestamp), k.frameData.timestamp = t, k.frameData.isProcessing = !0, k.yL.update.process(k.frameData), k.yL.preRender.process(k.frameData), k.yL.render.process(k.frameData), k.frameData.isProcessing = !1
                    }
                    didUpdate() {
                        this.updateScheduled || (this.updateScheduled = !0, tT.read(this.scheduleUpdate))
                    }
                    clearAllSnapshots() {
                        this.nodes.forEach(ep), this.sharedNodes.forEach(eP)
                    }
                    scheduleUpdateProjection() {
                        this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, k.Wi.preRender(this.updateProjection, !1, !0))
                    }
                    scheduleCheckAfterUnmount() {
                        k.Wi.postRender(() => {
                            this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
                        })
                    }
                    updateSnapshot() {
                        !this.snapshot && this.instance && (this.snapshot = this.measure())
                    }
                    updateLayout() {
                        if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
                        if (this.resumeFrom && !this.resumeFrom.instance)
                            for (let t = 0; t < this.path.length; t++) this.path[t].updateScroll();
                        let t = this.layout;
                        this.layout = this.measure(!1), this.layoutCorrected = (0, J.dO)(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
                        let {
                            visualElement: e
                        } = this.options;
                        e && e.notify("LayoutMeasure", this.layout.layoutBox, t ? t.layoutBox : void 0)
                    }
                    updateScroll(t = "measure") {
                        let e = !!(this.options.layoutScroll && this.instance);
                        if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === t && (e = !1), e) {
                            let e = n(this.instance);
                            this.scroll = {
                                animationId: this.root.animationId,
                                phase: t,
                                isRoot: e,
                                offset: i(this.instance),
                                wasRoot: this.scroll ? this.scroll.isRoot : e
                            }
                        }
                    }
                    resetTransform() {
                        if (!r) return;
                        let t = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout,
                            e = this.projectionDelta && !tZ(this.projectionDelta),
                            i = this.getTransformTemplate(),
                            n = i ? i(this.latestValues, "") : void 0,
                            s = n !== this.prevTransformTemplateValue;
                        t && (e || (0, t5.ud)(this.latestValues) || s) && (r(this.instance, n), this.shouldResetTransform = !1, this.scheduleRender())
                    }
                    measure(t = !0) {
                        var e;
                        let i = this.measurePageBox(),
                            n = this.removeElementScroll(i);
                        return t && (n = this.removeTransform(n)), eM((e = n).x), eM(e.y), {
                            animationId: this.root.animationId,
                            measuredBox: i,
                            layoutBox: n,
                            latestValues: {},
                            source: this.id
                        }
                    }
                    measurePageBox() {
                        var t;
                        let {
                            visualElement: e
                        } = this.options;
                        if (!e) return (0, J.dO)();
                        let i = e.measureViewportBox();
                        if (!((null === (t = this.scroll) || void 0 === t ? void 0 : t.wasRoot) || this.path.some(eC))) {
                            let {
                                scroll: t
                            } = this.root;
                            t && ((0, tU.am)(i.x, t.offset.x), (0, tU.am)(i.y, t.offset.y))
                        }
                        return i
                    }
                    removeElementScroll(t) {
                        var e;
                        let i = (0, J.dO)();
                        if (t$(i, t), null === (e = this.scroll) || void 0 === e ? void 0 : e.wasRoot) return i;
                        for (let e = 0; e < this.path.length; e++) {
                            let n = this.path[e],
                                {
                                    scroll: r,
                                    options: s
                                } = n;
                            n !== this.root && r && s.layoutScroll && (r.wasRoot && t$(i, t), (0, tU.am)(i.x, r.offset.x), (0, tU.am)(i.y, r.offset.y))
                        }
                        return i
                    }
                    applyTransform(t, e = !1) {
                        let i = (0, J.dO)();
                        t$(i, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let n = this.path[t];
                            !e && n.options.layoutScroll && n.scroll && n !== n.root && (0, tU.D2)(i, {
                                x: -n.scroll.offset.x,
                                y: -n.scroll.offset.y
                            }), (0, t5.ud)(n.latestValues) && (0, tU.D2)(i, n.latestValues)
                        }
                        return (0, t5.ud)(this.latestValues) && (0, tU.D2)(i, this.latestValues), i
                    }
                    removeTransform(t) {
                        let e = (0, J.dO)();
                        t$(e, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let i = this.path[t];
                            if (!i.instance || !(0, t5.ud)(i.latestValues)) continue;
                            (0, t5.Lj)(i.latestValues) && i.updateSnapshot();
                            let n = (0, J.dO)();
                            t$(n, i.measurePageBox()), tz(e, i.latestValues, i.snapshot ? i.snapshot.layoutBox : void 0, n)
                        }
                        return (0, t5.ud)(this.latestValues) && tz(e, this.latestValues), e
                    }
                    setTargetDelta(t) {
                        this.targetDelta = t, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
                    }
                    setOptions(t) {
                        this.options = { ...this.options,
                            ...t,
                            crossfade: void 0 === t.crossfade || t.crossfade
                        }
                    }
                    clearMeasurements() {
                        this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
                    }
                    forceRelativeParentToResolveTarget() {
                        this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== k.frameData.timestamp && this.relativeParent.resolveTargetDelta(!0)
                    }
                    resolveTargetDelta(t = !1) {
                        var e, i, n, r;
                        let s = this.getLead();
                        this.isProjectionDirty || (this.isProjectionDirty = s.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = s.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = s.isSharedProjectionDirty);
                        let o = !!this.resumingFrom || this !== s;
                        if (!(t || o && this.isSharedProjectionDirty || this.isProjectionDirty || (null === (e = this.parent) || void 0 === e ? void 0 : e.isProjectionDirty) || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
                        let {
                            layout: a,
                            layoutId: l
                        } = this.options;
                        if (this.layout && (a || l)) {
                            if (this.resolvedRelativeTargetAt = k.frameData.timestamp, !this.targetDelta && !this.relativeTarget) {
                                let t = this.getClosestProjectingParent();
                                t && t.layout && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = (0, J.dO)(), this.relativeTargetOrigin = (0, J.dO)(), K(this.relativeTargetOrigin, this.layout.layoutBox, t.layout.layoutBox), t$(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                            }
                            if (this.relativeTarget || this.targetDelta) {
                                if ((this.target || (this.target = (0, J.dO)(), this.targetWithTransforms = (0, J.dO)()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target) ? (this.forceRelativeParentToResolveTarget(), i = this.target, n = this.relativeTarget, r = this.relativeParent.target, Y(i.x, n.x, r.x), Y(i.y, n.y, r.y)) : this.targetDelta ? (this.resumingFrom ? this.target = this.applyTransform(this.layout.layoutBox) : t$(this.target, this.layout.layoutBox), (0, tU.o2)(this.target, this.targetDelta)) : t$(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget) {
                                    this.attemptToResolveRelativeTarget = !1;
                                    let t = this.getClosestProjectingParent();
                                    t && !!t.resumingFrom == !!this.resumingFrom && !t.options.layoutScroll && t.target && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = (0, J.dO)(), this.relativeTargetOrigin = (0, J.dO)(), K(this.relativeTargetOrigin, this.target, t.target), t$(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                                }
                                en && ei.resolvedTargetDeltas++
                            }
                        }
                    }
                    getClosestProjectingParent() {
                        return !this.parent || (0, t5.Lj)(this.parent.latestValues) || (0, t5.D_)(this.parent.latestValues) ? void 0 : this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent()
                    }
                    isProjecting() {
                        return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
                    }
                    calcProjection() {
                        var t;
                        let e = this.getLead(),
                            i = !!this.resumingFrom || this !== e,
                            n = !0;
                        if ((this.isProjectionDirty || (null === (t = this.parent) || void 0 === t ? void 0 : t.isProjectionDirty)) && (n = !1), i && (this.isSharedProjectionDirty || this.isTransformDirty) && (n = !1), this.resolvedRelativeTargetAt === k.frameData.timestamp && (n = !1), n) return;
                        let {
                            layout: r,
                            layoutId: s
                        } = this.options;
                        if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(r || s)) return;
                        t$(this.layoutCorrected, this.layout.layoutBox);
                        let o = this.treeScale.x,
                            a = this.treeScale.y;
                        (0, tU.YY)(this.layoutCorrected, this.treeScale, this.path, i), e.layout && !e.target && (1 !== this.treeScale.x || 1 !== this.treeScale.y) && (e.target = e.layout.layoutBox, e.targetWithTransforms = (0, J.dO)());
                        let {
                            target: l
                        } = e;
                        if (!l) {
                            this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender());
                            return
                        }
                        this.projectionDelta && this.prevProjectionDelta ? (tW(this.prevProjectionDelta.x, this.projectionDelta.x), tW(this.prevProjectionDelta.y, this.projectionDelta.y)) : this.createProjectionDeltas(), X(this.projectionDelta, this.layoutCorrected, l, this.latestValues), this.treeScale.x === o && this.treeScale.y === a && tQ(this.projectionDelta.x, this.prevProjectionDelta.x) && tQ(this.projectionDelta.y, this.prevProjectionDelta.y) || (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", l)), en && ei.recalculatedProjection++
                    }
                    hide() {
                        this.isVisible = !1
                    }
                    show() {
                        this.isVisible = !0
                    }
                    scheduleRender(t = !0) {
                        var e;
                        if (null === (e = this.options.visualElement) || void 0 === e || e.scheduleRender(), t) {
                            let t = this.getStack();
                            t && t.scheduleRender()
                        }
                        this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
                    }
                    createProjectionDeltas() {
                        this.prevProjectionDelta = (0, J.wc)(), this.projectionDelta = (0, J.wc)(), this.projectionDeltaWithTransform = (0, J.wc)()
                    }
                    setAnimationOrigin(t, e = !1) {
                        let i;
                        let n = this.snapshot,
                            r = n ? n.latestValues : {},
                            s = { ...this.latestValues
                            },
                            o = (0, J.wc)();
                        this.relativeParent && this.relativeParent.options.layoutRoot || (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !e;
                        let a = (0, J.dO)(),
                            l = (n ? n.source : void 0) !== (this.layout ? this.layout.source : void 0),
                            u = this.getStack(),
                            h = !u || u.members.length <= 1,
                            c = !!(l && !h && !0 === this.options.crossfade && !this.path.some(eS));
                        this.animationProgress = 0, this.mixTargetDelta = e => {
                            let n = e / 1e3;
                            if (eT(o.x, t.x, n), eT(o.y, t.y, n), this.setTargetDelta(o), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout) {
                                var u, d, p, f;
                                K(a, this.layout.layoutBox, this.relativeParent.layout.layoutBox), p = this.relativeTarget, f = this.relativeTargetOrigin, eb(p.x, f.x, a.x, n), eb(p.y, f.y, a.y, n), i && (u = this.relativeTarget, d = i, tq(u.x, d.x) && tq(u.y, d.y)) && (this.isProjectionDirty = !1), i || (i = (0, J.dO)()), t$(i, this.relativeTarget)
                            }
                            l && (this.animationValues = s, function(t, e, i, n, r, s) {
                                r ? (t.opacity = (0, U.t)(0, void 0 !== i.opacity ? i.opacity : 1, tL(n)), t.opacityExit = (0, U.t)(void 0 !== e.opacity ? e.opacity : 1, 0, tF(n))) : s && (t.opacity = (0, U.t)(void 0 !== e.opacity ? e.opacity : 1, void 0 !== i.opacity ? i.opacity : 1, n));
                                for (let r = 0; r < tC; r++) {
                                    let s = `border${tE[r]}Radius`,
                                        o = tj(e, s),
                                        a = tj(i, s);
                                    (void 0 !== o || void 0 !== a) && (o || (o = 0), a || (a = 0), 0 === o || 0 === a || tk(o) === tk(a) ? (t[s] = Math.max((0, U.t)(tR(o), tR(a), n), 0), (ti.aQ.test(a) || ti.aQ.test(o)) && (t[s] += "%")) : t[s] = a)
                                }(e.rotate || i.rotate) && (t.rotate = (0, U.t)(e.rotate || 0, i.rotate || 0, n))
                            }(s, r, this.latestValues, n, c, h)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = n
                        }, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0)
                    }
                    startAnimation(t) {
                        this.notifyListeners("animationStart"), this.currentAnimation && this.currentAnimation.stop(), this.resumingFrom && this.resumingFrom.currentAnimation && this.resumingFrom.currentAnimation.stop(), this.pendingAnimation && ((0, k.Pn)(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = k.Wi.update(() => {
                            tg.hasAnimatedSinceResize = !0, this.currentAnimation = (0, et.D)(0, 1e3, { ...t,
                                onUpdate: e => {
                                    this.mixTargetDelta(e), t.onUpdate && t.onUpdate(e)
                                },
                                onComplete: () => {
                                    t.onComplete && t.onComplete(), this.completeAnimation()
                                }
                            }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
                        })
                    }
                    completeAnimation() {
                        this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
                        let t = this.getStack();
                        t && t.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
                    }
                    finishAnimation() {
                        this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(1e3), this.currentAnimation.stop()), this.completeAnimation()
                    }
                    applyTransformsToTarget() {
                        let t = this.getLead(),
                            {
                                targetWithTransforms: e,
                                target: i,
                                layout: n,
                                latestValues: r
                            } = t;
                        if (e && i && n) {
                            if (this !== t && this.layout && n && eE(this.options.animationType, this.layout.layoutBox, n.layoutBox)) {
                                i = this.target || (0, J.dO)();
                                let e = I(this.layout.layoutBox.x);
                                i.x.min = t.target.x.min, i.x.max = i.x.min + e;
                                let n = I(this.layout.layoutBox.y);
                                i.y.min = t.target.y.min, i.y.max = i.y.min + n
                            }
                            t$(e, i), (0, tU.D2)(e, r), X(this.projectionDeltaWithTransform, this.layoutCorrected, e, r)
                        }
                    }
                    registerSharedNode(t, e) {
                        this.sharedNodes.has(t) || this.sharedNodes.set(t, new t1), this.sharedNodes.get(t).add(e);
                        let i = e.options.initialPromotionConfig;
                        e.promote({
                            transition: i ? i.transition : void 0,
                            preserveFollowOpacity: i && i.shouldPreserveFollowOpacity ? i.shouldPreserveFollowOpacity(e) : void 0
                        })
                    }
                    isLead() {
                        let t = this.getStack();
                        return !t || t.lead === this
                    }
                    getLead() {
                        var t;
                        let {
                            layoutId: e
                        } = this.options;
                        return e && (null === (t = this.getStack()) || void 0 === t ? void 0 : t.lead) || this
                    }
                    getPrevLead() {
                        var t;
                        let {
                            layoutId: e
                        } = this.options;
                        return e ? null === (t = this.getStack()) || void 0 === t ? void 0 : t.prevLead : void 0
                    }
                    getStack() {
                        let {
                            layoutId: t
                        } = this.options;
                        if (t) return this.root.sharedNodes.get(t)
                    }
                    promote({
                        needsReset: t,
                        transition: e,
                        preserveFollowOpacity: i
                    } = {}) {
                        let n = this.getStack();
                        n && n.promote(this, i), t && (this.projectionDelta = void 0, this.needsReset = !0), e && this.setOptions({
                            transition: e
                        })
                    }
                    relegate() {
                        let t = this.getStack();
                        return !!t && t.relegate(this)
                    }
                    resetSkewAndRotation() {
                        let {
                            visualElement: t
                        } = this.options;
                        if (!t) return;
                        let e = !1,
                            {
                                latestValues: i
                            } = t;
                        if ((i.z || i.rotate || i.rotateX || i.rotateY || i.rotateZ || i.skewX || i.skewY) && (e = !0), !e) return;
                        let n = {};
                        i.z && ea("z", t, n, this.animationValues);
                        for (let e = 0; e < er.length; e++) ea(`rotate${er[e]}`, t, n, this.animationValues), ea(`skew${er[e]}`, t, n, this.animationValues);
                        for (let e in t.render(), n) t.setStaticValue(e, n[e]), this.animationValues && (this.animationValues[e] = n[e]);
                        t.scheduleRender()
                    }
                    getProjectionStyles(t) {
                        var e, i;
                        if (!this.instance || this.isSVG) return;
                        if (!this.isVisible) return es;
                        let n = {
                                visibility: ""
                            },
                            r = this.getTransformTemplate();
                        if (this.needsReset) return this.needsReset = !1, n.opacity = "", n.pointerEvents = t6(null == t ? void 0 : t.pointerEvents) || "", n.transform = r ? r(this.latestValues, "") : "none", n;
                        let s = this.getLead();
                        if (!this.projectionDelta || !this.layout || !s.target) {
                            let e = {};
                            return this.options.layoutId && (e.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1, e.pointerEvents = t6(null == t ? void 0 : t.pointerEvents) || ""), this.hasProjected && !(0, t5.ud)(this.latestValues) && (e.transform = r ? r({}, "") : "none", this.hasProjected = !1), e
                        }
                        let o = s.animationValues || s.latestValues;
                        this.applyTransformsToTarget(), n.transform = function(t, e, i) {
                            let n = "",
                                r = t.x.translate / e.x,
                                s = t.y.translate / e.y,
                                o = (null == i ? void 0 : i.z) || 0;
                            if ((r || s || o) && (n = `translate3d(${r}px, ${s}px, ${o}px) `), (1 !== e.x || 1 !== e.y) && (n += `scale(${1/e.x}, ${1/e.y}) `), i) {
                                let {
                                    transformPerspective: t,
                                    rotate: e,
                                    rotateX: r,
                                    rotateY: s,
                                    skewX: o,
                                    skewY: a
                                } = i;
                                t && (n = `perspective(${t}px) ${n}`), e && (n += `rotate(${e}deg) `), r && (n += `rotateX(${r}deg) `), s && (n += `rotateY(${s}deg) `), o && (n += `skewX(${o}deg) `), a && (n += `skewY(${a}deg) `)
                            }
                            let a = t.x.scale * e.x,
                                l = t.y.scale * e.y;
                            return (1 !== a || 1 !== l) && (n += `scale(${a}, ${l})`), n || "none"
                        }(this.projectionDeltaWithTransform, this.treeScale, o), r && (n.transform = r(o, n.transform));
                        let {
                            x: a,
                            y: l
                        } = this.projectionDelta;
                        for (let t in n.transformOrigin = `${100*a.origin}% ${100*l.origin}% 0`, s.animationValues ? n.opacity = s === this ? null !== (i = null !== (e = o.opacity) && void 0 !== e ? e : this.latestValues.opacity) && void 0 !== i ? i : 1 : this.preserveOpacity ? this.latestValues.opacity : o.opacityExit : n.opacity = s === this ? void 0 !== o.opacity ? o.opacity : "" : void 0 !== o.opacityExit ? o.opacityExit : 0, tP.P) {
                            if (void 0 === o[t]) continue;
                            let {
                                correct: e,
                                applyTo: i
                            } = tP.P[t], r = "none" === n.transform ? o[t] : e(o[t], s);
                            if (i) {
                                let t = i.length;
                                for (let e = 0; e < t; e++) n[i[e]] = r
                            } else n[t] = r
                        }
                        return this.options.layoutId && (n.pointerEvents = s === this ? t6(null == t ? void 0 : t.pointerEvents) || "" : "none"), n
                    }
                    clearSnapshot() {
                        this.resumeFrom = this.snapshot = void 0
                    }
                    resetTree() {
                        this.root.nodes.forEach(t => {
                            var e;
                            return null === (e = t.currentAnimation) || void 0 === e ? void 0 : e.stop()
                        }), this.root.nodes.forEach(ef), this.root.sharedNodes.clear()
                    }
                }
            }

            function eu(t) {
                t.updateLayout()
            }

            function eh(t) {
                var e;
                let i = (null === (e = t.resumeFrom) || void 0 === e ? void 0 : e.snapshot) || t.snapshot;
                if (t.isLead() && t.layout && i && t.hasListeners("didUpdate")) {
                    let {
                        layoutBox: e,
                        measuredBox: n
                    } = t.layout, {
                        animationType: r
                    } = t.options, s = i.source !== t.layout.source;
                    "size" === r ? Q(t => {
                        let n = s ? i.measuredBox[t] : i.layoutBox[t],
                            r = I(n);
                        n.min = e[t].min, n.max = n.min + r
                    }) : eE(r, i.layoutBox, e) && Q(n => {
                        let r = s ? i.measuredBox[n] : i.layoutBox[n],
                            o = I(e[n]);
                        r.max = r.min + o, t.relativeTarget && !t.currentAnimation && (t.isProjectionDirty = !0, t.relativeTarget[n].max = t.relativeTarget[n].min + o)
                    });
                    let o = (0, J.wc)();
                    X(o, e, i.layoutBox);
                    let a = (0, J.wc)();
                    s ? X(a, t.applyTransform(n, !0), i.measuredBox) : X(a, e, i.layoutBox);
                    let l = !tZ(o),
                        u = !1;
                    if (!t.resumeFrom) {
                        let n = t.getClosestProjectingParent();
                        if (n && !n.resumeFrom) {
                            let {
                                snapshot: r,
                                layout: s
                            } = n;
                            if (r && s) {
                                let o = (0, J.dO)();
                                K(o, i.layoutBox, r.layoutBox);
                                let a = (0, J.dO)();
                                K(a, e, s.layoutBox), t_(o, a) || (u = !0), n.options.layoutRoot && (t.relativeTarget = a, t.relativeTargetOrigin = o, t.relativeParent = n)
                            }
                        }
                    }
                    t.notifyListeners("didUpdate", {
                        layout: e,
                        snapshot: i,
                        delta: a,
                        layoutDelta: o,
                        hasLayoutChanged: l,
                        hasRelativeTargetChanged: u
                    })
                } else if (t.isLead()) {
                    let {
                        onExitComplete: e
                    } = t.options;
                    e && e()
                }
                t.options.transition = void 0
            }

            function ec(t) {
                en && ei.totalNodes++, t.parent && (t.isProjecting() || (t.isProjectionDirty = t.parent.isProjectionDirty), t.isSharedProjectionDirty || (t.isSharedProjectionDirty = !!(t.isProjectionDirty || t.parent.isProjectionDirty || t.parent.isSharedProjectionDirty)), t.isTransformDirty || (t.isTransformDirty = t.parent.isTransformDirty))
            }

            function ed(t) {
                t.isProjectionDirty = t.isSharedProjectionDirty = t.isTransformDirty = !1
            }

            function ep(t) {
                t.clearSnapshot()
            }

            function ef(t) {
                t.clearMeasurements()
            }

            function em(t) {
                t.isLayoutDirty = !1
            }

            function ev(t) {
                let {
                    visualElement: e
                } = t.options;
                e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"), t.resetTransform()
            }

            function eg(t) {
                t.finishAnimation(), t.targetDelta = t.relativeTarget = t.target = void 0, t.isProjectionDirty = !0
            }

            function ey(t) {
                t.resolveTargetDelta()
            }

            function ex(t) {
                t.calcProjection()
            }

            function ew(t) {
                t.resetSkewAndRotation()
            }

            function eP(t) {
                t.removeLeadSnapshot()
            }

            function eT(t, e, i) {
                t.translate = (0, U.t)(e.translate, 0, i), t.scale = (0, U.t)(e.scale, 1, i), t.origin = e.origin, t.originPoint = e.originPoint
            }

            function eb(t, e, i, n) {
                t.min = (0, U.t)(e.min, i.min, n), t.max = (0, U.t)(e.max, i.max, n)
            }

            function eS(t) {
                return t.animationValues && void 0 !== t.animationValues.opacityExit
            }
            let eA = {
                    duration: .45,
                    ease: [.4, 0, .1, 1]
                },
                eD = t => "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().includes(t),
                eV = eD("applewebkit/") && !eD("chrome/") ? Math.round : T.Z;

            function eM(t) {
                t.min = eV(t.min), t.max = eV(t.max)
            }

            function eE(t, e, i) {
                return "position" === t || "preserve-aspect" === t && !(.2 >= Math.abs(tJ(e) - tJ(i)))
            }

            function eC(t) {
                var e;
                return t !== t.root && (null === (e = t.scroll) || void 0 === e ? void 0 : e.wasRoot)
            }
            let eR = el({
                    attachResizeListener: (t, e) => M(t, "resize", e),
                    measureScroll: () => ({
                        x: document.documentElement.scrollLeft || document.body.scrollLeft,
                        y: document.documentElement.scrollTop || document.body.scrollTop
                    }),
                    checkIsScrollRoot: () => !0
                }),
                ek = {
                    current: void 0
                },
                ej = el({
                    measureScroll: t => ({
                        x: t.scrollLeft,
                        y: t.scrollTop
                    }),
                    defaultParent: () => {
                        if (!ek.current) {
                            let t = new eR({});
                            t.mount(window), t.setOptions({
                                layoutScroll: !0
                            }), ek.current = t
                        }
                        return ek.current
                    },
                    resetTransform: (t, e) => {
                        t.style.transform = void 0 !== e ? e : "none"
                    },
                    checkIsScrollRoot: t => "fixed" === window.getComputedStyle(t).position
                });

            function eL(t, e, i) {
                let {
                    props: n
                } = t;
                t.animationState && n.whileHover && t.animationState.setActive("whileHover", "Start" === i);
                let r = n["onHover" + i];
                r && k.Wi.postRender(() => r(e, A(e)))
            }
            class eF extends y {
                mount() {
                    let {
                        current: t
                    } = this.node;
                    t && (this.unmount = (0, S.Mr)(t, t => (eL(this.node, t, "Start"), t => eL(this.node, t, "End"))))
                }
                unmount() {}
            }
            class eB extends y {
                constructor() {
                    super(...arguments), this.isActive = !1
                }
                onFocus() {
                    let t = !1;
                    try {
                        t = this.node.current.matches(":focus-visible")
                    } catch (e) {
                        t = !0
                    }
                    t && this.node.animationState && (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
                }
                onBlur() {
                    this.isActive && this.node.animationState && (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
                }
                mount() {
                    this.unmount = (0, C.z)(M(this.node.current, "focus", () => this.onFocus()), M(this.node.current, "blur", () => this.onBlur()))
                }
                unmount() {}
            }

            function eO(t, e, i) {
                let {
                    props: n
                } = t;
                t.animationState && n.whileTap && t.animationState.setActive("whileTap", "Start" === i);
                let r = n["onTap" + ("End" === i ? "" : i)];
                r && k.Wi.postRender(() => r(e, A(e)))
            }
            class e$ extends y {
                mount() {
                    let {
                        current: t
                    } = this.node;
                    t && (this.unmount = (0, S.OD)(t, t => (eO(this.node, t, "Start"), (t, {
                        success: e
                    }) => eO(this.node, t, e ? "End" : "Cancel")), {
                        useGlobalTarget: this.node.props.globalTapTarget
                    }))
                }
                unmount() {}
            }
            let eW = new WeakMap,
                eU = new WeakMap,
                eI = t => {
                    let e = eW.get(t.target);
                    e && e(t)
                },
                eN = t => {
                    t.forEach(eI)
                },
                eX = {
                    some: 0,
                    all: 1
                };
            class eY extends y {
                constructor() {
                    super(...arguments), this.hasEnteredView = !1, this.isInView = !1
                }
                startObserver() {
                    this.unmount();
                    let {
                        viewport: t = {}
                    } = this.node.getProps(), {
                        root: e,
                        margin: i,
                        amount: n = "some",
                        once: r
                    } = t, s = {
                        root: e ? e.current : void 0,
                        rootMargin: i,
                        threshold: "number" == typeof n ? n : eX[n]
                    };
                    return function(t, e, i) {
                        let n = function({
                            root: t,
                            ...e
                        }) {
                            let i = t || document;
                            eU.has(i) || eU.set(i, {});
                            let n = eU.get(i),
                                r = JSON.stringify(e);
                            return n[r] || (n[r] = new IntersectionObserver(eN, {
                                root: t,
                                ...e
                            })), n[r]
                        }(e);
                        return eW.set(t, i), n.observe(t), () => {
                            eW.delete(t), n.unobserve(t)
                        }
                    }(this.node.current, s, t => {
                        let {
                            isIntersecting: e
                        } = t;
                        if (this.isInView === e || (this.isInView = e, r && !e && this.hasEnteredView)) return;
                        e && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", e);
                        let {
                            onViewportEnter: i,
                            onViewportLeave: n
                        } = this.node.getProps(), s = e ? i : n;
                        s && s(t)
                    })
                }
                mount() {
                    this.startObserver()
                }
                update() {
                    if ("undefined" == typeof IntersectionObserver) return;
                    let {
                        props: t,
                        prevProps: e
                    } = this.node;
                    ["amount", "margin", "root"].some(function({
                        viewport: t = {}
                    }, {
                        viewport: e = {}
                    } = {}) {
                        return i => t[i] !== e[i]
                    }(t, e)) && this.startObserver()
                }
                unmount() {}
            }
            var ez = i(45750);
            let eK = (0, tp.createContext)({});
            var eH = i(11534);
            let eZ = (0, tp.createContext)({
                strict: !1
            });
            var eq = i(61750),
                eG = i(17743);

            function e_(t) {
                return Array.isArray(t) ? t.join(" ") : t
            }
            var eJ = i(35938),
                eQ = i(44563);
            let e0 = Symbol.for("motionComponentSymbol"),
                e1 = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

            function e5(t) {
                if ("string" != typeof t || t.includes("-"));
                else if (e1.indexOf(t) > -1 || /[A-Z]/u.test(t)) return !0;
                return !1
            }
            var e2 = i(33390),
                e4 = i(67098),
                e3 = i(31297),
                e9 = i(53576);
            let e6 = t => (e, i) => {
                    let n = (0, tp.useContext)(eK),
                        r = (0, tp.useContext)(tf.O),
                        s = () => (function({
                            scrapeMotionValuesFromProps: t,
                            createRenderState: e,
                            onMount: i
                        }, n, r, s) {
                            let a = {
                                latestValues: function(t, e, i, n) {
                                    let r = {},
                                        s = n(t, {});
                                    for (let t in s) r[t] = t6(s[t]);
                                    let {
                                        initial: a,
                                        animate: l
                                    } = t, u = (0, eG.G)(t), h = (0, eG.M)(t);
                                    e && h && !u && !1 !== t.inherit && (void 0 === a && (a = e.initial), void 0 === l && (l = e.animate));
                                    let c = !!i && !1 === i.initial,
                                        d = (c = c || !1 === a) ? l : a;
                                    if (d && "boolean" != typeof d && !(0, o.H)(d)) {
                                        let e = Array.isArray(d) ? d : [d];
                                        for (let i = 0; i < e.length; i++) {
                                            let n = (0, e3.o)(t, e[i]);
                                            if (n) {
                                                let {
                                                    transitionEnd: t,
                                                    transition: e,
                                                    ...i
                                                } = n;
                                                for (let t in i) {
                                                    let e = i[t];
                                                    if (Array.isArray(e)) {
                                                        let t = c ? e.length - 1 : 0;
                                                        e = e[t]
                                                    }
                                                    null !== e && (r[t] = e)
                                                }
                                                for (let e in t) r[e] = t[e]
                                            }
                                        }
                                    }
                                    return r
                                }(n, r, s, t),
                                renderState: e()
                            };
                            return i && (a.mount = t => i(n, t, a)), a
                        })(t, e, n, r);
                    return i ? s() : (0, e9.h)(s)
                },
                e7 = () => ({
                    style: {},
                    transform: {},
                    transformOrigin: {},
                    vars: {}
                }),
                e8 = () => ({ ...e7(),
                    attrs: {}
                });
            var it = i(67402),
                ie = i(37380);
            let ii = {
                    useVisualState: e6({
                        scrapeMotionValuesFromProps: e4.U,
                        createRenderState: e8,
                        onMount: (t, e, {
                            renderState: i,
                            latestValues: n
                        }) => {
                            k.Wi.read(() => {
                                try {
                                    i.dimensions = "function" == typeof e.getBBox ? e.getBBox() : e.getBoundingClientRect()
                                } catch (t) {
                                    i.dimensions = {
                                        x: 0,
                                        y: 0,
                                        width: 0,
                                        height: 0
                                    }
                                }
                            }), k.Wi.render(() => {
                                (0, it.i)(i, n, (0, ie.a)(e.tagName), t.transformTemplate), (0, e2.K)(e, i)
                            })
                        }
                    })
                },
                ir = {
                    useVisualState: e6({
                        scrapeMotionValuesFromProps: i(67971).U,
                        createRenderState: e7
                    })
                };
            var is = i(77556),
                io = i(4469);

            function ia(t, e, i) {
                for (let n in e)(0, t9.i)(e[n]) || (0, is.j)(n, i) || (t[n] = e[n])
            }
            let il = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "ignoreStrict", "viewport"]);

            function iu(t) {
                return t.startsWith("while") || t.startsWith("drag") && "draggable" !== t || t.startsWith("layout") || t.startsWith("onTap") || t.startsWith("onPan") || t.startsWith("onLayout") || il.has(t)
            }
            let ih = t => !iu(t);
            try {
                (n = require("@emotion/is-prop-valid").default) && (ih = t => t.startsWith("on") ? !iu(t) : n(t))
            } catch (t) {}
            var ic = i(59282),
                id = i(23482);
            let ip = function(t) {
                if ("undefined" == typeof Proxy) return t;
                let e = new Map;
                return new Proxy((...e) => t(...e), {
                    get: (i, n) => "create" === n ? t : (e.has(n) || e.set(n, t(n)), e.get(n))
                })
            }((r = {
                animation: {
                    Feature: x
                },
                exit: {
                    Feature: P
                },
                inView: {
                    Feature: eY
                },
                tap: {
                    Feature: e$
                },
                focus: {
                    Feature: eB
                },
                hover: {
                    Feature: eF
                },
                pan: {
                    Feature: tc
                },
                drag: {
                    Feature: tu,
                    ProjectionNode: ej,
                    MeasureLayout: tA
                },
                layout: {
                    ProjectionNode: ej,
                    MeasureLayout: tA
                }
            }, s = (t, e) => e5(t) ? new id.e(e) : new ic.W(e, {
                allowProjection: t !== tp.Fragment
            }), function(t, {
                forwardMotionProps: e
            } = {
                forwardMotionProps: !1
            }) {
                return function(t) {
                    let {
                        preloadedFeatures: e,
                        createVisualElement: i,
                        useRender: n,
                        useVisualState: r,
                        Component: s
                    } = t;
                    e && function(t) {
                        for (let e in t) eJ.featureDefinitions[e] = { ...eJ.featureDefinitions[e],
                            ...t[e]
                        }
                    }(e);
                    let o = (0, tp.forwardRef)(function(t, e) {
                        var o;
                        let a;
                        let l = { ...(0, tp.useContext)(ez._),
                                ...t,
                                layoutId: function(t) {
                                    let {
                                        layoutId: e
                                    } = t, i = (0, tp.useContext)(tm.p).id;
                                    return i && void 0 !== e ? i + "-" + e : e
                                }(t)
                            },
                            {
                                isStatic: h
                            } = l,
                            c = function(t) {
                                let {
                                    initial: e,
                                    animate: i
                                } = function(t, e) {
                                    if ((0, eG.G)(t)) {
                                        let {
                                            initial: e,
                                            animate: i
                                        } = t;
                                        return {
                                            initial: !1 === e || (0, u.$)(e) ? e : void 0,
                                            animate: (0, u.$)(i) ? i : void 0
                                        }
                                    }
                                    return !1 !== t.inherit ? e : {}
                                }(t, (0, tp.useContext)(eK));
                                return (0, tp.useMemo)(() => ({
                                    initial: e,
                                    animate: i
                                }), [e_(e), e_(i)])
                            }(t),
                            d = r(t, h);
                        if (!h && eQ.j) {
                            (0, tp.useContext)(eZ).strict;
                            let t = function(t) {
                                let {
                                    drag: e,
                                    layout: i
                                } = eJ.featureDefinitions;
                                if (!e && !i) return {};
                                let n = { ...e,
                                    ...i
                                };
                                return {
                                    MeasureLayout: (null == e ? void 0 : e.isEnabled(t)) || (null == i ? void 0 : i.isEnabled(t)) ? n.MeasureLayout : void 0,
                                    ProjectionNode: n.ProjectionNode
                                }
                            }(l);
                            a = t.MeasureLayout, c.visualElement = function(t, e, i, n, r) {
                                var s, o;
                                let {
                                    visualElement: a
                                } = (0, tp.useContext)(eK), l = (0, tp.useContext)(eZ), u = (0, tp.useContext)(tf.O), h = (0, tp.useContext)(ez._).reducedMotion, c = (0, tp.useRef)(null);
                                n = n || l.renderer, !c.current && n && (c.current = n(t, {
                                    visualState: e,
                                    parent: a,
                                    props: i,
                                    presenceContext: u,
                                    blockInitialAnimation: !!u && !1 === u.initial,
                                    reducedMotionConfig: h
                                }));
                                let d = c.current,
                                    p = (0, tp.useContext)(tv);
                                d && !d.projection && r && ("html" === d.type || "svg" === d.type) && function(t, e, i, n) {
                                    let {
                                        layoutId: r,
                                        layout: s,
                                        drag: o,
                                        dragConstraints: a,
                                        layoutScroll: l,
                                        layoutRoot: u
                                    } = e;
                                    t.projection = new i(t.latestValues, e["data-framer-portal-id"] ? void 0 : function t(e) {
                                        if (e) return !1 !== e.options.allowProjection ? e.projection : t(e.parent)
                                    }(t.parent)), t.projection.setOptions({
                                        layoutId: r,
                                        layout: s,
                                        alwaysMeasureLayout: !!o || a && $(a),
                                        visualElement: t,
                                        animationType: "string" == typeof s ? s : "both",
                                        initialPromotionConfig: n,
                                        layoutScroll: l,
                                        layoutRoot: u
                                    })
                                }(c.current, i, r, p);
                                let f = (0, tp.useRef)(!1);
                                (0, tp.useInsertionEffect)(() => {
                                    d && f.current && d.update(i, u)
                                });
                                let m = i[eq.M],
                                    v = (0, tp.useRef)(!!m && !(null === (s = window.MotionHandoffIsComplete) || void 0 === s ? void 0 : s.call(window, m)) && (null === (o = window.MotionHasOptimisedAnimation) || void 0 === o ? void 0 : o.call(window, m)));
                                return (0, eH.L)(() => {
                                    d && (f.current = !0, window.MotionIsMounted = !0, d.updateFeatures(), tT.render(d.render), v.current && d.animationState && d.animationState.animateChanges())
                                }), (0, tp.useEffect)(() => {
                                    d && (!v.current && d.animationState && d.animationState.animateChanges(), v.current && (queueMicrotask(() => {
                                        var t;
                                        null === (t = window.MotionHandoffMarkAsComplete) || void 0 === t || t.call(window, m)
                                    }), v.current = !1))
                                }), d
                            }(s, d, l, i, t.ProjectionNode)
                        }
                        return (0, td.jsxs)(eK.Provider, {
                            value: c,
                            children: [a && c.visualElement ? (0, td.jsx)(a, {
                                visualElement: c.visualElement,
                                ...l
                            }) : null, n(s, t, (o = c.visualElement, (0, tp.useCallback)(t => {
                                t && d.mount && d.mount(t), o && (t ? o.mount(t) : o.unmount()), e && ("function" == typeof e ? e(t) : $(e) && (e.current = t))
                            }, [o])), d, h, c.visualElement)]
                        })
                    });
                    return o[e0] = s, o
                }({ ...e5(t) ? ii : ir,
                    preloadedFeatures: r,
                    useRender: function(t = !1) {
                        return (e, i, n, {
                            latestValues: r
                        }, s) => {
                            let o = (e5(e) ? function(t, e, i, n) {
                                    let r = (0, tp.useMemo)(() => {
                                        let i = e8();
                                        return (0, it.i)(i, e, (0, ie.a)(n), t.transformTemplate), { ...i.attrs,
                                            style: { ...i.style
                                            }
                                        }
                                    }, [e]);
                                    if (t.style) {
                                        let e = {};
                                        ia(e, t.style, t), r.style = { ...e,
                                            ...r.style
                                        }
                                    }
                                    return r
                                } : function(t, e) {
                                    let i = {},
                                        n = function(t, e) {
                                            let i = t.style || {},
                                                n = {};
                                            return ia(n, i, t), Object.assign(n, function({
                                                transformTemplate: t
                                            }, e) {
                                                return (0, tp.useMemo)(() => {
                                                    let i = e7();
                                                    return (0, io.r)(i, e, t), Object.assign({}, i.vars, i.style)
                                                }, [e])
                                            }(t, e)), n
                                        }(t, e);
                                    return t.drag && !1 !== t.dragListener && (i.draggable = !1, n.userSelect = n.WebkitUserSelect = n.WebkitTouchCallout = "none", n.touchAction = !0 === t.drag ? "none" : `pan-${"x"===t.drag?"y":"x"}`), void 0 === t.tabIndex && (t.onTap || t.onTapStart || t.whileTap) && (i.tabIndex = 0), i.style = n, i
                                })(i, r, s, e),
                                a = function(t, e, i) {
                                    let n = {};
                                    for (let r in t)("values" !== r || "object" != typeof t.values) && (ih(r) || !0 === i && iu(r) || !e && !iu(r) || t.draggable && r.startsWith("onDrag")) && (n[r] = t[r]);
                                    return n
                                }(i, "string" == typeof e, t),
                                l = e !== tp.Fragment ? { ...a,
                                    ...o,
                                    ref: n
                                } : {},
                                {
                                    children: u
                                } = i,
                                h = (0, tp.useMemo)(() => (0, t9.i)(u) ? u.get() : u, [u]);
                            return (0, tp.createElement)(e, { ...l,
                                children: h
                            })
                        }
                    }(e),
                    createVisualElement: s,
                    Component: t
                })
            }))
        },
        94238: function(t, e, i) {
            i.d(e, {
                s: function() {
                    return f
                }
            });
            var n = i(13697),
                r = i(98751),
                s = i(4946),
                o = i(37249);
            let a = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
            var l = i(90401),
                u = i(38580),
                h = i(39545),
                c = i(83206),
                d = i(25861);
            let p = new Set(["auto", "none", "0"]);
            class f extends h.e {
                constructor(t, e, i, n, r) {
                    super(t, e, i, n, r, !0)
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        element: e,
                        name: i
                    } = this;
                    if (!e || !e.current) return;
                    super.readKeyframes();
                    for (let i = 0; i < t.length; i++) {
                        let n = t[i];
                        if ("string" == typeof n && (n = n.trim(), (0, o.t)(n))) {
                            let l = function t(e, i, n = 1) {
                                (0, r.k)(n <= 4, `Max CSS variable fallback depth detected in property "${e}". This may indicate a circular fallback dependency.`);
                                let [l, u] = function(t) {
                                    let e = a.exec(t);
                                    if (!e) return [, ];
                                    let [, i, n, r] = e;
                                    return [`--${null!=i?i:n}`, r]
                                }(e);
                                if (!l) return;
                                let h = window.getComputedStyle(i).getPropertyValue(l);
                                if (h) {
                                    let t = h.trim();
                                    return (0, s.P)(t) ? parseFloat(t) : t
                                }
                                return (0, o.t)(u) ? t(u, i, n + 1) : u
                            }(n, e.current);
                            void 0 !== l && (t[i] = l), i === t.length - 1 && (this.finalKeyframe = n)
                        }
                    }
                    if (this.resolveNoneKeyframes(), !l.z2.has(i) || 2 !== t.length) return;
                    let [n, h] = t, c = (0, u.C)(n), d = (0, u.C)(h);
                    if (c !== d) {
                        if ((0, l.mP)(c) && (0, l.mP)(d))
                            for (let e = 0; e < t.length; e++) {
                                let i = t[e];
                                "string" == typeof i && (t[e] = parseFloat(i))
                            } else this.needsMeasurement = !0
                    }
                }
                resolveNoneKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        name: e
                    } = this, i = [];
                    for (let e = 0; e < t.length; e++) {
                        var r;
                        ("number" == typeof(r = t[e]) ? 0 === r : null === r || "none" === r || "0" === r || (0, n.W)(r)) && i.push(e)
                    }
                    i.length && function(t, e, i) {
                        let n, r = 0;
                        for (; r < t.length && !n;) {
                            let e = t[r];
                            "string" == typeof e && !p.has(e) && (0, c.V)(e).values.length && (n = t[r]), r++
                        }
                        if (n && i)
                            for (let r of e) t[r] = (0, d.T)(i, n)
                    }(t, i, e)
                }
                measureInitialState() {
                    let {
                        element: t,
                        unresolvedKeyframes: e,
                        name: i
                    } = this;
                    if (!t || !t.current) return;
                    "height" === i && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = l.lw[i](t.measureViewportBox(), window.getComputedStyle(t.current)), e[0] = this.measuredOrigin;
                    let n = e[e.length - 1];
                    void 0 !== n && t.getValue(i, n).jump(n, !1)
                }
                measureEndState() {
                    var t;
                    let {
                        element: e,
                        name: i,
                        unresolvedKeyframes: n
                    } = this;
                    if (!e || !e.current) return;
                    let r = e.getValue(i);
                    r && r.jump(this.measuredOrigin, !1);
                    let s = n.length - 1,
                        o = n[s];
                    n[s] = l.lw[i](e.measureViewportBox(), window.getComputedStyle(e.current)), null !== o && void 0 === this.finalKeyframe && (this.finalKeyframe = o), (null === (t = this.removedTransforms) || void 0 === t ? void 0 : t.length) && this.removedTransforms.forEach(([t, i]) => {
                        e.getValue(t).set(i)
                    }), this.resolveNoneKeyframes()
                }
            }
        },
        57511: function(t, e, i) {
            i.d(e, {
                J: function() {
                    return o
                }
            });
            var n = i(84426),
                r = i(94238),
                s = i(23999);
            class o extends n.l {
                constructor() {
                    super(...arguments), this.KeyframeResolver = r.s
                }
                sortInstanceNodePosition(t, e) {
                    return 2 & t.compareDocumentPosition(e) ? 1 : -1
                }
                getBaseTargetFromProps(t, e) {
                    return t.style ? t.style[e] : void 0
                }
                removeValueFromRenderState(t, {
                    vars: e,
                    style: i
                }) {
                    delete e[t], delete i[t]
                }
                handleChildMotionValue() {
                    this.childSubscription && (this.childSubscription(), delete this.childSubscription);
                    let {
                        children: t
                    } = this.props;
                    (0, s.i)(t) && (this.childSubscription = t.on("change", t => {
                        this.current && (this.current.textContent = `${t}`)
                    }))
                }
            }
        },
        43198: function(t, e, i) {
            i.d(e, {
                t: function() {
                    return n
                }
            });
            let n = (0, i(64043).X)(() => void 0 !== window.ScrollTimeline)
        },
        17444: function(t, e, i) {
            i.d(e, {
                D: function() {
                    return n
                }
            });
            let n = t => t.replace(/([a-z])([A-Z])/gu, "$1-$2").toLowerCase()
        },
        37249: function(t, e, i) {
            i.d(e, {
                f: function() {
                    return r
                },
                t: function() {
                    return o
                }
            });
            let n = t => e => "string" == typeof e && e.startsWith(t),
                r = n("--"),
                s = n("var(--"),
                o = t => !!s(t) && a.test(t.split("/*")[0].trim()),
                a = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu
        },
        94239: function(t, e, i) {
            i.d(e, {
                v: function() {
                    return n
                }
            });

            function n(t) {
                return t instanceof SVGElement && "svg" !== t.tagName
            }
        },
        90401: function(t, e, i) {
            i.d(e, {
                Ei: function() {
                    return d
                },
                lw: function() {
                    return p
                },
                mP: function() {
                    return a
                },
                z2: function() {
                    return o
                }
            });
            var n = i(8834),
                r = i(74305),
                s = i(27492);
            let o = new Set(["width", "height", "top", "left", "right", "bottom", "x", "y", "translateX", "translateY"]),
                a = t => t === r.Rx || t === s.px,
                l = (t, e) => parseFloat(t.split(", ")[e]),
                u = (t, e) => (i, {
                    transform: n
                }) => {
                    if ("none" === n || !n) return 0;
                    let r = n.match(/^matrix3d\((.+)\)$/u);
                    if (r) return l(r[1], e); {
                        let e = n.match(/^matrix\((.+)\)$/u);
                        return e ? l(e[1], t) : 0
                    }
                },
                h = new Set(["x", "y", "z"]),
                c = n._.filter(t => !h.has(t));

            function d(t) {
                let e = [];
                return c.forEach(i => {
                    let n = t.getValue(i);
                    void 0 !== n && (e.push([i, n.get()]), n.set(i.startsWith("scale") ? 1 : 0))
                }), e
            }
            let p = {
                width: ({
                    x: t
                }, {
                    paddingLeft: e = "0",
                    paddingRight: i = "0"
                }) => t.max - t.min - parseFloat(e) - parseFloat(i),
                height: ({
                    y: t
                }, {
                    paddingTop: e = "0",
                    paddingBottom: i = "0"
                }) => t.max - t.min - parseFloat(e) - parseFloat(i),
                top: (t, {
                    top: e
                }) => parseFloat(e),
                left: (t, {
                    left: e
                }) => parseFloat(e),
                bottom: ({
                    y: t
                }, {
                    top: e
                }) => parseFloat(e) + (t.max - t.min),
                right: ({
                    x: t
                }, {
                    left: e
                }) => parseFloat(e) + (t.max - t.min),
                x: u(4, 13),
                y: u(5, 14)
            };
            p.translateX = p.x, p.translateY = p.y
        },
        25861: function(t, e, i) {
            i.d(e, {
                T: function() {
                    return o
                }
            });
            var n = i(83206),
                r = i(22779),
                s = i(22005);

            function o(t, e) {
                let i = (0, s.A)(t);
                return i !== r.h && (i = n.P), i.getAnimatableNone ? i.getAnimatableNone(e) : void 0
            }
        },
        22005: function(t, e, i) {
            i.d(e, {
                A: function() {
                    return o
                }
            });
            var n = i(33964),
                r = i(22779);
            let s = { ...i(66204).j,
                    color: n.$,
                    backgroundColor: n.$,
                    outlineColor: n.$,
                    fill: n.$,
                    stroke: n.$,
                    borderColor: n.$,
                    borderTopColor: n.$,
                    borderRightColor: n.$,
                    borderBottomColor: n.$,
                    borderLeftColor: n.$,
                    filter: r.h,
                    WebkitFilter: r.h
                },
                o = t => s[t]
        },
        38580: function(t, e, i) {
            i.d(e, {
                $: function() {
                    return o
                },
                C: function() {
                    return a
                }
            });
            var n = i(74305),
                r = i(27492),
                s = i(55113);
            let o = [n.Rx, r.px, r.aQ, r.RW, r.vw, r.vh, {
                    test: t => "auto" === t,
                    parse: t => t
                }],
                a = t => o.find((0, s.l)(t))
        },
        66204: function(t, e, i) {
            i.d(e, {
                j: function() {
                    return l
                }
            });
            var n = i(74305),
                r = i(27492);
            let s = {
                    borderWidth: r.px,
                    borderTopWidth: r.px,
                    borderRightWidth: r.px,
                    borderBottomWidth: r.px,
                    borderLeftWidth: r.px,
                    borderRadius: r.px,
                    radius: r.px,
                    borderTopLeftRadius: r.px,
                    borderTopRightRadius: r.px,
                    borderBottomRightRadius: r.px,
                    borderBottomLeftRadius: r.px,
                    width: r.px,
                    maxWidth: r.px,
                    height: r.px,
                    maxHeight: r.px,
                    top: r.px,
                    right: r.px,
                    bottom: r.px,
                    left: r.px,
                    padding: r.px,
                    paddingTop: r.px,
                    paddingRight: r.px,
                    paddingBottom: r.px,
                    paddingLeft: r.px,
                    margin: r.px,
                    marginTop: r.px,
                    marginRight: r.px,
                    marginBottom: r.px,
                    marginLeft: r.px,
                    backgroundPositionX: r.px,
                    backgroundPositionY: r.px
                },
                o = {
                    rotate: r.RW,
                    rotateX: r.RW,
                    rotateY: r.RW,
                    rotateZ: r.RW,
                    scale: n.bA,
                    scaleX: n.bA,
                    scaleY: n.bA,
                    scaleZ: n.bA,
                    skew: r.RW,
                    skewX: r.RW,
                    skewY: r.RW,
                    distance: r.px,
                    translateX: r.px,
                    translateY: r.px,
                    translateZ: r.px,
                    x: r.px,
                    y: r.px,
                    z: r.px,
                    perspective: r.px,
                    transformPerspective: r.px,
                    opacity: n.Fq,
                    originX: r.$C,
                    originY: r.$C,
                    originZ: r.px
                },
                a = { ...n.Rx,
                    transform: Math.round
                },
                l = { ...s,
                    ...o,
                    zIndex: a,
                    size: r.px,
                    fillOpacity: n.Fq,
                    strokeOpacity: n.Fq,
                    numOctaves: a
                }
        },
        55113: function(t, e, i) {
            i.d(e, {
                l: function() {
                    return n
                }
            });
            let n = t => e => e.test(t)
        },
        59282: function(t, e, i) {
            i.d(e, {
                W: function() {
                    return c
                }
            });
            var n = i(4469),
                r = i(37249),
                s = i(8834),
                o = i(67971),
                a = i(1125),
                l = i(22005),
                u = i(50813),
                h = i(57511);
            class c extends h.J {
                constructor() {
                    super(...arguments), this.type = "html", this.renderInstance = a.N
                }
                readValueFromInstance(t, e) {
                    if (s.G.has(e)) {
                        let t = (0, l.A)(e);
                        return t && t.default || 0
                    } {
                        let i = window.getComputedStyle(t),
                            n = ((0, r.f)(e) ? i.getPropertyValue(e) : i[e]) || 0;
                        return "string" == typeof n ? n.trim() : n
                    }
                }
                measureInstanceViewportBox(t, {
                    transformPagePoint: e
                }) {
                    return (0, u.J)(t, e)
                }
                build(t, e, i) {
                    (0, n.r)(t, e, i.transformTemplate)
                }
                scrapeMotionValuesFromProps(t, e, i) {
                    return (0, o.U)(t, e, i)
                }
            }
        },
        4469: function(t, e, i) {
            i.d(e, {
                r: function() {
                    return u
                }
            });
            var n = i(8834);
            let r = (t, e) => e && "number" == typeof t ? e.transform(t) : t;
            var s = i(66204);
            let o = {
                    x: "translateX",
                    y: "translateY",
                    z: "translateZ",
                    transformPerspective: "perspective"
                },
                a = n._.length;
            var l = i(37249);

            function u(t, e, i) {
                let {
                    style: u,
                    vars: h,
                    transformOrigin: c
                } = t, d = !1, p = !1;
                for (let t in e) {
                    let i = e[t];
                    if (n.G.has(t)) {
                        d = !0;
                        continue
                    }
                    if ((0, l.f)(t)) {
                        h[t] = i;
                        continue
                    } {
                        let e = r(i, s.j[t]);
                        t.startsWith("origin") ? (p = !0, c[t] = e) : u[t] = e
                    }
                }
                if (!e.transform && (d || i ? u.transform = function(t, e, i) {
                        let l = "",
                            u = !0;
                        for (let h = 0; h < a; h++) {
                            let a = n._[h],
                                c = t[a];
                            if (void 0 === c) continue;
                            let d = !0;
                            if (!(d = "number" == typeof c ? c === (a.startsWith("scale") ? 1 : 0) : 0 === parseFloat(c)) || i) {
                                let t = r(c, s.j[a]);
                                if (!d) {
                                    u = !1;
                                    let e = o[a] || a;
                                    l += `${e}(${t}) `
                                }
                                i && (e[a] = t)
                            }
                        }
                        return l = l.trim(), i ? l = i(e, u ? "" : l) : u && (l = "none"), l
                    }(e, t.transform, i) : u.transform && (u.transform = "none")), p) {
                    let {
                        originX: t = "50%",
                        originY: e = "50%",
                        originZ: i = 0
                    } = c;
                    u.transformOrigin = `${t} ${e} ${i}`
                }
            }
        },
        1125: function(t, e, i) {
            i.d(e, {
                N: function() {
                    return n
                }
            });

            function n(t, {
                style: e,
                vars: i
            }, n, r) {
                for (let s in Object.assign(t.style, e, r && r.getProjectionStyles(n)), i) t.style.setProperty(s, i[s])
            }
        },
        67971: function(t, e, i) {
            i.d(e, {
                U: function() {
                    return s
                }
            });
            var n = i(77556),
                r = i(23999);

            function s(t, e, i) {
                var s;
                let {
                    style: o
                } = t, a = {};
                for (let l in o)((0, r.i)(o[l]) || e.style && (0, r.i)(e.style[l]) || (0, n.j)(l, t) || (null === (s = null == i ? void 0 : i.getValue(l)) || void 0 === s ? void 0 : s.liveStyle) !== void 0) && (a[l] = o[l]);
                return a
            }
        },
        8834: function(t, e, i) {
            i.d(e, {
                G: function() {
                    return r
                },
                _: function() {
                    return n
                }
            });
            let n = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
                r = new Set(n)
        },
        37003: function(t, e, i) {
            i.d(e, {
                R: function() {
                    return n
                }
            });
            let n = new WeakMap
        },
        23482: function(t, e, i) {
            i.d(e, {
                e: function() {
                    return p
                }
            });
            var n = i(67098),
                r = i(57511),
                s = i(67402),
                o = i(17444),
                a = i(16582),
                l = i(8834),
                u = i(33390),
                h = i(22005),
                c = i(96674),
                d = i(37380);
            class p extends r.J {
                constructor() {
                    super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = c.dO
                }
                getBaseTargetFromProps(t, e) {
                    return t[e]
                }
                readValueFromInstance(t, e) {
                    if (l.G.has(e)) {
                        let t = (0, h.A)(e);
                        return t && t.default || 0
                    }
                    return e = a.s.has(e) ? e : (0, o.D)(e), t.getAttribute(e)
                }
                scrapeMotionValuesFromProps(t, e, i) {
                    return (0, n.U)(t, e, i)
                }
                build(t, e, i) {
                    (0, s.i)(t, e, this.isSVGTag, i.transformTemplate)
                }
                renderInstance(t, e, i, n) {
                    (0, u.K)(t, e, i, n)
                }
                mount(t) {
                    this.isSVGTag = (0, d.a)(t.tagName), super.mount(t)
                }
            }
        },
        67402: function(t, e, i) {
            i.d(e, {
                i: function() {
                    return l
                }
            });
            var n = i(4469),
                r = i(27492);

            function s(t, e, i) {
                return "string" == typeof t ? t : r.px.transform(e + i * t)
            }
            let o = {
                    offset: "stroke-dashoffset",
                    array: "stroke-dasharray"
                },
                a = {
                    offset: "strokeDashoffset",
                    array: "strokeDasharray"
                };

            function l(t, {
                attrX: e,
                attrY: i,
                attrScale: l,
                originX: u,
                originY: h,
                pathLength: c,
                pathSpacing: d = 1,
                pathOffset: p = 0,
                ...f
            }, m, v) {
                if ((0, n.r)(t, f, v), m) {
                    t.style.viewBox && (t.attrs.viewBox = t.style.viewBox);
                    return
                }
                t.attrs = t.style, t.style = {};
                let {
                    attrs: g,
                    style: y,
                    dimensions: x
                } = t;
                g.transform && (x && (y.transform = g.transform), delete g.transform), x && (void 0 !== u || void 0 !== h || y.transform) && (y.transformOrigin = function(t, e, i) {
                    let n = s(e, t.x, t.width),
                        r = s(i, t.y, t.height);
                    return `${n} ${r}`
                }(x, void 0 !== u ? u : .5, void 0 !== h ? h : .5)), void 0 !== e && (g.x = e), void 0 !== i && (g.y = i), void 0 !== l && (g.scale = l), void 0 !== c && function(t, e, i = 1, n = 0, s = !0) {
                    t.pathLength = 1;
                    let l = s ? o : a;
                    t[l.offset] = r.px.transform(-n);
                    let u = r.px.transform(e),
                        h = r.px.transform(i);
                    t[l.array] = `${u} ${h}`
                }(g, c, d, p, !1)
            }
        },
        16582: function(t, e, i) {
            i.d(e, {
                s: function() {
                    return n
                }
            });
            let n = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"])
        },
        37380: function(t, e, i) {
            i.d(e, {
                a: function() {
                    return n
                }
            });
            let n = t => "string" == typeof t && "svg" === t.toLowerCase()
        },
        33390: function(t, e, i) {
            i.d(e, {
                K: function() {
                    return o
                }
            });
            var n = i(17444),
                r = i(1125),
                s = i(16582);

            function o(t, e, i, o) {
                for (let i in (0, r.N)(t, e, void 0, o), e.attrs) t.setAttribute(s.s.has(i) ? i : (0, n.D)(i), e.attrs[i])
            }
        },
        67098: function(t, e, i) {
            i.d(e, {
                U: function() {
                    return o
                }
            });
            var n = i(23999),
                r = i(67971),
                s = i(8834);

            function o(t, e, i) {
                let o = (0, r.U)(t, e, i);
                for (let i in t)((0, n.i)(t[i]) || (0, n.i)(e[i])) && (o[-1 !== s._.indexOf(i) ? "attr" + i.charAt(0).toUpperCase() + i.substring(1) : i] = t[i]);
                return o
            }
        },
        39545: function(t, e, i) {
            i.d(e, {
                e: function() {
                    return c
                },
                m: function() {
                    return h
                }
            });
            var n = i(90401),
                r = i(45414);
            let s = new Set,
                o = !1,
                a = !1;

            function l() {
                if (a) {
                    let t = Array.from(s).filter(t => t.needsMeasurement),
                        e = new Set(t.map(t => t.element)),
                        i = new Map;
                    e.forEach(t => {
                        let e = (0, n.Ei)(t);
                        e.length && (i.set(t, e), t.render())
                    }), t.forEach(t => t.measureInitialState()), e.forEach(t => {
                        t.render();
                        let e = i.get(t);
                        e && e.forEach(([e, i]) => {
                            var n;
                            null === (n = t.getValue(e)) || void 0 === n || n.set(i)
                        })
                    }), t.forEach(t => t.measureEndState()), t.forEach(t => {
                        void 0 !== t.suspendedScrollY && window.scrollTo(0, t.suspendedScrollY)
                    })
                }
                a = !1, o = !1, s.forEach(t => t.complete()), s.clear()
            }

            function u() {
                s.forEach(t => {
                    t.readKeyframes(), t.needsMeasurement && (a = !0)
                })
            }

            function h() {
                u(), l()
            }
            class c {
                constructor(t, e, i, n, r, s = !1) {
                    this.isComplete = !1, this.isAsync = !1, this.needsMeasurement = !1, this.isScheduled = !1, this.unresolvedKeyframes = [...t], this.onComplete = e, this.name = i, this.motionValue = n, this.element = r, this.isAsync = s
                }
                scheduleResolve() {
                    this.isScheduled = !0, this.isAsync ? (s.add(this), o || (o = !0, r.Wi.read(u), r.Wi.resolveKeyframes(l))) : (this.readKeyframes(), this.complete())
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        name: e,
                        element: i,
                        motionValue: n
                    } = this;
                    for (let r = 0; r < t.length; r++)
                        if (null === t[r]) {
                            if (0 === r) {
                                let r = null == n ? void 0 : n.get(),
                                    s = t[t.length - 1];
                                if (void 0 !== r) t[0] = r;
                                else if (i && e) {
                                    let n = i.readValue(e, s);
                                    null != n && (t[0] = n)
                                }
                                void 0 === t[0] && (t[0] = s), n && void 0 === r && n.set(t[0])
                            } else t[r] = t[r - 1]
                        }
                }
                setFinalKeyframe() {}
                measureInitialState() {}
                renderEndStyles() {}
                measureEndState() {}
                complete() {
                    this.isComplete = !0, this.onComplete(this.unresolvedKeyframes, this.finalKeyframe), s.delete(this)
                }
                cancel() {
                    this.isComplete || (this.isScheduled = !1, s.delete(this))
                }
                resume() {
                    this.isComplete || this.scheduleResolve()
                }
            }
        },
        17743: function(t, e, i) {
            i.d(e, {
                G: function() {
                    return o
                },
                M: function() {
                    return a
                }
            });
            var n = i(20569),
                r = i(74115),
                s = i(72589);

            function o(t) {
                return (0, n.H)(t.animate) || s.V.some(e => (0, r.$)(t[e]))
            }

            function a(t) {
                return !!(o(t) || t.variants)
            }
        },
        74115: function(t, e, i) {
            i.d(e, {
                $: function() {
                    return n
                }
            });

            function n(t) {
                return "string" == typeof t || Array.isArray(t)
            }
        },
        67043: function(t, e, i) {
            i.d(e, {
                x: function() {
                    return r
                }
            });
            var n = i(31297);

            function r(t, e, i) {
                let r = t.getProps();
                return (0, n.o)(r, e, void 0 !== i ? i : r.custom, t)
            }
        },
        31297: function(t, e, i) {
            function n(t) {
                let e = [{}, {}];
                return null == t || t.values.forEach((t, i) => {
                    e[0][i] = t.get(), e[1][i] = t.getVelocity()
                }), e
            }

            function r(t, e, i, r) {
                if ("function" == typeof e) {
                    let [s, o] = n(r);
                    e = e(void 0 !== i ? i : t.custom, s, o)
                }
                if ("string" == typeof e && (e = t.variants && t.variants[e]), "function" == typeof e) {
                    let [s, o] = n(r);
                    e = e(void 0 !== i ? i : t.custom, s, o)
                }
                return e
            }
            i.d(e, {
                o: function() {
                    return r
                }
            })
        },
        48771: function(t, e, i) {
            i.d(e, {
                C: function() {
                    return o
                }
            });
            var n = i(4581),
                r = i(3078),
                s = i(67043);

            function o(t, e) {
                let {
                    transitionEnd: i = {},
                    transition: o = {},
                    ...a
                } = (0, s.x)(t, e) || {};
                for (let e in a = { ...a,
                        ...i
                    }) {
                    let i = (0, n.Y)(a[e]);
                    t.hasValue(e) ? t.getValue(e).set(i) : t.addValue(e, (0, r.BX)(i))
                }
            }
        },
        72589: function(t, e, i) {
            i.d(e, {
                V: function() {
                    return r
                },
                e: function() {
                    return n
                }
            });
            let n = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
                r = ["initial", ...n]
        },
        24118: function(t, e, i) {
            i.d(e, {
                c: function() {
                    return n
                }
            });
            let n = {
                skipAnimations: !1,
                useManualTiming: !1
            }
        },
        69013: function(t, e, i) {
            function n(t, e) {
                -1 === t.indexOf(e) && t.push(e)
            }

            function r(t, e) {
                let i = t.indexOf(e);
                i > -1 && t.splice(i, 1)
            }
            i.d(e, {
                cl: function() {
                    return r
                },
                y4: function() {
                    return n
                }
            })
        },
        59111: function(t, e, i) {
            i.d(e, {
                u: function() {
                    return n
                }
            });
            let n = (t, e, i) => i > e ? e : i < t ? t : i
        },
        88843: function(t, e, i) {
            i.d(e, {
                s: function() {
                    return u
                }
            });
            var n = i(59111),
                r = i(56920),
                s = i(76376),
                o = i(56277),
                a = i(98751),
                l = i(12006);

            function u(t, e, {
                clamp: i = !0,
                ease: u,
                mixer: h
            } = {}) {
                let c = t.length;
                if ((0, a.k)(c === e.length, "Both input and output ranges must be the same length"), 1 === c) return () => e[0];
                if (2 === c && t[0] === t[1]) return () => e[1];
                t[0] > t[c - 1] && (t = [...t].reverse(), e = [...e].reverse());
                let d = function(t, e, i) {
                        let n = [],
                            s = i || l.C,
                            a = t.length - 1;
                        for (let i = 0; i < a; i++) {
                            let a = s(t[i], t[i + 1]);
                            if (e) {
                                let t = Array.isArray(e) ? e[i] || o.Z : e;
                                a = (0, r.z)(t, a)
                            }
                            n.push(a)
                        }
                        return n
                    }(e, u, h),
                    p = d.length,
                    f = e => {
                        let i = 0;
                        if (p > 1)
                            for (; i < t.length - 2 && !(e < t[i + 1]); i++);
                        let n = (0, s.Y)(t[i], t[i + 1], e);
                        return d[i](n)
                    };
                return i ? e => f((0, n.u)(t[0], t[c - 1], e)) : f
            }
        },
        44563: function(t, e, i) {
            i.d(e, {
                j: function() {
                    return n
                }
            });
            let n = "undefined" != typeof window
        },
        4946: function(t, e, i) {
            i.d(e, {
                P: function() {
                    return n
                }
            });
            let n = t => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t)
        },
        13697: function(t, e, i) {
            i.d(e, {
                W: function() {
                    return n
                }
            });
            let n = t => /^0[^.\s]+$/u.test(t)
        },
        64043: function(t, e, i) {
            i.d(e, {
                X: function() {
                    return n
                }
            });

            function n(t) {
                let e;
                return () => (void 0 === e && (e = t()), e)
            }
        },
        12006: function(t, e, i) {
            i.d(e, {
                C: function() {
                    return A
                }
            });
            var n = i(96781),
                r = i(98751);

            function s(t, e, i) {
                return (i < 0 && (i += 1), i > 1 && (i -= 1), i < 1 / 6) ? t + (e - t) * 6 * i : i < .5 ? e : i < 2 / 3 ? t + (e - t) * (2 / 3 - i) * 6 : t
            }
            var o = i(87325),
                a = i(18859),
                l = i(92943);

            function u(t, e) {
                return i => i > 0 ? e : t
            }
            let h = (t, e, i) => {
                    let n = t * t,
                        r = i * (e * e - n) + n;
                    return r < 0 ? 0 : Math.sqrt(r)
                },
                c = [o.$, a.m, l.J],
                d = t => c.find(e => e.test(t));

            function p(t) {
                let e = d(t);
                if ((0, r.K)(!!e, `'${t}' is not an animatable color. Use the equivalent color code instead.`), !e) return !1;
                let i = e.parse(t);
                return e === l.J && (i = function({
                    hue: t,
                    saturation: e,
                    lightness: i,
                    alpha: n
                }) {
                    t /= 360, i /= 100;
                    let r = 0,
                        o = 0,
                        a = 0;
                    if (e /= 100) {
                        let n = i < .5 ? i * (1 + e) : i + e - i * e,
                            l = 2 * i - n;
                        r = s(l, n, t + 1 / 3), o = s(l, n, t), a = s(l, n, t - 1 / 3)
                    } else r = o = a = i;
                    return {
                        red: Math.round(255 * r),
                        green: Math.round(255 * o),
                        blue: Math.round(255 * a),
                        alpha: n
                    }
                }(i)), i
            }
            let f = (t, e) => {
                let i = p(t),
                    r = p(e);
                if (!i || !r) return u(t, e);
                let s = { ...i
                };
                return t => (s.red = h(i.red, r.red, t), s.green = h(i.green, r.green, t), s.blue = h(i.blue, r.blue, t), s.alpha = (0, n.t)(i.alpha, r.alpha, t), a.m.transform(s))
            };
            var m = i(56920),
                v = i(33964),
                g = i(83206),
                y = i(37249);
            let x = new Set(["none", "hidden"]);

            function w(t, e) {
                return i => (0, n.t)(t, e, i)
            }

            function P(t) {
                return "number" == typeof t ? w : "string" == typeof t ? (0, y.t)(t) ? u : v.$.test(t) ? f : S : Array.isArray(t) ? T : "object" == typeof t ? v.$.test(t) ? f : b : u
            }

            function T(t, e) {
                let i = [...t],
                    n = i.length,
                    r = t.map((t, i) => P(t)(t, e[i]));
                return t => {
                    for (let e = 0; e < n; e++) i[e] = r[e](t);
                    return i
                }
            }

            function b(t, e) {
                let i = { ...t,
                        ...e
                    },
                    n = {};
                for (let r in i) void 0 !== t[r] && void 0 !== e[r] && (n[r] = P(t[r])(t[r], e[r]));
                return t => {
                    for (let e in n) i[e] = n[e](t);
                    return i
                }
            }
            let S = (t, e) => {
                let i = g.P.createTransformer(e),
                    n = (0, g.V)(t),
                    s = (0, g.V)(e);
                return n.indexes.var.length === s.indexes.var.length && n.indexes.color.length === s.indexes.color.length && n.indexes.number.length >= s.indexes.number.length ? x.has(t) && !s.values.length || x.has(e) && !n.values.length ? x.has(t) ? i => i <= 0 ? t : e : i => i >= 1 ? e : t : (0, m.z)(T(function(t, e) {
                    var i;
                    let n = [],
                        r = {
                            color: 0,
                            var: 0,
                            number: 0
                        };
                    for (let s = 0; s < e.values.length; s++) {
                        let o = e.types[s],
                            a = t.indexes[o][r[o]],
                            l = null !== (i = t.values[a]) && void 0 !== i ? i : 0;
                        n[s] = l, r[o]++
                    }
                    return n
                }(n, s), s.values), i) : ((0, r.K)(!0, `Complex values '${t}' and '${e}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`), u(t, e))
            };

            function A(t, e, i) {
                return "number" == typeof t && "number" == typeof e && "number" == typeof i ? (0, n.t)(t, e, i) : P(t)(t, e)
            }
        },
        96781: function(t, e, i) {
            i.d(e, {
                t: function() {
                    return n
                }
            });
            let n = (t, e, i) => t + (e - t) * i
        },
        46261: function(t, e, i) {
            i.d(e, {
                Y: function() {
                    return r
                }
            });
            var n = i(98650);

            function r(t) {
                let e = [0];
                return (0, n.c)(e, t.length - 1), e
            }
        },
        98650: function(t, e, i) {
            i.d(e, {
                c: function() {
                    return s
                }
            });
            var n = i(96781),
                r = i(76376);

            function s(t, e) {
                let i = t[t.length - 1];
                for (let s = 1; s <= e; s++) {
                    let o = (0, r.Y)(0, e, s);
                    t.push((0, n.t)(i, 1, o))
                }
            }
        },
        56920: function(t, e, i) {
            i.d(e, {
                z: function() {
                    return r
                }
            });
            let n = (t, e) => i => e(t(i)),
                r = (...t) => t.reduce(n)
        },
        76376: function(t, e, i) {
            i.d(e, {
                Y: function() {
                    return n
                }
            });
            let n = (t, e, i) => {
                let n = e - t;
                return 0 === n ? 1 : (i - t) / n
            }
        },
        4581: function(t, e, i) {
            i.d(e, {
                Y: function() {
                    return s
                },
                p: function() {
                    return r
                }
            });
            var n = i(44944);
            let r = t => !!(t && "object" == typeof t && t.mix && t.toValue),
                s = t => (0, n.C)(t) ? t[t.length - 1] || 0 : t
        },
        34081: function(t, e, i) {
            i.d(e, {
                L: function() {
                    return r
                }
            });
            var n = i(69013);
            class r {
                constructor() {
                    this.subscriptions = []
                }
                add(t) {
                    return (0, n.y4)(this.subscriptions, t), () => (0, n.cl)(this.subscriptions, t)
                }
                notify(t, e, i) {
                    let n = this.subscriptions.length;
                    if (n) {
                        if (1 === n) this.subscriptions[0](t, e, i);
                        else
                            for (let r = 0; r < n; r++) {
                                let n = this.subscriptions[r];
                                n && n(t, e, i)
                            }
                    }
                }
                getSize() {
                    return this.subscriptions.length
                }
                clear() {
                    this.subscriptions.length = 0
                }
            }
        },
        56717: function(t, e, i) {
            i.d(e, {
                X: function() {
                    return r
                },
                w: function() {
                    return n
                }
            });
            let n = t => 1e3 * t,
                r = t => t / 1e3
        },
        53576: function(t, e, i) {
            i.d(e, {
                h: function() {
                    return r
                }
            });
            var n = i(2265);

            function r(t) {
                let e = (0, n.useRef)(null);
                return null === e.current && (e.current = t()), e.current
            }
        },
        11534: function(t, e, i) {
            i.d(e, {
                L: function() {
                    return r
                }
            });
            var n = i(2265);
            let r = i(44563).j ? n.useLayoutEffect : n.useEffect
        },
        51116: function(t, e, i) {
            i.d(e, {
                R: function() {
                    return n
                }
            });

            function n(t, e) {
                return e ? 1e3 / e * t : 0
            }
        },
        3078: function(t, e, i) {
            i.d(e, {
                BX: function() {
                    return h
                }
            });
            var n = i(34081),
                r = i(51116),
                s = i(40504),
                o = i(45414);
            let a = t => !isNaN(parseFloat(t)),
                l = {
                    current: void 0
                };
            class u {
                constructor(t, e = {}) {
                    this.version = "11.14.4", this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (t, e = !0) => {
                        let i = s.X.now();
                        this.updatedAt !== i && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(t), this.current !== this.prev && this.events.change && this.events.change.notify(this.current), e && this.events.renderRequest && this.events.renderRequest.notify(this.current)
                    }, this.hasAnimated = !1, this.setCurrent(t), this.owner = e.owner
                }
                setCurrent(t) {
                    this.current = t, this.updatedAt = s.X.now(), null === this.canTrackVelocity && void 0 !== t && (this.canTrackVelocity = a(this.current))
                }
                setPrevFrameValue(t = this.current) {
                    this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt
                }
                onChange(t) {
                    return this.on("change", t)
                }
                on(t, e) {
                    this.events[t] || (this.events[t] = new n.L);
                    let i = this.events[t].add(e);
                    return "change" === t ? () => {
                        i(), o.Wi.read(() => {
                            this.events.change.getSize() || this.stop()
                        })
                    } : i
                }
                clearListeners() {
                    for (let t in this.events) this.events[t].clear()
                }
                attach(t, e) {
                    this.passiveEffect = t, this.stopPassiveEffect = e
                }
                set(t, e = !0) {
                    e && this.passiveEffect ? this.passiveEffect(t, this.updateAndNotify) : this.updateAndNotify(t, e)
                }
                setWithVelocity(t, e, i) {
                    this.set(e), this.prev = void 0, this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt - i
                }
                jump(t, e = !0) {
                    this.updateAndNotify(t), this.prev = t, this.prevUpdatedAt = this.prevFrameValue = void 0, e && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
                get() {
                    return l.current && l.current.push(this), this.current
                }
                getPrevious() {
                    return this.prev
                }
                getVelocity() {
                    let t = s.X.now();
                    if (!this.canTrackVelocity || void 0 === this.prevFrameValue || t - this.updatedAt > 30) return 0;
                    let e = Math.min(this.updatedAt - this.prevUpdatedAt, 30);
                    return (0, r.R)(parseFloat(this.current) - parseFloat(this.prevFrameValue), e)
                }
                start(t) {
                    return this.stop(), new Promise(e => {
                        this.hasAnimated = !0, this.animation = t(e), this.events.animationStart && this.events.animationStart.notify()
                    }).then(() => {
                        this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
                    })
                }
                stop() {
                    this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
                }
                isAnimating() {
                    return !!this.animation
                }
                clearAnimation() {
                    delete this.animation
                }
                destroy() {
                    this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
            }

            function h(t, e) {
                return new u(t, e)
            }
        },
        87325: function(t, e, i) {
            i.d(e, {
                $: function() {
                    return r
                }
            });
            var n = i(18859);
            let r = {
                test: (0, i(65516).i)("#"),
                parse: function(t) {
                    let e = "",
                        i = "",
                        n = "",
                        r = "";
                    return t.length > 5 ? (e = t.substring(1, 3), i = t.substring(3, 5), n = t.substring(5, 7), r = t.substring(7, 9)) : (e = t.substring(1, 2), i = t.substring(2, 3), n = t.substring(3, 4), r = t.substring(4, 5), e += e, i += i, n += n, r += r), {
                        red: parseInt(e, 16),
                        green: parseInt(i, 16),
                        blue: parseInt(n, 16),
                        alpha: r ? parseInt(r, 16) / 255 : 1
                    }
                },
                transform: n.m.transform
            }
        },
        92943: function(t, e, i) {
            i.d(e, {
                J: function() {
                    return a
                }
            });
            var n = i(74305),
                r = i(27492),
                s = i(15472),
                o = i(65516);
            let a = {
                test: (0, o.i)("hsl", "hue"),
                parse: (0, o.d)("hue", "saturation", "lightness"),
                transform: ({
                    hue: t,
                    saturation: e,
                    lightness: i,
                    alpha: o = 1
                }) => "hsla(" + Math.round(t) + ", " + r.aQ.transform((0, s.N)(e)) + ", " + r.aQ.transform((0, s.N)(i)) + ", " + (0, s.N)(n.Fq.transform(o)) + ")"
            }
        },
        33964: function(t, e, i) {
            i.d(e, {
                $: function() {
                    return o
                }
            });
            var n = i(87325),
                r = i(92943),
                s = i(18859);
            let o = {
                test: t => s.m.test(t) || n.$.test(t) || r.J.test(t),
                parse: t => s.m.test(t) ? s.m.parse(t) : r.J.test(t) ? r.J.parse(t) : n.$.parse(t),
                transform: t => "string" == typeof t ? t : t.hasOwnProperty("red") ? s.m.transform(t) : r.J.transform(t)
            }
        },
        18859: function(t, e, i) {
            i.d(e, {
                m: function() {
                    return u
                }
            });
            var n = i(59111),
                r = i(74305),
                s = i(15472),
                o = i(65516);
            let a = t => (0, n.u)(0, 255, t),
                l = { ...r.Rx,
                    transform: t => Math.round(a(t))
                },
                u = {
                    test: (0, o.i)("rgb", "red"),
                    parse: (0, o.d)("red", "green", "blue"),
                    transform: ({
                        red: t,
                        green: e,
                        blue: i,
                        alpha: n = 1
                    }) => "rgba(" + l.transform(t) + ", " + l.transform(e) + ", " + l.transform(i) + ", " + (0, s.N)(r.Fq.transform(n)) + ")"
                }
        },
        65516: function(t, e, i) {
            i.d(e, {
                i: function() {
                    return s
                },
                d: function() {
                    return o
                }
            });
            var n = i(66941);
            let r = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
                s = (t, e) => i => !!("string" == typeof i && r.test(i) && i.startsWith(t) || e && null != i && Object.prototype.hasOwnProperty.call(i, e)),
                o = (t, e, i) => r => {
                    if ("string" != typeof r) return r;
                    let [s, o, a, l] = r.match(n.K);
                    return {
                        [t]: parseFloat(s),
                        [e]: parseFloat(o),
                        [i]: parseFloat(a),
                        alpha: void 0 !== l ? parseFloat(l) : 1
                    }
                }
        },
        22779: function(t, e, i) {
            i.d(e, {
                h: function() {
                    return l
                }
            });
            var n = i(83206),
                r = i(66941);
            let s = new Set(["brightness", "contrast", "saturate", "opacity"]);

            function o(t) {
                let [e, i] = t.slice(0, -1).split("(");
                if ("drop-shadow" === e) return t;
                let [n] = i.match(r.K) || [];
                if (!n) return t;
                let o = i.replace(n, ""),
                    a = s.has(e) ? 1 : 0;
                return n !== i && (a *= 100), e + "(" + a + o + ")"
            }
            let a = /\b([a-z-]*)\(.*?\)/gu,
                l = { ...n.P,
                    getAnimatableNone: t => {
                        let e = t.match(a);
                        return e ? e.map(o).join(" ") : t
                    }
                }
        },
        83206: function(t, e, i) {
            i.d(e, {
                V: function() {
                    return h
                },
                P: function() {
                    return f
                }
            });
            var n = i(33964);
            let r = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
            var s = i(66941),
                o = i(15472);
            let a = "number",
                l = "color",
                u = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

            function h(t) {
                let e = t.toString(),
                    i = [],
                    r = {
                        color: [],
                        number: [],
                        var: []
                    },
                    s = [],
                    o = 0,
                    h = e.replace(u, t => (n.$.test(t) ? (r.color.push(o), s.push(l), i.push(n.$.parse(t))) : t.startsWith("var(") ? (r.var.push(o), s.push("var"), i.push(t)) : (r.number.push(o), s.push(a), i.push(parseFloat(t))), ++o, "${}")).split("${}");
                return {
                    values: i,
                    split: h,
                    indexes: r,
                    types: s
                }
            }

            function c(t) {
                return h(t).values
            }

            function d(t) {
                let {
                    split: e,
                    types: i
                } = h(t), r = e.length;
                return t => {
                    let s = "";
                    for (let u = 0; u < r; u++)
                        if (s += e[u], void 0 !== t[u]) {
                            let e = i[u];
                            e === a ? s += (0, o.N)(t[u]) : e === l ? s += n.$.transform(t[u]) : s += t[u]
                        }
                    return s
                }
            }
            let p = t => "number" == typeof t ? 0 : t,
                f = {
                    test: function(t) {
                        var e, i;
                        return isNaN(t) && "string" == typeof t && ((null === (e = t.match(s.K)) || void 0 === e ? void 0 : e.length) || 0) + ((null === (i = t.match(r)) || void 0 === i ? void 0 : i.length) || 0) > 0
                    },
                    parse: c,
                    createTransformer: d,
                    getAnimatableNone: function(t) {
                        let e = c(t);
                        return d(t)(e.map(p))
                    }
                }
        },
        74305: function(t, e, i) {
            i.d(e, {
                Fq: function() {
                    return s
                },
                Rx: function() {
                    return r
                },
                bA: function() {
                    return o
                }
            });
            var n = i(59111);
            let r = {
                    test: t => "number" == typeof t,
                    parse: parseFloat,
                    transform: t => t
                },
                s = { ...r,
                    transform: t => (0, n.u)(0, 1, t)
                },
                o = { ...r,
                    default: 1
                }
        },
        27492: function(t, e, i) {
            i.d(e, {
                $C: function() {
                    return u
                },
                RW: function() {
                    return r
                },
                aQ: function() {
                    return s
                },
                px: function() {
                    return o
                },
                vh: function() {
                    return a
                },
                vw: function() {
                    return l
                }
            });
            let n = t => ({
                    test: e => "string" == typeof e && e.endsWith(t) && 1 === e.split(" ").length,
                    parse: parseFloat,
                    transform: e => `${e}${t}`
                }),
                r = n("deg"),
                s = n("%"),
                o = n("px"),
                a = n("vh"),
                l = n("vw"),
                u = { ...s,
                    parse: t => s.parse(t) / 100,
                    transform: t => s.transform(100 * t)
                }
        },
        66941: function(t, e, i) {
            i.d(e, {
                K: function() {
                    return n
                }
            });
            let n = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu
        },
        15472: function(t, e, i) {
            i.d(e, {
                N: function() {
                    return n
                }
            });
            let n = t => Math.round(1e5 * t) / 1e5
        },
        1327: function(t, e, i) {
            i.d(e, {
                K: function() {
                    return r
                }
            });
            var n = i(23999);

            function r(t, e) {
                let i = t.getValue("willChange");
                if ((0, n.i)(i) && i.add) return i.add(e)
            }
        },
        23999: function(t, e, i) {
            i.d(e, {
                i: function() {
                    return n
                }
            });
            let n = t => !!(t && t.getVelocity)
        },
        41904: function(t, e, i) {
            i.d(e, {
                Mr: function() {
                    return a
                },
                DJ: function() {
                    return l
                },
                OD: function() {
                    return v
                },
                IG: function() {
                    return r
                },
                KV: function() {
                    return g
                }
            });
            let n = {
                x: !1,
                y: !1
            };

            function r(t, e, i) {
                var n;
                if (t instanceof Element) return [t];
                if ("string" == typeof t) {
                    let r = document;
                    e && (r = e.current);
                    let s = null !== (n = null == i ? void 0 : i[t]) && void 0 !== n ? n : r.querySelectorAll(t);
                    return s ? Array.from(s) : []
                }
                return Array.from(t)
            }

            function s(t, e) {
                let i = r(t),
                    n = new AbortController;
                return [i, {
                    passive: !0,
                    ...e,
                    signal: n.signal
                }, () => n.abort()]
            }

            function o(t) {
                return e => {
                    "touch" === e.pointerType || n.x || n.y || t(e)
                }
            }

            function a(t, e, i = {}) {
                let [n, r, a] = s(t, i), l = o(t => {
                    let {
                        target: i
                    } = t, n = e(t);
                    if (!n || !i) return;
                    let s = o(t => {
                        n(t), i.removeEventListener("pointerleave", s)
                    });
                    i.addEventListener("pointerleave", s, r)
                });
                return n.forEach(t => {
                    t.addEventListener("pointerenter", l, r)
                }), a
            }
            let l = t => "mouse" === t.pointerType ? "number" != typeof t.button || t.button <= 0 : !1 !== t.isPrimary,
                u = new WeakSet;

            function h(t) {
                return e => {
                    "Enter" === e.key && t(e)
                }
            }

            function c(t, e) {
                t.dispatchEvent(new PointerEvent("pointer" + e, {
                    isPrimary: !0,
                    bubbles: !0
                }))
            }
            let d = (t, e) => {
                    let i = t.currentTarget;
                    if (!i) return;
                    let n = h(() => {
                        if (u.has(i)) return;
                        c(i, "down");
                        let t = h(() => {
                            c(i, "up")
                        });
                        i.addEventListener("keyup", t, e), i.addEventListener("blur", () => c(i, "cancel"), e)
                    });
                    i.addEventListener("keydown", n, e), i.addEventListener("blur", () => i.removeEventListener("keydown", n), e)
                },
                p = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]),
                f = (t, e) => !!e && (t === e || f(t, e.parentElement));

            function m(t) {
                return l(t) && !(n.x || n.y)
            }

            function v(t, e, i = {}) {
                let [n, r, o] = s(t, i), a = t => {
                    let n = t.currentTarget;
                    if (!m(t) || u.has(n)) return;
                    u.add(n);
                    let s = e(t),
                        o = (t, e) => {
                            window.removeEventListener("pointerup", a), window.removeEventListener("pointercancel", l), m(t) && u.has(n) && (u.delete(n), s && s(t, {
                                success: e
                            }))
                        },
                        a = t => {
                            o(t, i.useGlobalTarget || f(n, t.target))
                        },
                        l = t => {
                            o(t, !1)
                        };
                    window.addEventListener("pointerup", a, r), window.addEventListener("pointercancel", l, r)
                };
                return n.forEach(t => {
                    p.has(t.tagName) || -1 !== t.tabIndex || (t.tabIndex = 0), (i.useGlobalTarget ? window : t).addEventListener("pointerdown", a, r), t.addEventListener("focus", t => d(t, r), r)
                }), o
            }

            function g(t) {
                return "x" === t || "y" === t ? n[t] ? null : (n[t] = !0, () => {
                    n[t] = !1
                }) : n.x || n.y ? null : (n.x = n.y = !0, () => {
                    n.x = n.y = !1
                })
            }
        },
        98751: function(t, e, i) {
            i.d(e, {
                K: function() {
                    return r
                },
                k: function() {
                    return s
                }
            });
            var n = i(56277);
            let r = n.Z,
                s = n.Z
        },
        56277: function(t, e, i) {
            i.d(e, {
                Z: function() {
                    return n
                }
            });
            let n = t => t
        }
    }
]);