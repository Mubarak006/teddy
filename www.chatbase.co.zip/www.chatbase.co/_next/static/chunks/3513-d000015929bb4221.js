"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3513], {
        71605: function(e, t, n) {
            n.d(t, {
                B: function() {
                    return f
                }
            });
            var r = n(2265),
                o = n(73966),
                l = n(98575),
                u = n(1119);
            let i = (0, r.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...o
                } = e, l = r.Children.toArray(n), i = l.find(s);
                if (i) {
                    let e = i.props.children,
                        n = l.map(t => t !== i ? t : r.Children.count(e) > 1 ? r.Children.only(null) : (0, r.isValidElement)(e) ? e.props.children : null);
                    return (0, r.createElement)(c, (0, u.Z)({}, o, {
                        ref: t
                    }), (0, r.isValidElement)(e) ? (0, r.cloneElement)(e, void 0, n) : null)
                }
                return (0, r.createElement)(c, (0, u.Z)({}, o, {
                    ref: t
                }), n)
            });
            i.displayName = "Slot";
            let c = (0, r.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...o
                } = e;
                return (0, r.isValidElement)(n) ? (0, r.cloneElement)(n, { ... function(e, t) {
                        let n = { ...t
                        };
                        for (let r in t) {
                            let o = e[r],
                                l = t[r];
                            /^on[A-Z]/.test(r) ? o && l ? n[r] = (...e) => {
                                l(...e), o(...e)
                            } : o && (n[r] = o) : "style" === r ? n[r] = { ...o,
                                ...l
                            } : "className" === r && (n[r] = [o, l].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...n
                        }
                    }(o, n.props),
                    ref: t ? (0, l.F)(t, n.ref) : n.ref
                }) : r.Children.count(n) > 1 ? r.Children.only(null) : null
            });
            c.displayName = "SlotClone";
            let a = ({
                children: e
            }) => (0, r.createElement)(r.Fragment, null, e);

            function s(e) {
                return (0, r.isValidElement)(e) && e.type === a
            }

            function f(e) {
                let t = e + "CollectionProvider",
                    [n, u] = (0, o.b)(t),
                    [c, a] = n(t, {
                        collectionRef: {
                            current: null
                        },
                        itemMap: new Map
                    }),
                    s = e + "CollectionSlot",
                    f = r.forwardRef((e, t) => {
                        let {
                            scope: n,
                            children: o
                        } = e, u = a(s, n), c = (0, l.e)(t, u.collectionRef);
                        return r.createElement(i, {
                            ref: c
                        }, o)
                    }),
                    d = e + "CollectionItemSlot",
                    m = "data-radix-collection-item";
                return [{
                    Provider: e => {
                        let {
                            scope: t,
                            children: n
                        } = e, o = r.useRef(null), l = r.useRef(new Map).current;
                        return r.createElement(c, {
                            scope: t,
                            itemMap: l,
                            collectionRef: o
                        }, n)
                    },
                    Slot: f,
                    ItemSlot: r.forwardRef((e, t) => {
                        let {
                            scope: n,
                            children: o,
                            ...u
                        } = e, c = r.useRef(null), s = (0, l.e)(t, c), f = a(d, n);
                        return r.useEffect(() => (f.itemMap.set(c, {
                            ref: c,
                            ...u
                        }), () => void f.itemMap.delete(c))), r.createElement(i, {
                            [m]: "",
                            ref: s
                        }, o)
                    })
                }, function(t) {
                    let n = a(e + "CollectionConsumer", t);
                    return r.useCallback(() => {
                        let e = n.collectionRef.current;
                        if (!e) return [];
                        let t = Array.from(e.querySelectorAll(`[${m}]`));
                        return Array.from(n.itemMap.values()).sort((e, n) => t.indexOf(e.ref.current) - t.indexOf(n.ref.current))
                    }, [n.collectionRef, n.itemMap])
                }, u]
            }
        },
        29114: function(e, t, n) {
            n.d(t, {
                gm: function() {
                    return l
                }
            });
            var r = n(2265);
            let o = (0, r.createContext)(void 0);

            function l(e) {
                let t = (0, r.useContext)(o);
                return e || t || "ltr"
            }
        },
        71599: function(e, t, n) {
            n.d(t, {
                z: function() {
                    return i
                }
            });
            var r = n(2265),
                o = n(54887),
                l = n(98575),
                u = n(61188);
            let i = e => {
                let {
                    present: t,
                    children: n
                } = e, i = function(e) {
                    var t, n;
                    let [l, i] = (0, r.useState)(), a = (0, r.useRef)({}), s = (0, r.useRef)(e), f = (0, r.useRef)("none"), [d, m] = (t = e ? "mounted" : "unmounted", n = {
                        mounted: {
                            UNMOUNT: "unmounted",
                            ANIMATION_OUT: "unmountSuspended"
                        },
                        unmountSuspended: {
                            MOUNT: "mounted",
                            ANIMATION_END: "unmounted"
                        },
                        unmounted: {
                            MOUNT: "mounted"
                        }
                    }, (0, r.useReducer)((e, t) => {
                        let r = n[e][t];
                        return null != r ? r : e
                    }, t));
                    return (0, r.useEffect)(() => {
                        let e = c(a.current);
                        f.current = "mounted" === d ? e : "none"
                    }, [d]), (0, u.b)(() => {
                        let t = a.current,
                            n = s.current;
                        if (n !== e) {
                            let r = f.current,
                                o = c(t);
                            e ? m("MOUNT") : "none" === o || (null == t ? void 0 : t.display) === "none" ? m("UNMOUNT") : n && r !== o ? m("ANIMATION_OUT") : m("UNMOUNT"), s.current = e
                        }
                    }, [e, m]), (0, u.b)(() => {
                        if (l) {
                            let e = e => {
                                    let t = c(a.current).includes(e.animationName);
                                    e.target === l && t && (0, o.flushSync)(() => m("ANIMATION_END"))
                                },
                                t = e => {
                                    e.target === l && (f.current = c(a.current))
                                };
                            return l.addEventListener("animationstart", t), l.addEventListener("animationcancel", e), l.addEventListener("animationend", e), () => {
                                l.removeEventListener("animationstart", t), l.removeEventListener("animationcancel", e), l.removeEventListener("animationend", e)
                            }
                        }
                        m("ANIMATION_END")
                    }, [l, m]), {
                        isPresent: ["mounted", "unmountSuspended"].includes(d),
                        ref: (0, r.useCallback)(e => {
                            e && (a.current = getComputedStyle(e)), i(e)
                        }, [])
                    }
                }(t), a = "function" == typeof n ? n({
                    present: i.isPresent
                }) : r.Children.only(n), s = (0, l.e)(i.ref, a.ref);
                return "function" == typeof n || i.isPresent ? (0, r.cloneElement)(a, {
                    ref: s
                }) : null
            };

            function c(e) {
                return (null == e ? void 0 : e.animationName) || "none"
            }
            i.displayName = "Presence"
        },
        1353: function(e, t, n) {
            n.d(t, {
                Pc: function() {
                    return I
                },
                ck: function() {
                    return F
                },
                fC: function() {
                    return S
                }
            });
            var r = n(1119),
                o = n(2265),
                l = n(6741),
                u = n(71605),
                i = n(98575),
                c = n(73966),
                a = n(99255),
                s = n(82912),
                f = n(26606),
                d = n(80886),
                m = n(29114);
            let p = "rovingFocusGroup.onEntryFocus",
                v = {
                    bubbles: !1,
                    cancelable: !0
                },
                E = "RovingFocusGroup",
                [b, w, R] = (0, u.B)(E),
                [h, I] = (0, c.b)(E, [R]),
                [M, N] = h(E),
                A = (0, o.forwardRef)((e, t) => (0, o.createElement)(b.Provider, {
                    scope: e.__scopeRovingFocusGroup
                }, (0, o.createElement)(b.Slot, {
                    scope: e.__scopeRovingFocusGroup
                }, (0, o.createElement)(C, (0, r.Z)({}, e, {
                    ref: t
                }))))),
                C = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeRovingFocusGroup: n,
                        orientation: u,
                        loop: c = !1,
                        dir: a,
                        currentTabStopId: E,
                        defaultCurrentTabStopId: b,
                        onCurrentTabStopIdChange: R,
                        onEntryFocus: h,
                        ...I
                    } = e, N = (0, o.useRef)(null), A = (0, i.e)(t, N), C = (0, m.gm)(a), [g = null, T] = (0, d.T)({
                        prop: E,
                        defaultProp: b,
                        onChange: R
                    }), [S, F] = (0, o.useState)(!1), _ = (0, f.W)(h), O = w(n), D = (0, o.useRef)(!1), [U, k] = (0, o.useState)(0);
                    return (0, o.useEffect)(() => {
                        let e = N.current;
                        if (e) return e.addEventListener(p, _), () => e.removeEventListener(p, _)
                    }, [_]), (0, o.createElement)(M, {
                        scope: n,
                        orientation: u,
                        dir: C,
                        loop: c,
                        currentTabStopId: g,
                        onItemFocus: (0, o.useCallback)(e => T(e), [T]),
                        onItemShiftTab: (0, o.useCallback)(() => F(!0), []),
                        onFocusableItemAdd: (0, o.useCallback)(() => k(e => e + 1), []),
                        onFocusableItemRemove: (0, o.useCallback)(() => k(e => e - 1), [])
                    }, (0, o.createElement)(s.WV.div, (0, r.Z)({
                        tabIndex: S || 0 === U ? -1 : 0,
                        "data-orientation": u
                    }, I, {
                        ref: A,
                        style: {
                            outline: "none",
                            ...e.style
                        },
                        onMouseDown: (0, l.M)(e.onMouseDown, () => {
                            D.current = !0
                        }),
                        onFocus: (0, l.M)(e.onFocus, e => {
                            let t = !D.current;
                            if (e.target === e.currentTarget && t && !S) {
                                let t = new CustomEvent(p, v);
                                if (e.currentTarget.dispatchEvent(t), !t.defaultPrevented) {
                                    let e = O().filter(e => e.focusable);
                                    y([e.find(e => e.active), e.find(e => e.id === g), ...e].filter(Boolean).map(e => e.ref.current))
                                }
                            }
                            D.current = !1
                        }),
                        onBlur: (0, l.M)(e.onBlur, () => F(!1))
                    })))
                }),
                g = (0, o.forwardRef)((e, t) => {
                    let {
                        __scopeRovingFocusGroup: n,
                        focusable: u = !0,
                        active: i = !1,
                        tabStopId: c,
                        ...f
                    } = e, d = (0, a.M)(), m = c || d, p = N("RovingFocusGroupItem", n), v = p.currentTabStopId === m, E = w(n), {
                        onFocusableItemAdd: R,
                        onFocusableItemRemove: h
                    } = p;
                    return (0, o.useEffect)(() => {
                        if (u) return R(), () => h()
                    }, [u, R, h]), (0, o.createElement)(b.ItemSlot, {
                        scope: n,
                        id: m,
                        focusable: u,
                        active: i
                    }, (0, o.createElement)(s.WV.span, (0, r.Z)({
                        tabIndex: v ? 0 : -1,
                        "data-orientation": p.orientation
                    }, f, {
                        ref: t,
                        onMouseDown: (0, l.M)(e.onMouseDown, e => {
                            u ? p.onItemFocus(m) : e.preventDefault()
                        }),
                        onFocus: (0, l.M)(e.onFocus, () => p.onItemFocus(m)),
                        onKeyDown: (0, l.M)(e.onKeyDown, e => {
                            if ("Tab" === e.key && e.shiftKey) {
                                p.onItemShiftTab();
                                return
                            }
                            if (e.target !== e.currentTarget) return;
                            let t = function(e, t, n) {
                                var r;
                                let o = (r = e.key, "rtl" !== n ? r : "ArrowLeft" === r ? "ArrowRight" : "ArrowRight" === r ? "ArrowLeft" : r);
                                if (!("vertical" === t && ["ArrowLeft", "ArrowRight"].includes(o)) && !("horizontal" === t && ["ArrowUp", "ArrowDown"].includes(o))) return T[o]
                            }(e, p.orientation, p.dir);
                            if (void 0 !== t) {
                                e.preventDefault();
                                let o = E().filter(e => e.focusable).map(e => e.ref.current);
                                if ("last" === t) o.reverse();
                                else if ("prev" === t || "next" === t) {
                                    var n, r;
                                    "prev" === t && o.reverse();
                                    let l = o.indexOf(e.currentTarget);
                                    o = p.loop ? (n = o, r = l + 1, n.map((e, t) => n[(r + t) % n.length])) : o.slice(l + 1)
                                }
                                setTimeout(() => y(o))
                            }
                        })
                    })))
                }),
                T = {
                    ArrowLeft: "prev",
                    ArrowUp: "prev",
                    ArrowRight: "next",
                    ArrowDown: "next",
                    PageUp: "first",
                    Home: "first",
                    PageDown: "last",
                    End: "last"
                };

            function y(e) {
                let t = document.activeElement;
                for (let n of e)
                    if (n === t || (n.focus(), document.activeElement !== t)) return
            }
            let S = A,
                F = g
        }
    }
]);