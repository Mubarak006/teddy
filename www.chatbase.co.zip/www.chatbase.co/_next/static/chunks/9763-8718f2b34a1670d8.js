"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9763], {
        3392: function(t, e, i) {
            i.d(e, {
                j: function() {
                    return r
                }
            });
            var n = i(24112),
                s = i(45345),
                r = new class extends n.l {#
                    t;#
                    e;#
                    i;
                    constructor() {
                        super(), this.#i = t => {
                            if (!s.sk && window.addEventListener) {
                                let e = () => t();
                                return window.addEventListener("visibilitychange", e, !1), () => {
                                    window.removeEventListener("visibilitychange", e)
                                }
                            }
                        }
                    }
                    onSubscribe() {
                        this.#e || this.setEventListener(this.#i)
                    }
                    onUnsubscribe() {
                        this.hasListeners() || (this.#e ? .(), this.#e = void 0)
                    }
                    setEventListener(t) {
                        this.#i = t, this.#e ? .(), this.#e = t(t => {
                            "boolean" == typeof t ? this.setFocused(t) : this.onFocus()
                        })
                    }
                    setFocused(t) {
                        this.#t !== t && (this.#t = t, this.onFocus())
                    }
                    onFocus() {
                        let t = this.isFocused();
                        this.listeners.forEach(e => {
                            e(t)
                        })
                    }
                    isFocused() {
                        return "boolean" == typeof this.#t ? this.#t : globalThis.document ? .visibilityState !== "hidden"
                    }
                }
        },
        18238: function(t, e, i) {
            i.d(e, {
                V: function() {
                    return n
                }
            });
            var n = function() {
                let t = [],
                    e = 0,
                    i = t => {
                        t()
                    },
                    n = t => {
                        t()
                    },
                    s = t => setTimeout(t, 0),
                    r = n => {
                        e ? t.push(n) : s(() => {
                            i(n)
                        })
                    },
                    o = () => {
                        let e = t;
                        t = [], e.length && s(() => {
                            n(() => {
                                e.forEach(t => {
                                    i(t)
                                })
                            })
                        })
                    };
                return {
                    batch: t => {
                        let i;
                        e++;
                        try {
                            i = t()
                        } finally {
                            --e || o()
                        }
                        return i
                    },
                    batchCalls: t => (...e) => {
                        r(() => {
                            t(...e)
                        })
                    },
                    schedule: r,
                    setNotifyFunction: t => {
                        i = t
                    },
                    setBatchNotifyFunction: t => {
                        n = t
                    },
                    setScheduler: t => {
                        s = t
                    }
                }
            }()
        },
        57853: function(t, e, i) {
            i.d(e, {
                N: function() {
                    return r
                }
            });
            var n = i(24112),
                s = i(45345),
                r = new class extends n.l {#
                    n = !0;#
                    e;#
                    i;
                    constructor() {
                        super(), this.#i = t => {
                            if (!s.sk && window.addEventListener) {
                                let e = () => t(!0),
                                    i = () => t(!1);
                                return window.addEventListener("online", e, !1), window.addEventListener("offline", i, !1), () => {
                                    window.removeEventListener("online", e), window.removeEventListener("offline", i)
                                }
                            }
                        }
                    }
                    onSubscribe() {
                        this.#e || this.setEventListener(this.#i)
                    }
                    onUnsubscribe() {
                        this.hasListeners() || (this.#e ? .(), this.#e = void 0)
                    }
                    setEventListener(t) {
                        this.#i = t, this.#e ? .(), this.#e = t(this.setOnline.bind(this))
                    }
                    setOnline(t) {
                        this.#n !== t && (this.#n = t, this.listeners.forEach(e => {
                            e(t)
                        }))
                    }
                    isOnline() {
                        return this.#n
                    }
                }
        },
        21733: function(t, e, i) {
            i.d(e, {
                A: function() {
                    return u
                },
                z: function() {
                    return a
                }
            });
            var n = i(45345),
                s = i(18238),
                r = i(11255),
                o = i(7989),
                u = class extends o.F {#
                    s;#
                    r;#
                    o;#
                    u;#
                    a;#
                    c;
                    constructor(t) {
                        super(), this.#c = !1, this.#a = t.defaultOptions, this.setOptions(t.options), this.observers = [], this.#o = t.cache, this.queryKey = t.queryKey, this.queryHash = t.queryHash, this.#s = function(t) {
                            let e = "function" == typeof t.initialData ? t.initialData() : t.initialData,
                                i = void 0 !== e,
                                n = i ? "function" == typeof t.initialDataUpdatedAt ? t.initialDataUpdatedAt() : t.initialDataUpdatedAt : 0;
                            return {
                                data: e,
                                dataUpdateCount: 0,
                                dataUpdatedAt: i ? n ? ? Date.now() : 0,
                                error: null,
                                errorUpdateCount: 0,
                                errorUpdatedAt: 0,
                                fetchFailureCount: 0,
                                fetchFailureReason: null,
                                fetchMeta: null,
                                isInvalidated: !1,
                                status: i ? "success" : "pending",
                                fetchStatus: "idle"
                            }
                        }(this.options), this.state = t.state ? ? this.#s, this.scheduleGc()
                    }
                    get meta() {
                        return this.options.meta
                    }
                    get promise() {
                        return this.#u ? .promise
                    }
                    setOptions(t) {
                        this.options = { ...this.#a,
                            ...t
                        }, this.updateGcTime(this.options.gcTime)
                    }
                    optionalRemove() {
                        this.observers.length || "idle" !== this.state.fetchStatus || this.#o.remove(this)
                    }
                    setData(t, e) {
                        let i = (0, n.oE)(this.state.data, t, this.options);
                        return this.#h({
                            data: i,
                            type: "success",
                            dataUpdatedAt: e ? .updatedAt,
                            manual: e ? .manual
                        }), i
                    }
                    setState(t, e) {
                        this.#h({
                            type: "setState",
                            state: t,
                            setStateOptions: e
                        })
                    }
                    cancel(t) {
                        let e = this.#u ? .promise;
                        return this.#u ? .cancel(t), e ? e.then(n.ZT).catch(n.ZT) : Promise.resolve()
                    }
                    destroy() {
                        super.destroy(), this.cancel({
                            silent: !0
                        })
                    }
                    reset() {
                        this.destroy(), this.setState(this.#s)
                    }
                    isActive() {
                        return this.observers.some(t => !1 !== (0, n.Nc)(t.options.enabled, this))
                    }
                    isDisabled() {
                        return this.getObserversCount() > 0 && !this.isActive()
                    }
                    isStale() {
                        return !!this.state.isInvalidated || (this.getObserversCount() > 0 ? this.observers.some(t => t.getCurrentResult().isStale) : void 0 === this.state.data)
                    }
                    isStaleByTime(t = 0) {
                        return this.state.isInvalidated || void 0 === this.state.data || !(0, n.Kp)(this.state.dataUpdatedAt, t)
                    }
                    onFocus() {
                        let t = this.observers.find(t => t.shouldFetchOnWindowFocus());
                        t ? .refetch({
                            cancelRefetch: !1
                        }), this.#u ? .continue()
                    }
                    onOnline() {
                        let t = this.observers.find(t => t.shouldFetchOnReconnect());
                        t ? .refetch({
                            cancelRefetch: !1
                        }), this.#u ? .continue()
                    }
                    addObserver(t) {
                        this.observers.includes(t) || (this.observers.push(t), this.clearGcTimeout(), this.#o.notify({
                            type: "observerAdded",
                            query: this,
                            observer: t
                        }))
                    }
                    removeObserver(t) {
                        this.observers.includes(t) && (this.observers = this.observers.filter(e => e !== t), this.observers.length || (this.#u && (this.#c ? this.#u.cancel({
                            revert: !0
                        }) : this.#u.cancelRetry()), this.scheduleGc()), this.#o.notify({
                            type: "observerRemoved",
                            query: this,
                            observer: t
                        }))
                    }
                    getObserversCount() {
                        return this.observers.length
                    }
                    invalidate() {
                        this.state.isInvalidated || this.#h({
                            type: "invalidate"
                        })
                    }
                    fetch(t, e) {
                        if ("idle" !== this.state.fetchStatus) {
                            if (void 0 !== this.state.data && e ? .cancelRefetch) this.cancel({
                                silent: !0
                            });
                            else if (this.#u) return this.#u.continueRetry(), this.#u.promise
                        }
                        if (t && this.setOptions(t), !this.options.queryFn) {
                            let t = this.observers.find(t => t.options.queryFn);
                            t && this.setOptions(t.options)
                        }
                        let i = new AbortController,
                            s = t => {
                                Object.defineProperty(t, "signal", {
                                    enumerable: !0,
                                    get: () => (this.#c = !0, i.signal)
                                })
                            },
                            o = {
                                fetchOptions: e,
                                options: this.options,
                                queryKey: this.queryKey,
                                state: this.state,
                                fetchFn: () => {
                                    let t = (0, n.cG)(this.options, e),
                                        i = {
                                            queryKey: this.queryKey,
                                            meta: this.meta
                                        };
                                    return (s(i), this.#c = !1, this.options.persister) ? this.options.persister(t, i, this) : t(i)
                                }
                            };
                        s(o), this.options.behavior ? .onFetch(o, this), this.#r = this.state, ("idle" === this.state.fetchStatus || this.state.fetchMeta !== o.fetchOptions ? .meta) && this.#h({
                            type: "fetch",
                            meta: o.fetchOptions ? .meta
                        });
                        let u = t => {
                            (0, r.DV)(t) && t.silent || this.#h({
                                type: "error",
                                error: t
                            }), (0, r.DV)(t) || (this.#o.config.onError ? .(t, this), this.#o.config.onSettled ? .(this.state.data, t, this)), this.isFetchingOptimistic || this.scheduleGc(), this.isFetchingOptimistic = !1
                        };
                        return this.#u = (0, r.Mz)({
                            initialPromise: e ? .initialPromise,
                            fn: o.fetchFn,
                            abort: i.abort.bind(i),
                            onSuccess: t => {
                                if (void 0 === t) {
                                    u(Error(`${this.queryHash} data is undefined`));
                                    return
                                }
                                try {
                                    this.setData(t)
                                } catch (t) {
                                    u(t);
                                    return
                                }
                                this.#o.config.onSuccess ? .(t, this), this.#o.config.onSettled ? .(t, this.state.error, this), this.isFetchingOptimistic || this.scheduleGc(), this.isFetchingOptimistic = !1
                            },
                            onError: u,
                            onFail: (t, e) => {
                                this.#h({
                                    type: "failed",
                                    failureCount: t,
                                    error: e
                                })
                            },
                            onPause: () => {
                                this.#h({
                                    type: "pause"
                                })
                            },
                            onContinue: () => {
                                this.#h({
                                    type: "continue"
                                })
                            },
                            retry: o.options.retry,
                            retryDelay: o.options.retryDelay,
                            networkMode: o.options.networkMode,
                            canRun: () => !0
                        }), this.#u.start()
                    }#
                    h(t) {
                        this.state = (e => {
                            switch (t.type) {
                                case "failed":
                                    return { ...e,
                                        fetchFailureCount: t.failureCount,
                                        fetchFailureReason: t.error
                                    };
                                case "pause":
                                    return { ...e,
                                        fetchStatus: "paused"
                                    };
                                case "continue":
                                    return { ...e,
                                        fetchStatus: "fetching"
                                    };
                                case "fetch":
                                    return { ...e,
                                        ...a(e.data, this.options),
                                        fetchMeta: t.meta ? ? null
                                    };
                                case "success":
                                    return { ...e,
                                        data: t.data,
                                        dataUpdateCount: e.dataUpdateCount + 1,
                                        dataUpdatedAt: t.dataUpdatedAt ? ? Date.now(),
                                        error: null,
                                        isInvalidated: !1,
                                        status: "success",
                                        ...!t.manual && {
                                            fetchStatus: "idle",
                                            fetchFailureCount: 0,
                                            fetchFailureReason: null
                                        }
                                    };
                                case "error":
                                    let i = t.error;
                                    if ((0, r.DV)(i) && i.revert && this.#r) return { ...this.#r,
                                        fetchStatus: "idle"
                                    };
                                    return { ...e,
                                        error: i,
                                        errorUpdateCount: e.errorUpdateCount + 1,
                                        errorUpdatedAt: Date.now(),
                                        fetchFailureCount: e.fetchFailureCount + 1,
                                        fetchFailureReason: i,
                                        fetchStatus: "idle",
                                        status: "error"
                                    };
                                case "invalidate":
                                    return { ...e,
                                        isInvalidated: !0
                                    };
                                case "setState":
                                    return { ...e,
                                        ...t.state
                                    }
                            }
                        })(this.state), s.V.batch(() => {
                            this.observers.forEach(t => {
                                t.onQueryUpdate()
                            }), this.#o.notify({
                                query: this,
                                type: "updated",
                                action: t
                            })
                        })
                    }
                };

            function a(t, e) {
                return {
                    fetchFailureCount: 0,
                    fetchFailureReason: null,
                    fetchStatus: (0, r.Kw)(e.networkMode) ? "fetching" : "paused",
                    ...void 0 === t && {
                        error: null,
                        status: "pending"
                    }
                }
            }
        },
        7989: function(t, e, i) {
            i.d(e, {
                F: function() {
                    return s
                }
            });
            var n = i(45345),
                s = class {#
                    l;
                    destroy() {
                        this.clearGcTimeout()
                    }
                    scheduleGc() {
                        this.clearGcTimeout(), (0, n.PN)(this.gcTime) && (this.#l = setTimeout(() => {
                            this.optionalRemove()
                        }, this.gcTime))
                    }
                    updateGcTime(t) {
                        this.gcTime = Math.max(this.gcTime || 0, t ? ? (n.sk ? 1 / 0 : 3e5))
                    }
                    clearGcTimeout() {
                        this.#l && (clearTimeout(this.#l), this.#l = void 0)
                    }
                }
        },
        11255: function(t, e, i) {
            i.d(e, {
                DV: function() {
                    return c
                },
                Kw: function() {
                    return u
                },
                Mz: function() {
                    return h
                }
            });
            var n = i(3392),
                s = i(57853),
                r = i(45345);

            function o(t) {
                return Math.min(1e3 * 2 ** t, 3e4)
            }

            function u(t) {
                return (t ? ? "online") !== "online" || s.N.isOnline()
            }
            var a = class extends Error {
                constructor(t) {
                    super("CancelledError"), this.revert = t ? .revert, this.silent = t ? .silent
                }
            };

            function c(t) {
                return t instanceof a
            }

            function h(t) {
                let e, i, c, h = !1,
                    l = 0,
                    f = !1,
                    d = new Promise((t, e) => {
                        i = t, c = e
                    }),
                    p = () => n.j.isFocused() && ("always" === t.networkMode || s.N.isOnline()) && t.canRun(),
                    y = () => u(t.networkMode) && t.canRun(),
                    v = n => {
                        f || (f = !0, t.onSuccess ? .(n), e ? .(), i(n))
                    },
                    b = i => {
                        f || (f = !0, t.onError ? .(i), e ? .(), c(i))
                    },
                    m = () => new Promise(i => {
                        e = t => {
                            (f || p()) && i(t)
                        }, t.onPause ? .()
                    }).then(() => {
                        e = void 0, f || t.onContinue ? .()
                    }),
                    g = () => {
                        let e;
                        if (f) return;
                        let i = 0 === l ? t.initialPromise : void 0;
                        try {
                            e = i ? ? t.fn()
                        } catch (t) {
                            e = Promise.reject(t)
                        }
                        Promise.resolve(e).then(v).catch(e => {
                            if (f) return;
                            let i = t.retry ? ? (r.sk ? 0 : 3),
                                n = t.retryDelay ? ? o,
                                s = "function" == typeof n ? n(l, e) : n,
                                u = !0 === i || "number" == typeof i && l < i || "function" == typeof i && i(l, e);
                            if (h || !u) {
                                b(e);
                                return
                            }
                            l++, t.onFail ? .(l, e), (0, r._v)(s).then(() => p() ? void 0 : m()).then(() => {
                                h ? b(e) : g()
                            })
                        })
                    };
                return {
                    promise: d,
                    cancel: e => {
                        f || (b(new a(e)), t.abort ? .())
                    },
                    continue: () => (e ? .(), d),
                    cancelRetry: () => {
                        h = !0
                    },
                    continueRetry: () => {
                        h = !1
                    },
                    canStart: y,
                    start: () => (y() ? g() : m().then(g), d)
                }
            }
        },
        24112: function(t, e, i) {
            i.d(e, {
                l: function() {
                    return n
                }
            });
            var n = class {
                constructor() {
                    this.listeners = new Set, this.subscribe = this.subscribe.bind(this)
                }
                subscribe(t) {
                    return this.listeners.add(t), this.onSubscribe(), () => {
                        this.listeners.delete(t), this.onUnsubscribe()
                    }
                }
                hasListeners() {
                    return this.listeners.size > 0
                }
                onSubscribe() {}
                onUnsubscribe() {}
            }
        },
        45345: function(t, e, i) {
            i.d(e, {
                CN: function() {
                    return E
                },
                Ht: function() {
                    return C
                },
                KC: function() {
                    return a
                },
                Kp: function() {
                    return u
                },
                Nc: function() {
                    return c
                },
                PN: function() {
                    return o
                },
                Q$: function() {
                    return y
                },
                Rm: function() {
                    return f
                },
                SE: function() {
                    return r
                },
                VS: function() {
                    return v
                },
                VX: function() {
                    return O
                },
                Wk: function() {
                    return F
                },
                X7: function() {
                    return l
                },
                Ym: function() {
                    return d
                },
                ZT: function() {
                    return s
                },
                _v: function() {
                    return S
                },
                _x: function() {
                    return h
                },
                cG: function() {
                    return T
                },
                oE: function() {
                    return w
                },
                sk: function() {
                    return n
                },
                to: function() {
                    return p
                }
            });
            var n = "undefined" == typeof window || "Deno" in globalThis;

            function s() {}

            function r(t, e) {
                return "function" == typeof t ? t(e) : t
            }

            function o(t) {
                return "number" == typeof t && t >= 0 && t !== 1 / 0
            }

            function u(t, e) {
                return Math.max(t + (e || 0) - Date.now(), 0)
            }

            function a(t, e) {
                return "function" == typeof t ? t(e) : t
            }

            function c(t, e) {
                return "function" == typeof t ? t(e) : t
            }

            function h(t, e) {
                let {
                    type: i = "all",
                    exact: n,
                    fetchStatus: s,
                    predicate: r,
                    queryKey: o,
                    stale: u
                } = t;
                if (o) {
                    if (n) {
                        if (e.queryHash !== f(o, e.options)) return !1
                    } else if (!p(e.queryKey, o)) return !1
                }
                if ("all" !== i) {
                    let t = e.isActive();
                    if ("active" === i && !t || "inactive" === i && t) return !1
                }
                return ("boolean" != typeof u || e.isStale() === u) && (!s || s === e.state.fetchStatus) && (!r || !!r(e))
            }

            function l(t, e) {
                let {
                    exact: i,
                    status: n,
                    predicate: s,
                    mutationKey: r
                } = t;
                if (r) {
                    if (!e.options.mutationKey) return !1;
                    if (i) {
                        if (d(e.options.mutationKey) !== d(r)) return !1
                    } else if (!p(e.options.mutationKey, r)) return !1
                }
                return (!n || e.state.status === n) && (!s || !!s(e))
            }

            function f(t, e) {
                return (e ? .queryKeyHashFn || d)(t)
            }

            function d(t) {
                return JSON.stringify(t, (t, e) => m(e) ? Object.keys(e).sort().reduce((t, i) => (t[i] = e[i], t), {}) : e)
            }

            function p(t, e) {
                return t === e || typeof t == typeof e && !!t && !!e && "object" == typeof t && "object" == typeof e && !Object.keys(e).some(i => !p(t[i], e[i]))
            }

            function y(t, e) {
                if (t === e) return t;
                let i = b(t) && b(e);
                if (i || m(t) && m(e)) {
                    let n = i ? t : Object.keys(t),
                        s = n.length,
                        r = i ? e : Object.keys(e),
                        o = r.length,
                        u = i ? [] : {},
                        a = 0;
                    for (let s = 0; s < o; s++) {
                        let o = i ? s : r[s];
                        (!i && n.includes(o) || i) && void 0 === t[o] && void 0 === e[o] ? (u[o] = void 0, a++) : (u[o] = y(t[o], e[o]), u[o] === t[o] && void 0 !== t[o] && a++)
                    }
                    return s === o && a === s ? t : u
                }
                return e
            }

            function v(t, e) {
                if (!e || Object.keys(t).length !== Object.keys(e).length) return !1;
                for (let i in t)
                    if (t[i] !== e[i]) return !1;
                return !0
            }

            function b(t) {
                return Array.isArray(t) && t.length === Object.keys(t).length
            }

            function m(t) {
                if (!g(t)) return !1;
                let e = t.constructor;
                if (void 0 === e) return !0;
                let i = e.prototype;
                return !!(g(i) && i.hasOwnProperty("isPrototypeOf")) && Object.getPrototypeOf(t) === Object.prototype
            }

            function g(t) {
                return "[object Object]" === Object.prototype.toString.call(t)
            }

            function S(t) {
                return new Promise(e => {
                    setTimeout(e, t)
                })
            }

            function w(t, e, i) {
                return "function" == typeof i.structuralSharing ? i.structuralSharing(t, e) : !1 !== i.structuralSharing ? y(t, e) : e
            }

            function F(t) {
                return t
            }

            function O(t, e, i = 0) {
                let n = [...t, e];
                return i && n.length > i ? n.slice(1) : n
            }

            function C(t, e, i = 0) {
                let n = [e, ...t];
                return i && n.length > i ? n.slice(0, -1) : n
            }
            var E = Symbol();

            function T(t, e) {
                return !t.queryFn && e ? .initialPromise ? () => e.initialPromise : t.queryFn && t.queryFn !== E ? t.queryFn : () => Promise.reject(Error(`Missing queryFn: '${t.queryHash}'`))
            }
        },
        29827: function(t, e, i) {
            i.r(e), i.d(e, {
                QueryClientContext: function() {
                    return r
                },
                QueryClientProvider: function() {
                    return u
                },
                useQueryClient: function() {
                    return o
                }
            });
            var n = i(2265),
                s = i(57437),
                r = n.createContext(void 0),
                o = t => {
                    let e = n.useContext(r);
                    if (t) return t;
                    if (!e) throw Error("No QueryClient set, use QueryClientProvider to set one");
                    return e
                },
                u = t => {
                    let {
                        client: e,
                        children: i
                    } = t;
                    return n.useEffect(() => (e.mount(), () => {
                        e.unmount()
                    }), [e]), (0, s.jsx)(r.Provider, {
                        value: e,
                        children: i
                    })
                }
        }
    }
]);