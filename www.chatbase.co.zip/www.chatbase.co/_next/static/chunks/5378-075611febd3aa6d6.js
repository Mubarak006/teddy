"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5378], {
        79205: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return c
                }
            });
            var r = n(2265);
            let u = e => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(),
                l = function() {
                    for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                    return t.filter((e, t, n) => !!e && n.indexOf(e) === t).join(" ")
                };
            var o = {
                xmlns: "http://www.w3.org/2000/svg",
                width: 24,
                height: 24,
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: 2,
                strokeLinecap: "round",
                strokeLinejoin: "round"
            };
            let i = (0, r.forwardRef)((e, t) => {
                    let {
                        color: n = "currentColor",
                        size: u = 24,
                        strokeWidth: i = 2,
                        absoluteStrokeWidth: c,
                        className: a = "",
                        children: f,
                        iconNode: s,
                        ...d
                    } = e;
                    return (0, r.createElement)("svg", {
                        ref: t,
                        ...o,
                        width: u,
                        height: u,
                        stroke: n,
                        strokeWidth: c ? 24 * Number(i) / Number(u) : i,
                        className: l("lucide", a),
                        ...d
                    }, [...s.map(e => {
                        let [t, n] = e;
                        return (0, r.createElement)(t, n)
                    }), ...Array.isArray(f) ? f : [f]])
                }),
                c = (e, t) => {
                    let n = (0, r.forwardRef)((n, o) => {
                        let {
                            className: c,
                            ...a
                        } = n;
                        return (0, r.createElement)(i, {
                            ref: o,
                            iconNode: t,
                            className: l("lucide-".concat(u(e)), c),
                            ...a
                        })
                    });
                    return n.displayName = "".concat(e), n
                }
        },
        1119: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return r
                }
            });

            function r() {
                return (r = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
        },
        6741: function(e, t, n) {
            n.d(t, {
                M: function() {
                    return r
                }
            });

            function r(e, t, {
                checkForDefaultPrevented: n = !0
            } = {}) {
                return function(r) {
                    if (null == e || e(r), !1 === n || !r.defaultPrevented) return null == t ? void 0 : t(r)
                }
            }
        },
        98575: function(e, t, n) {
            n.d(t, {
                F: function() {
                    return u
                },
                e: function() {
                    return l
                }
            });
            var r = n(2265);

            function u(...e) {
                return t => e.forEach(e => {
                    "function" == typeof e ? e(t) : null != e && (e.current = t)
                })
            }

            function l(...e) {
                return (0, r.useCallback)(u(...e), e)
            }
        },
        73966: function(e, t, n) {
            n.d(t, {
                b: function() {
                    return l
                },
                k: function() {
                    return u
                }
            });
            var r = n(2265);

            function u(e, t) {
                let n = (0, r.createContext)(t);

                function u(e) {
                    let {
                        children: t,
                        ...u
                    } = e, l = (0, r.useMemo)(() => u, Object.values(u));
                    return (0, r.createElement)(n.Provider, {
                        value: l
                    }, t)
                }
                return u.displayName = e + "Provider", [u, function(u) {
                    let l = (0, r.useContext)(n);
                    if (l) return l;
                    if (void 0 !== t) return t;
                    throw Error(`\`${u}\` must be used within \`${e}\``)
                }]
            }

            function l(e, t = []) {
                let n = [],
                    u = () => {
                        let t = n.map(e => (0, r.createContext)(e));
                        return function(n) {
                            let u = (null == n ? void 0 : n[e]) || t;
                            return (0, r.useMemo)(() => ({
                                [`__scope${e}`]: { ...n,
                                    [e]: u
                                }
                            }), [n, u])
                        }
                    };
                return u.scopeName = e, [function(t, u) {
                    let l = (0, r.createContext)(u),
                        o = n.length;

                    function i(t) {
                        let {
                            scope: n,
                            children: u,
                            ...i
                        } = t, c = (null == n ? void 0 : n[e][o]) || l, a = (0, r.useMemo)(() => i, Object.values(i));
                        return (0, r.createElement)(c.Provider, {
                            value: a
                        }, u)
                    }
                    return n = [...n, u], i.displayName = t + "Provider", [i, function(n, i) {
                        let c = (null == i ? void 0 : i[e][o]) || l,
                            a = (0, r.useContext)(c);
                        if (a) return a;
                        if (void 0 !== u) return u;
                        throw Error(`\`${n}\` must be used within \`${t}\``)
                    }]
                }, function(...e) {
                    let t = e[0];
                    if (1 === e.length) return t;
                    let n = () => {
                        let n = e.map(e => ({
                            useScope: e(),
                            scopeName: e.scopeName
                        }));
                        return function(e) {
                            let u = n.reduce((t, {
                                useScope: n,
                                scopeName: r
                            }) => {
                                let u = n(e)[`__scope${r}`];
                                return { ...t,
                                    ...u
                                }
                            }, {});
                            return (0, r.useMemo)(() => ({
                                [`__scope${t.scopeName}`]: u
                            }), [u])
                        }
                    };
                    return n.scopeName = t.scopeName, n
                }(u, ...t)]
            }
        },
        99255: function(e, t, n) {
            n.d(t, {
                M: function() {
                    return c
                }
            });
            var r, u = n(2265),
                l = n(61188);
            let o = (r || (r = n.t(u, 2)))["useId".toString()] || (() => void 0),
                i = 0;

            function c(e) {
                let [t, n] = u.useState(o());
                return (0, l.b)(() => {
                    e || n(e => null != e ? e : String(i++))
                }, [e]), e || (t ? `radix-${t}` : "")
            }
        },
        82912: function(e, t, n) {
            n.d(t, {
                WV: function() {
                    return s
                },
                jH: function() {
                    return d
                }
            });
            var r = n(1119),
                u = n(2265),
                l = n(54887),
                o = n(98575);
            let i = (0, u.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...l
                } = e, o = u.Children.toArray(n), i = o.find(f);
                if (i) {
                    let e = i.props.children,
                        n = o.map(t => t !== i ? t : u.Children.count(e) > 1 ? u.Children.only(null) : (0, u.isValidElement)(e) ? e.props.children : null);
                    return (0, u.createElement)(c, (0, r.Z)({}, l, {
                        ref: t
                    }), (0, u.isValidElement)(e) ? (0, u.cloneElement)(e, void 0, n) : null)
                }
                return (0, u.createElement)(c, (0, r.Z)({}, l, {
                    ref: t
                }), n)
            });
            i.displayName = "Slot";
            let c = (0, u.forwardRef)((e, t) => {
                let {
                    children: n,
                    ...r
                } = e;
                return (0, u.isValidElement)(n) ? (0, u.cloneElement)(n, { ... function(e, t) {
                        let n = { ...t
                        };
                        for (let r in t) {
                            let u = e[r],
                                l = t[r];
                            /^on[A-Z]/.test(r) ? u && l ? n[r] = (...e) => {
                                l(...e), u(...e)
                            } : u && (n[r] = u) : "style" === r ? n[r] = { ...u,
                                ...l
                            } : "className" === r && (n[r] = [u, l].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...n
                        }
                    }(r, n.props),
                    ref: t ? (0, o.F)(t, n.ref) : n.ref
                }) : u.Children.count(n) > 1 ? u.Children.only(null) : null
            });
            c.displayName = "SlotClone";
            let a = ({
                children: e
            }) => (0, u.createElement)(u.Fragment, null, e);

            function f(e) {
                return (0, u.isValidElement)(e) && e.type === a
            }
            let s = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                let n = (0, u.forwardRef)((e, n) => {
                    let {
                        asChild: l,
                        ...o
                    } = e, c = l ? i : t;
                    return (0, u.useEffect)(() => {
                        window[Symbol.for("radix-ui")] = !0
                    }, []), (0, u.createElement)(c, (0, r.Z)({}, o, {
                        ref: n
                    }))
                });
                return n.displayName = `Primitive.${t}`, { ...e,
                    [t]: n
                }
            }, {});

            function d(e, t) {
                e && (0, l.flushSync)(() => e.dispatchEvent(t))
            }
        },
        26606: function(e, t, n) {
            n.d(t, {
                W: function() {
                    return u
                }
            });
            var r = n(2265);

            function u(e) {
                let t = (0, r.useRef)(e);
                return (0, r.useEffect)(() => {
                    t.current = e
                }), (0, r.useMemo)(() => (...e) => {
                    var n;
                    return null === (n = t.current) || void 0 === n ? void 0 : n.call(t, ...e)
                }, [])
            }
        },
        80886: function(e, t, n) {
            n.d(t, {
                T: function() {
                    return l
                }
            });
            var r = n(2265),
                u = n(26606);

            function l({
                prop: e,
                defaultProp: t,
                onChange: n = () => {}
            }) {
                let [l, o] = function({
                    defaultProp: e,
                    onChange: t
                }) {
                    let n = (0, r.useState)(e),
                        [l] = n,
                        o = (0, r.useRef)(l),
                        i = (0, u.W)(t);
                    return (0, r.useEffect)(() => {
                        o.current !== l && (i(l), o.current = l)
                    }, [l, o, i]), n
                }({
                    defaultProp: t,
                    onChange: n
                }), i = void 0 !== e, c = i ? e : l, a = (0, u.W)(n);
                return [c, (0, r.useCallback)(t => {
                    if (i) {
                        let n = "function" == typeof t ? t(e) : t;
                        n !== e && a(n)
                    } else o(t)
                }, [i, e, o, a])]
            }
        },
        61188: function(e, t, n) {
            n.d(t, {
                b: function() {
                    return u
                }
            });
            var r = n(2265);
            let u = (null == globalThis ? void 0 : globalThis.document) ? r.useLayoutEffect : () => {}
        }
    }
]);