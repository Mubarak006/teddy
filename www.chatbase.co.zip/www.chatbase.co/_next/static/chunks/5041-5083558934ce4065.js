"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5041], {
        6846: function(t, e, i) {
            i.d(e, {
                v: function() {
                    return d
                }
            });
            var n = i(94521),
                r = i(767),
                s = i(77919),
                o = i(48626),
                a = i(8662),
                l = i(91174);
            let u = (t, e) => "zIndex" !== e && !!("number" == typeof t || Array.isArray(t) || "string" == typeof t && (l.P.test(t) || "0" === t) && !t.startsWith("url("));
            var h = i(40281);
            class d {
                constructor({
                    autoplay: t = !0,
                    delay: e = 0,
                    type: i = "keyframes",
                    repeat: r = 0,
                    repeatDelay: s = 0,
                    repeatType: o = "loop",
                    ...a
                }) {
                    this.isStopped = !1, this.hasAttemptedResolve = !1, this.createdAt = n.X.now(), this.options = {
                        autoplay: t,
                        delay: e,
                        type: i,
                        repeat: r,
                        repeatDelay: s,
                        repeatType: o,
                        ...a
                    }, this.updateFinishedPromise()
                }
                calcStartTime() {
                    return this.resolvedAt && this.resolvedAt - this.createdAt > 40 ? this.resolvedAt : this.createdAt
                }
                get resolved() {
                    return this._resolved || this.hasAttemptedResolve || (0, r.m)(), this._resolved
                }
                onKeyframesResolved(t, e) {
                    this.resolvedAt = n.X.now(), this.hasAttemptedResolve = !0;
                    let {
                        name: i,
                        type: r,
                        velocity: l,
                        delay: d,
                        onComplete: c,
                        onUpdate: p,
                        isGenerator: m
                    } = this.options;
                    if (!m && ! function(t, e, i, n) {
                            let r = t[0];
                            if (null === r) return !1;
                            if ("display" === e || "visibility" === e) return !0;
                            let s = t[t.length - 1],
                                l = u(r, e),
                                h = u(s, e);
                            return (0, o.K)(l === h, `You are trying to animate ${e} from "${r}" to "${s}". ${r} is not an animatable value - to enable this animation set ${r} to a value animatable to ${s} via the \`style\` property.`), !!l && !!h && (function(t) {
                                let e = t[0];
                                if (1 === t.length) return !0;
                                for (let i = 0; i < t.length; i++)
                                    if (t[i] !== e) return !0
                            }(t) || ("spring" === i || (0, a.x)(i)) && n)
                        }(t, i, r, l)) {
                        if (s.c.current || !d) {
                            null == p || p((0, h.$)(t, this.options, e)), null == c || c(), this.resolveFinishedPromise();
                            return
                        }
                        this.options.duration = 0
                    }
                    let f = this.initPlayback(t, e);
                    !1 !== f && (this._resolved = {
                        keyframes: t,
                        finalKeyframe: e,
                        ...f
                    }, this.onPostResolved())
                }
                onPostResolved() {}
                then(t, e) {
                    return this.currentFinishedPromise.then(t, e)
                }
                flatten() {
                    this.options.type = "keyframes", this.options.ease = "linear"
                }
                updateFinishedPromise() {
                    this.currentFinishedPromise = new Promise(t => {
                        this.resolveFinishedPromise = t
                    })
                }
            }
        },
        83449: function(t, e, i) {
            i.d(e, {
                s: function() {
                    return X
                },
                y: function() {
                    return z
                }
            });
            var n = i(767),
                r = i(67468),
                s = i(93543),
                o = i(88253);

            function a(t, e, i) {
                let n = Math.max(e - 5, 0);
                return (0, o.R)(i - t(n), e - n)
            }
            var l = i(48626),
                u = i(71389);
            let h = {
                stiffness: 100,
                damping: 10,
                mass: 1,
                velocity: 0,
                duration: 800,
                bounce: .3,
                visualDuration: .3,
                restSpeed: {
                    granular: .01,
                    default: 2
                },
                restDelta: {
                    granular: .005,
                    default: .5
                },
                minDuration: .01,
                maxDuration: 10,
                minDamping: .05,
                maxDamping: 1
            };

            function d(t, e) {
                return t * Math.sqrt(1 - e * e)
            }

            function c(t) {
                let e = 0,
                    i = t.next(e);
                for (; !i.done && e < 2e4;) e += 50, i = t.next(e);
                return e >= 2e4 ? 1 / 0 : e
            }
            let p = ["duration", "bounce"],
                m = ["stiffness", "damping", "mass"];

            function f(t, e) {
                return e.some(e => void 0 !== t[e])
            }

            function v(t = h.visualDuration, e = h.bounce) {
                let i;
                let n = "object" != typeof t ? {
                        visualDuration: t,
                        keyframes: [0, 1],
                        bounce: e
                    } : t,
                    {
                        restSpeed: o,
                        restDelta: v
                    } = n,
                    g = n.keyframes[0],
                    y = n.keyframes[n.keyframes.length - 1],
                    x = {
                        done: !1,
                        value: g
                    },
                    {
                        stiffness: w,
                        damping: P,
                        mass: T,
                        duration: b,
                        velocity: S,
                        isResolvedFromDuration: A
                    } = function(t) {
                        let e = {
                            velocity: h.velocity,
                            stiffness: h.stiffness,
                            damping: h.damping,
                            mass: h.mass,
                            isResolvedFromDuration: !1,
                            ...t
                        };
                        if (!f(t, m) && f(t, p)) {
                            if (t.visualDuration) {
                                let i = 2 * Math.PI / (1.2 * t.visualDuration),
                                    n = i * i,
                                    r = 2 * (0, u.u)(.05, 1, 1 - t.bounce) * Math.sqrt(n);
                                e = { ...e,
                                    mass: h.mass,
                                    stiffness: n,
                                    damping: r
                                }
                            } else {
                                let i = function({
                                    duration: t = h.duration,
                                    bounce: e = h.bounce,
                                    velocity: i = h.velocity,
                                    mass: n = h.mass
                                }) {
                                    let r, o;
                                    (0, l.K)(t <= (0, s.w)(h.maxDuration), "Spring duration must be 10 seconds or less");
                                    let a = 1 - e;
                                    a = (0, u.u)(h.minDamping, h.maxDamping, a), t = (0, u.u)(h.minDuration, h.maxDuration, (0, s.X)(t)), a < 1 ? (r = e => {
                                        let n = e * a,
                                            r = n * t;
                                        return .001 - (n - i) / d(e, a) * Math.exp(-r)
                                    }, o = e => {
                                        let n = e * a * t,
                                            s = Math.pow(a, 2) * Math.pow(e, 2) * t,
                                            o = d(Math.pow(e, 2), a);
                                        return (n * i + i - s) * Math.exp(-n) * (-r(e) + .001 > 0 ? -1 : 1) / o
                                    }) : (r = e => -.001 + Math.exp(-e * t) * ((e - i) * t + 1), o = e => t * t * (i - e) * Math.exp(-e * t));
                                    let c = function(t, e, i) {
                                        let n = i;
                                        for (let i = 1; i < 12; i++) n -= t(n) / e(n);
                                        return n
                                    }(r, o, 5 / t);
                                    if (t = (0, s.w)(t), isNaN(c)) return {
                                        stiffness: h.stiffness,
                                        damping: h.damping,
                                        duration: t
                                    }; {
                                        let e = Math.pow(c, 2) * n;
                                        return {
                                            stiffness: e,
                                            damping: 2 * a * Math.sqrt(n * e),
                                            duration: t
                                        }
                                    }
                                }(t);
                                (e = { ...e,
                                    ...i,
                                    mass: h.mass
                                }).isResolvedFromDuration = !0
                            }
                        }
                        return e
                    }({ ...n,
                        velocity: -(0, s.X)(n.velocity || 0)
                    }),
                    V = S || 0,
                    E = P / (2 * Math.sqrt(w * T)),
                    D = y - g,
                    M = (0, s.X)(Math.sqrt(w / T)),
                    C = 5 > Math.abs(D);
                if (o || (o = C ? h.restSpeed.granular : h.restSpeed.default), v || (v = C ? h.restDelta.granular : h.restDelta.default), E < 1) {
                    let t = d(M, E);
                    i = e => y - Math.exp(-E * M * e) * ((V + E * M * D) / t * Math.sin(t * e) + D * Math.cos(t * e))
                } else if (1 === E) i = t => y - Math.exp(-M * t) * (D + (V + M * D) * t);
                else {
                    let t = M * Math.sqrt(E * E - 1);
                    i = e => {
                        let i = Math.exp(-E * M * e),
                            n = Math.min(t * e, 300);
                        return y - i * ((V + E * M * D) * Math.sinh(n) + t * D * Math.cosh(n)) / t
                    }
                }
                let R = {
                    calculatedDuration: A && b || null,
                    next: t => {
                        let e = i(t);
                        if (A) x.done = t >= b;
                        else {
                            let n = 0;
                            E < 1 && (n = 0 === t ? (0, s.w)(V) : a(i, t, e));
                            let r = Math.abs(n) <= o,
                                l = Math.abs(y - e) <= v;
                            x.done = r && l
                        }
                        return x.value = x.done ? y : e, x
                    },
                    toString: () => {
                        let t = Math.min(c(R), 2e4),
                            e = (0, r.w)(e => R.next(t * e).value, t, 30);
                        return t + "ms " + e
                    }
                };
                return R
            }

            function g({
                keyframes: t,
                velocity: e = 0,
                power: i = .8,
                timeConstant: n = 325,
                bounceDamping: r = 10,
                bounceStiffness: s = 500,
                modifyTarget: o,
                min: l,
                max: u,
                restDelta: h = .5,
                restSpeed: d
            }) {
                let c, p;
                let m = t[0],
                    f = {
                        done: !1,
                        value: m
                    },
                    g = t => void 0 !== l && t < l || void 0 !== u && t > u,
                    y = t => void 0 === l ? u : void 0 === u ? l : Math.abs(l - t) < Math.abs(u - t) ? l : u,
                    x = i * e,
                    w = m + x,
                    P = void 0 === o ? w : o(w);
                P !== w && (x = P - m);
                let T = t => -x * Math.exp(-t / n),
                    b = t => P + T(t),
                    S = t => {
                        let e = T(t),
                            i = b(t);
                        f.done = Math.abs(e) <= h, f.value = f.done ? P : i
                    },
                    A = t => {
                        g(f.value) && (c = t, p = v({
                            keyframes: [f.value, y(f.value)],
                            velocity: a(b, t, f.value),
                            damping: r,
                            stiffness: s,
                            restDelta: h,
                            restSpeed: d
                        }))
                    };
                return A(0), {
                    calculatedDuration: null,
                    next: t => {
                        let e = !1;
                        return (p || void 0 !== c || (e = !0, S(t), A(t)), void 0 !== c && t >= c) ? p.next(t - c) : (e || S(t), f)
                    }
                }
            }
            var y = i(5027);
            let x = (0, y._)(.42, 0, 1, 1),
                w = (0, y._)(0, 0, .58, 1),
                P = (0, y._)(.42, 0, .58, 1),
                T = t => Array.isArray(t) && "number" != typeof t[0];
            var b = i(57268),
                S = i(98426),
                A = i(51356),
                V = i(93974),
                E = i(83435);
            let D = {
                    linear: b.Z,
                    easeIn: x,
                    easeInOut: P,
                    easeOut: w,
                    circIn: S.Z7,
                    circInOut: S.X7,
                    circOut: S.Bn,
                    backIn: A.G2,
                    backInOut: A.XL,
                    backOut: A.CG,
                    anticipate: V.L
                },
                M = t => {
                    if ((0, E.q)(t)) {
                        (0, l.k)(4 === t.length, "Cubic bezier arrays must contain four numerical values.");
                        let [e, i, n, r] = t;
                        return (0, y._)(e, i, n, r)
                    }
                    return "string" == typeof t ? ((0, l.k)(void 0 !== D[t], `Invalid easing type '${t}'`), D[t]) : t
                };
            var C = i(53135),
                R = i(15184);

            function k({
                duration: t = 300,
                keyframes: e,
                times: i,
                ease: n = "easeInOut"
            }) {
                let r = T(n) ? n.map(M) : M(n),
                    s = {
                        done: !1,
                        value: e[0]
                    },
                    o = (i && i.length === e.length ? i : (0, R.Y)(e)).map(e => e * t),
                    a = (0, C.s)(o, e, {
                        ease: Array.isArray(r) ? r : e.map(() => r || P).splice(0, e.length - 1)
                    });
                return {
                    calculatedDuration: t,
                    next: e => (s.value = a(e), s.done = e >= t, s)
                }
            }
            var L = i(6846),
                j = i(60777),
                F = i(65566),
                B = i(94521),
                O = i(31198);
            let $ = t => {
                let e = ({
                    timestamp: e
                }) => t(e);
                return {
                    start: () => O.Wi.update(e, !0),
                    stop: () => (0, O.Pn)(e),
                    now: () => O.frameData.isProcessing ? O.frameData.timestamp : B.X.now()
                }
            };
            var W = i(40281),
                I = i(8662);
            let U = {
                    decay: g,
                    inertia: g,
                    tween: k,
                    keyframes: k,
                    spring: v
                },
                N = t => t / 100;
            class X extends L.v {
                constructor(t) {
                    super(t), this.holdTime = null, this.cancelTime = null, this.currentTime = 0, this.playbackSpeed = 1, this.pendingPlayState = "running", this.startTime = null, this.state = "idle", this.stop = () => {
                        if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                        this.teardown();
                        let {
                            onStop: t
                        } = this.options;
                        t && t()
                    };
                    let {
                        name: e,
                        motionValue: i,
                        element: r,
                        keyframes: s
                    } = this.options, o = (null == r ? void 0 : r.KeyframeResolver) || n.e;
                    this.resolver = new o(s, (t, e) => this.onKeyframesResolved(t, e), e, i, r), this.resolver.scheduleResolve()
                }
                flatten() {
                    super.flatten(), this._resolved && Object.assign(this._resolved, this.initPlayback(this._resolved.keyframes))
                }
                initPlayback(t) {
                    let e, i;
                    let {
                        type: n = "keyframes",
                        repeat: r = 0,
                        repeatDelay: s = 0,
                        repeatType: o,
                        velocity: a = 0
                    } = this.options, l = (0, I.x)(n) ? n : U[n] || k;
                    l !== k && "number" != typeof t[0] && (e = (0, j.z)(N, (0, F.C)(t[0], t[1])), t = [0, 100]);
                    let u = l({ ...this.options,
                        keyframes: t
                    });
                    "mirror" === o && (i = l({ ...this.options,
                        keyframes: [...t].reverse(),
                        velocity: -a
                    })), null === u.calculatedDuration && (u.calculatedDuration = c(u));
                    let {
                        calculatedDuration: h
                    } = u, d = h + s;
                    return {
                        generator: u,
                        mirroredGenerator: i,
                        mapPercentToKeyframes: e,
                        calculatedDuration: h,
                        resolvedDuration: d,
                        totalDuration: d * (r + 1) - s
                    }
                }
                onPostResolved() {
                    let {
                        autoplay: t = !0
                    } = this.options;
                    this.play(), "paused" !== this.pendingPlayState && t ? this.state = this.pendingPlayState : this.pause()
                }
                tick(t, e = !1) {
                    let {
                        resolved: i
                    } = this;
                    if (!i) {
                        let {
                            keyframes: t
                        } = this.options;
                        return {
                            done: !0,
                            value: t[t.length - 1]
                        }
                    }
                    let {
                        finalKeyframe: n,
                        generator: r,
                        mirroredGenerator: s,
                        mapPercentToKeyframes: o,
                        keyframes: a,
                        calculatedDuration: l,
                        totalDuration: h,
                        resolvedDuration: d
                    } = i;
                    if (null === this.startTime) return r.next(0);
                    let {
                        delay: c,
                        repeat: p,
                        repeatType: m,
                        repeatDelay: f,
                        onUpdate: v
                    } = this.options;
                    this.speed > 0 ? this.startTime = Math.min(this.startTime, t) : this.speed < 0 && (this.startTime = Math.min(t - h / this.speed, this.startTime)), e ? this.currentTime = t : null !== this.holdTime ? this.currentTime = this.holdTime : this.currentTime = Math.round(t - this.startTime) * this.speed;
                    let g = this.currentTime - c * (this.speed >= 0 ? 1 : -1),
                        y = this.speed >= 0 ? g < 0 : g > h;
                    this.currentTime = Math.max(g, 0), "finished" === this.state && null === this.holdTime && (this.currentTime = h);
                    let x = this.currentTime,
                        w = r;
                    if (p) {
                        let t = Math.min(this.currentTime, h) / d,
                            e = Math.floor(t),
                            i = t % 1;
                        !i && t >= 1 && (i = 1), 1 === i && e--, (e = Math.min(e, p + 1)) % 2 && ("reverse" === m ? (i = 1 - i, f && (i -= f / d)) : "mirror" === m && (w = s)), x = (0, u.u)(0, 1, i) * d
                    }
                    let P = y ? {
                        done: !1,
                        value: a[0]
                    } : w.next(x);
                    o && (P.value = o(P.value));
                    let {
                        done: T
                    } = P;
                    y || null === l || (T = this.speed >= 0 ? this.currentTime >= h : this.currentTime <= 0);
                    let b = null === this.holdTime && ("finished" === this.state || "running" === this.state && T);
                    return b && void 0 !== n && (P.value = (0, W.$)(a, this.options, n)), v && v(P.value), b && this.finish(), P
                }
                get duration() {
                    let {
                        resolved: t
                    } = this;
                    return t ? (0, s.X)(t.calculatedDuration) : 0
                }
                get time() {
                    return (0, s.X)(this.currentTime)
                }
                set time(t) {
                    t = (0, s.w)(t), this.currentTime = t, null !== this.holdTime || 0 === this.speed ? this.holdTime = t : this.driver && (this.startTime = this.driver.now() - t / this.speed)
                }
                get speed() {
                    return this.playbackSpeed
                }
                set speed(t) {
                    let e = this.playbackSpeed !== t;
                    this.playbackSpeed = t, e && (this.time = (0, s.X)(this.currentTime))
                }
                play() {
                    if (this.resolver.isScheduled || this.resolver.resume(), !this._resolved) {
                        this.pendingPlayState = "running";
                        return
                    }
                    if (this.isStopped) return;
                    let {
                        driver: t = $,
                        onPlay: e,
                        startTime: i
                    } = this.options;
                    this.driver || (this.driver = t(t => this.tick(t))), e && e();
                    let n = this.driver.now();
                    null !== this.holdTime ? this.startTime = n - this.holdTime : this.startTime ? "finished" === this.state && (this.startTime = n) : this.startTime = null != i ? i : this.calcStartTime(), "finished" === this.state && this.updateFinishedPromise(), this.cancelTime = this.startTime, this.holdTime = null, this.state = "running", this.driver.start()
                }
                pause() {
                    var t;
                    if (!this._resolved) {
                        this.pendingPlayState = "paused";
                        return
                    }
                    this.state = "paused", this.holdTime = null !== (t = this.currentTime) && void 0 !== t ? t : 0
                }
                complete() {
                    "running" !== this.state && this.play(), this.pendingPlayState = this.state = "finished", this.holdTime = null
                }
                finish() {
                    this.teardown(), this.state = "finished";
                    let {
                        onComplete: t
                    } = this.options;
                    t && t()
                }
                cancel() {
                    null !== this.cancelTime && this.tick(this.cancelTime), this.teardown(), this.updateFinishedPromise()
                }
                teardown() {
                    this.state = "idle", this.stopDriver(), this.resolveFinishedPromise(), this.updateFinishedPromise(), this.startTime = this.cancelTime = null, this.resolver.cancel()
                }
                stopDriver() {
                    this.driver && (this.driver.stop(), this.driver = void 0)
                }
                sample(t) {
                    return this.startTime = 0, this.tick(t, !0)
                }
            }

            function z(t) {
                return new X(t)
            }
        },
        40281: function(t, e, i) {
            i.d(e, {
                $: function() {
                    return r
                }
            });
            let n = t => null !== t;

            function r(t, {
                repeat: e,
                repeatType: i = "loop"
            }, r) {
                let s = t.filter(n),
                    o = e && "loop" !== i && e % 2 == 1 ? 0 : s.length - 1;
                return o && void 0 !== r ? r : s[o]
            }
        },
        67468: function(t, e, i) {
            i.d(e, {
                w: function() {
                    return r
                }
            });
            var n = i(73633);
            let r = (t, e, i = 10) => {
                let r = "",
                    s = Math.max(Math.round(e / i), 2);
                for (let e = 0; e < s; e++) r += t((0, n.Y)(0, s - 1, e)) + ", ";
                return `linear(${r.substring(0,r.length-2)})`
            }
        },
        8662: function(t, e, i) {
            i.d(e, {
                x: function() {
                    return n
                }
            });

            function n(t) {
                return "function" == typeof t
            }
        },
        26728: function(t, e, i) {
            i.d(e, {
                p: function() {
                    return n
                }
            });
            let n = (0, i(2265).createContext)({})
        },
        50456: function(t, e, i) {
            i.d(e, {
                _: function() {
                    return n
                }
            });
            let n = (0, i(2265).createContext)({
                transformPagePoint: t => t,
                isStatic: !1,
                reducedMotion: "never"
            })
        },
        40123: function(t, e, i) {
            i.d(e, {
                O: function() {
                    return n
                }
            });
            let n = (0, i(2265).createContext)(null)
        },
        93974: function(t, e, i) {
            i.d(e, {
                L: function() {
                    return r
                }
            });
            var n = i(51356);
            let r = t => (t *= 2) < 1 ? .5 * (0, n.G2)(t) : .5 * (2 - Math.pow(2, -10 * (t - 1)))
        },
        51356: function(t, e, i) {
            i.d(e, {
                CG: function() {
                    return o
                },
                G2: function() {
                    return a
                },
                XL: function() {
                    return l
                }
            });
            var n = i(5027),
                r = i(54532),
                s = i(37535);
            let o = (0, n._)(.33, 1.53, .69, .99),
                a = (0, s.M)(o),
                l = (0, r.o)(a)
        },
        98426: function(t, e, i) {
            i.d(e, {
                Bn: function() {
                    return o
                },
                X7: function() {
                    return a
                },
                Z7: function() {
                    return s
                }
            });
            var n = i(54532),
                r = i(37535);
            let s = t => 1 - Math.sin(Math.acos(t)),
                o = (0, r.M)(s),
                a = (0, n.o)(s)
        },
        5027: function(t, e, i) {
            i.d(e, {
                _: function() {
                    return s
                }
            });
            var n = i(57268);
            let r = (t, e, i) => (((1 - 3 * i + 3 * e) * t + (3 * i - 6 * e)) * t + 3 * e) * t;

            function s(t, e, i, s) {
                if (t === e && i === s) return n.Z;
                let o = e => (function(t, e, i, n, s) {
                    let o, a;
                    let l = 0;
                    do(o = r(a = e + (i - e) / 2, n, s) - t) > 0 ? i = a : e = a; while (Math.abs(o) > 1e-7 && ++l < 12);
                    return a
                })(e, 0, 1, t, i);
                return t => 0 === t || 1 === t ? t : r(o(t), e, s)
            }
        },
        54532: function(t, e, i) {
            i.d(e, {
                o: function() {
                    return n
                }
            });
            let n = t => e => e <= .5 ? t(2 * e) / 2 : (2 - t(2 * (1 - e))) / 2
        },
        37535: function(t, e, i) {
            i.d(e, {
                M: function() {
                    return n
                }
            });
            let n = t => e => 1 - t(1 - e)
        },
        83435: function(t, e, i) {
            i.d(e, {
                q: function() {
                    return n
                }
            });
            let n = t => Array.isArray(t) && "number" == typeof t[0]
        },
        38701: function(t, e, i) {
            i.d(e, {
                Z: function() {
                    return s
                }
            });
            var n = i(93798);
            let r = ["read", "resolveKeyframes", "update", "preRender", "render", "postRender"];

            function s(t, e) {
                let i = !1,
                    s = !0,
                    o = {
                        delta: 0,
                        timestamp: 0,
                        isProcessing: !1
                    },
                    a = () => i = !0,
                    l = r.reduce((t, e) => (t[e] = function(t) {
                        let e = new Set,
                            i = new Set,
                            n = !1,
                            r = !1,
                            s = new WeakSet,
                            o = {
                                delta: 0,
                                timestamp: 0,
                                isProcessing: !1
                            };

                        function a(e) {
                            s.has(e) && (l.schedule(e), t()), e(o)
                        }
                        let l = {
                            schedule: (t, r = !1, o = !1) => {
                                let a = o && n ? e : i;
                                return r && s.add(t), a.has(t) || a.add(t), t
                            },
                            cancel: t => {
                                i.delete(t), s.delete(t)
                            },
                            process: t => {
                                if (o = t, n) {
                                    r = !0;
                                    return
                                }
                                n = !0, [e, i] = [i, e], i.clear(), e.forEach(a), n = !1, r && (r = !1, l.process(t))
                            }
                        };
                        return l
                    }(a), t), {}),
                    {
                        read: u,
                        resolveKeyframes: h,
                        update: d,
                        preRender: c,
                        render: p,
                        postRender: m
                    } = l,
                    f = () => {
                        let r = n.c.useManualTiming ? o.timestamp : performance.now();
                        i = !1, o.delta = s ? 1e3 / 60 : Math.max(Math.min(r - o.timestamp, 40), 1), o.timestamp = r, o.isProcessing = !0, u.process(o), h.process(o), d.process(o), c.process(o), p.process(o), m.process(o), o.isProcessing = !1, i && e && (s = !1, t(f))
                    },
                    v = () => {
                        i = !0, s = !0, o.isProcessing || t(f)
                    };
                return {
                    schedule: r.reduce((t, e) => {
                        let n = l[e];
                        return t[e] = (t, e = !1, r = !1) => (i || v(), n.schedule(t, e, r)), t
                    }, {}),
                    cancel: t => {
                        for (let e = 0; e < r.length; e++) l[r[e]].cancel(t)
                    },
                    state: o,
                    steps: l
                }
            }
        },
        31198: function(t, e, i) {
            i.d(e, {
                Pn: function() {
                    return s
                },
                Wi: function() {
                    return r
                },
                frameData: function() {
                    return o
                },
                yL: function() {
                    return a
                }
            });
            var n = i(57268);
            let {
                schedule: r,
                cancel: s,
                state: o,
                steps: a
            } = (0, i(38701).Z)("undefined" != typeof requestAnimationFrame ? requestAnimationFrame : n.Z, !0)
        },
        94521: function(t, e, i) {
            let n;
            i.d(e, {
                X: function() {
                    return a
                }
            });
            var r = i(93798),
                s = i(31198);

            function o() {
                n = void 0
            }
            let a = {
                now: () => (void 0 === n && a.set(s.frameData.isProcessing || r.c.useManualTiming ? s.frameData.timestamp : performance.now()), n),
                set: t => {
                    n = t, queueMicrotask(o)
                }
            }
        },
        88588: function(t, e, i) {
            function n(t) {
                return null !== t && "object" == typeof t && "function" == typeof t.start
            }
            i.d(e, {
                E: function() {
                    return nZ
                }
            });
            let r = t => Array.isArray(t);

            function s(t, e) {
                if (!Array.isArray(e)) return !1;
                let i = e.length;
                if (i !== t.length) return !1;
                for (let n = 0; n < i; n++)
                    if (e[n] !== t[n]) return !1;
                return !0
            }

            function o(t) {
                return "string" == typeof t || Array.isArray(t)
            }

            function a(t) {
                let e = [{}, {}];
                return null == t || t.values.forEach((t, i) => {
                    e[0][i] = t.get(), e[1][i] = t.getVelocity()
                }), e
            }

            function l(t, e, i, n) {
                if ("function" == typeof e) {
                    let [r, s] = a(n);
                    e = e(void 0 !== i ? i : t.custom, r, s)
                }
                if ("string" == typeof e && (e = t.variants && t.variants[e]), "function" == typeof e) {
                    let [r, s] = a(n);
                    e = e(void 0 !== i ? i : t.custom, r, s)
                }
                return e
            }

            function u(t, e, i) {
                let n = t.getProps();
                return l(n, e, void 0 !== i ? i : n.custom, t)
            }
            let h = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
                d = ["initial", ...h];
            var c, p, m, f = i(41397),
                v = i(93543);
            let g = {
                    type: "spring",
                    stiffness: 500,
                    damping: 25,
                    restSpeed: 10
                },
                y = t => ({
                    type: "spring",
                    stiffness: 550,
                    damping: 0 === t ? 2 * Math.sqrt(550) : 30,
                    restSpeed: 10
                }),
                x = {
                    type: "keyframes",
                    duration: .8
                },
                w = {
                    type: "keyframes",
                    ease: [.25, .1, .35, 1],
                    duration: .3
                },
                P = (t, {
                    keyframes: e
                }) => e.length > 2 ? x : f.G.has(t) ? t.startsWith("scale") ? y(e[1]) : g : w;

            function T(t, e) {
                return t ? t[e] || t.default || t : void 0
            }
            var b = i(93798),
                S = i(77919),
                A = i(40281),
                V = i(31198),
                E = i(93974),
                D = i(51356),
                M = i(98426);
            let C = t => /^0[^.\s]+$/u.test(t);
            var R = i(48626);
            let k = t => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t);
            var L = i(13938);
            let j = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
            var F = i(27976),
                B = i(77964),
                O = i(89304);
            let $ = t => e => e.test(t),
                W = [B.Rx, O.px, O.aQ, O.RW, O.vw, O.vh, {
                    test: t => "auto" === t,
                    parse: t => t
                }],
                I = t => W.find($(t));
            var U = i(767),
                N = i(91174),
                X = i(14445);
            let z = new Set(["brightness", "contrast", "saturate", "opacity"]);

            function Y(t) {
                let [e, i] = t.slice(0, -1).split("(");
                if ("drop-shadow" === e) return t;
                let [n] = i.match(X.K) || [];
                if (!n) return t;
                let r = i.replace(n, ""),
                    s = z.has(e) ? 1 : 0;
                return n !== i && (s *= 100), e + "(" + s + r + ")"
            }
            let K = /\b([a-z-]*)\(.*?\)/gu,
                q = { ...N.P,
                    getAnimatableNone: t => {
                        let e = t.match(K);
                        return e ? e.map(Y).join(" ") : t
                    }
                };
            var Z = i(51288);
            let G = {
                    borderWidth: O.px,
                    borderTopWidth: O.px,
                    borderRightWidth: O.px,
                    borderBottomWidth: O.px,
                    borderLeftWidth: O.px,
                    borderRadius: O.px,
                    radius: O.px,
                    borderTopLeftRadius: O.px,
                    borderTopRightRadius: O.px,
                    borderBottomRightRadius: O.px,
                    borderBottomLeftRadius: O.px,
                    width: O.px,
                    maxWidth: O.px,
                    height: O.px,
                    maxHeight: O.px,
                    top: O.px,
                    right: O.px,
                    bottom: O.px,
                    left: O.px,
                    padding: O.px,
                    paddingTop: O.px,
                    paddingRight: O.px,
                    paddingBottom: O.px,
                    paddingLeft: O.px,
                    margin: O.px,
                    marginTop: O.px,
                    marginRight: O.px,
                    marginBottom: O.px,
                    marginLeft: O.px,
                    backgroundPositionX: O.px,
                    backgroundPositionY: O.px
                },
                H = {
                    rotate: O.RW,
                    rotateX: O.RW,
                    rotateY: O.RW,
                    rotateZ: O.RW,
                    scale: B.bA,
                    scaleX: B.bA,
                    scaleY: B.bA,
                    scaleZ: B.bA,
                    skew: O.RW,
                    skewX: O.RW,
                    skewY: O.RW,
                    distance: O.px,
                    translateX: O.px,
                    translateY: O.px,
                    translateZ: O.px,
                    x: O.px,
                    y: O.px,
                    z: O.px,
                    perspective: O.px,
                    transformPerspective: O.px,
                    opacity: B.Fq,
                    originX: O.$C,
                    originY: O.$C,
                    originZ: O.px
                },
                _ = { ...B.Rx,
                    transform: Math.round
                },
                J = { ...G,
                    ...H,
                    zIndex: _,
                    size: O.px,
                    fillOpacity: B.Fq,
                    strokeOpacity: B.Fq,
                    numOctaves: _
                },
                Q = { ...J,
                    color: Z.$,
                    backgroundColor: Z.$,
                    outlineColor: Z.$,
                    fill: Z.$,
                    stroke: Z.$,
                    borderColor: Z.$,
                    borderTopColor: Z.$,
                    borderRightColor: Z.$,
                    borderBottomColor: Z.$,
                    borderLeftColor: Z.$,
                    filter: q,
                    WebkitFilter: q
                },
                tt = t => Q[t];

            function te(t, e) {
                let i = tt(t);
                return i !== q && (i = N.P), i.getAnimatableNone ? i.getAnimatableNone(e) : void 0
            }
            let ti = new Set(["auto", "none", "0"]);
            class tn extends U.e {
                constructor(t, e, i, n, r) {
                    super(t, e, i, n, r, !0)
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        element: e,
                        name: i
                    } = this;
                    if (!e || !e.current) return;
                    super.readKeyframes();
                    for (let i = 0; i < t.length; i++) {
                        let n = t[i];
                        if ("string" == typeof n && (n = n.trim(), (0, L.t)(n))) {
                            let r = function t(e, i, n = 1) {
                                (0, R.k)(n <= 4, `Max CSS variable fallback depth detected in property "${e}". This may indicate a circular fallback dependency.`);
                                let [r, s] = function(t) {
                                    let e = j.exec(t);
                                    if (!e) return [, ];
                                    let [, i, n, r] = e;
                                    return [`--${null!=i?i:n}`, r]
                                }(e);
                                if (!r) return;
                                let o = window.getComputedStyle(i).getPropertyValue(r);
                                if (o) {
                                    let t = o.trim();
                                    return k(t) ? parseFloat(t) : t
                                }
                                return (0, L.t)(s) ? t(s, i, n + 1) : s
                            }(n, e.current);
                            void 0 !== r && (t[i] = r), i === t.length - 1 && (this.finalKeyframe = n)
                        }
                    }
                    if (this.resolveNoneKeyframes(), !F.z2.has(i) || 2 !== t.length) return;
                    let [n, r] = t, s = I(n), o = I(r);
                    if (s !== o) {
                        if ((0, F.mP)(s) && (0, F.mP)(o))
                            for (let e = 0; e < t.length; e++) {
                                let i = t[e];
                                "string" == typeof i && (t[e] = parseFloat(i))
                            } else this.needsMeasurement = !0
                    }
                }
                resolveNoneKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        name: e
                    } = this, i = [];
                    for (let e = 0; e < t.length; e++) {
                        var n;
                        ("number" == typeof(n = t[e]) ? 0 === n : null === n || "none" === n || "0" === n || C(n)) && i.push(e)
                    }
                    i.length && function(t, e, i) {
                        let n, r = 0;
                        for (; r < t.length && !n;) {
                            let e = t[r];
                            "string" == typeof e && !ti.has(e) && (0, N.V)(e).values.length && (n = t[r]), r++
                        }
                        if (n && i)
                            for (let r of e) t[r] = te(i, n)
                    }(t, i, e)
                }
                measureInitialState() {
                    let {
                        element: t,
                        unresolvedKeyframes: e,
                        name: i
                    } = this;
                    if (!t || !t.current) return;
                    "height" === i && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = F.lw[i](t.measureViewportBox(), window.getComputedStyle(t.current)), e[0] = this.measuredOrigin;
                    let n = e[e.length - 1];
                    void 0 !== n && t.getValue(i, n).jump(n, !1)
                }
                measureEndState() {
                    var t;
                    let {
                        element: e,
                        name: i,
                        unresolvedKeyframes: n
                    } = this;
                    if (!e || !e.current) return;
                    let r = e.getValue(i);
                    r && r.jump(this.measuredOrigin, !1);
                    let s = n.length - 1,
                        o = n[s];
                    n[s] = F.lw[i](e.measureViewportBox(), window.getComputedStyle(e.current)), null !== o && void 0 === this.finalKeyframe && (this.finalKeyframe = o), (null === (t = this.removedTransforms) || void 0 === t ? void 0 : t.length) && this.removedTransforms.forEach(([t, i]) => {
                        e.getValue(t).set(i)
                    }), this.resolveNoneKeyframes()
                }
            }
            var tr = i(57268),
                ts = i(8662),
                to = i(6846),
                ta = i(83449);
            let tl = new Set(["opacity", "clipPath", "filter", "transform"]);
            var tu = i(83435),
                th = i(67468),
                td = i(60453);
            let tc = {
                    linearEasing: void 0
                },
                tp = function(t, e) {
                    let i = (0, td.X)(t);
                    return () => {
                        var t;
                        return null !== (t = tc[e]) && void 0 !== t ? t : i()
                    }
                }(() => {
                    try {
                        document.createElement("div").animate({
                            opacity: 0
                        }, {
                            easing: "linear(0, 1)"
                        })
                    } catch (t) {
                        return !1
                    }
                    return !0
                }, "linearEasing"),
                tm = ([t, e, i, n]) => `cubic-bezier(${t}, ${e}, ${i}, ${n})`,
                tf = {
                    linear: "linear",
                    ease: "ease",
                    easeIn: "ease-in",
                    easeOut: "ease-out",
                    easeInOut: "ease-in-out",
                    circIn: tm([0, .65, .55, 1]),
                    circOut: tm([.55, 0, 1, .45]),
                    backIn: tm([.31, .01, .66, -.59]),
                    backOut: tm([.33, 1.53, .69, .99])
                };

            function tv(t, e) {
                t.timeline = e, t.onfinish = null
            }
            let tg = (0, td.X)(() => Object.hasOwnProperty.call(Element.prototype, "animate")),
                ty = {
                    anticipate: E.L,
                    backInOut: D.XL,
                    circInOut: M.X7
                };
            class tx extends to.v {
                constructor(t) {
                    super(t);
                    let {
                        name: e,
                        motionValue: i,
                        element: n,
                        keyframes: r
                    } = this.options;
                    this.resolver = new tn(r, (t, e) => this.onKeyframesResolved(t, e), e, i, n), this.resolver.scheduleResolve()
                }
                initPlayback(t, e) {
                    var i, n;
                    let {
                        duration: r = 300,
                        times: s,
                        ease: o,
                        type: a,
                        motionValue: l,
                        name: u,
                        startTime: h
                    } = this.options;
                    if (!(null === (i = l.owner) || void 0 === i ? void 0 : i.current)) return !1;
                    if ("string" == typeof o && tp() && o in ty && (o = ty[o]), n = this.options, (0, ts.x)(n.type) || "spring" === n.type || ! function t(e) {
                            return !!("function" == typeof e && tp() || !e || "string" == typeof e && (e in tf || tp()) || (0, tu.q)(e) || Array.isArray(e) && e.every(t))
                        }(n.ease)) {
                        let {
                            onComplete: e,
                            onUpdate: i,
                            motionValue: n,
                            element: l,
                            ...u
                        } = this.options, h = function(t, e) {
                            let i = new ta.s({ ...e,
                                    keyframes: t,
                                    repeat: 0,
                                    delay: 0,
                                    isGenerator: !0
                                }),
                                n = {
                                    done: !1,
                                    value: t[0]
                                },
                                r = [],
                                s = 0;
                            for (; !n.done && s < 2e4;) r.push((n = i.sample(s)).value), s += 10;
                            return {
                                times: void 0,
                                keyframes: r,
                                duration: s - 10,
                                ease: "linear"
                            }
                        }(t, u);
                        1 === (t = h.keyframes).length && (t[1] = t[0]), r = h.duration, s = h.times, o = h.ease, a = "keyframes"
                    }
                    let d = function(t, e, i, {
                        delay: n = 0,
                        duration: r = 300,
                        repeat: s = 0,
                        repeatType: o = "loop",
                        ease: a = "easeInOut",
                        times: l
                    } = {}) {
                        let u = {
                            [e]: i
                        };
                        l && (u.offset = l);
                        let h = function t(e, i) {
                            if (e) return "function" == typeof e && tp() ? (0, th.w)(e, i) : (0, tu.q)(e) ? tm(e) : Array.isArray(e) ? e.map(e => t(e, i) || tf.easeOut) : tf[e]
                        }(a, r);
                        return Array.isArray(h) && (u.easing = h), t.animate(u, {
                            delay: n,
                            duration: r,
                            easing: Array.isArray(h) ? "linear" : h,
                            fill: "both",
                            iterations: s + 1,
                            direction: "reverse" === o ? "alternate" : "normal"
                        })
                    }(l.owner.current, u, t, { ...this.options,
                        duration: r,
                        times: s,
                        ease: o
                    });
                    return d.startTime = null != h ? h : this.calcStartTime(), this.pendingTimeline ? (tv(d, this.pendingTimeline), this.pendingTimeline = void 0) : d.onfinish = () => {
                        let {
                            onComplete: i
                        } = this.options;
                        l.set((0, A.$)(t, this.options, e)), i && i(), this.cancel(), this.resolveFinishedPromise()
                    }, {
                        animation: d,
                        duration: r,
                        times: s,
                        type: a,
                        ease: o,
                        keyframes: t
                    }
                }
                get duration() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    let {
                        duration: e
                    } = t;
                    return (0, v.X)(e)
                }
                get time() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 0;
                    let {
                        animation: e
                    } = t;
                    return (0, v.X)(e.currentTime || 0)
                }
                set time(t) {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return;
                    let {
                        animation: i
                    } = e;
                    i.currentTime = (0, v.w)(t)
                }
                get speed() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return 1;
                    let {
                        animation: e
                    } = t;
                    return e.playbackRate
                }
                set speed(t) {
                    let {
                        resolved: e
                    } = this;
                    if (!e) return;
                    let {
                        animation: i
                    } = e;
                    i.playbackRate = t
                }
                get state() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return "idle";
                    let {
                        animation: e
                    } = t;
                    return e.playState
                }
                get startTime() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return null;
                    let {
                        animation: e
                    } = t;
                    return e.startTime
                }
                attachTimeline(t) {
                    if (this._resolved) {
                        let {
                            resolved: e
                        } = this;
                        if (!e) return tr.Z;
                        let {
                            animation: i
                        } = e;
                        tv(i, t)
                    } else this.pendingTimeline = t;
                    return tr.Z
                }
                play() {
                    if (this.isStopped) return;
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e
                    } = t;
                    "finished" === e.playState && this.updateFinishedPromise(), e.play()
                }
                pause() {
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e
                    } = t;
                    e.pause()
                }
                stop() {
                    if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
                    this.resolveFinishedPromise(), this.updateFinishedPromise();
                    let {
                        resolved: t
                    } = this;
                    if (!t) return;
                    let {
                        animation: e,
                        keyframes: i,
                        duration: n,
                        type: r,
                        ease: s,
                        times: o
                    } = t;
                    if ("idle" === e.playState || "finished" === e.playState) return;
                    if (this.time) {
                        let {
                            motionValue: t,
                            onUpdate: e,
                            onComplete: a,
                            element: l,
                            ...u
                        } = this.options, h = new ta.s({ ...u,
                            keyframes: i,
                            duration: n,
                            type: r,
                            ease: s,
                            times: o,
                            isGenerator: !0
                        }), d = (0, v.w)(this.time);
                        t.setWithVelocity(h.sample(d - 10).value, h.sample(d).value, 10)
                    }
                    let {
                        onStop: a
                    } = this.options;
                    a && a(), this.cancel()
                }
                complete() {
                    let {
                        resolved: t
                    } = this;
                    t && t.animation.finish()
                }
                cancel() {
                    let {
                        resolved: t
                    } = this;
                    t && t.animation.cancel()
                }
                static supports(t) {
                    let {
                        motionValue: e,
                        name: i,
                        repeatDelay: n,
                        repeatType: r,
                        damping: s,
                        type: o
                    } = t;
                    return tg() && i && tl.has(i) && e && e.owner && e.owner.current instanceof HTMLElement && !e.owner.getProps().onUpdate && !n && "mirror" !== r && 0 !== s && "inertia" !== o
                }
            }
            var tw = i(23587);
            class tP {
                constructor(t) {
                    this.stop = () => this.runAll("stop"), this.animations = t.filter(Boolean)
                }
                then(t, e) {
                    return Promise.all(this.animations).then(t).catch(e)
                }
                getAll(t) {
                    return this.animations[0][t]
                }
                setAll(t, e) {
                    for (let i = 0; i < this.animations.length; i++) this.animations[i][t] = e
                }
                attachTimeline(t, e) {
                    let i = this.animations.map(i => (0, tw.t)() && i.attachTimeline ? i.attachTimeline(t) : e(i));
                    return () => {
                        i.forEach((t, e) => {
                            t && t(), this.animations[e].stop()
                        })
                    }
                }
                get time() {
                    return this.getAll("time")
                }
                set time(t) {
                    this.setAll("time", t)
                }
                get speed() {
                    return this.getAll("speed")
                }
                set speed(t) {
                    this.setAll("speed", t)
                }
                get startTime() {
                    return this.getAll("startTime")
                }
                get duration() {
                    let t = 0;
                    for (let e = 0; e < this.animations.length; e++) t = Math.max(t, this.animations[e].duration);
                    return t
                }
                runAll(t) {
                    this.animations.forEach(e => e[t]())
                }
                flatten() {
                    this.runAll("flatten")
                }
                play() {
                    this.runAll("play")
                }
                pause() {
                    this.runAll("pause")
                }
                cancel() {
                    this.runAll("cancel")
                }
                complete() {
                    this.runAll("complete")
                }
            }
            let tT = (t, e, i, n = {}, r, s) => o => {
                    let a = T(n, t) || {},
                        l = a.delay || n.delay || 0,
                        {
                            elapsed: u = 0
                        } = n;
                    u -= (0, v.w)(l);
                    let h = {
                        keyframes: Array.isArray(i) ? i : [null, i],
                        ease: "easeOut",
                        velocity: e.getVelocity(),
                        ...a,
                        delay: -u,
                        onUpdate: t => {
                            e.set(t), a.onUpdate && a.onUpdate(t)
                        },
                        onComplete: () => {
                            o(), a.onComplete && a.onComplete()
                        },
                        name: t,
                        motionValue: e,
                        element: s ? void 0 : r
                    };
                    ! function({
                        when: t,
                        delay: e,
                        delayChildren: i,
                        staggerChildren: n,
                        staggerDirection: r,
                        repeat: s,
                        repeatType: o,
                        repeatDelay: a,
                        from: l,
                        elapsed: u,
                        ...h
                    }) {
                        return !!Object.keys(h).length
                    }(a) && (h = { ...h,
                        ...P(t, h)
                    }), h.duration && (h.duration = (0, v.w)(h.duration)), h.repeatDelay && (h.repeatDelay = (0, v.w)(h.repeatDelay)), void 0 !== h.from && (h.keyframes[0] = h.from);
                    let d = !1;
                    if (!1 !== h.type && (0 !== h.duration || h.repeatDelay) || (h.duration = 0, 0 !== h.delay || (d = !0)), (S.c.current || b.c.skipAnimations) && (d = !0, h.duration = 0, h.delay = 0), d && !s && void 0 !== e.get()) {
                        let t = (0, A.$)(h.keyframes, a);
                        if (void 0 !== t) return V.Wi.update(() => {
                            h.onUpdate(t), h.onComplete()
                        }), new tP([])
                    }
                    return !s && tx.supports(h) ? new tx(h) : new ta.s(h)
                },
                tb = t => !!(t && "object" == typeof t && t.mix && t.toValue),
                tS = t => r(t) ? t[t.length - 1] || 0 : t;
            var tA = i(51935);
            let tV = t => t.replace(/([a-z])([A-Z])/gu, "$1-$2").toLowerCase(),
                tE = "data-" + tV("framerAppearId");
            var tD = i(75469);

            function tM(t, e) {
                let i = t.getValue("willChange");
                if ((0, tD.i)(i) && i.add) return i.add(e)
            }

            function tC(t, e, {
                delay: i = 0,
                transitionOverride: n,
                type: r
            } = {}) {
                var s;
                let {
                    transition: o = t.getDefaultTransition(),
                    transitionEnd: a,
                    ...l
                } = e;
                n && (o = n);
                let h = [],
                    d = r && t.animationState && t.animationState.getState()[r];
                for (let e in l) {
                    let n = t.getValue(e, null !== (s = t.latestValues[e]) && void 0 !== s ? s : null),
                        r = l[e];
                    if (void 0 === r || d && function({
                            protectedKeys: t,
                            needsAnimating: e
                        }, i) {
                            let n = t.hasOwnProperty(i) && !0 !== e[i];
                            return e[i] = !1, n
                        }(d, e)) continue;
                    let a = {
                            delay: i,
                            ...T(o || {}, e)
                        },
                        u = !1;
                    if (window.MotionHandoffAnimation) {
                        let i = t.props[tE];
                        if (i) {
                            let t = window.MotionHandoffAnimation(i, e, V.Wi);
                            null !== t && (a.startTime = t, u = !0)
                        }
                    }
                    tM(t, e), n.start(tT(e, n, r, t.shouldReduceMotion && f.G.has(e) ? {
                        type: !1
                    } : a, t, u));
                    let c = n.animation;
                    c && h.push(c)
                }
                return a && Promise.all(h).then(() => {
                    V.Wi.update(() => {
                        a && function(t, e) {
                            let {
                                transitionEnd: i = {},
                                transition: n = {},
                                ...r
                            } = u(t, e) || {};
                            for (let e in r = { ...r,
                                    ...i
                                }) {
                                let i = tS(r[e]);
                                t.hasValue(e) ? t.getValue(e).set(i) : t.addValue(e, (0, tA.BX)(i))
                            }
                        }(t, a)
                    })
                }), h
            }

            function tR(t, e, i = {}) {
                var n;
                let r = u(t, e, "exit" === i.type ? null === (n = t.presenceContext) || void 0 === n ? void 0 : n.custom : void 0),
                    {
                        transition: s = t.getDefaultTransition() || {}
                    } = r || {};
                i.transitionOverride && (s = i.transitionOverride);
                let o = r ? () => Promise.all(tC(t, r, i)) : () => Promise.resolve(),
                    a = t.variantChildren && t.variantChildren.size ? (n = 0) => {
                        let {
                            delayChildren: r = 0,
                            staggerChildren: o,
                            staggerDirection: a
                        } = s;
                        return function(t, e, i = 0, n = 0, r = 1, s) {
                            let o = [],
                                a = (t.variantChildren.size - 1) * n,
                                l = 1 === r ? (t = 0) => t * n : (t = 0) => a - t * n;
                            return Array.from(t.variantChildren).sort(tk).forEach((t, n) => {
                                t.notify("AnimationStart", e), o.push(tR(t, e, { ...s,
                                    delay: i + l(n)
                                }).then(() => t.notify("AnimationComplete", e)))
                            }), Promise.all(o)
                        }(t, e, r + n, o, a, i)
                    } : () => Promise.resolve(),
                    {
                        when: l
                    } = s;
                if (!l) return Promise.all([o(), a(i.delay)]); {
                    let [t, e] = "beforeChildren" === l ? [o, a] : [a, o];
                    return t().then(() => e())
                }
            }

            function tk(t, e) {
                return t.sortNodePosition(e)
            }
            let tL = d.length,
                tj = [...h].reverse(),
                tF = h.length;

            function tB(t = !1) {
                return {
                    isActive: t,
                    protectedKeys: {},
                    needsAnimating: {},
                    prevResolvedValues: {}
                }
            }

            function tO() {
                return {
                    animate: tB(!0),
                    whileInView: tB(),
                    whileHover: tB(),
                    whileTap: tB(),
                    whileDrag: tB(),
                    whileFocus: tB(),
                    exit: tB()
                }
            }
            class t$ {
                constructor(t) {
                    this.isMounted = !1, this.node = t
                }
                update() {}
            }
            class tW extends t$ {
                constructor(t) {
                    super(t), t.animationState || (t.animationState = function(t) {
                        let e = e => Promise.all(e.map(({
                                animation: e,
                                options: i
                            }) => (function(t, e, i = {}) {
                                let n;
                                if (t.notify("AnimationStart", e), Array.isArray(e)) n = Promise.all(e.map(e => tR(t, e, i)));
                                else if ("string" == typeof e) n = tR(t, e, i);
                                else {
                                    let r = "function" == typeof e ? u(t, e, i.custom) : e;
                                    n = Promise.all(tC(t, r, i))
                                }
                                return n.then(() => {
                                    t.notify("AnimationComplete", e)
                                })
                            })(t, e, i))),
                            i = tO(),
                            a = !0,
                            l = e => (i, n) => {
                                var r;
                                let s = u(t, n, "exit" === e ? null === (r = t.presenceContext) || void 0 === r ? void 0 : r.custom : void 0);
                                if (s) {
                                    let {
                                        transition: t,
                                        transitionEnd: e,
                                        ...n
                                    } = s;
                                    i = { ...i,
                                        ...n,
                                        ...e
                                    }
                                }
                                return i
                            };

                        function h(u) {
                            let {
                                props: h
                            } = t, c = function t(e) {
                                if (!e) return;
                                if (!e.isControllingVariants) {
                                    let i = e.parent && t(e.parent) || {};
                                    return void 0 !== e.props.initial && (i.initial = e.props.initial), i
                                }
                                let i = {};
                                for (let t = 0; t < tL; t++) {
                                    let n = d[t],
                                        r = e.props[n];
                                    (o(r) || !1 === r) && (i[n] = r)
                                }
                                return i
                            }(t.parent) || {}, p = [], m = new Set, f = {}, v = 1 / 0;
                            for (let e = 0; e < tF; e++) {
                                var g;
                                let d = tj[e],
                                    y = i[d],
                                    x = void 0 !== h[d] ? h[d] : c[d],
                                    w = o(x),
                                    P = d === u ? y.isActive : null;
                                !1 === P && (v = e);
                                let T = x === c[d] && x !== h[d] && w;
                                if (T && a && t.manuallyAnimateOnMount && (T = !1), y.protectedKeys = { ...f
                                    }, !y.isActive && null === P || !x && !y.prevProp || n(x) || "boolean" == typeof x) continue;
                                let b = (g = y.prevProp, "string" == typeof x ? x !== g : !!Array.isArray(x) && !s(x, g)),
                                    S = b || d === u && y.isActive && !T && w || e > v && w,
                                    A = !1,
                                    V = Array.isArray(x) ? x : [x],
                                    E = V.reduce(l(d), {});
                                !1 === P && (E = {});
                                let {
                                    prevResolvedValues: D = {}
                                } = y, M = { ...D,
                                    ...E
                                }, C = e => {
                                    S = !0, m.has(e) && (A = !0, m.delete(e)), y.needsAnimating[e] = !0;
                                    let i = t.getValue(e);
                                    i && (i.liveStyle = !1)
                                };
                                for (let t in M) {
                                    let e = E[t],
                                        i = D[t];
                                    if (!f.hasOwnProperty(t))(r(e) && r(i) ? s(e, i) : e === i) ? void 0 !== e && m.has(t) ? C(t) : y.protectedKeys[t] = !0 : null != e ? C(t) : m.add(t)
                                }
                                y.prevProp = x, y.prevResolvedValues = E, y.isActive && (f = { ...f,
                                    ...E
                                }), a && t.blockInitialAnimation && (S = !1);
                                let R = !(T && b) || A;
                                S && R && p.push(...V.map(t => ({
                                    animation: t,
                                    options: {
                                        type: d
                                    }
                                })))
                            }
                            if (m.size) {
                                let e = {};
                                m.forEach(i => {
                                    let n = t.getBaseTarget(i),
                                        r = t.getValue(i);
                                    r && (r.liveStyle = !0), e[i] = null != n ? n : null
                                }), p.push({
                                    animation: e
                                })
                            }
                            let y = !!p.length;
                            return a && (!1 === h.initial || h.initial === h.animate) && !t.manuallyAnimateOnMount && (y = !1), a = !1, y ? e(p) : Promise.resolve()
                        }
                        return {
                            animateChanges: h,
                            setActive: function(e, n) {
                                var r;
                                if (i[e].isActive === n) return Promise.resolve();
                                null === (r = t.variantChildren) || void 0 === r || r.forEach(t => {
                                    var i;
                                    return null === (i = t.animationState) || void 0 === i ? void 0 : i.setActive(e, n)
                                }), i[e].isActive = n;
                                let s = h(e);
                                for (let t in i) i[t].protectedKeys = {};
                                return s
                            },
                            setAnimateFunction: function(i) {
                                e = i(t)
                            },
                            getState: () => i,
                            reset: () => {
                                i = tO(), a = !0
                            }
                        }
                    }(t))
                }
                updateAnimationControlsSubscription() {
                    let {
                        animate: t
                    } = this.node.getProps();
                    n(t) && (this.unmountControls = t.subscribe(this.node))
                }
                mount() {
                    this.updateAnimationControlsSubscription()
                }
                update() {
                    let {
                        animate: t
                    } = this.node.getProps(), {
                        animate: e
                    } = this.node.prevProps || {};
                    t !== e && this.updateAnimationControlsSubscription()
                }
                unmount() {
                    var t;
                    this.node.animationState.reset(), null === (t = this.unmountControls) || void 0 === t || t.call(this)
                }
            }
            let tI = 0;
            class tU extends t$ {
                constructor() {
                    super(...arguments), this.id = tI++
                }
                update() {
                    if (!this.node.presenceContext) return;
                    let {
                        isPresent: t,
                        onExitComplete: e
                    } = this.node.presenceContext, {
                        isPresent: i
                    } = this.node.prevPresenceContext || {};
                    if (!this.node.animationState || t === i) return;
                    let n = this.node.animationState.setActive("exit", !t);
                    e && !t && n.then(() => e(this.id))
                }
                mount() {
                    let {
                        register: t
                    } = this.node.presenceContext || {};
                    t && (this.unmount = t(this.id))
                }
                unmount() {}
            }
            let tN = {
                    x: !1,
                    y: !1
                },
                tX = t => "mouse" === t.pointerType ? "number" != typeof t.button || t.button <= 0 : !1 !== t.isPrimary;

            function tz(t) {
                return {
                    point: {
                        x: t.pageX,
                        y: t.pageY
                    }
                }
            }
            let tY = t => e => tX(e) && t(e, tz(e));

            function tK(t, e, i, n = {
                passive: !0
            }) {
                return t.addEventListener(e, i, n), () => t.removeEventListener(e, i)
            }

            function tq(t, e, i, n) {
                return tK(t, e, tY(i), n)
            }
            var tZ = i(60777);
            let tG = (t, e) => Math.abs(t - e);
            class tH {
                constructor(t, e, {
                    transformPagePoint: i,
                    contextWindow: n,
                    dragSnapToOrigin: r = !1
                } = {}) {
                    if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.updatePoint = () => {
                            var t, e;
                            if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let i = tQ(this.lastMoveEventInfo, this.history),
                                n = null !== this.startEvent,
                                r = (t = i.offset, e = {
                                    x: 0,
                                    y: 0
                                }, Math.sqrt(tG(t.x, e.x) ** 2 + tG(t.y, e.y) ** 2) >= 3);
                            if (!n && !r) return;
                            let {
                                point: s
                            } = i, {
                                timestamp: o
                            } = V.frameData;
                            this.history.push({ ...s,
                                timestamp: o
                            });
                            let {
                                onStart: a,
                                onMove: l
                            } = this.handlers;
                            n || (a && a(this.lastMoveEvent, i), this.startEvent = this.lastMoveEvent), l && l(this.lastMoveEvent, i)
                        }, this.handlePointerMove = (t, e) => {
                            this.lastMoveEvent = t, this.lastMoveEventInfo = t_(e, this.transformPagePoint), V.Wi.update(this.updatePoint, !0)
                        }, this.handlePointerUp = (t, e) => {
                            this.end();
                            let {
                                onEnd: i,
                                onSessionEnd: n,
                                resumeAnimation: r
                            } = this.handlers;
                            if (this.dragSnapToOrigin && r && r(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let s = tQ("pointercancel" === t.type ? this.lastMoveEventInfo : t_(e, this.transformPagePoint), this.history);
                            this.startEvent && i && i(t, s), n && n(t, s)
                        }, !tX(t)) return;
                    this.dragSnapToOrigin = r, this.handlers = e, this.transformPagePoint = i, this.contextWindow = n || window;
                    let s = t_(tz(t), this.transformPagePoint),
                        {
                            point: o
                        } = s,
                        {
                            timestamp: a
                        } = V.frameData;
                    this.history = [{ ...o,
                        timestamp: a
                    }];
                    let {
                        onSessionStart: l
                    } = e;
                    l && l(t, tQ(s, this.history)), this.removeListeners = (0, tZ.z)(tq(this.contextWindow, "pointermove", this.handlePointerMove), tq(this.contextWindow, "pointerup", this.handlePointerUp), tq(this.contextWindow, "pointercancel", this.handlePointerUp))
                }
                updateHandlers(t) {
                    this.handlers = t
                }
                end() {
                    this.removeListeners && this.removeListeners(), (0, V.Pn)(this.updatePoint)
                }
            }

            function t_(t, e) {
                return e ? {
                    point: e(t.point)
                } : t
            }

            function tJ(t, e) {
                return {
                    x: t.x - e.x,
                    y: t.y - e.y
                }
            }

            function tQ({
                point: t
            }, e) {
                return {
                    point: t,
                    delta: tJ(t, t0(e)),
                    offset: tJ(t, e[0]),
                    velocity: function(t, e) {
                        if (t.length < 2) return {
                            x: 0,
                            y: 0
                        };
                        let i = t.length - 1,
                            n = null,
                            r = t0(t);
                        for (; i >= 0 && (n = t[i], !(r.timestamp - n.timestamp > (0, v.w)(.1)));) i--;
                        if (!n) return {
                            x: 0,
                            y: 0
                        };
                        let s = (0, v.X)(r.timestamp - n.timestamp);
                        if (0 === s) return {
                            x: 0,
                            y: 0
                        };
                        let o = {
                            x: (r.x - n.x) / s,
                            y: (r.y - n.y) / s
                        };
                        return o.x === 1 / 0 && (o.x = 0), o.y === 1 / 0 && (o.y = 0), o
                    }(e, 0)
                }
            }

            function t0(t) {
                return t[t.length - 1]
            }

            function t1(t) {
                return t && "object" == typeof t && Object.prototype.hasOwnProperty.call(t, "current")
            }
            var t5 = i(73633),
                t3 = i(98082);

            function t2(t) {
                return t.max - t.min
            }

            function t9(t, e, i, n = .5) {
                t.origin = n, t.originPoint = (0, t3.t)(e.min, e.max, t.origin), t.scale = t2(i) / t2(e), t.translate = (0, t3.t)(i.min, i.max, t.origin) - t.originPoint, (t.scale >= .9999 && t.scale <= 1.0001 || isNaN(t.scale)) && (t.scale = 1), (t.translate >= -.01 && t.translate <= .01 || isNaN(t.translate)) && (t.translate = 0)
            }

            function t4(t, e, i, n) {
                t9(t.x, e.x, i.x, n ? n.originX : void 0), t9(t.y, e.y, i.y, n ? n.originY : void 0)
            }

            function t6(t, e, i) {
                t.min = i.min + e.min, t.max = t.min + t2(e)
            }

            function t7(t, e, i) {
                t.min = e.min - i.min, t.max = t.min + t2(e)
            }

            function t8(t, e, i) {
                t7(t.x, e.x, i.x), t7(t.y, e.y, i.y)
            }
            var et = i(71389);

            function ee(t, e, i) {
                return {
                    min: void 0 !== e ? t.min + e : void 0,
                    max: void 0 !== i ? t.max + i - (t.max - t.min) : void 0
                }
            }

            function ei(t, e) {
                let i = e.min - t.min,
                    n = e.max - t.max;
                return e.max - e.min < t.max - t.min && ([i, n] = [n, i]), {
                    min: i,
                    max: n
                }
            }

            function en(t, e, i) {
                return {
                    min: er(t, e),
                    max: er(t, i)
                }
            }

            function er(t, e) {
                return "number" == typeof t ? t : t[e] || 0
            }
            let es = () => ({
                    translate: 0,
                    scale: 1,
                    origin: 0,
                    originPoint: 0
                }),
                eo = () => ({
                    x: es(),
                    y: es()
                }),
                ea = () => ({
                    min: 0,
                    max: 0
                }),
                el = () => ({
                    x: ea(),
                    y: ea()
                });

            function eu(t) {
                return [t("x"), t("y")]
            }

            function eh({
                top: t,
                left: e,
                right: i,
                bottom: n
            }) {
                return {
                    x: {
                        min: e,
                        max: i
                    },
                    y: {
                        min: t,
                        max: n
                    }
                }
            }

            function ed(t) {
                return void 0 === t || 1 === t
            }

            function ec({
                scale: t,
                scaleX: e,
                scaleY: i
            }) {
                return !ed(t) || !ed(e) || !ed(i)
            }

            function ep(t) {
                return ec(t) || em(t) || t.z || t.rotate || t.rotateX || t.rotateY || t.skewX || t.skewY
            }

            function em(t) {
                var e, i;
                return (e = t.x) && "0%" !== e || (i = t.y) && "0%" !== i
            }

            function ef(t, e, i, n, r) {
                return void 0 !== r && (t = n + r * (t - n)), n + i * (t - n) + e
            }

            function ev(t, e = 0, i = 1, n, r) {
                t.min = ef(t.min, e, i, n, r), t.max = ef(t.max, e, i, n, r)
            }

            function eg(t, {
                x: e,
                y: i
            }) {
                ev(t.x, e.translate, e.scale, e.originPoint), ev(t.y, i.translate, i.scale, i.originPoint)
            }

            function ey(t, e) {
                t.min = t.min + e, t.max = t.max + e
            }

            function ex(t, e, i, n, r = .5) {
                let s = (0, t3.t)(t.min, t.max, r);
                ev(t, e, i, s, n)
            }

            function ew(t, e) {
                ex(t.x, e.x, e.scaleX, e.scale, e.originX), ex(t.y, e.y, e.scaleY, e.scale, e.originY)
            }

            function eP(t, e) {
                return eh(function(t, e) {
                    if (!e) return t;
                    let i = e({
                            x: t.left,
                            y: t.top
                        }),
                        n = e({
                            x: t.right,
                            y: t.bottom
                        });
                    return {
                        top: i.y,
                        left: i.x,
                        bottom: n.y,
                        right: n.x
                    }
                }(t.getBoundingClientRect(), e))
            }
            let eT = ({
                    current: t
                }) => t ? t.ownerDocument.defaultView : null,
                eb = new WeakMap;
            class eS {
                constructor(t) {
                    this.openDragLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
                        x: 0,
                        y: 0
                    }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = el(), this.visualElement = t
                }
                start(t, {
                    snapToCursor: e = !1
                } = {}) {
                    let {
                        presenceContext: i
                    } = this.visualElement;
                    if (i && !1 === i.isPresent) return;
                    let {
                        dragSnapToOrigin: n
                    } = this.getProps();
                    this.panSession = new tH(t, {
                        onSessionStart: t => {
                            let {
                                dragSnapToOrigin: i
                            } = this.getProps();
                            i ? this.pauseAnimation() : this.stopAnimation(), e && this.snapToCursor(tz(t).point)
                        },
                        onStart: (t, e) => {
                            let {
                                drag: i,
                                dragPropagation: n,
                                onDragStart: r
                            } = this.getProps();
                            if (i && !n && (this.openDragLock && this.openDragLock(), this.openDragLock = "x" === i || "y" === i ? tN[i] ? null : (tN[i] = !0, () => {
                                    tN[i] = !1
                                }) : tN.x || tN.y ? null : (tN.x = tN.y = !0, () => {
                                    tN.x = tN.y = !1
                                }), !this.openDragLock)) return;
                            this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), eu(t => {
                                let e = this.getAxisMotionValue(t).get() || 0;
                                if (O.aQ.test(e)) {
                                    let {
                                        projection: i
                                    } = this.visualElement;
                                    if (i && i.layout) {
                                        let n = i.layout.layoutBox[t];
                                        if (n) {
                                            let t = t2(n);
                                            e = parseFloat(e) / 100 * t
                                        }
                                    }
                                }
                                this.originPoint[t] = e
                            }), r && V.Wi.postRender(() => r(t, e)), tM(this.visualElement, "transform");
                            let {
                                animationState: s
                            } = this.visualElement;
                            s && s.setActive("whileDrag", !0)
                        },
                        onMove: (t, e) => {
                            let {
                                dragPropagation: i,
                                dragDirectionLock: n,
                                onDirectionLock: r,
                                onDrag: s
                            } = this.getProps();
                            if (!i && !this.openDragLock) return;
                            let {
                                offset: o
                            } = e;
                            if (n && null === this.currentDirection) {
                                this.currentDirection = function(t, e = 10) {
                                    let i = null;
                                    return Math.abs(t.y) > e ? i = "y" : Math.abs(t.x) > e && (i = "x"), i
                                }(o), null !== this.currentDirection && r && r(this.currentDirection);
                                return
                            }
                            this.updateAxis("x", e.point, o), this.updateAxis("y", e.point, o), this.visualElement.render(), s && s(t, e)
                        },
                        onSessionEnd: (t, e) => this.stop(t, e),
                        resumeAnimation: () => eu(t => {
                            var e;
                            return "paused" === this.getAnimationState(t) && (null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.play())
                        })
                    }, {
                        transformPagePoint: this.visualElement.getTransformPagePoint(),
                        dragSnapToOrigin: n,
                        contextWindow: eT(this.visualElement)
                    })
                }
                stop(t, e) {
                    let i = this.isDragging;
                    if (this.cancel(), !i) return;
                    let {
                        velocity: n
                    } = e;
                    this.startAnimation(n);
                    let {
                        onDragEnd: r
                    } = this.getProps();
                    r && V.Wi.postRender(() => r(t, e))
                }
                cancel() {
                    this.isDragging = !1;
                    let {
                        projection: t,
                        animationState: e
                    } = this.visualElement;
                    t && (t.isAnimationBlocked = !1), this.panSession && this.panSession.end(), this.panSession = void 0;
                    let {
                        dragPropagation: i
                    } = this.getProps();
                    !i && this.openDragLock && (this.openDragLock(), this.openDragLock = null), e && e.setActive("whileDrag", !1)
                }
                updateAxis(t, e, i) {
                    let {
                        drag: n
                    } = this.getProps();
                    if (!i || !eA(t, n, this.currentDirection)) return;
                    let r = this.getAxisMotionValue(t),
                        s = this.originPoint[t] + i[t];
                    this.constraints && this.constraints[t] && (s = function(t, {
                        min: e,
                        max: i
                    }, n) {
                        return void 0 !== e && t < e ? t = n ? (0, t3.t)(e, t, n.min) : Math.max(t, e) : void 0 !== i && t > i && (t = n ? (0, t3.t)(i, t, n.max) : Math.min(t, i)), t
                    }(s, this.constraints[t], this.elastic[t])), r.set(s)
                }
                resolveConstraints() {
                    var t;
                    let {
                        dragConstraints: e,
                        dragElastic: i
                    } = this.getProps(), n = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : null === (t = this.visualElement.projection) || void 0 === t ? void 0 : t.layout, r = this.constraints;
                    e && t1(e) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : e && n ? this.constraints = function(t, {
                        top: e,
                        left: i,
                        bottom: n,
                        right: r
                    }) {
                        return {
                            x: ee(t.x, i, r),
                            y: ee(t.y, e, n)
                        }
                    }(n.layoutBox, e) : this.constraints = !1, this.elastic = function(t = .35) {
                        return !1 === t ? t = 0 : !0 === t && (t = .35), {
                            x: en(t, "left", "right"),
                            y: en(t, "top", "bottom")
                        }
                    }(i), r !== this.constraints && n && this.constraints && !this.hasMutatedConstraints && eu(t => {
                        !1 !== this.constraints && this.getAxisMotionValue(t) && (this.constraints[t] = function(t, e) {
                            let i = {};
                            return void 0 !== e.min && (i.min = e.min - t.min), void 0 !== e.max && (i.max = e.max - t.min), i
                        }(n.layoutBox[t], this.constraints[t]))
                    })
                }
                resolveRefConstraints() {
                    var t;
                    let {
                        dragConstraints: e,
                        onMeasureDragConstraints: i
                    } = this.getProps();
                    if (!e || !t1(e)) return !1;
                    let n = e.current;
                    (0, R.k)(null !== n, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.");
                    let {
                        projection: r
                    } = this.visualElement;
                    if (!r || !r.layout) return !1;
                    let s = function(t, e, i) {
                            let n = eP(t, i),
                                {
                                    scroll: r
                                } = e;
                            return r && (ey(n.x, r.offset.x), ey(n.y, r.offset.y)), n
                        }(n, r.root, this.visualElement.getTransformPagePoint()),
                        o = {
                            x: ei((t = r.layout.layoutBox).x, s.x),
                            y: ei(t.y, s.y)
                        };
                    if (i) {
                        let t = i(function({
                            x: t,
                            y: e
                        }) {
                            return {
                                top: e.min,
                                right: t.max,
                                bottom: e.max,
                                left: t.min
                            }
                        }(o));
                        this.hasMutatedConstraints = !!t, t && (o = eh(t))
                    }
                    return o
                }
                startAnimation(t) {
                    let {
                        drag: e,
                        dragMomentum: i,
                        dragElastic: n,
                        dragTransition: r,
                        dragSnapToOrigin: s,
                        onDragTransitionEnd: o
                    } = this.getProps(), a = this.constraints || {};
                    return Promise.all(eu(o => {
                        if (!eA(o, e, this.currentDirection)) return;
                        let l = a && a[o] || {};
                        s && (l = {
                            min: 0,
                            max: 0
                        });
                        let u = {
                            type: "inertia",
                            velocity: i ? t[o] : 0,
                            bounceStiffness: n ? 200 : 1e6,
                            bounceDamping: n ? 40 : 1e7,
                            timeConstant: 750,
                            restDelta: 1,
                            restSpeed: 10,
                            ...r,
                            ...l
                        };
                        return this.startAxisValueAnimation(o, u)
                    })).then(o)
                }
                startAxisValueAnimation(t, e) {
                    let i = this.getAxisMotionValue(t);
                    return tM(this.visualElement, t), i.start(tT(t, i, 0, e, this.visualElement, !1))
                }
                stopAnimation() {
                    eu(t => this.getAxisMotionValue(t).stop())
                }
                pauseAnimation() {
                    eu(t => {
                        var e;
                        return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.pause()
                    })
                }
                getAnimationState(t) {
                    var e;
                    return null === (e = this.getAxisMotionValue(t).animation) || void 0 === e ? void 0 : e.state
                }
                getAxisMotionValue(t) {
                    let e = `_drag${t.toUpperCase()}`,
                        i = this.visualElement.getProps();
                    return i[e] || this.visualElement.getValue(t, (i.initial ? i.initial[t] : void 0) || 0)
                }
                snapToCursor(t) {
                    eu(e => {
                        let {
                            drag: i
                        } = this.getProps();
                        if (!eA(e, i, this.currentDirection)) return;
                        let {
                            projection: n
                        } = this.visualElement, r = this.getAxisMotionValue(e);
                        if (n && n.layout) {
                            let {
                                min: i,
                                max: s
                            } = n.layout.layoutBox[e];
                            r.set(t[e] - (0, t3.t)(i, s, .5))
                        }
                    })
                }
                scalePositionWithinConstraints() {
                    if (!this.visualElement.current) return;
                    let {
                        drag: t,
                        dragConstraints: e
                    } = this.getProps(), {
                        projection: i
                    } = this.visualElement;
                    if (!t1(e) || !i || !this.constraints) return;
                    this.stopAnimation();
                    let n = {
                        x: 0,
                        y: 0
                    };
                    eu(t => {
                        let e = this.getAxisMotionValue(t);
                        if (e && !1 !== this.constraints) {
                            let i = e.get();
                            n[t] = function(t, e) {
                                let i = .5,
                                    n = t2(t),
                                    r = t2(e);
                                return r > n ? i = (0, t5.Y)(e.min, e.max - n, t.min) : n > r && (i = (0, t5.Y)(t.min, t.max - r, e.min)), (0, et.u)(0, 1, i)
                            }({
                                min: i,
                                max: i
                            }, this.constraints[t])
                        }
                    });
                    let {
                        transformTemplate: r
                    } = this.visualElement.getProps();
                    this.visualElement.current.style.transform = r ? r({}, "") : "none", i.root && i.root.updateScroll(), i.updateLayout(), this.resolveConstraints(), eu(e => {
                        if (!eA(e, t, null)) return;
                        let i = this.getAxisMotionValue(e),
                            {
                                min: r,
                                max: s
                            } = this.constraints[e];
                        i.set((0, t3.t)(r, s, n[e]))
                    })
                }
                addListeners() {
                    if (!this.visualElement.current) return;
                    eb.set(this.visualElement, this);
                    let t = tq(this.visualElement.current, "pointerdown", t => {
                            let {
                                drag: e,
                                dragListener: i = !0
                            } = this.getProps();
                            e && i && this.start(t)
                        }),
                        e = () => {
                            let {
                                dragConstraints: t
                            } = this.getProps();
                            t1(t) && t.current && (this.constraints = this.resolveRefConstraints())
                        },
                        {
                            projection: i
                        } = this.visualElement,
                        n = i.addEventListener("measure", e);
                    i && !i.layout && (i.root && i.root.updateScroll(), i.updateLayout()), V.Wi.read(e);
                    let r = tK(window, "resize", () => this.scalePositionWithinConstraints()),
                        s = i.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e
                        }) => {
                            this.isDragging && e && (eu(e => {
                                let i = this.getAxisMotionValue(e);
                                i && (this.originPoint[e] += t[e].translate, i.set(i.get() + t[e].translate))
                            }), this.visualElement.render())
                        });
                    return () => {
                        r(), t(), n(), s && s()
                    }
                }
                getProps() {
                    let t = this.visualElement.getProps(),
                        {
                            drag: e = !1,
                            dragDirectionLock: i = !1,
                            dragPropagation: n = !1,
                            dragConstraints: r = !1,
                            dragElastic: s = .35,
                            dragMomentum: o = !0
                        } = t;
                    return { ...t,
                        drag: e,
                        dragDirectionLock: i,
                        dragPropagation: n,
                        dragConstraints: r,
                        dragElastic: s,
                        dragMomentum: o
                    }
                }
            }

            function eA(t, e, i) {
                return (!0 === e || e === t) && (null === i || i === t)
            }
            class eV extends t$ {
                constructor(t) {
                    super(t), this.removeGroupControls = tr.Z, this.removeListeners = tr.Z, this.controls = new eS(t)
                }
                mount() {
                    let {
                        dragControls: t
                    } = this.node.getProps();
                    t && (this.removeGroupControls = t.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || tr.Z
                }
                unmount() {
                    this.removeGroupControls(), this.removeListeners()
                }
            }
            let eE = t => (e, i) => {
                t && V.Wi.postRender(() => t(e, i))
            };
            class eD extends t$ {
                constructor() {
                    super(...arguments), this.removePointerDownListener = tr.Z
                }
                onPointerDown(t) {
                    this.session = new tH(t, this.createPanHandlers(), {
                        transformPagePoint: this.node.getTransformPagePoint(),
                        contextWindow: eT(this.node)
                    })
                }
                createPanHandlers() {
                    let {
                        onPanSessionStart: t,
                        onPanStart: e,
                        onPan: i,
                        onPanEnd: n
                    } = this.node.getProps();
                    return {
                        onSessionStart: eE(t),
                        onStart: eE(e),
                        onMove: i,
                        onEnd: (t, e) => {
                            delete this.session, n && V.Wi.postRender(() => n(t, e))
                        }
                    }
                }
                mount() {
                    this.removePointerDownListener = tq(this.node.current, "pointerdown", t => this.onPointerDown(t))
                }
                update() {
                    this.session && this.session.updateHandlers(this.createPanHandlers())
                }
                unmount() {
                    this.removePointerDownListener(), this.session && this.session.end()
                }
            }
            var eM = i(57437),
                eC = i(2265),
                eR = i(40123),
                ek = i(26728);
            let eL = (0, eC.createContext)({}),
                ej = {
                    hasAnimatedSinceResize: !0,
                    hasEverUpdated: !1
                };

            function eF(t, e) {
                return e.max === e.min ? 0 : t / (e.max - e.min) * 100
            }
            let eB = {
                    correct: (t, e) => {
                        if (!e.target) return t;
                        if ("string" == typeof t) {
                            if (!O.px.test(t)) return t;
                            t = parseFloat(t)
                        }
                        let i = eF(t, e.target.x),
                            n = eF(t, e.target.y);
                        return `${i}% ${n}%`
                    }
                },
                eO = {},
                {
                    schedule: e$,
                    cancel: eW
                } = (0, i(38701).Z)(queueMicrotask, !1);
            class eI extends eC.Component {
                componentDidMount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: i,
                        layoutId: n
                    } = this.props, {
                        projection: r
                    } = t;
                    Object.assign(eO, eN), r && (e.group && e.group.add(r), i && i.register && n && i.register(r), r.root.didUpdate(), r.addEventListener("animationComplete", () => {
                        this.safeToRemove()
                    }), r.setOptions({ ...r.options,
                        onExitComplete: () => this.safeToRemove()
                    })), ej.hasEverUpdated = !0
                }
                getSnapshotBeforeUpdate(t) {
                    let {
                        layoutDependency: e,
                        visualElement: i,
                        drag: n,
                        isPresent: r
                    } = this.props, s = i.projection;
                    return s && (s.isPresent = r, n || t.layoutDependency !== e || void 0 === e ? s.willUpdate() : this.safeToRemove(), t.isPresent === r || (r ? s.promote() : s.relegate() || V.Wi.postRender(() => {
                        let t = s.getStack();
                        t && t.members.length || this.safeToRemove()
                    }))), null
                }
                componentDidUpdate() {
                    let {
                        projection: t
                    } = this.props.visualElement;
                    t && (t.root.didUpdate(), e$.postRender(() => {
                        !t.currentAnimation && t.isLead() && this.safeToRemove()
                    }))
                }
                componentWillUnmount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: i
                    } = this.props, {
                        projection: n
                    } = t;
                    n && (n.scheduleCheckAfterUnmount(), e && e.group && e.group.remove(n), i && i.deregister && i.deregister(n))
                }
                safeToRemove() {
                    let {
                        safeToRemove: t
                    } = this.props;
                    t && t()
                }
                render() {
                    return null
                }
            }

            function eU(t) {
                let [e, i] = function() {
                    let t = (0, eC.useContext)(eR.O);
                    if (null === t) return [!0, null];
                    let {
                        isPresent: e,
                        onExitComplete: i,
                        register: n
                    } = t, r = (0, eC.useId)();
                    (0, eC.useEffect)(() => n(r), []);
                    let s = (0, eC.useCallback)(() => i && i(r), [r, i]);
                    return !e && i ? [!1, s] : [!0]
                }(), n = (0, eC.useContext)(ek.p);
                return (0, eM.jsx)(eI, { ...t,
                    layoutGroup: n,
                    switchLayoutGroup: (0, eC.useContext)(eL),
                    isPresent: e,
                    safeToRemove: i
                })
            }
            let eN = {
                borderRadius: { ...eB,
                    applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
                },
                borderTopLeftRadius: eB,
                borderTopRightRadius: eB,
                borderBottomLeftRadius: eB,
                borderBottomRightRadius: eB,
                boxShadow: {
                    correct: (t, {
                        treeScale: e,
                        projectionDelta: i
                    }) => {
                        let n = N.P.parse(t);
                        if (n.length > 5) return t;
                        let r = N.P.createTransformer(t),
                            s = "number" != typeof n[0] ? 1 : 0,
                            o = i.x.scale * e.x,
                            a = i.y.scale * e.y;
                        n[0 + s] /= o, n[1 + s] /= a;
                        let l = (0, t3.t)(o, a, .5);
                        return "number" == typeof n[2 + s] && (n[2 + s] /= l), "number" == typeof n[3 + s] && (n[3 + s] /= l), r(n)
                    }
                }
            };
            var eX = i(70786);
            let ez = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
                eY = ez.length,
                eK = t => "string" == typeof t ? parseFloat(t) : t,
                eq = t => "number" == typeof t || O.px.test(t);

            function eZ(t, e) {
                return void 0 !== t[e] ? t[e] : t.borderRadius
            }
            let eG = e_(0, .5, M.Bn),
                eH = e_(.5, .95, tr.Z);

            function e_(t, e, i) {
                return n => n < t ? 0 : n > e ? 1 : i((0, t5.Y)(t, e, n))
            }

            function eJ(t, e) {
                t.min = e.min, t.max = e.max
            }

            function eQ(t, e) {
                eJ(t.x, e.x), eJ(t.y, e.y)
            }

            function e0(t, e) {
                t.translate = e.translate, t.scale = e.scale, t.originPoint = e.originPoint, t.origin = e.origin
            }

            function e1(t, e, i, n, r) {
                return t -= e, t = n + 1 / i * (t - n), void 0 !== r && (t = n + 1 / r * (t - n)), t
            }

            function e5(t, e, [i, n, r], s, o) {
                ! function(t, e = 0, i = 1, n = .5, r, s = t, o = t) {
                    if (O.aQ.test(e) && (e = parseFloat(e), e = (0, t3.t)(o.min, o.max, e / 100) - o.min), "number" != typeof e) return;
                    let a = (0, t3.t)(s.min, s.max, n);
                    t === s && (a -= e), t.min = e1(t.min, e, i, a, r), t.max = e1(t.max, e, i, a, r)
                }(t, e[i], e[n], e[r], e.scale, s, o)
            }
            let e3 = ["x", "scaleX", "originX"],
                e2 = ["y", "scaleY", "originY"];

            function e9(t, e, i, n) {
                e5(t.x, e, e3, i ? i.x : void 0, n ? n.x : void 0), e5(t.y, e, e2, i ? i.y : void 0, n ? n.y : void 0)
            }

            function e4(t) {
                return 0 === t.translate && 1 === t.scale
            }

            function e6(t) {
                return e4(t.x) && e4(t.y)
            }

            function e7(t, e) {
                return t.min === e.min && t.max === e.max
            }

            function e8(t, e) {
                return Math.round(t.min) === Math.round(e.min) && Math.round(t.max) === Math.round(e.max)
            }

            function it(t, e) {
                return e8(t.x, e.x) && e8(t.y, e.y)
            }

            function ie(t) {
                return t2(t.x) / t2(t.y)
            }

            function ii(t, e) {
                return t.translate === e.translate && t.scale === e.scale && t.originPoint === e.originPoint
            }
            var ir = i(31824);
            class is {
                constructor() {
                    this.members = []
                }
                add(t) {
                    (0, ir.y4)(this.members, t), t.scheduleRender()
                }
                remove(t) {
                    if ((0, ir.cl)(this.members, t), t === this.prevLead && (this.prevLead = void 0), t === this.lead) {
                        let t = this.members[this.members.length - 1];
                        t && this.promote(t)
                    }
                }
                relegate(t) {
                    let e;
                    let i = this.members.findIndex(e => t === e);
                    if (0 === i) return !1;
                    for (let t = i; t >= 0; t--) {
                        let i = this.members[t];
                        if (!1 !== i.isPresent) {
                            e = i;
                            break
                        }
                    }
                    return !!e && (this.promote(e), !0)
                }
                promote(t, e) {
                    let i = this.lead;
                    if (t !== i && (this.prevLead = i, this.lead = t, t.show(), i)) {
                        i.instance && i.scheduleRender(), t.scheduleRender(), t.resumeFrom = i, e && (t.resumeFrom.preserveOpacity = !0), i.snapshot && (t.snapshot = i.snapshot, t.snapshot.latestValues = i.animationValues || i.latestValues), t.root && t.root.isUpdating && (t.isLayoutDirty = !0);
                        let {
                            crossfade: n
                        } = t.options;
                        !1 === n && i.hide()
                    }
                }
                exitAnimationComplete() {
                    this.members.forEach(t => {
                        let {
                            options: e,
                            resumingFrom: i
                        } = t;
                        e.onExitComplete && e.onExitComplete(), i && i.options.onExitComplete && i.options.onExitComplete()
                    })
                }
                scheduleRender() {
                    this.members.forEach(t => {
                        t.instance && t.scheduleRender(!1)
                    })
                }
                removeLeadSnapshot() {
                    this.lead && this.lead.snapshot && (this.lead.snapshot = void 0)
                }
            }
            let io = (t, e) => t.depth - e.depth;
            class ia {
                constructor() {
                    this.children = [], this.isDirty = !1
                }
                add(t) {
                    (0, ir.y4)(this.children, t), this.isDirty = !0
                }
                remove(t) {
                    (0, ir.cl)(this.children, t), this.isDirty = !0
                }
                forEach(t) {
                    this.isDirty && this.children.sort(io), this.isDirty = !1, this.children.forEach(t)
                }
            }

            function il(t) {
                let e = (0, tD.i)(t) ? t.get() : t;
                return tb(e) ? e.toValue() : e
            }
            var iu = i(94521);
            let ih = {
                    type: "projectionFrame",
                    totalNodes: 0,
                    resolvedTargetDeltas: 0,
                    recalculatedProjection: 0
                },
                id = "undefined" != typeof window && void 0 !== window.MotionDebug,
                ic = ["", "X", "Y", "Z"],
                ip = {
                    visibility: "hidden"
                },
                im = 0;

            function iv(t, e, i, n) {
                let {
                    latestValues: r
                } = e;
                r[t] && (i[t] = r[t], e.setStaticValue(t, 0), n && (n[t] = 0))
            }

            function ig({
                attachResizeListener: t,
                defaultParent: e,
                measureScroll: i,
                checkIsScrollRoot: n,
                resetTransform: r
            }) {
                return class {
                    constructor(t = {}, i = null == e ? void 0 : e()) {
                        this.id = im++, this.animationId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
                            x: 1,
                            y: 1
                        }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                            this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
                        }, this.updateProjection = () => {
                            this.projectionUpdateScheduled = !1, id && (ih.totalNodes = ih.resolvedTargetDeltas = ih.recalculatedProjection = 0), this.nodes.forEach(iw), this.nodes.forEach(iE), this.nodes.forEach(iD), this.nodes.forEach(iP), id && window.MotionDebug.record(ih)
                        }, this.resolvedRelativeTargetAt = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = t, this.root = i ? i.root || i : this, this.path = i ? [...i.path, i] : [], this.parent = i, this.depth = i ? i.depth + 1 : 0;
                        for (let t = 0; t < this.path.length; t++) this.path[t].shouldResetTransform = !0;
                        this.root === this && (this.nodes = new ia)
                    }
                    addEventListener(t, e) {
                        return this.eventHandlers.has(t) || this.eventHandlers.set(t, new eX.L), this.eventHandlers.get(t).add(e)
                    }
                    notifyListeners(t, ...e) {
                        let i = this.eventHandlers.get(t);
                        i && i.notify(...e)
                    }
                    hasListeners(t) {
                        return this.eventHandlers.has(t)
                    }
                    mount(e, i = this.root.hasTreeAnimated) {
                        if (this.instance) return;
                        this.isSVG = e instanceof SVGElement && "svg" !== e.tagName, this.instance = e;
                        let {
                            layoutId: n,
                            layout: r,
                            visualElement: s
                        } = this.options;
                        if (s && !s.current && s.mount(e), this.root.nodes.add(this), this.parent && this.parent.children.add(this), i && (r || n) && (this.isLayoutDirty = !0), t) {
                            let i;
                            let n = () => this.root.updateBlockedByResize = !1;
                            t(e, () => {
                                this.root.updateBlockedByResize = !0, i && i(), i = function(t, e) {
                                    let i = iu.X.now(),
                                        n = ({
                                            timestamp: e
                                        }) => {
                                            let r = e - i;
                                            r >= 250 && ((0, V.Pn)(n), t(r - 250))
                                        };
                                    return V.Wi.read(n, !0), () => (0, V.Pn)(n)
                                }(n, 0), ej.hasAnimatedSinceResize && (ej.hasAnimatedSinceResize = !1, this.nodes.forEach(iV))
                            })
                        }
                        n && this.root.registerSharedNode(n, this), !1 !== this.options.animate && s && (n || r) && this.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e,
                            hasRelativeTargetChanged: i,
                            layout: n
                        }) => {
                            if (this.isTreeAnimationBlocked()) {
                                this.target = void 0, this.relativeTarget = void 0;
                                return
                            }
                            let r = this.options.transition || s.getDefaultTransition() || ij,
                                {
                                    onLayoutAnimationStart: o,
                                    onLayoutAnimationComplete: a
                                } = s.getProps(),
                                l = !this.targetLayout || !it(this.targetLayout, n) || i,
                                u = !e && i;
                            if (this.options.layoutRoot || this.resumeFrom && this.resumeFrom.instance || u || e && (l || !this.currentAnimation)) {
                                this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0), this.setAnimationOrigin(t, u);
                                let e = { ...T(r, "layout"),
                                    onPlay: o,
                                    onComplete: a
                                };
                                (s.shouldReduceMotion || this.options.layoutRoot) && (e.delay = 0, e.type = !1), this.startAnimation(e)
                            } else e || iV(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                            this.targetLayout = n
                        })
                    }
                    unmount() {
                        this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
                        let t = this.getStack();
                        t && t.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, (0, V.Pn)(this.updateProjection)
                    }
                    blockUpdate() {
                        this.updateManuallyBlocked = !0
                    }
                    unblockUpdate() {
                        this.updateManuallyBlocked = !1
                    }
                    isUpdateBlocked() {
                        return this.updateManuallyBlocked || this.updateBlockedByResize
                    }
                    isTreeAnimationBlocked() {
                        return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
                    }
                    startUpdate() {
                        !this.isUpdateBlocked() && (this.isUpdating = !0, this.nodes && this.nodes.forEach(iM), this.animationId++)
                    }
                    getTransformTemplate() {
                        let {
                            visualElement: t
                        } = this.options;
                        return t && t.getProps().transformTemplate
                    }
                    willUpdate(t = !0) {
                        if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
                            this.options.onExitComplete && this.options.onExitComplete();
                            return
                        }
                        if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && function t(e) {
                                if (e.hasCheckedOptimisedAppear = !0, e.root === e) return;
                                let {
                                    visualElement: i
                                } = e.options;
                                if (!i) return;
                                let n = i.props[tE];
                                if (window.MotionHasOptimisedAnimation(n, "transform")) {
                                    let {
                                        layout: t,
                                        layoutId: i
                                    } = e.options;
                                    window.MotionCancelOptimisedAnimation(n, "transform", V.Wi, !(t || i))
                                }
                                let {
                                    parent: r
                                } = e;
                                r && !r.hasCheckedOptimisedAppear && t(r)
                            }(this), this.root.isUpdating || this.root.startUpdate(), this.isLayoutDirty) return;
                        this.isLayoutDirty = !0;
                        for (let t = 0; t < this.path.length; t++) {
                            let e = this.path[t];
                            e.shouldResetTransform = !0, e.updateScroll("snapshot"), e.options.layoutRoot && e.willUpdate(!1)
                        }
                        let {
                            layoutId: e,
                            layout: i
                        } = this.options;
                        if (void 0 === e && !i) return;
                        let n = this.getTransformTemplate();
                        this.prevTransformTemplateValue = n ? n(this.latestValues, "") : void 0, this.updateSnapshot(), t && this.notifyListeners("willUpdate")
                    }
                    update() {
                        if (this.updateScheduled = !1, this.isUpdateBlocked()) {
                            this.unblockUpdate(), this.clearAllSnapshots(), this.nodes.forEach(ib);
                            return
                        }
                        this.isUpdating || this.nodes.forEach(iS), this.isUpdating = !1, this.nodes.forEach(iA), this.nodes.forEach(iy), this.nodes.forEach(ix), this.clearAllSnapshots();
                        let t = iu.X.now();
                        V.frameData.delta = (0, et.u)(0, 1e3 / 60, t - V.frameData.timestamp), V.frameData.timestamp = t, V.frameData.isProcessing = !0, V.yL.update.process(V.frameData), V.yL.preRender.process(V.frameData), V.yL.render.process(V.frameData), V.frameData.isProcessing = !1
                    }
                    didUpdate() {
                        this.updateScheduled || (this.updateScheduled = !0, e$.read(this.scheduleUpdate))
                    }
                    clearAllSnapshots() {
                        this.nodes.forEach(iT), this.sharedNodes.forEach(iC)
                    }
                    scheduleUpdateProjection() {
                        this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, V.Wi.preRender(this.updateProjection, !1, !0))
                    }
                    scheduleCheckAfterUnmount() {
                        V.Wi.postRender(() => {
                            this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
                        })
                    }
                    updateSnapshot() {
                        !this.snapshot && this.instance && (this.snapshot = this.measure())
                    }
                    updateLayout() {
                        if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
                        if (this.resumeFrom && !this.resumeFrom.instance)
                            for (let t = 0; t < this.path.length; t++) this.path[t].updateScroll();
                        let t = this.layout;
                        this.layout = this.measure(!1), this.layoutCorrected = el(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
                        let {
                            visualElement: e
                        } = this.options;
                        e && e.notify("LayoutMeasure", this.layout.layoutBox, t ? t.layoutBox : void 0)
                    }
                    updateScroll(t = "measure") {
                        let e = !!(this.options.layoutScroll && this.instance);
                        if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === t && (e = !1), e) {
                            let e = n(this.instance);
                            this.scroll = {
                                animationId: this.root.animationId,
                                phase: t,
                                isRoot: e,
                                offset: i(this.instance),
                                wasRoot: this.scroll ? this.scroll.isRoot : e
                            }
                        }
                    }
                    resetTransform() {
                        if (!r) return;
                        let t = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout,
                            e = this.projectionDelta && !e6(this.projectionDelta),
                            i = this.getTransformTemplate(),
                            n = i ? i(this.latestValues, "") : void 0,
                            s = n !== this.prevTransformTemplateValue;
                        t && (e || ep(this.latestValues) || s) && (r(this.instance, n), this.shouldResetTransform = !1, this.scheduleRender())
                    }
                    measure(t = !0) {
                        var e;
                        let i = this.measurePageBox(),
                            n = this.removeElementScroll(i);
                        return t && (n = this.removeTransform(n)), iO((e = n).x), iO(e.y), {
                            animationId: this.root.animationId,
                            measuredBox: i,
                            layoutBox: n,
                            latestValues: {},
                            source: this.id
                        }
                    }
                    measurePageBox() {
                        var t;
                        let {
                            visualElement: e
                        } = this.options;
                        if (!e) return el();
                        let i = e.measureViewportBox();
                        if (!((null === (t = this.scroll) || void 0 === t ? void 0 : t.wasRoot) || this.path.some(iW))) {
                            let {
                                scroll: t
                            } = this.root;
                            t && (ey(i.x, t.offset.x), ey(i.y, t.offset.y))
                        }
                        return i
                    }
                    removeElementScroll(t) {
                        var e;
                        let i = el();
                        if (eQ(i, t), null === (e = this.scroll) || void 0 === e ? void 0 : e.wasRoot) return i;
                        for (let e = 0; e < this.path.length; e++) {
                            let n = this.path[e],
                                {
                                    scroll: r,
                                    options: s
                                } = n;
                            n !== this.root && r && s.layoutScroll && (r.wasRoot && eQ(i, t), ey(i.x, r.offset.x), ey(i.y, r.offset.y))
                        }
                        return i
                    }
                    applyTransform(t, e = !1) {
                        let i = el();
                        eQ(i, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let n = this.path[t];
                            !e && n.options.layoutScroll && n.scroll && n !== n.root && ew(i, {
                                x: -n.scroll.offset.x,
                                y: -n.scroll.offset.y
                            }), ep(n.latestValues) && ew(i, n.latestValues)
                        }
                        return ep(this.latestValues) && ew(i, this.latestValues), i
                    }
                    removeTransform(t) {
                        let e = el();
                        eQ(e, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let i = this.path[t];
                            if (!i.instance || !ep(i.latestValues)) continue;
                            ec(i.latestValues) && i.updateSnapshot();
                            let n = el();
                            eQ(n, i.measurePageBox()), e9(e, i.latestValues, i.snapshot ? i.snapshot.layoutBox : void 0, n)
                        }
                        return ep(this.latestValues) && e9(e, this.latestValues), e
                    }
                    setTargetDelta(t) {
                        this.targetDelta = t, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
                    }
                    setOptions(t) {
                        this.options = { ...this.options,
                            ...t,
                            crossfade: void 0 === t.crossfade || t.crossfade
                        }
                    }
                    clearMeasurements() {
                        this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
                    }
                    forceRelativeParentToResolveTarget() {
                        this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== V.frameData.timestamp && this.relativeParent.resolveTargetDelta(!0)
                    }
                    resolveTargetDelta(t = !1) {
                        var e, i, n, r;
                        let s = this.getLead();
                        this.isProjectionDirty || (this.isProjectionDirty = s.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = s.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = s.isSharedProjectionDirty);
                        let o = !!this.resumingFrom || this !== s;
                        if (!(t || o && this.isSharedProjectionDirty || this.isProjectionDirty || (null === (e = this.parent) || void 0 === e ? void 0 : e.isProjectionDirty) || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
                        let {
                            layout: a,
                            layoutId: l
                        } = this.options;
                        if (this.layout && (a || l)) {
                            if (this.resolvedRelativeTargetAt = V.frameData.timestamp, !this.targetDelta && !this.relativeTarget) {
                                let t = this.getClosestProjectingParent();
                                t && t.layout && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = el(), this.relativeTargetOrigin = el(), t8(this.relativeTargetOrigin, this.layout.layoutBox, t.layout.layoutBox), eQ(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                            }
                            if (this.relativeTarget || this.targetDelta) {
                                if ((this.target || (this.target = el(), this.targetWithTransforms = el()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target) ? (this.forceRelativeParentToResolveTarget(), i = this.target, n = this.relativeTarget, r = this.relativeParent.target, t6(i.x, n.x, r.x), t6(i.y, n.y, r.y)) : this.targetDelta ? (this.resumingFrom ? this.target = this.applyTransform(this.layout.layoutBox) : eQ(this.target, this.layout.layoutBox), eg(this.target, this.targetDelta)) : eQ(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget) {
                                    this.attemptToResolveRelativeTarget = !1;
                                    let t = this.getClosestProjectingParent();
                                    t && !!t.resumingFrom == !!this.resumingFrom && !t.options.layoutScroll && t.target && 1 !== this.animationProgress ? (this.relativeParent = t, this.forceRelativeParentToResolveTarget(), this.relativeTarget = el(), this.relativeTargetOrigin = el(), t8(this.relativeTargetOrigin, this.target, t.target), eQ(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                                }
                                id && ih.resolvedTargetDeltas++
                            }
                        }
                    }
                    getClosestProjectingParent() {
                        return !this.parent || ec(this.parent.latestValues) || em(this.parent.latestValues) ? void 0 : this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent()
                    }
                    isProjecting() {
                        return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
                    }
                    calcProjection() {
                        var t;
                        let e = this.getLead(),
                            i = !!this.resumingFrom || this !== e,
                            n = !0;
                        if ((this.isProjectionDirty || (null === (t = this.parent) || void 0 === t ? void 0 : t.isProjectionDirty)) && (n = !1), i && (this.isSharedProjectionDirty || this.isTransformDirty) && (n = !1), this.resolvedRelativeTargetAt === V.frameData.timestamp && (n = !1), n) return;
                        let {
                            layout: r,
                            layoutId: s
                        } = this.options;
                        if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(r || s)) return;
                        eQ(this.layoutCorrected, this.layout.layoutBox);
                        let o = this.treeScale.x,
                            a = this.treeScale.y;
                        ! function(t, e, i, n = !1) {
                            let r, s;
                            let o = i.length;
                            if (o) {
                                e.x = e.y = 1;
                                for (let a = 0; a < o; a++) {
                                    s = (r = i[a]).projectionDelta;
                                    let {
                                        visualElement: o
                                    } = r.options;
                                    (!o || !o.props.style || "contents" !== o.props.style.display) && (n && r.options.layoutScroll && r.scroll && r !== r.root && ew(t, {
                                        x: -r.scroll.offset.x,
                                        y: -r.scroll.offset.y
                                    }), s && (e.x *= s.x.scale, e.y *= s.y.scale, eg(t, s)), n && ep(r.latestValues) && ew(t, r.latestValues))
                                }
                                e.x < 1.0000000000001 && e.x > .999999999999 && (e.x = 1), e.y < 1.0000000000001 && e.y > .999999999999 && (e.y = 1)
                            }
                        }(this.layoutCorrected, this.treeScale, this.path, i), e.layout && !e.target && (1 !== this.treeScale.x || 1 !== this.treeScale.y) && (e.target = e.layout.layoutBox, e.targetWithTransforms = el());
                        let {
                            target: l
                        } = e;
                        if (!l) {
                            this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender());
                            return
                        }
                        this.projectionDelta && this.prevProjectionDelta ? (e0(this.prevProjectionDelta.x, this.projectionDelta.x), e0(this.prevProjectionDelta.y, this.projectionDelta.y)) : this.createProjectionDeltas(), t4(this.projectionDelta, this.layoutCorrected, l, this.latestValues), this.treeScale.x === o && this.treeScale.y === a && ii(this.projectionDelta.x, this.prevProjectionDelta.x) && ii(this.projectionDelta.y, this.prevProjectionDelta.y) || (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", l)), id && ih.recalculatedProjection++
                    }
                    hide() {
                        this.isVisible = !1
                    }
                    show() {
                        this.isVisible = !0
                    }
                    scheduleRender(t = !0) {
                        var e;
                        if (null === (e = this.options.visualElement) || void 0 === e || e.scheduleRender(), t) {
                            let t = this.getStack();
                            t && t.scheduleRender()
                        }
                        this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
                    }
                    createProjectionDeltas() {
                        this.prevProjectionDelta = eo(), this.projectionDelta = eo(), this.projectionDeltaWithTransform = eo()
                    }
                    setAnimationOrigin(t, e = !1) {
                        let i;
                        let n = this.snapshot,
                            r = n ? n.latestValues : {},
                            s = { ...this.latestValues
                            },
                            o = eo();
                        this.relativeParent && this.relativeParent.options.layoutRoot || (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !e;
                        let a = el(),
                            l = (n ? n.source : void 0) !== (this.layout ? this.layout.source : void 0),
                            u = this.getStack(),
                            h = !u || u.members.length <= 1,
                            d = !!(l && !h && !0 === this.options.crossfade && !this.path.some(iL));
                        this.animationProgress = 0, this.mixTargetDelta = e => {
                            let n = e / 1e3;
                            if (iR(o.x, t.x, n), iR(o.y, t.y, n), this.setTargetDelta(o), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout) {
                                var u, c, p, m;
                                t8(a, this.layout.layoutBox, this.relativeParent.layout.layoutBox), p = this.relativeTarget, m = this.relativeTargetOrigin, ik(p.x, m.x, a.x, n), ik(p.y, m.y, a.y, n), i && (u = this.relativeTarget, c = i, e7(u.x, c.x) && e7(u.y, c.y)) && (this.isProjectionDirty = !1), i || (i = el()), eQ(i, this.relativeTarget)
                            }
                            l && (this.animationValues = s, function(t, e, i, n, r, s) {
                                r ? (t.opacity = (0, t3.t)(0, void 0 !== i.opacity ? i.opacity : 1, eG(n)), t.opacityExit = (0, t3.t)(void 0 !== e.opacity ? e.opacity : 1, 0, eH(n))) : s && (t.opacity = (0, t3.t)(void 0 !== e.opacity ? e.opacity : 1, void 0 !== i.opacity ? i.opacity : 1, n));
                                for (let r = 0; r < eY; r++) {
                                    let s = `border${ez[r]}Radius`,
                                        o = eZ(e, s),
                                        a = eZ(i, s);
                                    (void 0 !== o || void 0 !== a) && (o || (o = 0), a || (a = 0), 0 === o || 0 === a || eq(o) === eq(a) ? (t[s] = Math.max((0, t3.t)(eK(o), eK(a), n), 0), (O.aQ.test(a) || O.aQ.test(o)) && (t[s] += "%")) : t[s] = a)
                                }(e.rotate || i.rotate) && (t.rotate = (0, t3.t)(e.rotate || 0, i.rotate || 0, n))
                            }(s, r, this.latestValues, n, d, h)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = n
                        }, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0)
                    }
                    startAnimation(t) {
                        this.notifyListeners("animationStart"), this.currentAnimation && this.currentAnimation.stop(), this.resumingFrom && this.resumingFrom.currentAnimation && this.resumingFrom.currentAnimation.stop(), this.pendingAnimation && ((0, V.Pn)(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = V.Wi.update(() => {
                            ej.hasAnimatedSinceResize = !0, this.currentAnimation = function(t, e, i) {
                                let n = (0, tD.i)(0) ? 0 : (0, tA.BX)(0);
                                return n.start(tT("", n, 1e3, i)), n.animation
                            }(0, 0, { ...t,
                                onUpdate: e => {
                                    this.mixTargetDelta(e), t.onUpdate && t.onUpdate(e)
                                },
                                onComplete: () => {
                                    t.onComplete && t.onComplete(), this.completeAnimation()
                                }
                            }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
                        })
                    }
                    completeAnimation() {
                        this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
                        let t = this.getStack();
                        t && t.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
                    }
                    finishAnimation() {
                        this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(1e3), this.currentAnimation.stop()), this.completeAnimation()
                    }
                    applyTransformsToTarget() {
                        let t = this.getLead(),
                            {
                                targetWithTransforms: e,
                                target: i,
                                layout: n,
                                latestValues: r
                            } = t;
                        if (e && i && n) {
                            if (this !== t && this.layout && n && i$(this.options.animationType, this.layout.layoutBox, n.layoutBox)) {
                                i = this.target || el();
                                let e = t2(this.layout.layoutBox.x);
                                i.x.min = t.target.x.min, i.x.max = i.x.min + e;
                                let n = t2(this.layout.layoutBox.y);
                                i.y.min = t.target.y.min, i.y.max = i.y.min + n
                            }
                            eQ(e, i), ew(e, r), t4(this.projectionDeltaWithTransform, this.layoutCorrected, e, r)
                        }
                    }
                    registerSharedNode(t, e) {
                        this.sharedNodes.has(t) || this.sharedNodes.set(t, new is), this.sharedNodes.get(t).add(e);
                        let i = e.options.initialPromotionConfig;
                        e.promote({
                            transition: i ? i.transition : void 0,
                            preserveFollowOpacity: i && i.shouldPreserveFollowOpacity ? i.shouldPreserveFollowOpacity(e) : void 0
                        })
                    }
                    isLead() {
                        let t = this.getStack();
                        return !t || t.lead === this
                    }
                    getLead() {
                        var t;
                        let {
                            layoutId: e
                        } = this.options;
                        return e && (null === (t = this.getStack()) || void 0 === t ? void 0 : t.lead) || this
                    }
                    getPrevLead() {
                        var t;
                        let {
                            layoutId: e
                        } = this.options;
                        return e ? null === (t = this.getStack()) || void 0 === t ? void 0 : t.prevLead : void 0
                    }
                    getStack() {
                        let {
                            layoutId: t
                        } = this.options;
                        if (t) return this.root.sharedNodes.get(t)
                    }
                    promote({
                        needsReset: t,
                        transition: e,
                        preserveFollowOpacity: i
                    } = {}) {
                        let n = this.getStack();
                        n && n.promote(this, i), t && (this.projectionDelta = void 0, this.needsReset = !0), e && this.setOptions({
                            transition: e
                        })
                    }
                    relegate() {
                        let t = this.getStack();
                        return !!t && t.relegate(this)
                    }
                    resetSkewAndRotation() {
                        let {
                            visualElement: t
                        } = this.options;
                        if (!t) return;
                        let e = !1,
                            {
                                latestValues: i
                            } = t;
                        if ((i.z || i.rotate || i.rotateX || i.rotateY || i.rotateZ || i.skewX || i.skewY) && (e = !0), !e) return;
                        let n = {};
                        i.z && iv("z", t, n, this.animationValues);
                        for (let e = 0; e < ic.length; e++) iv(`rotate${ic[e]}`, t, n, this.animationValues), iv(`skew${ic[e]}`, t, n, this.animationValues);
                        for (let e in t.render(), n) t.setStaticValue(e, n[e]), this.animationValues && (this.animationValues[e] = n[e]);
                        t.scheduleRender()
                    }
                    getProjectionStyles(t) {
                        var e, i;
                        if (!this.instance || this.isSVG) return;
                        if (!this.isVisible) return ip;
                        let n = {
                                visibility: ""
                            },
                            r = this.getTransformTemplate();
                        if (this.needsReset) return this.needsReset = !1, n.opacity = "", n.pointerEvents = il(null == t ? void 0 : t.pointerEvents) || "", n.transform = r ? r(this.latestValues, "") : "none", n;
                        let s = this.getLead();
                        if (!this.projectionDelta || !this.layout || !s.target) {
                            let e = {};
                            return this.options.layoutId && (e.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1, e.pointerEvents = il(null == t ? void 0 : t.pointerEvents) || ""), this.hasProjected && !ep(this.latestValues) && (e.transform = r ? r({}, "") : "none", this.hasProjected = !1), e
                        }
                        let o = s.animationValues || s.latestValues;
                        this.applyTransformsToTarget(), n.transform = function(t, e, i) {
                            let n = "",
                                r = t.x.translate / e.x,
                                s = t.y.translate / e.y,
                                o = (null == i ? void 0 : i.z) || 0;
                            if ((r || s || o) && (n = `translate3d(${r}px, ${s}px, ${o}px) `), (1 !== e.x || 1 !== e.y) && (n += `scale(${1/e.x}, ${1/e.y}) `), i) {
                                let {
                                    transformPerspective: t,
                                    rotate: e,
                                    rotateX: r,
                                    rotateY: s,
                                    skewX: o,
                                    skewY: a
                                } = i;
                                t && (n = `perspective(${t}px) ${n}`), e && (n += `rotate(${e}deg) `), r && (n += `rotateX(${r}deg) `), s && (n += `rotateY(${s}deg) `), o && (n += `skewX(${o}deg) `), a && (n += `skewY(${a}deg) `)
                            }
                            let a = t.x.scale * e.x,
                                l = t.y.scale * e.y;
                            return (1 !== a || 1 !== l) && (n += `scale(${a}, ${l})`), n || "none"
                        }(this.projectionDeltaWithTransform, this.treeScale, o), r && (n.transform = r(o, n.transform));
                        let {
                            x: a,
                            y: l
                        } = this.projectionDelta;
                        for (let t in n.transformOrigin = `${100*a.origin}% ${100*l.origin}% 0`, s.animationValues ? n.opacity = s === this ? null !== (i = null !== (e = o.opacity) && void 0 !== e ? e : this.latestValues.opacity) && void 0 !== i ? i : 1 : this.preserveOpacity ? this.latestValues.opacity : o.opacityExit : n.opacity = s === this ? void 0 !== o.opacity ? o.opacity : "" : void 0 !== o.opacityExit ? o.opacityExit : 0, eO) {
                            if (void 0 === o[t]) continue;
                            let {
                                correct: e,
                                applyTo: i
                            } = eO[t], r = "none" === n.transform ? o[t] : e(o[t], s);
                            if (i) {
                                let t = i.length;
                                for (let e = 0; e < t; e++) n[i[e]] = r
                            } else n[t] = r
                        }
                        return this.options.layoutId && (n.pointerEvents = s === this ? il(null == t ? void 0 : t.pointerEvents) || "" : "none"), n
                    }
                    clearSnapshot() {
                        this.resumeFrom = this.snapshot = void 0
                    }
                    resetTree() {
                        this.root.nodes.forEach(t => {
                            var e;
                            return null === (e = t.currentAnimation) || void 0 === e ? void 0 : e.stop()
                        }), this.root.nodes.forEach(ib), this.root.sharedNodes.clear()
                    }
                }
            }

            function iy(t) {
                t.updateLayout()
            }

            function ix(t) {
                var e;
                let i = (null === (e = t.resumeFrom) || void 0 === e ? void 0 : e.snapshot) || t.snapshot;
                if (t.isLead() && t.layout && i && t.hasListeners("didUpdate")) {
                    let {
                        layoutBox: e,
                        measuredBox: n
                    } = t.layout, {
                        animationType: r
                    } = t.options, s = i.source !== t.layout.source;
                    "size" === r ? eu(t => {
                        let n = s ? i.measuredBox[t] : i.layoutBox[t],
                            r = t2(n);
                        n.min = e[t].min, n.max = n.min + r
                    }) : i$(r, i.layoutBox, e) && eu(n => {
                        let r = s ? i.measuredBox[n] : i.layoutBox[n],
                            o = t2(e[n]);
                        r.max = r.min + o, t.relativeTarget && !t.currentAnimation && (t.isProjectionDirty = !0, t.relativeTarget[n].max = t.relativeTarget[n].min + o)
                    });
                    let o = eo();
                    t4(o, e, i.layoutBox);
                    let a = eo();
                    s ? t4(a, t.applyTransform(n, !0), i.measuredBox) : t4(a, e, i.layoutBox);
                    let l = !e6(o),
                        u = !1;
                    if (!t.resumeFrom) {
                        let n = t.getClosestProjectingParent();
                        if (n && !n.resumeFrom) {
                            let {
                                snapshot: r,
                                layout: s
                            } = n;
                            if (r && s) {
                                let o = el();
                                t8(o, i.layoutBox, r.layoutBox);
                                let a = el();
                                t8(a, e, s.layoutBox), it(o, a) || (u = !0), n.options.layoutRoot && (t.relativeTarget = a, t.relativeTargetOrigin = o, t.relativeParent = n)
                            }
                        }
                    }
                    t.notifyListeners("didUpdate", {
                        layout: e,
                        snapshot: i,
                        delta: a,
                        layoutDelta: o,
                        hasLayoutChanged: l,
                        hasRelativeTargetChanged: u
                    })
                } else if (t.isLead()) {
                    let {
                        onExitComplete: e
                    } = t.options;
                    e && e()
                }
                t.options.transition = void 0
            }

            function iw(t) {
                id && ih.totalNodes++, t.parent && (t.isProjecting() || (t.isProjectionDirty = t.parent.isProjectionDirty), t.isSharedProjectionDirty || (t.isSharedProjectionDirty = !!(t.isProjectionDirty || t.parent.isProjectionDirty || t.parent.isSharedProjectionDirty)), t.isTransformDirty || (t.isTransformDirty = t.parent.isTransformDirty))
            }

            function iP(t) {
                t.isProjectionDirty = t.isSharedProjectionDirty = t.isTransformDirty = !1
            }

            function iT(t) {
                t.clearSnapshot()
            }

            function ib(t) {
                t.clearMeasurements()
            }

            function iS(t) {
                t.isLayoutDirty = !1
            }

            function iA(t) {
                let {
                    visualElement: e
                } = t.options;
                e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"), t.resetTransform()
            }

            function iV(t) {
                t.finishAnimation(), t.targetDelta = t.relativeTarget = t.target = void 0, t.isProjectionDirty = !0
            }

            function iE(t) {
                t.resolveTargetDelta()
            }

            function iD(t) {
                t.calcProjection()
            }

            function iM(t) {
                t.resetSkewAndRotation()
            }

            function iC(t) {
                t.removeLeadSnapshot()
            }

            function iR(t, e, i) {
                t.translate = (0, t3.t)(e.translate, 0, i), t.scale = (0, t3.t)(e.scale, 1, i), t.origin = e.origin, t.originPoint = e.originPoint
            }

            function ik(t, e, i, n) {
                t.min = (0, t3.t)(e.min, i.min, n), t.max = (0, t3.t)(e.max, i.max, n)
            }

            function iL(t) {
                return t.animationValues && void 0 !== t.animationValues.opacityExit
            }
            let ij = {
                    duration: .45,
                    ease: [.4, 0, .1, 1]
                },
                iF = t => "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().includes(t),
                iB = iF("applewebkit/") && !iF("chrome/") ? Math.round : tr.Z;

            function iO(t) {
                t.min = iB(t.min), t.max = iB(t.max)
            }

            function i$(t, e, i) {
                return "position" === t || "preserve-aspect" === t && !(.2 >= Math.abs(ie(e) - ie(i)))
            }

            function iW(t) {
                var e;
                return t !== t.root && (null === (e = t.scroll) || void 0 === e ? void 0 : e.wasRoot)
            }
            let iI = ig({
                    attachResizeListener: (t, e) => tK(t, "resize", e),
                    measureScroll: () => ({
                        x: document.documentElement.scrollLeft || document.body.scrollLeft,
                        y: document.documentElement.scrollTop || document.body.scrollTop
                    }),
                    checkIsScrollRoot: () => !0
                }),
                iU = {
                    current: void 0
                },
                iN = ig({
                    measureScroll: t => ({
                        x: t.scrollLeft,
                        y: t.scrollTop
                    }),
                    defaultParent: () => {
                        if (!iU.current) {
                            let t = new iI({});
                            t.mount(window), t.setOptions({
                                layoutScroll: !0
                            }), iU.current = t
                        }
                        return iU.current
                    },
                    resetTransform: (t, e) => {
                        t.style.transform = void 0 !== e ? e : "none"
                    },
                    checkIsScrollRoot: t => "fixed" === window.getComputedStyle(t).position
                });
            var iX = i(34399);

            function iz(t, e) {
                let i = (0, iX.I)(t),
                    n = new AbortController;
                return [i, {
                    passive: !0,
                    ...e,
                    signal: n.signal
                }, () => n.abort()]
            }

            function iY(t) {
                return e => {
                    "touch" === e.pointerType || tN.x || tN.y || t(e)
                }
            }

            function iK(t, e, i) {
                let {
                    props: n
                } = t;
                t.animationState && n.whileHover && t.animationState.setActive("whileHover", "Start" === i);
                let r = n["onHover" + i];
                r && V.Wi.postRender(() => r(e, tz(e)))
            }
            class iq extends t$ {
                mount() {
                    let {
                        current: t
                    } = this.node;
                    t && (this.unmount = function(t, e, i = {}) {
                        let [n, r, s] = iz(t, i), o = iY(t => {
                            let {
                                target: i
                            } = t, n = e(t);
                            if (!n || !i) return;
                            let s = iY(t => {
                                n(t), i.removeEventListener("pointerleave", s)
                            });
                            i.addEventListener("pointerleave", s, r)
                        });
                        return n.forEach(t => {
                            t.addEventListener("pointerenter", o, r)
                        }), s
                    }(t, t => (iK(this.node, t, "Start"), t => iK(this.node, t, "End"))))
                }
                unmount() {}
            }
            class iZ extends t$ {
                constructor() {
                    super(...arguments), this.isActive = !1
                }
                onFocus() {
                    let t = !1;
                    try {
                        t = this.node.current.matches(":focus-visible")
                    } catch (e) {
                        t = !0
                    }
                    t && this.node.animationState && (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
                }
                onBlur() {
                    this.isActive && this.node.animationState && (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
                }
                mount() {
                    this.unmount = (0, tZ.z)(tK(this.node.current, "focus", () => this.onFocus()), tK(this.node.current, "blur", () => this.onBlur()))
                }
                unmount() {}
            }
            let iG = new WeakSet;

            function iH(t) {
                return e => {
                    "Enter" === e.key && t(e)
                }
            }

            function i_(t, e) {
                t.dispatchEvent(new PointerEvent("pointer" + e, {
                    isPrimary: !0,
                    bubbles: !0
                }))
            }
            let iJ = (t, e) => {
                    let i = t.currentTarget;
                    if (!i) return;
                    let n = iH(() => {
                        if (iG.has(i)) return;
                        i_(i, "down");
                        let t = iH(() => {
                            i_(i, "up")
                        });
                        i.addEventListener("keyup", t, e), i.addEventListener("blur", () => i_(i, "cancel"), e)
                    });
                    i.addEventListener("keydown", n, e), i.addEventListener("blur", () => i.removeEventListener("keydown", n), e)
                },
                iQ = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]),
                i0 = (t, e) => !!e && (t === e || i0(t, e.parentElement));

            function i1(t) {
                return tX(t) && !(tN.x || tN.y)
            }

            function i5(t, e, i) {
                let {
                    props: n
                } = t;
                t.animationState && n.whileTap && t.animationState.setActive("whileTap", "Start" === i);
                let r = n["onTap" + ("End" === i ? "" : i)];
                r && V.Wi.postRender(() => r(e, tz(e)))
            }
            class i3 extends t$ {
                mount() {
                    let {
                        current: t
                    } = this.node;
                    t && (this.unmount = function(t, e, i = {}) {
                        let [n, r, s] = iz(t, i), o = t => {
                            let n = t.currentTarget;
                            if (!i1(t) || iG.has(n)) return;
                            iG.add(n);
                            let s = e(t),
                                o = (t, e) => {
                                    window.removeEventListener("pointerup", a), window.removeEventListener("pointercancel", l), i1(t) && iG.has(n) && (iG.delete(n), s && s(t, {
                                        success: e
                                    }))
                                },
                                a = t => {
                                    o(t, i.useGlobalTarget || i0(n, t.target))
                                },
                                l = t => {
                                    o(t, !1)
                                };
                            window.addEventListener("pointerup", a, r), window.addEventListener("pointercancel", l, r)
                        };
                        return n.forEach(t => {
                            iQ.has(t.tagName) || -1 !== t.tabIndex || (t.tabIndex = 0), (i.useGlobalTarget ? window : t).addEventListener("pointerdown", o, r), t.addEventListener("focus", t => iJ(t, r), r)
                        }), s
                    }(t, t => (i5(this.node, t, "Start"), (t, {
                        success: e
                    }) => i5(this.node, t, e ? "End" : "Cancel")), {
                        useGlobalTarget: this.node.props.globalTapTarget
                    }))
                }
                unmount() {}
            }
            let i2 = new WeakMap,
                i9 = new WeakMap,
                i4 = t => {
                    let e = i2.get(t.target);
                    e && e(t)
                },
                i6 = t => {
                    t.forEach(i4)
                },
                i7 = {
                    some: 0,
                    all: 1
                };
            class i8 extends t$ {
                constructor() {
                    super(...arguments), this.hasEnteredView = !1, this.isInView = !1
                }
                startObserver() {
                    this.unmount();
                    let {
                        viewport: t = {}
                    } = this.node.getProps(), {
                        root: e,
                        margin: i,
                        amount: n = "some",
                        once: r
                    } = t, s = {
                        root: e ? e.current : void 0,
                        rootMargin: i,
                        threshold: "number" == typeof n ? n : i7[n]
                    };
                    return function(t, e, i) {
                        let n = function({
                            root: t,
                            ...e
                        }) {
                            let i = t || document;
                            i9.has(i) || i9.set(i, {});
                            let n = i9.get(i),
                                r = JSON.stringify(e);
                            return n[r] || (n[r] = new IntersectionObserver(i6, {
                                root: t,
                                ...e
                            })), n[r]
                        }(e);
                        return i2.set(t, i), n.observe(t), () => {
                            i2.delete(t), n.unobserve(t)
                        }
                    }(this.node.current, s, t => {
                        let {
                            isIntersecting: e
                        } = t;
                        if (this.isInView === e || (this.isInView = e, r && !e && this.hasEnteredView)) return;
                        e && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", e);
                        let {
                            onViewportEnter: i,
                            onViewportLeave: n
                        } = this.node.getProps(), s = e ? i : n;
                        s && s(t)
                    })
                }
                mount() {
                    this.startObserver()
                }
                update() {
                    if ("undefined" == typeof IntersectionObserver) return;
                    let {
                        props: t,
                        prevProps: e
                    } = this.node;
                    ["amount", "margin", "root"].some(function({
                        viewport: t = {}
                    }, {
                        viewport: e = {}
                    } = {}) {
                        return i => t[i] !== e[i]
                    }(t, e)) && this.startObserver()
                }
                unmount() {}
            }
            var nt = i(50456);
            let ne = (0, eC.createContext)({});
            var ni = i(98675);
            let nn = (0, eC.createContext)({
                strict: !1
            });

            function nr(t) {
                return n(t.animate) || d.some(e => o(t[e]))
            }

            function ns(t) {
                return !!(nr(t) || t.variants)
            }

            function no(t) {
                return Array.isArray(t) ? t.join(" ") : t
            }
            let na = {
                    animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
                    exit: ["exit"],
                    drag: ["drag", "dragControls"],
                    focus: ["whileFocus"],
                    hover: ["whileHover", "onHoverStart", "onHoverEnd"],
                    tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
                    pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
                    inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
                    layout: ["layout", "layoutId"]
                },
                nl = {};
            for (let t in na) nl[t] = {
                isEnabled: e => na[t].some(t => !!e[t])
            };
            var nu = i(72412);
            let nh = Symbol.for("motionComponentSymbol"),
                nd = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

            function nc(t) {
                if ("string" != typeof t || t.includes("-"));
                else if (nd.indexOf(t) > -1 || /[A-Z]/u.test(t)) return !0;
                return !1
            }

            function np(t, {
                style: e,
                vars: i
            }, n, r) {
                for (let s in Object.assign(t.style, e, r && r.getProjectionStyles(n)), i) t.style.setProperty(s, i[s])
            }
            let nm = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"]);

            function nf(t, e, i, n) {
                for (let i in np(t, e, void 0, n), e.attrs) t.setAttribute(nm.has(i) ? i : tV(i), e.attrs[i])
            }

            function nv(t, {
                layout: e,
                layoutId: i
            }) {
                return f.G.has(t) || t.startsWith("origin") || (e || void 0 !== i) && (!!eO[t] || "opacity" === t)
            }

            function ng(t, e, i) {
                var n;
                let {
                    style: r
                } = t, s = {};
                for (let o in r)((0, tD.i)(r[o]) || e.style && (0, tD.i)(e.style[o]) || nv(o, t) || (null === (n = null == i ? void 0 : i.getValue(o)) || void 0 === n ? void 0 : n.liveStyle) !== void 0) && (s[o] = r[o]);
                return s
            }

            function ny(t, e, i) {
                let n = ng(t, e, i);
                for (let i in t)((0, tD.i)(t[i]) || (0, tD.i)(e[i])) && (n[-1 !== f._.indexOf(i) ? "attr" + i.charAt(0).toUpperCase() + i.substring(1) : i] = t[i]);
                return n
            }
            var nx = i(39409);
            let nw = t => (e, i) => {
                    let r = (0, eC.useContext)(ne),
                        s = (0, eC.useContext)(eR.O),
                        o = () => (function({
                            scrapeMotionValuesFromProps: t,
                            createRenderState: e,
                            onMount: i
                        }, r, s, o) {
                            let a = {
                                latestValues: function(t, e, i, r) {
                                    let s = {},
                                        o = r(t, {});
                                    for (let t in o) s[t] = il(o[t]);
                                    let {
                                        initial: a,
                                        animate: u
                                    } = t, h = nr(t), d = ns(t);
                                    e && d && !h && !1 !== t.inherit && (void 0 === a && (a = e.initial), void 0 === u && (u = e.animate));
                                    let c = !!i && !1 === i.initial,
                                        p = (c = c || !1 === a) ? u : a;
                                    if (p && "boolean" != typeof p && !n(p)) {
                                        let e = Array.isArray(p) ? p : [p];
                                        for (let i = 0; i < e.length; i++) {
                                            let n = l(t, e[i]);
                                            if (n) {
                                                let {
                                                    transitionEnd: t,
                                                    transition: e,
                                                    ...i
                                                } = n;
                                                for (let t in i) {
                                                    let e = i[t];
                                                    if (Array.isArray(e)) {
                                                        let t = c ? e.length - 1 : 0;
                                                        e = e[t]
                                                    }
                                                    null !== e && (s[t] = e)
                                                }
                                                for (let e in t) s[e] = t[e]
                                            }
                                        }
                                    }
                                    return s
                                }(r, s, o, t),
                                renderState: e()
                            };
                            return i && (a.mount = t => i(r, t, a)), a
                        })(t, e, r, s);
                    return i ? o() : (0, nx.h)(o)
                },
                nP = () => ({
                    style: {},
                    transform: {},
                    transformOrigin: {},
                    vars: {}
                }),
                nT = () => ({ ...nP(),
                    attrs: {}
                }),
                nb = (t, e) => e && "number" == typeof t ? e.transform(t) : t,
                nS = {
                    x: "translateX",
                    y: "translateY",
                    z: "translateZ",
                    transformPerspective: "perspective"
                },
                nA = f._.length;

            function nV(t, e, i) {
                let {
                    style: n,
                    vars: r,
                    transformOrigin: s
                } = t, o = !1, a = !1;
                for (let t in e) {
                    let i = e[t];
                    if (f.G.has(t)) {
                        o = !0;
                        continue
                    }
                    if ((0, L.f)(t)) {
                        r[t] = i;
                        continue
                    } {
                        let e = nb(i, J[t]);
                        t.startsWith("origin") ? (a = !0, s[t] = e) : n[t] = e
                    }
                }
                if (!e.transform && (o || i ? n.transform = function(t, e, i) {
                        let n = "",
                            r = !0;
                        for (let s = 0; s < nA; s++) {
                            let o = f._[s],
                                a = t[o];
                            if (void 0 === a) continue;
                            let l = !0;
                            if (!(l = "number" == typeof a ? a === (o.startsWith("scale") ? 1 : 0) : 0 === parseFloat(a)) || i) {
                                let t = nb(a, J[o]);
                                if (!l) {
                                    r = !1;
                                    let e = nS[o] || o;
                                    n += `${e}(${t}) `
                                }
                                i && (e[o] = t)
                            }
                        }
                        return n = n.trim(), i ? n = i(e, r ? "" : n) : r && (n = "none"), n
                    }(e, t.transform, i) : n.transform && (n.transform = "none")), a) {
                    let {
                        originX: t = "50%",
                        originY: e = "50%",
                        originZ: i = 0
                    } = s;
                    n.transformOrigin = `${t} ${e} ${i}`
                }
            }

            function nE(t, e, i) {
                return "string" == typeof t ? t : O.px.transform(e + i * t)
            }
            let nD = {
                    offset: "stroke-dashoffset",
                    array: "stroke-dasharray"
                },
                nM = {
                    offset: "strokeDashoffset",
                    array: "strokeDasharray"
                };

            function nC(t, {
                attrX: e,
                attrY: i,
                attrScale: n,
                originX: r,
                originY: s,
                pathLength: o,
                pathSpacing: a = 1,
                pathOffset: l = 0,
                ...u
            }, h, d) {
                if (nV(t, u, d), h) {
                    t.style.viewBox && (t.attrs.viewBox = t.style.viewBox);
                    return
                }
                t.attrs = t.style, t.style = {};
                let {
                    attrs: c,
                    style: p,
                    dimensions: m
                } = t;
                c.transform && (m && (p.transform = c.transform), delete c.transform), m && (void 0 !== r || void 0 !== s || p.transform) && (p.transformOrigin = function(t, e, i) {
                    let n = nE(e, t.x, t.width),
                        r = nE(i, t.y, t.height);
                    return `${n} ${r}`
                }(m, void 0 !== r ? r : .5, void 0 !== s ? s : .5)), void 0 !== e && (c.x = e), void 0 !== i && (c.y = i), void 0 !== n && (c.scale = n), void 0 !== o && function(t, e, i = 1, n = 0, r = !0) {
                    t.pathLength = 1;
                    let s = r ? nD : nM;
                    t[s.offset] = O.px.transform(-n);
                    let o = O.px.transform(e),
                        a = O.px.transform(i);
                    t[s.array] = `${o} ${a}`
                }(c, o, a, l, !1)
            }
            let nR = t => "string" == typeof t && "svg" === t.toLowerCase(),
                nk = {
                    useVisualState: nw({
                        scrapeMotionValuesFromProps: ny,
                        createRenderState: nT,
                        onMount: (t, e, {
                            renderState: i,
                            latestValues: n
                        }) => {
                            V.Wi.read(() => {
                                try {
                                    i.dimensions = "function" == typeof e.getBBox ? e.getBBox() : e.getBoundingClientRect()
                                } catch (t) {
                                    i.dimensions = {
                                        x: 0,
                                        y: 0,
                                        width: 0,
                                        height: 0
                                    }
                                }
                            }), V.Wi.render(() => {
                                nC(i, n, nR(e.tagName), t.transformTemplate), nf(e, i)
                            })
                        }
                    })
                },
                nL = {
                    useVisualState: nw({
                        scrapeMotionValuesFromProps: ng,
                        createRenderState: nP
                    })
                };

            function nj(t, e, i) {
                for (let n in e)(0, tD.i)(e[n]) || nv(n, i) || (t[n] = e[n])
            }
            let nF = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "ignoreStrict", "viewport"]);

            function nB(t) {
                return t.startsWith("while") || t.startsWith("drag") && "draggable" !== t || t.startsWith("layout") || t.startsWith("onTap") || t.startsWith("onPan") || t.startsWith("onLayout") || nF.has(t)
            }
            let nO = t => !nB(t);
            try {
                (c = require("@emotion/is-prop-valid").default) && (nO = t => t.startsWith("on") ? !nB(t) : c(t))
            } catch (t) {}
            let n$ = {
                    current: null
                },
                nW = {
                    current: !1
                },
                nI = new WeakMap,
                nU = [...W, Z.$, N.P],
                nN = t => nU.find($(t)),
                nX = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"];
            class nz {
                scrapeMotionValuesFromProps(t, e, i) {
                    return {}
                }
                constructor({
                    parent: t,
                    props: e,
                    presenceContext: i,
                    reducedMotionConfig: n,
                    blockInitialAnimation: r,
                    visualState: s
                }, o = {}) {
                    this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = new Map, this.KeyframeResolver = U.e, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
                        this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
                    }, this.renderScheduledAt = 0, this.scheduleRender = () => {
                        let t = iu.X.now();
                        this.renderScheduledAt < t && (this.renderScheduledAt = t, V.Wi.render(this.render, !1, !0))
                    };
                    let {
                        latestValues: a,
                        renderState: l
                    } = s;
                    this.latestValues = a, this.baseTarget = { ...a
                    }, this.initialValues = e.initial ? { ...a
                    } : {}, this.renderState = l, this.parent = t, this.props = e, this.presenceContext = i, this.depth = t ? t.depth + 1 : 0, this.reducedMotionConfig = n, this.options = o, this.blockInitialAnimation = !!r, this.isControllingVariants = nr(e), this.isVariantNode = ns(e), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = !!(t && t.current);
                    let {
                        willChange: u,
                        ...h
                    } = this.scrapeMotionValuesFromProps(e, {}, this);
                    for (let t in h) {
                        let e = h[t];
                        void 0 !== a[t] && (0, tD.i)(e) && e.set(a[t], !1)
                    }
                }
                mount(t) {
                    this.current = t, nI.set(t, this), this.projection && !this.projection.instance && this.projection.mount(t), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((t, e) => this.bindToMotionValue(e, t)), nW.current || function() {
                        if (nW.current = !0, nu.j) {
                            if (window.matchMedia) {
                                let t = window.matchMedia("(prefers-reduced-motion)"),
                                    e = () => n$.current = t.matches;
                                t.addListener(e), e()
                            } else n$.current = !1
                        }
                    }(), this.shouldReduceMotion = "never" !== this.reducedMotionConfig && ("always" === this.reducedMotionConfig || n$.current), this.parent && this.parent.children.add(this), this.update(this.props, this.presenceContext)
                }
                unmount() {
                    for (let t in nI.delete(this.current), this.projection && this.projection.unmount(), (0, V.Pn)(this.notifyUpdate), (0, V.Pn)(this.render), this.valueSubscriptions.forEach(t => t()), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent && this.parent.children.delete(this), this.events) this.events[t].clear();
                    for (let t in this.features) {
                        let e = this.features[t];
                        e && (e.unmount(), e.isMounted = !1)
                    }
                    this.current = null
                }
                bindToMotionValue(t, e) {
                    let i;
                    this.valueSubscriptions.has(t) && this.valueSubscriptions.get(t)();
                    let n = f.G.has(t),
                        r = e.on("change", e => {
                            this.latestValues[t] = e, this.props.onUpdate && V.Wi.preRender(this.notifyUpdate), n && this.projection && (this.projection.isTransformDirty = !0)
                        }),
                        s = e.on("renderRequest", this.scheduleRender);
                    window.MotionCheckAppearSync && (i = window.MotionCheckAppearSync(this, t, e)), this.valueSubscriptions.set(t, () => {
                        r(), s(), i && i(), e.owner && e.stop()
                    })
                }
                sortNodePosition(t) {
                    return this.current && this.sortInstanceNodePosition && this.type === t.type ? this.sortInstanceNodePosition(this.current, t.current) : 0
                }
                updateFeatures() {
                    let t = "animation";
                    for (t in nl) {
                        let e = nl[t];
                        if (!e) continue;
                        let {
                            isEnabled: i,
                            Feature: n
                        } = e;
                        if (!this.features[t] && n && i(this.props) && (this.features[t] = new n(this)), this.features[t]) {
                            let e = this.features[t];
                            e.isMounted ? e.update() : (e.mount(), e.isMounted = !0)
                        }
                    }
                }
                triggerBuild() {
                    this.build(this.renderState, this.latestValues, this.props)
                }
                measureViewportBox() {
                    return this.current ? this.measureInstanceViewportBox(this.current, this.props) : el()
                }
                getStaticValue(t) {
                    return this.latestValues[t]
                }
                setStaticValue(t, e) {
                    this.latestValues[t] = e
                }
                update(t, e) {
                    (t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = t, this.prevPresenceContext = this.presenceContext, this.presenceContext = e;
                    for (let e = 0; e < nX.length; e++) {
                        let i = nX[e];
                        this.propEventSubscriptions[i] && (this.propEventSubscriptions[i](), delete this.propEventSubscriptions[i]);
                        let n = t["on" + i];
                        n && (this.propEventSubscriptions[i] = this.on(i, n))
                    }
                    this.prevMotionValues = function(t, e, i) {
                        for (let n in e) {
                            let r = e[n],
                                s = i[n];
                            if ((0, tD.i)(r)) t.addValue(n, r);
                            else if ((0, tD.i)(s)) t.addValue(n, (0, tA.BX)(r, {
                                owner: t
                            }));
                            else if (s !== r) {
                                if (t.hasValue(n)) {
                                    let e = t.getValue(n);
                                    !0 === e.liveStyle ? e.jump(r) : e.hasAnimated || e.set(r)
                                } else {
                                    let e = t.getStaticValue(n);
                                    t.addValue(n, (0, tA.BX)(void 0 !== e ? e : r, {
                                        owner: t
                                    }))
                                }
                            }
                        }
                        for (let n in i) void 0 === e[n] && t.removeValue(n);
                        return e
                    }(this, this.scrapeMotionValuesFromProps(t, this.prevProps, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue()
                }
                getProps() {
                    return this.props
                }
                getVariant(t) {
                    return this.props.variants ? this.props.variants[t] : void 0
                }
                getDefaultTransition() {
                    return this.props.transition
                }
                getTransformPagePoint() {
                    return this.props.transformPagePoint
                }
                getClosestVariantNode() {
                    return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
                }
                addVariantChild(t) {
                    let e = this.getClosestVariantNode();
                    if (e) return e.variantChildren && e.variantChildren.add(t), () => e.variantChildren.delete(t)
                }
                addValue(t, e) {
                    let i = this.values.get(t);
                    e !== i && (i && this.removeValue(t), this.bindToMotionValue(t, e), this.values.set(t, e), this.latestValues[t] = e.get())
                }
                removeValue(t) {
                    this.values.delete(t);
                    let e = this.valueSubscriptions.get(t);
                    e && (e(), this.valueSubscriptions.delete(t)), delete this.latestValues[t], this.removeValueFromRenderState(t, this.renderState)
                }
                hasValue(t) {
                    return this.values.has(t)
                }
                getValue(t, e) {
                    if (this.props.values && this.props.values[t]) return this.props.values[t];
                    let i = this.values.get(t);
                    return void 0 === i && void 0 !== e && (i = (0, tA.BX)(null === e ? void 0 : e, {
                        owner: this
                    }), this.addValue(t, i)), i
                }
                readValue(t, e) {
                    var i;
                    let n = void 0 === this.latestValues[t] && this.current ? null !== (i = this.getBaseTargetFromProps(this.props, t)) && void 0 !== i ? i : this.readValueFromInstance(this.current, t, this.options) : this.latestValues[t];
                    return null != n && ("string" == typeof n && (k(n) || C(n)) ? n = parseFloat(n) : !nN(n) && N.P.test(e) && (n = te(t, e)), this.setBaseTarget(t, (0, tD.i)(n) ? n.get() : n)), (0, tD.i)(n) ? n.get() : n
                }
                setBaseTarget(t, e) {
                    this.baseTarget[t] = e
                }
                getBaseTarget(t) {
                    var e;
                    let i;
                    let {
                        initial: n
                    } = this.props;
                    if ("string" == typeof n || "object" == typeof n) {
                        let r = l(this.props, n, null === (e = this.presenceContext) || void 0 === e ? void 0 : e.custom);
                        r && (i = r[t])
                    }
                    if (n && void 0 !== i) return i;
                    let r = this.getBaseTargetFromProps(this.props, t);
                    return void 0 === r || (0, tD.i)(r) ? void 0 !== this.initialValues[t] && void 0 === i ? void 0 : this.baseTarget[t] : r
                }
                on(t, e) {
                    return this.events[t] || (this.events[t] = new eX.L), this.events[t].add(e)
                }
                notify(t, ...e) {
                    this.events[t] && this.events[t].notify(...e)
                }
            }
            class nY extends nz {
                constructor() {
                    super(...arguments), this.KeyframeResolver = tn
                }
                sortInstanceNodePosition(t, e) {
                    return 2 & t.compareDocumentPosition(e) ? 1 : -1
                }
                getBaseTargetFromProps(t, e) {
                    return t.style ? t.style[e] : void 0
                }
                removeValueFromRenderState(t, {
                    vars: e,
                    style: i
                }) {
                    delete e[t], delete i[t]
                }
                handleChildMotionValue() {
                    this.childSubscription && (this.childSubscription(), delete this.childSubscription);
                    let {
                        children: t
                    } = this.props;
                    (0, tD.i)(t) && (this.childSubscription = t.on("change", t => {
                        this.current && (this.current.textContent = `${t}`)
                    }))
                }
            }
            class nK extends nY {
                constructor() {
                    super(...arguments), this.type = "html", this.renderInstance = np
                }
                readValueFromInstance(t, e) {
                    if (f.G.has(e)) {
                        let t = tt(e);
                        return t && t.default || 0
                    } {
                        let i = window.getComputedStyle(t),
                            n = ((0, L.f)(e) ? i.getPropertyValue(e) : i[e]) || 0;
                        return "string" == typeof n ? n.trim() : n
                    }
                }
                measureInstanceViewportBox(t, {
                    transformPagePoint: e
                }) {
                    return eP(t, e)
                }
                build(t, e, i) {
                    nV(t, e, i.transformTemplate)
                }
                scrapeMotionValuesFromProps(t, e, i) {
                    return ng(t, e, i)
                }
            }
            class nq extends nY {
                constructor() {
                    super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = el
                }
                getBaseTargetFromProps(t, e) {
                    return t[e]
                }
                readValueFromInstance(t, e) {
                    if (f.G.has(e)) {
                        let t = tt(e);
                        return t && t.default || 0
                    }
                    return e = nm.has(e) ? e : tV(e), t.getAttribute(e)
                }
                scrapeMotionValuesFromProps(t, e, i) {
                    return ny(t, e, i)
                }
                build(t, e, i) {
                    nC(t, e, this.isSVGTag, i.transformTemplate)
                }
                renderInstance(t, e, i, n) {
                    nf(t, e, i, n)
                }
                mount(t) {
                    this.isSVGTag = nR(t.tagName), super.mount(t)
                }
            }
            let nZ = function(t) {
                if ("undefined" == typeof Proxy) return t;
                let e = new Map;
                return new Proxy((...e) => t(...e), {
                    get: (i, n) => "create" === n ? t : (e.has(n) || e.set(n, t(n)), e.get(n))
                })
            }((p = {
                animation: {
                    Feature: tW
                },
                exit: {
                    Feature: tU
                },
                inView: {
                    Feature: i8
                },
                tap: {
                    Feature: i3
                },
                focus: {
                    Feature: iZ
                },
                hover: {
                    Feature: iq
                },
                pan: {
                    Feature: eD
                },
                drag: {
                    Feature: eV,
                    ProjectionNode: iN,
                    MeasureLayout: eU
                },
                layout: {
                    ProjectionNode: iN,
                    MeasureLayout: eU
                }
            }, m = (t, e) => nc(t) ? new nq(e) : new nK(e, {
                allowProjection: t !== eC.Fragment
            }), function(t, {
                forwardMotionProps: e
            } = {
                forwardMotionProps: !1
            }) {
                return function(t) {
                    let {
                        preloadedFeatures: e,
                        createVisualElement: i,
                        useRender: n,
                        useVisualState: r,
                        Component: s
                    } = t;
                    e && function(t) {
                        for (let e in t) nl[e] = { ...nl[e],
                            ...t[e]
                        }
                    }(e);
                    let a = (0, eC.forwardRef)(function(t, e) {
                        var a;
                        let l;
                        let u = { ...(0, eC.useContext)(nt._),
                                ...t,
                                layoutId: function(t) {
                                    let {
                                        layoutId: e
                                    } = t, i = (0, eC.useContext)(ek.p).id;
                                    return i && void 0 !== e ? i + "-" + e : e
                                }(t)
                            },
                            {
                                isStatic: h
                            } = u,
                            d = function(t) {
                                let {
                                    initial: e,
                                    animate: i
                                } = function(t, e) {
                                    if (nr(t)) {
                                        let {
                                            initial: e,
                                            animate: i
                                        } = t;
                                        return {
                                            initial: !1 === e || o(e) ? e : void 0,
                                            animate: o(i) ? i : void 0
                                        }
                                    }
                                    return !1 !== t.inherit ? e : {}
                                }(t, (0, eC.useContext)(ne));
                                return (0, eC.useMemo)(() => ({
                                    initial: e,
                                    animate: i
                                }), [no(e), no(i)])
                            }(t),
                            c = r(t, h);
                        if (!h && nu.j) {
                            (0, eC.useContext)(nn).strict;
                            let t = function(t) {
                                let {
                                    drag: e,
                                    layout: i
                                } = nl;
                                if (!e && !i) return {};
                                let n = { ...e,
                                    ...i
                                };
                                return {
                                    MeasureLayout: (null == e ? void 0 : e.isEnabled(t)) || (null == i ? void 0 : i.isEnabled(t)) ? n.MeasureLayout : void 0,
                                    ProjectionNode: n.ProjectionNode
                                }
                            }(u);
                            l = t.MeasureLayout, d.visualElement = function(t, e, i, n, r) {
                                var s, o;
                                let {
                                    visualElement: a
                                } = (0, eC.useContext)(ne), l = (0, eC.useContext)(nn), u = (0, eC.useContext)(eR.O), h = (0, eC.useContext)(nt._).reducedMotion, d = (0, eC.useRef)(null);
                                n = n || l.renderer, !d.current && n && (d.current = n(t, {
                                    visualState: e,
                                    parent: a,
                                    props: i,
                                    presenceContext: u,
                                    blockInitialAnimation: !!u && !1 === u.initial,
                                    reducedMotionConfig: h
                                }));
                                let c = d.current,
                                    p = (0, eC.useContext)(eL);
                                c && !c.projection && r && ("html" === c.type || "svg" === c.type) && function(t, e, i, n) {
                                    let {
                                        layoutId: r,
                                        layout: s,
                                        drag: o,
                                        dragConstraints: a,
                                        layoutScroll: l,
                                        layoutRoot: u
                                    } = e;
                                    t.projection = new i(t.latestValues, e["data-framer-portal-id"] ? void 0 : function t(e) {
                                        if (e) return !1 !== e.options.allowProjection ? e.projection : t(e.parent)
                                    }(t.parent)), t.projection.setOptions({
                                        layoutId: r,
                                        layout: s,
                                        alwaysMeasureLayout: !!o || a && t1(a),
                                        visualElement: t,
                                        animationType: "string" == typeof s ? s : "both",
                                        initialPromotionConfig: n,
                                        layoutScroll: l,
                                        layoutRoot: u
                                    })
                                }(d.current, i, r, p);
                                let m = (0, eC.useRef)(!1);
                                (0, eC.useInsertionEffect)(() => {
                                    c && m.current && c.update(i, u)
                                });
                                let f = i[tE],
                                    v = (0, eC.useRef)(!!f && !(null === (s = window.MotionHandoffIsComplete) || void 0 === s ? void 0 : s.call(window, f)) && (null === (o = window.MotionHasOptimisedAnimation) || void 0 === o ? void 0 : o.call(window, f)));
                                return (0, ni.L)(() => {
                                    c && (m.current = !0, window.MotionIsMounted = !0, c.updateFeatures(), e$.render(c.render), v.current && c.animationState && c.animationState.animateChanges())
                                }), (0, eC.useEffect)(() => {
                                    c && (!v.current && c.animationState && c.animationState.animateChanges(), v.current && (queueMicrotask(() => {
                                        var t;
                                        null === (t = window.MotionHandoffMarkAsComplete) || void 0 === t || t.call(window, f)
                                    }), v.current = !1))
                                }), c
                            }(s, c, u, i, t.ProjectionNode)
                        }
                        return (0, eM.jsxs)(ne.Provider, {
                            value: d,
                            children: [l && d.visualElement ? (0, eM.jsx)(l, {
                                visualElement: d.visualElement,
                                ...u
                            }) : null, n(s, t, (a = d.visualElement, (0, eC.useCallback)(t => {
                                t && c.mount && c.mount(t), a && (t ? a.mount(t) : a.unmount()), e && ("function" == typeof e ? e(t) : t1(e) && (e.current = t))
                            }, [a])), c, h, d.visualElement)]
                        })
                    });
                    return a[nh] = s, a
                }({ ...nc(t) ? nk : nL,
                    preloadedFeatures: p,
                    useRender: function(t = !1) {
                        return (e, i, n, {
                            latestValues: r
                        }, s) => {
                            let o = (nc(e) ? function(t, e, i, n) {
                                    let r = (0, eC.useMemo)(() => {
                                        let i = nT();
                                        return nC(i, e, nR(n), t.transformTemplate), { ...i.attrs,
                                            style: { ...i.style
                                            }
                                        }
                                    }, [e]);
                                    if (t.style) {
                                        let e = {};
                                        nj(e, t.style, t), r.style = { ...e,
                                            ...r.style
                                        }
                                    }
                                    return r
                                } : function(t, e) {
                                    let i = {},
                                        n = function(t, e) {
                                            let i = t.style || {},
                                                n = {};
                                            return nj(n, i, t), Object.assign(n, function({
                                                transformTemplate: t
                                            }, e) {
                                                return (0, eC.useMemo)(() => {
                                                    let i = nP();
                                                    return nV(i, e, t), Object.assign({}, i.vars, i.style)
                                                }, [e])
                                            }(t, e)), n
                                        }(t, e);
                                    return t.drag && !1 !== t.dragListener && (i.draggable = !1, n.userSelect = n.WebkitUserSelect = n.WebkitTouchCallout = "none", n.touchAction = !0 === t.drag ? "none" : `pan-${"x"===t.drag?"y":"x"}`), void 0 === t.tabIndex && (t.onTap || t.onTapStart || t.whileTap) && (i.tabIndex = 0), i.style = n, i
                                })(i, r, s, e),
                                a = function(t, e, i) {
                                    let n = {};
                                    for (let r in t)("values" !== r || "object" != typeof t.values) && (nO(r) || !0 === i && nB(r) || !e && !nB(r) || t.draggable && r.startsWith("onDrag")) && (n[r] = t[r]);
                                    return n
                                }(i, "string" == typeof e, t),
                                l = e !== eC.Fragment ? { ...a,
                                    ...o,
                                    ref: n
                                } : {},
                                {
                                    children: u
                                } = i,
                                h = (0, eC.useMemo)(() => (0, tD.i)(u) ? u.get() : u, [u]);
                            return (0, eC.createElement)(e, { ...l,
                                children: h
                            })
                        }
                    }(e),
                    createVisualElement: m,
                    Component: t
                })
            }))
        },
        23587: function(t, e, i) {
            i.d(e, {
                t: function() {
                    return n
                }
            });
            let n = (0, i(60453).X)(() => void 0 !== window.ScrollTimeline)
        },
        13938: function(t, e, i) {
            i.d(e, {
                f: function() {
                    return r
                },
                t: function() {
                    return o
                }
            });
            let n = t => e => "string" == typeof e && e.startsWith(t),
                r = n("--"),
                s = n("var(--"),
                o = t => !!s(t) && a.test(t.split("/*")[0].trim()),
                a = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu
        },
        27976: function(t, e, i) {
            i.d(e, {
                Ei: function() {
                    return c
                },
                lw: function() {
                    return p
                },
                mP: function() {
                    return a
                },
                z2: function() {
                    return o
                }
            });
            var n = i(41397),
                r = i(77964),
                s = i(89304);
            let o = new Set(["width", "height", "top", "left", "right", "bottom", "x", "y", "translateX", "translateY"]),
                a = t => t === r.Rx || t === s.px,
                l = (t, e) => parseFloat(t.split(", ")[e]),
                u = (t, e) => (i, {
                    transform: n
                }) => {
                    if ("none" === n || !n) return 0;
                    let r = n.match(/^matrix3d\((.+)\)$/u);
                    if (r) return l(r[1], e); {
                        let e = n.match(/^matrix\((.+)\)$/u);
                        return e ? l(e[1], t) : 0
                    }
                },
                h = new Set(["x", "y", "z"]),
                d = n._.filter(t => !h.has(t));

            function c(t) {
                let e = [];
                return d.forEach(i => {
                    let n = t.getValue(i);
                    void 0 !== n && (e.push([i, n.get()]), n.set(i.startsWith("scale") ? 1 : 0))
                }), e
            }
            let p = {
                width: ({
                    x: t
                }, {
                    paddingLeft: e = "0",
                    paddingRight: i = "0"
                }) => t.max - t.min - parseFloat(e) - parseFloat(i),
                height: ({
                    y: t
                }, {
                    paddingTop: e = "0",
                    paddingBottom: i = "0"
                }) => t.max - t.min - parseFloat(e) - parseFloat(i),
                top: (t, {
                    top: e
                }) => parseFloat(e),
                left: (t, {
                    left: e
                }) => parseFloat(e),
                bottom: ({
                    y: t
                }, {
                    top: e
                }) => parseFloat(e) + (t.max - t.min),
                right: ({
                    x: t
                }, {
                    left: e
                }) => parseFloat(e) + (t.max - t.min),
                x: u(4, 13),
                y: u(5, 14)
            };
            p.translateX = p.x, p.translateY = p.y
        },
        41397: function(t, e, i) {
            i.d(e, {
                G: function() {
                    return r
                },
                _: function() {
                    return n
                }
            });
            let n = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
                r = new Set(n)
        },
        767: function(t, e, i) {
            i.d(e, {
                e: function() {
                    return d
                },
                m: function() {
                    return h
                }
            });
            var n = i(27976),
                r = i(31198);
            let s = new Set,
                o = !1,
                a = !1;

            function l() {
                if (a) {
                    let t = Array.from(s).filter(t => t.needsMeasurement),
                        e = new Set(t.map(t => t.element)),
                        i = new Map;
                    e.forEach(t => {
                        let e = (0, n.Ei)(t);
                        e.length && (i.set(t, e), t.render())
                    }), t.forEach(t => t.measureInitialState()), e.forEach(t => {
                        t.render();
                        let e = i.get(t);
                        e && e.forEach(([e, i]) => {
                            var n;
                            null === (n = t.getValue(e)) || void 0 === n || n.set(i)
                        })
                    }), t.forEach(t => t.measureEndState()), t.forEach(t => {
                        void 0 !== t.suspendedScrollY && window.scrollTo(0, t.suspendedScrollY)
                    })
                }
                a = !1, o = !1, s.forEach(t => t.complete()), s.clear()
            }

            function u() {
                s.forEach(t => {
                    t.readKeyframes(), t.needsMeasurement && (a = !0)
                })
            }

            function h() {
                u(), l()
            }
            class d {
                constructor(t, e, i, n, r, s = !1) {
                    this.isComplete = !1, this.isAsync = !1, this.needsMeasurement = !1, this.isScheduled = !1, this.unresolvedKeyframes = [...t], this.onComplete = e, this.name = i, this.motionValue = n, this.element = r, this.isAsync = s
                }
                scheduleResolve() {
                    this.isScheduled = !0, this.isAsync ? (s.add(this), o || (o = !0, r.Wi.read(u), r.Wi.resolveKeyframes(l))) : (this.readKeyframes(), this.complete())
                }
                readKeyframes() {
                    let {
                        unresolvedKeyframes: t,
                        name: e,
                        element: i,
                        motionValue: n
                    } = this;
                    for (let r = 0; r < t.length; r++)
                        if (null === t[r]) {
                            if (0 === r) {
                                let r = null == n ? void 0 : n.get(),
                                    s = t[t.length - 1];
                                if (void 0 !== r) t[0] = r;
                                else if (i && e) {
                                    let n = i.readValue(e, s);
                                    null != n && (t[0] = n)
                                }
                                void 0 === t[0] && (t[0] = s), n && void 0 === r && n.set(t[0])
                            } else t[r] = t[r - 1]
                        }
                }
                setFinalKeyframe() {}
                measureInitialState() {}
                renderEndStyles() {}
                measureEndState() {}
                complete() {
                    this.isComplete = !0, this.onComplete(this.unresolvedKeyframes, this.finalKeyframe), s.delete(this)
                }
                cancel() {
                    this.isComplete || (this.isScheduled = !1, s.delete(this))
                }
                resume() {
                    this.isComplete || this.scheduleResolve()
                }
            }
        },
        93798: function(t, e, i) {
            i.d(e, {
                c: function() {
                    return n
                }
            });
            let n = {
                skipAnimations: !1,
                useManualTiming: !1
            }
        },
        31824: function(t, e, i) {
            function n(t, e) {
                -1 === t.indexOf(e) && t.push(e)
            }

            function r(t, e) {
                let i = t.indexOf(e);
                i > -1 && t.splice(i, 1)
            }
            i.d(e, {
                cl: function() {
                    return r
                },
                y4: function() {
                    return n
                }
            })
        },
        71389: function(t, e, i) {
            i.d(e, {
                u: function() {
                    return n
                }
            });
            let n = (t, e, i) => i > e ? e : i < t ? t : i
        },
        53135: function(t, e, i) {
            i.d(e, {
                s: function() {
                    return u
                }
            });
            var n = i(71389),
                r = i(60777),
                s = i(73633),
                o = i(48626),
                a = i(57268),
                l = i(65566);

            function u(t, e, {
                clamp: i = !0,
                ease: u,
                mixer: h
            } = {}) {
                let d = t.length;
                if ((0, o.k)(d === e.length, "Both input and output ranges must be the same length"), 1 === d) return () => e[0];
                if (2 === d && t[0] === t[1]) return () => e[1];
                t[0] > t[d - 1] && (t = [...t].reverse(), e = [...e].reverse());
                let c = function(t, e, i) {
                        let n = [],
                            s = i || l.C,
                            o = t.length - 1;
                        for (let i = 0; i < o; i++) {
                            let o = s(t[i], t[i + 1]);
                            if (e) {
                                let t = Array.isArray(e) ? e[i] || a.Z : e;
                                o = (0, r.z)(t, o)
                            }
                            n.push(o)
                        }
                        return n
                    }(e, u, h),
                    p = c.length,
                    m = e => {
                        let i = 0;
                        if (p > 1)
                            for (; i < t.length - 2 && !(e < t[i + 1]); i++);
                        let n = (0, s.Y)(t[i], t[i + 1], e);
                        return c[i](n)
                    };
                return i ? e => m((0, n.u)(t[0], t[d - 1], e)) : m
            }
        },
        72412: function(t, e, i) {
            i.d(e, {
                j: function() {
                    return n
                }
            });
            let n = "undefined" != typeof window
        },
        60453: function(t, e, i) {
            i.d(e, {
                X: function() {
                    return n
                }
            });

            function n(t) {
                let e;
                return () => (void 0 === e && (e = t()), e)
            }
        },
        65566: function(t, e, i) {
            i.d(e, {
                C: function() {
                    return A
                }
            });
            var n = i(98082),
                r = i(48626);

            function s(t, e, i) {
                return (i < 0 && (i += 1), i > 1 && (i -= 1), i < 1 / 6) ? t + (e - t) * 6 * i : i < .5 ? e : i < 2 / 3 ? t + (e - t) * (2 / 3 - i) * 6 : t
            }
            var o = i(59796),
                a = i(56335),
                l = i(94094);

            function u(t, e) {
                return i => i > 0 ? e : t
            }
            let h = (t, e, i) => {
                    let n = t * t,
                        r = i * (e * e - n) + n;
                    return r < 0 ? 0 : Math.sqrt(r)
                },
                d = [o.$, a.m, l.J],
                c = t => d.find(e => e.test(t));

            function p(t) {
                let e = c(t);
                if ((0, r.K)(!!e, `'${t}' is not an animatable color. Use the equivalent color code instead.`), !e) return !1;
                let i = e.parse(t);
                return e === l.J && (i = function({
                    hue: t,
                    saturation: e,
                    lightness: i,
                    alpha: n
                }) {
                    t /= 360, i /= 100;
                    let r = 0,
                        o = 0,
                        a = 0;
                    if (e /= 100) {
                        let n = i < .5 ? i * (1 + e) : i + e - i * e,
                            l = 2 * i - n;
                        r = s(l, n, t + 1 / 3), o = s(l, n, t), a = s(l, n, t - 1 / 3)
                    } else r = o = a = i;
                    return {
                        red: Math.round(255 * r),
                        green: Math.round(255 * o),
                        blue: Math.round(255 * a),
                        alpha: n
                    }
                }(i)), i
            }
            let m = (t, e) => {
                let i = p(t),
                    r = p(e);
                if (!i || !r) return u(t, e);
                let s = { ...i
                };
                return t => (s.red = h(i.red, r.red, t), s.green = h(i.green, r.green, t), s.blue = h(i.blue, r.blue, t), s.alpha = (0, n.t)(i.alpha, r.alpha, t), a.m.transform(s))
            };
            var f = i(60777),
                v = i(51288),
                g = i(91174),
                y = i(13938);
            let x = new Set(["none", "hidden"]);

            function w(t, e) {
                return i => (0, n.t)(t, e, i)
            }

            function P(t) {
                return "number" == typeof t ? w : "string" == typeof t ? (0, y.t)(t) ? u : v.$.test(t) ? m : S : Array.isArray(t) ? T : "object" == typeof t ? v.$.test(t) ? m : b : u
            }

            function T(t, e) {
                let i = [...t],
                    n = i.length,
                    r = t.map((t, i) => P(t)(t, e[i]));
                return t => {
                    for (let e = 0; e < n; e++) i[e] = r[e](t);
                    return i
                }
            }

            function b(t, e) {
                let i = { ...t,
                        ...e
                    },
                    n = {};
                for (let r in i) void 0 !== t[r] && void 0 !== e[r] && (n[r] = P(t[r])(t[r], e[r]));
                return t => {
                    for (let e in n) i[e] = n[e](t);
                    return i
                }
            }
            let S = (t, e) => {
                let i = g.P.createTransformer(e),
                    n = (0, g.V)(t),
                    s = (0, g.V)(e);
                return n.indexes.var.length === s.indexes.var.length && n.indexes.color.length === s.indexes.color.length && n.indexes.number.length >= s.indexes.number.length ? x.has(t) && !s.values.length || x.has(e) && !n.values.length ? x.has(t) ? i => i <= 0 ? t : e : i => i >= 1 ? e : t : (0, f.z)(T(function(t, e) {
                    var i;
                    let n = [],
                        r = {
                            color: 0,
                            var: 0,
                            number: 0
                        };
                    for (let s = 0; s < e.values.length; s++) {
                        let o = e.types[s],
                            a = t.indexes[o][r[o]],
                            l = null !== (i = t.values[a]) && void 0 !== i ? i : 0;
                        n[s] = l, r[o]++
                    }
                    return n
                }(n, s), s.values), i) : ((0, r.K)(!0, `Complex values '${t}' and '${e}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`), u(t, e))
            };

            function A(t, e, i) {
                return "number" == typeof t && "number" == typeof e && "number" == typeof i ? (0, n.t)(t, e, i) : P(t)(t, e)
            }
        },
        98082: function(t, e, i) {
            i.d(e, {
                t: function() {
                    return n
                }
            });
            let n = (t, e, i) => t + (e - t) * i
        },
        15184: function(t, e, i) {
            i.d(e, {
                Y: function() {
                    return s
                }
            });
            var n = i(98082),
                r = i(73633);

            function s(t) {
                let e = [0];
                return ! function(t, e) {
                    let i = t[t.length - 1];
                    for (let s = 1; s <= e; s++) {
                        let o = (0, r.Y)(0, e, s);
                        t.push((0, n.t)(i, 1, o))
                    }
                }(e, t.length - 1), e
            }
        },
        60777: function(t, e, i) {
            i.d(e, {
                z: function() {
                    return r
                }
            });
            let n = (t, e) => i => e(t(i)),
                r = (...t) => t.reduce(n)
        },
        73633: function(t, e, i) {
            i.d(e, {
                Y: function() {
                    return n
                }
            });
            let n = (t, e, i) => {
                let n = e - t;
                return 0 === n ? 1 : (i - t) / n
            }
        },
        70786: function(t, e, i) {
            i.d(e, {
                L: function() {
                    return r
                }
            });
            var n = i(31824);
            class r {
                constructor() {
                    this.subscriptions = []
                }
                add(t) {
                    return (0, n.y4)(this.subscriptions, t), () => (0, n.cl)(this.subscriptions, t)
                }
                notify(t, e, i) {
                    let n = this.subscriptions.length;
                    if (n) {
                        if (1 === n) this.subscriptions[0](t, e, i);
                        else
                            for (let r = 0; r < n; r++) {
                                let n = this.subscriptions[r];
                                n && n(t, e, i)
                            }
                    }
                }
                getSize() {
                    return this.subscriptions.length
                }
                clear() {
                    this.subscriptions.length = 0
                }
            }
        },
        93543: function(t, e, i) {
            i.d(e, {
                X: function() {
                    return r
                },
                w: function() {
                    return n
                }
            });
            let n = t => 1e3 * t,
                r = t => t / 1e3
        },
        39409: function(t, e, i) {
            i.d(e, {
                h: function() {
                    return r
                }
            });
            var n = i(2265);

            function r(t) {
                let e = (0, n.useRef)(null);
                return null === e.current && (e.current = t()), e.current
            }
        },
        77919: function(t, e, i) {
            i.d(e, {
                c: function() {
                    return n
                }
            });
            let n = {
                current: !1
            }
        },
        98675: function(t, e, i) {
            i.d(e, {
                L: function() {
                    return r
                }
            });
            var n = i(2265);
            let r = i(72412).j ? n.useLayoutEffect : n.useEffect
        },
        88253: function(t, e, i) {
            i.d(e, {
                R: function() {
                    return n
                }
            });

            function n(t, e) {
                return e ? 1e3 / e * t : 0
            }
        },
        51935: function(t, e, i) {
            i.d(e, {
                BX: function() {
                    return h
                },
                S1: function() {
                    return l
                }
            });
            var n = i(70786),
                r = i(88253),
                s = i(94521),
                o = i(31198);
            let a = t => !isNaN(parseFloat(t)),
                l = {
                    current: void 0
                };
            class u {
                constructor(t, e = {}) {
                    this.version = "11.14.4", this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (t, e = !0) => {
                        let i = s.X.now();
                        this.updatedAt !== i && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(t), this.current !== this.prev && this.events.change && this.events.change.notify(this.current), e && this.events.renderRequest && this.events.renderRequest.notify(this.current)
                    }, this.hasAnimated = !1, this.setCurrent(t), this.owner = e.owner
                }
                setCurrent(t) {
                    this.current = t, this.updatedAt = s.X.now(), null === this.canTrackVelocity && void 0 !== t && (this.canTrackVelocity = a(this.current))
                }
                setPrevFrameValue(t = this.current) {
                    this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt
                }
                onChange(t) {
                    return this.on("change", t)
                }
                on(t, e) {
                    this.events[t] || (this.events[t] = new n.L);
                    let i = this.events[t].add(e);
                    return "change" === t ? () => {
                        i(), o.Wi.read(() => {
                            this.events.change.getSize() || this.stop()
                        })
                    } : i
                }
                clearListeners() {
                    for (let t in this.events) this.events[t].clear()
                }
                attach(t, e) {
                    this.passiveEffect = t, this.stopPassiveEffect = e
                }
                set(t, e = !0) {
                    e && this.passiveEffect ? this.passiveEffect(t, this.updateAndNotify) : this.updateAndNotify(t, e)
                }
                setWithVelocity(t, e, i) {
                    this.set(e), this.prev = void 0, this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt - i
                }
                jump(t, e = !0) {
                    this.updateAndNotify(t), this.prev = t, this.prevUpdatedAt = this.prevFrameValue = void 0, e && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
                get() {
                    return l.current && l.current.push(this), this.current
                }
                getPrevious() {
                    return this.prev
                }
                getVelocity() {
                    let t = s.X.now();
                    if (!this.canTrackVelocity || void 0 === this.prevFrameValue || t - this.updatedAt > 30) return 0;
                    let e = Math.min(this.updatedAt - this.prevUpdatedAt, 30);
                    return (0, r.R)(parseFloat(this.current) - parseFloat(this.prevFrameValue), e)
                }
                start(t) {
                    return this.stop(), new Promise(e => {
                        this.hasAnimated = !0, this.animation = t(e), this.events.animationStart && this.events.animationStart.notify()
                    }).then(() => {
                        this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
                    })
                }
                stop() {
                    this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
                }
                isAnimating() {
                    return !!this.animation
                }
                clearAnimation() {
                    delete this.animation
                }
                destroy() {
                    this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
                }
            }

            function h(t, e) {
                return new u(t, e)
            }
        },
        59796: function(t, e, i) {
            i.d(e, {
                $: function() {
                    return r
                }
            });
            var n = i(56335);
            let r = {
                test: (0, i(20701).i)("#"),
                parse: function(t) {
                    let e = "",
                        i = "",
                        n = "",
                        r = "";
                    return t.length > 5 ? (e = t.substring(1, 3), i = t.substring(3, 5), n = t.substring(5, 7), r = t.substring(7, 9)) : (e = t.substring(1, 2), i = t.substring(2, 3), n = t.substring(3, 4), r = t.substring(4, 5), e += e, i += i, n += n, r += r), {
                        red: parseInt(e, 16),
                        green: parseInt(i, 16),
                        blue: parseInt(n, 16),
                        alpha: r ? parseInt(r, 16) / 255 : 1
                    }
                },
                transform: n.m.transform
            }
        },
        94094: function(t, e, i) {
            i.d(e, {
                J: function() {
                    return a
                }
            });
            var n = i(77964),
                r = i(89304),
                s = i(16442),
                o = i(20701);
            let a = {
                test: (0, o.i)("hsl", "hue"),
                parse: (0, o.d)("hue", "saturation", "lightness"),
                transform: ({
                    hue: t,
                    saturation: e,
                    lightness: i,
                    alpha: o = 1
                }) => "hsla(" + Math.round(t) + ", " + r.aQ.transform((0, s.N)(e)) + ", " + r.aQ.transform((0, s.N)(i)) + ", " + (0, s.N)(n.Fq.transform(o)) + ")"
            }
        },
        51288: function(t, e, i) {
            i.d(e, {
                $: function() {
                    return o
                }
            });
            var n = i(59796),
                r = i(94094),
                s = i(56335);
            let o = {
                test: t => s.m.test(t) || n.$.test(t) || r.J.test(t),
                parse: t => s.m.test(t) ? s.m.parse(t) : r.J.test(t) ? r.J.parse(t) : n.$.parse(t),
                transform: t => "string" == typeof t ? t : t.hasOwnProperty("red") ? s.m.transform(t) : r.J.transform(t)
            }
        },
        56335: function(t, e, i) {
            i.d(e, {
                m: function() {
                    return u
                }
            });
            var n = i(71389),
                r = i(77964),
                s = i(16442),
                o = i(20701);
            let a = t => (0, n.u)(0, 255, t),
                l = { ...r.Rx,
                    transform: t => Math.round(a(t))
                },
                u = {
                    test: (0, o.i)("rgb", "red"),
                    parse: (0, o.d)("red", "green", "blue"),
                    transform: ({
                        red: t,
                        green: e,
                        blue: i,
                        alpha: n = 1
                    }) => "rgba(" + l.transform(t) + ", " + l.transform(e) + ", " + l.transform(i) + ", " + (0, s.N)(r.Fq.transform(n)) + ")"
                }
        },
        20701: function(t, e, i) {
            i.d(e, {
                i: function() {
                    return s
                },
                d: function() {
                    return o
                }
            });
            var n = i(14445);
            let r = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
                s = (t, e) => i => !!("string" == typeof i && r.test(i) && i.startsWith(t) || e && null != i && Object.prototype.hasOwnProperty.call(i, e)),
                o = (t, e, i) => r => {
                    if ("string" != typeof r) return r;
                    let [s, o, a, l] = r.match(n.K);
                    return {
                        [t]: parseFloat(s),
                        [e]: parseFloat(o),
                        [i]: parseFloat(a),
                        alpha: void 0 !== l ? parseFloat(l) : 1
                    }
                }
        },
        91174: function(t, e, i) {
            i.d(e, {
                V: function() {
                    return h
                },
                P: function() {
                    return m
                }
            });
            var n = i(51288);
            let r = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
            var s = i(14445),
                o = i(16442);
            let a = "number",
                l = "color",
                u = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

            function h(t) {
                let e = t.toString(),
                    i = [],
                    r = {
                        color: [],
                        number: [],
                        var: []
                    },
                    s = [],
                    o = 0,
                    h = e.replace(u, t => (n.$.test(t) ? (r.color.push(o), s.push(l), i.push(n.$.parse(t))) : t.startsWith("var(") ? (r.var.push(o), s.push("var"), i.push(t)) : (r.number.push(o), s.push(a), i.push(parseFloat(t))), ++o, "${}")).split("${}");
                return {
                    values: i,
                    split: h,
                    indexes: r,
                    types: s
                }
            }

            function d(t) {
                return h(t).values
            }

            function c(t) {
                let {
                    split: e,
                    types: i
                } = h(t), r = e.length;
                return t => {
                    let s = "";
                    for (let u = 0; u < r; u++)
                        if (s += e[u], void 0 !== t[u]) {
                            let e = i[u];
                            e === a ? s += (0, o.N)(t[u]) : e === l ? s += n.$.transform(t[u]) : s += t[u]
                        }
                    return s
                }
            }
            let p = t => "number" == typeof t ? 0 : t,
                m = {
                    test: function(t) {
                        var e, i;
                        return isNaN(t) && "string" == typeof t && ((null === (e = t.match(s.K)) || void 0 === e ? void 0 : e.length) || 0) + ((null === (i = t.match(r)) || void 0 === i ? void 0 : i.length) || 0) > 0
                    },
                    parse: d,
                    createTransformer: c,
                    getAnimatableNone: function(t) {
                        let e = d(t);
                        return c(t)(e.map(p))
                    }
                }
        },
        77964: function(t, e, i) {
            i.d(e, {
                Fq: function() {
                    return s
                },
                Rx: function() {
                    return r
                },
                bA: function() {
                    return o
                }
            });
            var n = i(71389);
            let r = {
                    test: t => "number" == typeof t,
                    parse: parseFloat,
                    transform: t => t
                },
                s = { ...r,
                    transform: t => (0, n.u)(0, 1, t)
                },
                o = { ...r,
                    default: 1
                }
        },
        89304: function(t, e, i) {
            i.d(e, {
                $C: function() {
                    return u
                },
                RW: function() {
                    return r
                },
                aQ: function() {
                    return s
                },
                px: function() {
                    return o
                },
                vh: function() {
                    return a
                },
                vw: function() {
                    return l
                }
            });
            let n = t => ({
                    test: e => "string" == typeof e && e.endsWith(t) && 1 === e.split(" ").length,
                    parse: parseFloat,
                    transform: e => `${e}${t}`
                }),
                r = n("deg"),
                s = n("%"),
                o = n("px"),
                a = n("vh"),
                l = n("vw"),
                u = { ...s,
                    parse: t => s.parse(t) / 100,
                    transform: t => s.transform(100 * t)
                }
        },
        14445: function(t, e, i) {
            i.d(e, {
                K: function() {
                    return n
                }
            });
            let n = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu
        },
        16442: function(t, e, i) {
            i.d(e, {
                N: function() {
                    return n
                }
            });
            let n = t => Math.round(1e5 * t) / 1e5
        },
        75469: function(t, e, i) {
            i.d(e, {
                i: function() {
                    return n
                }
            });
            let n = t => !!(t && t.getVelocity)
        },
        34399: function(t, e, i) {
            i.d(e, {
                I: function() {
                    return n
                }
            });

            function n(t, e, i) {
                var n;
                if (t instanceof Element) return [t];
                if ("string" == typeof t) {
                    let r = document;
                    e && (r = e.current);
                    let s = null !== (n = null == i ? void 0 : i[t]) && void 0 !== n ? n : r.querySelectorAll(t);
                    return s ? Array.from(s) : []
                }
                return Array.from(t)
            }
        },
        48626: function(t, e, i) {
            i.d(e, {
                K: function() {
                    return r
                },
                k: function() {
                    return s
                }
            });
            var n = i(57268);
            let r = n.Z,
                s = n.Z
        },
        57268: function(t, e, i) {
            i.d(e, {
                Z: function() {
                    return n
                }
            });
            let n = t => t
        }
    }
]);