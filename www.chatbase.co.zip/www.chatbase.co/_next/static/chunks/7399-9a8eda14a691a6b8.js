"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7399], {
        91668: function(t, e, n) {
            n.d(e, {
                VY: function() {
                    return H
                },
                zt: function() {
                    return A
                },
                fC: function() {
                    return N
                },
                pn: function() {
                    return T
                },
                xz: function() {
                    return B
                }
            });
            var r = n(1119),
                i = n(2265),
                o = n(6741),
                s = n(98575),
                a = n(73966),
                u = n(15278),
                l = n(99255),
                c = n(77331),
                h = (n(83832), n(71599)),
                d = n(82912);
            (0, i.forwardRef)((t, e) => {
                let {
                    children: n,
                    ...o
                } = t, s = i.Children.toArray(n), a = s.find(m);
                if (a) {
                    let t = a.props.children,
                        n = s.map(e => e !== a ? e : i.Children.count(t) > 1 ? i.Children.only(null) : (0, i.isValidElement)(t) ? t.props.children : null);
                    return (0, i.createElement)(p, (0, r.Z)({}, o, {
                        ref: e
                    }), (0, i.isValidElement)(t) ? (0, i.cloneElement)(t, void 0, n) : null)
                }
                return (0, i.createElement)(p, (0, r.Z)({}, o, {
                    ref: e
                }), n)
            }).displayName = "Slot";
            let p = (0, i.forwardRef)((t, e) => {
                let {
                    children: n,
                    ...r
                } = t;
                return (0, i.isValidElement)(n) ? (0, i.cloneElement)(n, { ... function(t, e) {
                        let n = { ...e
                        };
                        for (let r in e) {
                            let i = t[r],
                                o = e[r];
                            /^on[A-Z]/.test(r) ? i && o ? n[r] = (...t) => {
                                o(...t), i(...t)
                            } : i && (n[r] = i) : "style" === r ? n[r] = { ...i,
                                ...o
                            } : "className" === r && (n[r] = [i, o].filter(Boolean).join(" "))
                        }
                        return { ...t,
                            ...n
                        }
                    }(r, n.props),
                    ref: e ? (0, s.F)(e, n.ref) : n.ref
                }) : i.Children.count(n) > 1 ? i.Children.only(null) : null
            });
            p.displayName = "SlotClone";
            let f = ({
                children: t
            }) => (0, i.createElement)(i.Fragment, null, t);

            function m(t) {
                return (0, i.isValidElement)(t) && t.type === f
            }
            var y = n(80886),
                v = n(95098);
            let [b, g] = (0, a.b)("Tooltip", [c.D7]), C = (0, c.D7)(), x = "tooltip.open", [w, E] = b("TooltipProvider"), T = t => {
                let {
                    __scopeTooltip: e,
                    delayDuration: n = 700,
                    skipDelayDuration: r = 300,
                    disableHoverableContent: o = !1,
                    children: s
                } = t, [a, u] = (0, i.useState)(!0), l = (0, i.useRef)(!1), c = (0, i.useRef)(0);
                return (0, i.useEffect)(() => {
                    let t = c.current;
                    return () => window.clearTimeout(t)
                }, []), (0, i.createElement)(w, {
                    scope: e,
                    isOpenDelayed: a,
                    delayDuration: n,
                    onOpen: (0, i.useCallback)(() => {
                        window.clearTimeout(c.current), u(!1)
                    }, []),
                    onClose: (0, i.useCallback)(() => {
                        window.clearTimeout(c.current), c.current = window.setTimeout(() => u(!0), r)
                    }, [r]),
                    isPointerInTransitRef: l,
                    onPointerInTransitChange: (0, i.useCallback)(t => {
                        l.current = t
                    }, []),
                    disableHoverableContent: o
                }, s)
            }, M = "Tooltip", [R, O] = b(M), k = "TooltipTrigger", P = (0, i.forwardRef)((t, e) => {
                let {
                    __scopeTooltip: n,
                    ...a
                } = t, u = O(k, n), l = E(k, n), h = C(n), p = (0, i.useRef)(null), f = (0, s.e)(e, p, u.onTriggerChange), m = (0, i.useRef)(!1), y = (0, i.useRef)(!1), v = (0, i.useCallback)(() => m.current = !1, []);
                return (0, i.useEffect)(() => () => document.removeEventListener("pointerup", v), [v]), (0, i.createElement)(c.ee, (0, r.Z)({
                    asChild: !0
                }, h), (0, i.createElement)(d.WV.button, (0, r.Z)({
                    "aria-describedby": u.open ? u.contentId : void 0,
                    "data-state": u.stateAttribute
                }, a, {
                    ref: f,
                    onPointerMove: (0, o.M)(t.onPointerMove, t => {
                        "touch" === t.pointerType || y.current || l.isPointerInTransitRef.current || (u.onTriggerEnter(), y.current = !0)
                    }),
                    onPointerLeave: (0, o.M)(t.onPointerLeave, () => {
                        u.onTriggerLeave(), y.current = !1
                    }),
                    onPointerDown: (0, o.M)(t.onPointerDown, () => {
                        m.current = !0, document.addEventListener("pointerup", v, {
                            once: !0
                        })
                    }),
                    onFocus: (0, o.M)(t.onFocus, () => {
                        m.current || u.onOpen()
                    }),
                    onBlur: (0, o.M)(t.onBlur, u.onClose),
                    onClick: (0, o.M)(t.onClick, u.onClose)
                })))
            }), [D, _] = b("TooltipPortal", {
                forceMount: void 0
            }), S = "TooltipContent", L = (0, i.forwardRef)((t, e) => {
                let n = _(S, t.__scopeTooltip),
                    {
                        forceMount: o = n.forceMount,
                        side: s = "top",
                        ...a
                    } = t,
                    u = O(S, t.__scopeTooltip);
                return (0, i.createElement)(h.z, {
                    present: o || u.open
                }, u.disableHoverableContent ? (0, i.createElement)(F, (0, r.Z)({
                    side: s
                }, a, {
                    ref: e
                })) : (0, i.createElement)(I, (0, r.Z)({
                    side: s
                }, a, {
                    ref: e
                })))
            }), I = (0, i.forwardRef)((t, e) => {
                let n = O(S, t.__scopeTooltip),
                    o = E(S, t.__scopeTooltip),
                    a = (0, i.useRef)(null),
                    u = (0, s.e)(e, a),
                    [l, c] = (0, i.useState)(null),
                    {
                        trigger: h,
                        onClose: d
                    } = n,
                    p = a.current,
                    {
                        onPointerInTransitChange: f
                    } = o,
                    m = (0, i.useCallback)(() => {
                        c(null), f(!1)
                    }, [f]),
                    y = (0, i.useCallback)((t, e) => {
                        let n = t.currentTarget,
                            r = {
                                x: t.clientX,
                                y: t.clientY
                            },
                            i = function(t, e) {
                                let n = Math.abs(e.top - t.y),
                                    r = Math.abs(e.bottom - t.y),
                                    i = Math.abs(e.right - t.x),
                                    o = Math.abs(e.left - t.x);
                                switch (Math.min(n, r, i, o)) {
                                    case o:
                                        return "left";
                                    case i:
                                        return "right";
                                    case n:
                                        return "top";
                                    case r:
                                        return "bottom";
                                    default:
                                        throw Error("unreachable")
                                }
                            }(r, n.getBoundingClientRect());
                        c(function(t) {
                            let e = t.slice();
                            return e.sort((t, e) => t.x < e.x ? -1 : t.x > e.x ? 1 : t.y < e.y ? -1 : t.y > e.y ? 1 : 0),
                                function(t) {
                                    if (t.length <= 1) return t.slice();
                                    let e = [];
                                    for (let n = 0; n < t.length; n++) {
                                        let r = t[n];
                                        for (; e.length >= 2;) {
                                            let t = e[e.length - 1],
                                                n = e[e.length - 2];
                                            if ((t.x - n.x) * (r.y - n.y) >= (t.y - n.y) * (r.x - n.x)) e.pop();
                                            else break
                                        }
                                        e.push(r)
                                    }
                                    e.pop();
                                    let n = [];
                                    for (let e = t.length - 1; e >= 0; e--) {
                                        let r = t[e];
                                        for (; n.length >= 2;) {
                                            let t = n[n.length - 1],
                                                e = n[n.length - 2];
                                            if ((t.x - e.x) * (r.y - e.y) >= (t.y - e.y) * (r.x - e.x)) n.pop();
                                            else break
                                        }
                                        n.push(r)
                                    }
                                    return (n.pop(), 1 === e.length && 1 === n.length && e[0].x === n[0].x && e[0].y === n[0].y) ? e : e.concat(n)
                                }(e)
                        }([... function(t, e, n = 5) {
                            let r = [];
                            switch (e) {
                                case "top":
                                    r.push({
                                        x: t.x - n,
                                        y: t.y + n
                                    }, {
                                        x: t.x + n,
                                        y: t.y + n
                                    });
                                    break;
                                case "bottom":
                                    r.push({
                                        x: t.x - n,
                                        y: t.y - n
                                    }, {
                                        x: t.x + n,
                                        y: t.y - n
                                    });
                                    break;
                                case "left":
                                    r.push({
                                        x: t.x + n,
                                        y: t.y - n
                                    }, {
                                        x: t.x + n,
                                        y: t.y + n
                                    });
                                    break;
                                case "right":
                                    r.push({
                                        x: t.x - n,
                                        y: t.y - n
                                    }, {
                                        x: t.x - n,
                                        y: t.y + n
                                    })
                            }
                            return r
                        }(r, i), ... function(t) {
                            let {
                                top: e,
                                right: n,
                                bottom: r,
                                left: i
                            } = t;
                            return [{
                                x: i,
                                y: e
                            }, {
                                x: n,
                                y: e
                            }, {
                                x: n,
                                y: r
                            }, {
                                x: i,
                                y: r
                            }]
                        }(e.getBoundingClientRect())])), f(!0)
                    }, [f]);
                return (0, i.useEffect)(() => () => m(), [m]), (0, i.useEffect)(() => {
                    if (h && p) {
                        let t = t => y(t, p),
                            e = t => y(t, h);
                        return h.addEventListener("pointerleave", t), p.addEventListener("pointerleave", e), () => {
                            h.removeEventListener("pointerleave", t), p.removeEventListener("pointerleave", e)
                        }
                    }
                }, [h, p, y, m]), (0, i.useEffect)(() => {
                    if (l) {
                        let t = t => {
                            let e = t.target,
                                n = {
                                    x: t.clientX,
                                    y: t.clientY
                                },
                                r = (null == h ? void 0 : h.contains(e)) || (null == p ? void 0 : p.contains(e)),
                                i = ! function(t, e) {
                                    let {
                                        x: n,
                                        y: r
                                    } = t, i = !1;
                                    for (let t = 0, o = e.length - 1; t < e.length; o = t++) {
                                        let s = e[t].x,
                                            a = e[t].y,
                                            u = e[o].x,
                                            l = e[o].y;
                                        a > r != l > r && n < (u - s) * (r - a) / (l - a) + s && (i = !i)
                                    }
                                    return i
                                }(n, l);
                            r ? m() : i && (m(), d())
                        };
                        return document.addEventListener("pointermove", t), () => document.removeEventListener("pointermove", t)
                    }
                }, [h, p, l, d, m]), (0, i.createElement)(F, (0, r.Z)({}, t, {
                    ref: u
                }))
            }), [V, Z] = b(M, {
                isInside: !1
            }), F = (0, i.forwardRef)((t, e) => {
                let {
                    __scopeTooltip: n,
                    children: o,
                    "aria-label": s,
                    onEscapeKeyDown: a,
                    onPointerDownOutside: l,
                    ...h
                } = t, d = O(S, n), p = C(n), {
                    onClose: m
                } = d;
                return (0, i.useEffect)(() => (document.addEventListener(x, m), () => document.removeEventListener(x, m)), [m]), (0, i.useEffect)(() => {
                    if (d.trigger) {
                        let t = t => {
                            let e = t.target;
                            null != e && e.contains(d.trigger) && m()
                        };
                        return window.addEventListener("scroll", t, {
                            capture: !0
                        }), () => window.removeEventListener("scroll", t, {
                            capture: !0
                        })
                    }
                }, [d.trigger, m]), (0, i.createElement)(u.XB, {
                    asChild: !0,
                    disableOutsidePointerEvents: !1,
                    onEscapeKeyDown: a,
                    onPointerDownOutside: l,
                    onFocusOutside: t => t.preventDefault(),
                    onDismiss: m
                }, (0, i.createElement)(c.VY, (0, r.Z)({
                    "data-state": d.stateAttribute
                }, p, h, {
                    ref: e,
                    style: { ...h.style,
                        "--radix-tooltip-content-transform-origin": "var(--radix-popper-transform-origin)",
                        "--radix-tooltip-content-available-width": "var(--radix-popper-available-width)",
                        "--radix-tooltip-content-available-height": "var(--radix-popper-available-height)",
                        "--radix-tooltip-trigger-width": "var(--radix-popper-anchor-width)",
                        "--radix-tooltip-trigger-height": "var(--radix-popper-anchor-height)"
                    }
                }), (0, i.createElement)(f, null, o), (0, i.createElement)(V, {
                    scope: n,
                    isInside: !0
                }, (0, i.createElement)(v.f, {
                    id: d.contentId,
                    role: "tooltip"
                }, s || o))))
            }), A = T, N = t => {
                let {
                    __scopeTooltip: e,
                    children: n,
                    open: r,
                    defaultOpen: o = !1,
                    onOpenChange: s,
                    disableHoverableContent: a,
                    delayDuration: u
                } = t, h = E(M, t.__scopeTooltip), d = C(e), [p, f] = (0, i.useState)(null), m = (0, l.M)(), v = (0, i.useRef)(0), b = null != a ? a : h.disableHoverableContent, g = null != u ? u : h.delayDuration, w = (0, i.useRef)(!1), [T = !1, O] = (0, y.T)({
                    prop: r,
                    defaultProp: o,
                    onChange: t => {
                        t ? (h.onOpen(), document.dispatchEvent(new CustomEvent(x))) : h.onClose(), null == s || s(t)
                    }
                }), k = (0, i.useMemo)(() => T ? w.current ? "delayed-open" : "instant-open" : "closed", [T]), P = (0, i.useCallback)(() => {
                    window.clearTimeout(v.current), w.current = !1, O(!0)
                }, [O]), D = (0, i.useCallback)(() => {
                    window.clearTimeout(v.current), O(!1)
                }, [O]), _ = (0, i.useCallback)(() => {
                    window.clearTimeout(v.current), v.current = window.setTimeout(() => {
                        w.current = !0, O(!0)
                    }, g)
                }, [g, O]);
                return (0, i.useEffect)(() => () => window.clearTimeout(v.current), []), (0, i.createElement)(c.fC, d, (0, i.createElement)(R, {
                    scope: e,
                    contentId: m,
                    open: T,
                    stateAttribute: k,
                    trigger: p,
                    onTriggerChange: f,
                    onTriggerEnter: (0, i.useCallback)(() => {
                        h.isOpenDelayed ? _() : P()
                    }, [h.isOpenDelayed, _, P]),
                    onTriggerLeave: (0, i.useCallback)(() => {
                        b ? D() : window.clearTimeout(v.current)
                    }, [D, b]),
                    onOpen: P,
                    onClose: D,
                    disableHoverableContent: b
                }, n))
            }, B = P, H = L
        },
        95098: function(t, e, n) {
            n.d(e, {
                T: function() {
                    return s
                },
                f: function() {
                    return a
                }
            });
            var r = n(1119),
                i = n(2265),
                o = n(82912);
            let s = (0, i.forwardRef)((t, e) => (0, i.createElement)(o.WV.span, (0, r.Z)({}, t, {
                    ref: e,
                    style: {
                        position: "absolute",
                        border: 0,
                        width: 1,
                        height: 1,
                        padding: 0,
                        margin: -1,
                        overflow: "hidden",
                        clip: "rect(0, 0, 0, 0)",
                        whiteSpace: "nowrap",
                        wordWrap: "normal",
                        ...t.style
                    }
                }))),
                a = s
        },
        2894: function(t, e, n) {
            n.d(e, {
                R: function() {
                    return a
                },
                m: function() {
                    return s
                }
            });
            var r = n(18238),
                i = n(7989),
                o = n(11255),
                s = class extends i.F {#
                    t;#
                    e;#
                    n;
                    constructor(t) {
                        super(), this.mutationId = t.mutationId, this.#e = t.mutationCache, this.#t = [], this.state = t.state || a(), this.setOptions(t.options), this.scheduleGc()
                    }
                    setOptions(t) {
                        this.options = t, this.updateGcTime(this.options.gcTime)
                    }
                    get meta() {
                        return this.options.meta
                    }
                    addObserver(t) {
                        this.#t.includes(t) || (this.#t.push(t), this.clearGcTimeout(), this.#e.notify({
                            type: "observerAdded",
                            mutation: this,
                            observer: t
                        }))
                    }
                    removeObserver(t) {
                        this.#t = this.#t.filter(e => e !== t), this.scheduleGc(), this.#e.notify({
                            type: "observerRemoved",
                            mutation: this,
                            observer: t
                        })
                    }
                    optionalRemove() {
                        this.#t.length || ("pending" === this.state.status ? this.scheduleGc() : this.#e.remove(this))
                    }
                    continue () {
                        return this.#n ? .continue() ? ? this.execute(this.state.variables)
                    }
                    async execute(t) {
                        this.#n = (0, o.Mz)({
                            fn: () => this.options.mutationFn ? this.options.mutationFn(t) : Promise.reject(Error("No mutationFn found")),
                            onFail: (t, e) => {
                                this.#r({
                                    type: "failed",
                                    failureCount: t,
                                    error: e
                                })
                            },
                            onPause: () => {
                                this.#r({
                                    type: "pause"
                                })
                            },
                            onContinue: () => {
                                this.#r({
                                    type: "continue"
                                })
                            },
                            retry: this.options.retry ? ? 0,
                            retryDelay: this.options.retryDelay,
                            networkMode: this.options.networkMode,
                            canRun: () => this.#e.canRun(this)
                        });
                        let e = "pending" === this.state.status,
                            n = !this.#n.canStart();
                        try {
                            if (!e) {
                                this.#r({
                                    type: "pending",
                                    variables: t,
                                    isPaused: n
                                }), await this.#e.config.onMutate ? .(t, this);
                                let e = await this.options.onMutate ? .(t);
                                e !== this.state.context && this.#r({
                                    type: "pending",
                                    context: e,
                                    variables: t,
                                    isPaused: n
                                })
                            }
                            let r = await this.#n.start();
                            return await this.#e.config.onSuccess ? .(r, t, this.state.context, this), await this.options.onSuccess ? .(r, t, this.state.context), await this.#e.config.onSettled ? .(r, null, this.state.variables, this.state.context, this), await this.options.onSettled ? .(r, null, t, this.state.context), this.#r({
                                type: "success",
                                data: r
                            }), r
                        } catch (e) {
                            try {
                                throw await this.#e.config.onError ? .(e, t, this.state.context, this), await this.options.onError ? .(e, t, this.state.context), await this.#e.config.onSettled ? .(void 0, e, this.state.variables, this.state.context, this), await this.options.onSettled ? .(void 0, e, t, this.state.context), e
                            } finally {
                                this.#r({
                                    type: "error",
                                    error: e
                                })
                            }
                        } finally {
                            this.#e.runNext(this)
                        }
                    }#
                    r(t) {
                        this.state = (e => {
                            switch (t.type) {
                                case "failed":
                                    return { ...e,
                                        failureCount: t.failureCount,
                                        failureReason: t.error
                                    };
                                case "pause":
                                    return { ...e,
                                        isPaused: !0
                                    };
                                case "continue":
                                    return { ...e,
                                        isPaused: !1
                                    };
                                case "pending":
                                    return { ...e,
                                        context: t.context,
                                        data: void 0,
                                        failureCount: 0,
                                        failureReason: null,
                                        error: null,
                                        isPaused: t.isPaused,
                                        status: "pending",
                                        variables: t.variables,
                                        submittedAt: Date.now()
                                    };
                                case "success":
                                    return { ...e,
                                        data: t.data,
                                        failureCount: 0,
                                        failureReason: null,
                                        error: null,
                                        status: "success",
                                        isPaused: !1
                                    };
                                case "error":
                                    return { ...e,
                                        data: void 0,
                                        error: t.error,
                                        failureCount: e.failureCount + 1,
                                        failureReason: t.error,
                                        isPaused: !1,
                                        status: "error"
                                    }
                            }
                        })(this.state), r.V.batch(() => {
                            this.#t.forEach(e => {
                                e.onMutationUpdate(t)
                            }), this.#e.notify({
                                mutation: this,
                                type: "updated",
                                action: t
                            })
                        })
                    }
                };

            function a() {
                return {
                    context: void 0,
                    data: void 0,
                    error: null,
                    failureCount: 0,
                    failureReason: null,
                    isPaused: !1,
                    status: "idle",
                    variables: void 0,
                    submittedAt: 0
                }
            }
        },
        21770: function(t, e, n) {
            n.d(e, {
                useMutation: function() {
                    return h
                }
            });
            var r = n(2265),
                i = n(2894),
                o = n(18238),
                s = n(24112),
                a = n(45345),
                u = class extends s.l {#
                    i;#
                    o = void 0;#
                    s;#
                    a;
                    constructor(t, e) {
                        super(), this.#i = t, this.setOptions(e), this.bindMethods(), this.#u()
                    }
                    bindMethods() {
                        this.mutate = this.mutate.bind(this), this.reset = this.reset.bind(this)
                    }
                    setOptions(t) {
                        let e = this.options;
                        this.options = this.#i.defaultMutationOptions(t), (0, a.VS)(this.options, e) || this.#i.getMutationCache().notify({
                            type: "observerOptionsUpdated",
                            mutation: this.#s,
                            observer: this
                        }), e ? .mutationKey && this.options.mutationKey && (0, a.Ym)(e.mutationKey) !== (0, a.Ym)(this.options.mutationKey) ? this.reset() : this.#s ? .state.status === "pending" && this.#s.setOptions(this.options)
                    }
                    onUnsubscribe() {
                        this.hasListeners() || this.#s ? .removeObserver(this)
                    }
                    onMutationUpdate(t) {
                        this.#u(), this.#l(t)
                    }
                    getCurrentResult() {
                        return this.#o
                    }
                    reset() {
                        this.#s ? .removeObserver(this), this.#s = void 0, this.#u(), this.#l()
                    }
                    mutate(t, e) {
                        return this.#a = e, this.#s ? .removeObserver(this), this.#s = this.#i.getMutationCache().build(this.#i, this.options), this.#s.addObserver(this), this.#s.execute(t)
                    }#
                    u() {
                        let t = this.#s ? .state ? ? (0, i.R)();
                        this.#o = { ...t,
                            isPending: "pending" === t.status,
                            isSuccess: "success" === t.status,
                            isError: "error" === t.status,
                            isIdle: "idle" === t.status,
                            mutate: this.mutate,
                            reset: this.reset
                        }
                    }#
                    l(t) {
                        o.V.batch(() => {
                            if (this.#a && this.hasListeners()) {
                                let e = this.#o.variables,
                                    n = this.#o.context;
                                t ? .type === "success" ? (this.#a.onSuccess ? .(t.data, e, n), this.#a.onSettled ? .(t.data, null, e, n)) : t ? .type === "error" && (this.#a.onError ? .(t.error, e, n), this.#a.onSettled ? .(void 0, t.error, e, n))
                            }
                            this.listeners.forEach(t => {
                                t(this.#o)
                            })
                        })
                    }
                },
                l = n(29827),
                c = n(51172);

            function h(t, e) {
                let n = (0, l.useQueryClient)(e),
                    [i] = r.useState(() => new u(n, t));
                r.useEffect(() => {
                    i.setOptions(t)
                }, [i, t]);
                let s = r.useSyncExternalStore(r.useCallback(t => i.subscribe(o.V.batchCalls(t)), [i]), () => i.getCurrentResult(), () => i.getCurrentResult()),
                    a = r.useCallback((t, e) => {
                        i.mutate(t, e).catch(c.Z)
                    }, [i]);
                if (s.error && (0, c.L)(i.options.throwOnError, [s.error])) throw s.error;
                return { ...s,
                    mutate: a,
                    mutateAsync: s.mutate
                }
            }
        }
    }
]);