(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4012], {
        30311: function(e, t, r) {
            "use strict";
            var a = r(82957).Buffer;
            let o = void 0 !== a,
                n = /"(?:_|\\u005[Ff])(?:_|\\u005[Ff])(?:p|\\u0070)(?:r|\\u0072)(?:o|\\u006[Ff])(?:t|\\u0074)(?:o|\\u006[Ff])(?:_|\\u005[Ff])(?:_|\\u005[Ff])"\s*:/,
                s = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;

            function l(e, t, r) {
                null == r && null !== t && "object" == typeof t && (r = t, t = void 0), o && a.isBuffer(e) && (e = e.toString()), e && 65279 === e.charCodeAt(0) && (e = e.slice(1));
                let l = JSON.parse(e, t);
                if (null === l || "object" != typeof l) return l;
                let u = r && r.protoAction || "error",
                    c = r && r.constructorAction || "error";
                if ("ignore" === u && "ignore" === c) return l;
                if ("ignore" !== u && "ignore" !== c) {
                    if (!1 === n.test(e) && !1 === s.test(e)) return l
                } else if ("ignore" !== u && "ignore" === c) {
                    if (!1 === n.test(e)) return l
                } else if (!1 === s.test(e)) return l;
                return i(l, {
                    protoAction: u,
                    constructorAction: c,
                    safe: r && r.safe
                })
            }

            function i(e, {
                protoAction: t = "error",
                constructorAction: r = "error",
                safe: a
            } = {}) {
                let o = [e];
                for (; o.length;) {
                    let e = o;
                    for (let n of (o = [], e)) {
                        if ("ignore" !== t && Object.prototype.hasOwnProperty.call(n, "__proto__")) {
                            if (!0 === a) return null;
                            if ("error" === t) throw SyntaxError("Object contains forbidden prototype property");
                            delete n.__proto__
                        }
                        if ("ignore" !== r && Object.prototype.hasOwnProperty.call(n, "constructor") && Object.prototype.hasOwnProperty.call(n.constructor, "prototype")) {
                            if (!0 === a) return null;
                            if ("error" === r) throw SyntaxError("Object contains forbidden prototype property");
                            delete n.constructor
                        }
                        for (let e in n) {
                            let t = n[e];
                            t && "object" == typeof t && o.push(t)
                        }
                    }
                }
                return e
            }

            function u(e, t, r) {
                let a = Error.stackTraceLimit;
                Error.stackTraceLimit = 0;
                try {
                    return l(e, t, r)
                } finally {
                    Error.stackTraceLimit = a
                }
            }
            e.exports = u, e.exports.default = u, e.exports.parse = u, e.exports.safeParse = function(e, t) {
                let r = Error.stackTraceLimit;
                Error.stackTraceLimit = 0;
                try {
                    return l(e, t, {
                        safe: !0
                    })
                } catch (e) {
                    return null
                } finally {
                    Error.stackTraceLimit = r
                }
            }, e.exports.scan = i
        },
        21868: function(e, t, r) {
            "use strict";
            var a = r(2265),
                o = "function" == typeof Object.is ? Object.is : function(e, t) {
                    return e === t && (0 !== e || 1 / e == 1 / t) || e != e && t != t
                },
                n = a.useState,
                s = a.useEffect,
                l = a.useLayoutEffect,
                i = a.useDebugValue;

            function u(e) {
                var t = e.getSnapshot;
                e = e.value;
                try {
                    var r = t();
                    return !o(e, r)
                } catch (e) {
                    return !0
                }
            }
            var c = "undefined" == typeof window || void 0 === window.document || void 0 === window.document.createElement ? function(e, t) {
                return t()
            } : function(e, t) {
                var r = t(),
                    a = n({
                        inst: {
                            value: r,
                            getSnapshot: t
                        }
                    }),
                    o = a[0].inst,
                    c = a[1];
                return l(function() {
                    o.value = r, o.getSnapshot = t, u(o) && c({
                        inst: o
                    })
                }, [e, r, t]), s(function() {
                    return u(o) && c({
                        inst: o
                    }), e(function() {
                        u(o) && c({
                            inst: o
                        })
                    })
                }, [e]), i(r), r
            };
            t.useSyncExternalStore = void 0 !== a.useSyncExternalStore ? a.useSyncExternalStore : c
        },
        3486: function(e, t, r) {
            "use strict";
            e.exports = r(21868)
        },
        20940: function(e) {
            e.exports = function(e, t) {
                let r;
                if ("function" != typeof e) throw TypeError(`Expected the first argument to be a \`function\`, got \`${typeof e}\`.`);
                let a = 0;
                return function(...o) {
                    clearTimeout(r);
                    let n = Date.now(),
                        s = t - (n - a);
                    s <= 0 ? (a = n, e.apply(this, o)) : r = setTimeout(() => {
                        a = Date.now(), e.apply(this, o)
                    }, s)
                }
            }
        },
        54012: function(e, t, r) {
            "use strict";
            let a;
            r.d(t, {
                RJ: function() {
                    return e0
                }
            });
            var o, n, s, l, i = r(2265),
                u = "vercel.ai.error",
                c = Symbol.for(u),
                d = class e extends Error {
                    constructor({
                        name: e,
                        message: t,
                        cause: r
                    }) {
                        super(t), this[o] = !0, this.name = e, this.cause = r
                    }
                    static isInstance(t) {
                        return e.hasMarker(t, u)
                    }
                    static hasMarker(e, t) {
                        let r = Symbol.for(t);
                        return null != e && "object" == typeof e && r in e && "boolean" == typeof e[r] && !0 === e[r]
                    }
                };
            o = c;
            var p = d;

            function f(e) {
                return null == e ? "unknown error" : "string" == typeof e ? e : e instanceof Error ? e.message : JSON.stringify(e)
            }
            Symbol.for("vercel.ai.error.AI_APICallError"), Symbol.for("vercel.ai.error.AI_EmptyResponseBodyError");
            var g = "AI_InvalidArgumentError",
                h = `vercel.ai.error.${g}`,
                y = Symbol.for(h),
                m = class extends p {
                    constructor({
                        message: e,
                        cause: t,
                        argument: r
                    }) {
                        super({
                            name: g,
                            message: e,
                            cause: t
                        }), this[n] = !0, this.argument = r
                    }
                    static isInstance(e) {
                        return p.hasMarker(e, h)
                    }
                };
            n = y, Symbol.for("vercel.ai.error.AI_InvalidPromptError"), Symbol.for("vercel.ai.error.AI_InvalidResponseDataError");
            var E = "AI_JSONParseError",
                _ = `vercel.ai.error.${E}`,
                I = Symbol.for(_),
                v = class extends p {
                    constructor({
                        text: e,
                        cause: t
                    }) {
                        super({
                            name: E,
                            message: `JSON parsing failed: Text: ${e}.
Error message: ${f(t)}`,
                            cause: t
                        }), this[s] = !0, this.text = e
                    }
                    static isInstance(e) {
                        return p.hasMarker(e, _)
                    }
                };
            s = I, Symbol.for("vercel.ai.error.AI_LoadAPIKeyError"), Symbol.for("vercel.ai.error.AI_LoadSettingError"), Symbol.for("vercel.ai.error.AI_NoContentGeneratedError"), Symbol.for("vercel.ai.error.AI_NoSuchModelError"), Symbol.for("vercel.ai.error.AI_TooManyEmbeddingValuesForCallError");
            var b = "AI_TypeValidationError",
                w = `vercel.ai.error.${b}`,
                T = Symbol.for(w),
                S = class e extends p {
                    constructor({
                        value: e,
                        cause: t
                    }) {
                        super({
                            name: b,
                            message: `Type validation failed: Value: ${JSON.stringify(e)}.
Error message: ${f(t)}`,
                            cause: t
                        }), this[l] = !0, this.value = e
                    }
                    static isInstance(e) {
                        return p.hasMarker(e, w)
                    }
                    static wrap({
                        value: t,
                        cause: r
                    }) {
                        return e.isInstance(r) && r.value === t ? r : new e({
                            value: t,
                            cause: r
                        })
                    }
                };
            l = T, Symbol.for("vercel.ai.error.AI_UnsupportedFunctionalityError");
            let A = (e, t = 21) => (r = t) => {
                let a = "",
                    o = 0 | r;
                for (; o--;) a += e[Math.random() * e.length | 0];
                return a
            };
            var R = r(30311);
            r(25566);
            var k = (({
                    prefix: e,
                    size: t = 16,
                    alphabet: r = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
                    separator: a = "-"
                } = {}) => {
                    let o = A(r, t);
                    if (null == e) return o;
                    if (r.includes(a)) throw new m({
                        argument: "separator",
                        message: `The separator "${a}" must not be part of the alphabet "${r}".`
                    });
                    return t => `${e}${a}${o(t)}`
                })(),
                C = Symbol.for("vercel.ai.validator");

            function N({
                text: e,
                schema: t
            }) {
                try {
                    let r = R.parse(e);
                    if (null == t) return {
                        success: !0,
                        value: r,
                        rawValue: r
                    };
                    let a = function({
                        value: e,
                        schema: t
                    }) {
                        let r = "object" == typeof t && null !== t && C in t && !0 === t[C] && "validate" in t ? t : {
                            [C]: !0,
                            validate: e => {
                                let r = t.safeParse(e);
                                return r.success ? {
                                    success: !0,
                                    value: r.data
                                } : {
                                    success: !1,
                                    error: r.error
                                }
                            }
                        };
                        try {
                            if (null == r.validate) return {
                                success: !0,
                                value: e
                            };
                            let t = r.validate(e);
                            if (t.success) return t;
                            return {
                                success: !1,
                                error: S.wrap({
                                    value: e,
                                    cause: t.error
                                })
                            }
                        } catch (t) {
                            return {
                                success: !1,
                                error: S.wrap({
                                    value: e,
                                    cause: t
                                })
                            }
                        }
                    }({
                        value: r,
                        schema: t
                    });
                    return a.success ? { ...a,
                        rawValue: r
                    } : a
                } catch (t) {
                    return {
                        success: !1,
                        error: v.isInstance(t) ? t : new v({
                            text: e,
                            cause: t
                        })
                    }
                }
            }
            var {
                btoa: x,
                atob: O
            } = globalThis;
            Symbol("Let zodToJsonSchema decide on which parser to use");
            var D = {
                    code: "0",
                    name: "text",
                    parse: e => {
                        if ("string" != typeof e) throw Error('"text" parts expect a string value.');
                        return {
                            type: "text",
                            value: e
                        }
                    }
                },
                L = {
                    code: "3",
                    name: "error",
                    parse: e => {
                        if ("string" != typeof e) throw Error('"error" parts expect a string value.');
                        return {
                            type: "error",
                            value: e
                        }
                    }
                },
                F = {
                    code: "4",
                    name: "assistant_message",
                    parse: e => {
                        if (null == e || "object" != typeof e || !("id" in e) || !("role" in e) || !("content" in e) || "string" != typeof e.id || "string" != typeof e.role || "assistant" !== e.role || !Array.isArray(e.content) || !e.content.every(e => null != e && "object" == typeof e && "type" in e && "text" === e.type && "text" in e && null != e.text && "object" == typeof e.text && "value" in e.text && "string" == typeof e.text.value)) throw Error('"assistant_message" parts expect an object with an "id", "role", and "content" property.');
                        return {
                            type: "assistant_message",
                            value: e
                        }
                    }
                },
                j = {
                    code: "5",
                    name: "assistant_control_data",
                    parse: e => {
                        if (null == e || "object" != typeof e || !("threadId" in e) || !("messageId" in e) || "string" != typeof e.threadId || "string" != typeof e.messageId) throw Error('"assistant_control_data" parts expect an object with a "threadId" and "messageId" property.');
                        return {
                            type: "assistant_control_data",
                            value: {
                                threadId: e.threadId,
                                messageId: e.messageId
                            }
                        }
                    }
                },
                M = {
                    code: "6",
                    name: "data_message",
                    parse: e => {
                        if (null == e || "object" != typeof e || !("role" in e) || !("data" in e) || "string" != typeof e.role || "data" !== e.role) throw Error('"data_message" parts expect an object with a "role" and "data" property.');
                        return {
                            type: "data_message",
                            value: e
                        }
                    }
                };
            D.code, L.code, F.code, j.code, M.code, D.name, D.code, L.name, L.code, F.name, F.code, j.name, j.code, M.name, M.code, [D, L, F, j, M].map(e => e.code);
            var V = [{
                    code: "0",
                    name: "text",
                    parse: e => {
                        if ("string" != typeof e) throw Error('"text" parts expect a string value.');
                        return {
                            type: "text",
                            value: e
                        }
                    }
                }, {
                    code: "2",
                    name: "data",
                    parse: e => {
                        if (!Array.isArray(e)) throw Error('"data" parts expect an array value.');
                        return {
                            type: "data",
                            value: e
                        }
                    }
                }, {
                    code: "3",
                    name: "error",
                    parse: e => {
                        if ("string" != typeof e) throw Error('"error" parts expect a string value.');
                        return {
                            type: "error",
                            value: e
                        }
                    }
                }, {
                    code: "8",
                    name: "message_annotations",
                    parse: e => {
                        if (!Array.isArray(e)) throw Error('"message_annotations" parts expect an array value.');
                        return {
                            type: "message_annotations",
                            value: e
                        }
                    }
                }, {
                    code: "9",
                    name: "tool_call",
                    parse: e => {
                        if (null == e || "object" != typeof e || !("toolCallId" in e) || "string" != typeof e.toolCallId || !("toolName" in e) || "string" != typeof e.toolName || !("args" in e) || "object" != typeof e.args) throw Error('"tool_call" parts expect an object with a "toolCallId", "toolName", and "args" property.');
                        return {
                            type: "tool_call",
                            value: e
                        }
                    }
                }, {
                    code: "a",
                    name: "tool_result",
                    parse: e => {
                        if (null == e || "object" != typeof e || !("toolCallId" in e) || "string" != typeof e.toolCallId || !("result" in e)) throw Error('"tool_result" parts expect an object with a "toolCallId" and a "result" property.');
                        return {
                            type: "tool_result",
                            value: e
                        }
                    }
                }, {
                    code: "b",
                    name: "tool_call_streaming_start",
                    parse: e => {
                        if (null == e || "object" != typeof e || !("toolCallId" in e) || "string" != typeof e.toolCallId || !("toolName" in e) || "string" != typeof e.toolName) throw Error('"tool_call_streaming_start" parts expect an object with a "toolCallId" and "toolName" property.');
                        return {
                            type: "tool_call_streaming_start",
                            value: e
                        }
                    }
                }, {
                    code: "c",
                    name: "tool_call_delta",
                    parse: e => {
                        if (null == e || "object" != typeof e || !("toolCallId" in e) || "string" != typeof e.toolCallId || !("argsTextDelta" in e) || "string" != typeof e.argsTextDelta) throw Error('"tool_call_delta" parts expect an object with a "toolCallId" and "argsTextDelta" property.');
                        return {
                            type: "tool_call_delta",
                            value: e
                        }
                    }
                }, {
                    code: "d",
                    name: "finish_message",
                    parse: e => {
                        if (null == e || "object" != typeof e || !("finishReason" in e) || "string" != typeof e.finishReason) throw Error('"finish_message" parts expect an object with a "finishReason" property.');
                        let t = {
                            finishReason: e.finishReason
                        };
                        return "usage" in e && null != e.usage && "object" == typeof e.usage && "promptTokens" in e.usage && "completionTokens" in e.usage && (t.usage = {
                            promptTokens: "number" == typeof e.usage.promptTokens ? e.usage.promptTokens : Number.NaN,
                            completionTokens: "number" == typeof e.usage.completionTokens ? e.usage.completionTokens : Number.NaN
                        }), {
                            type: "finish_message",
                            value: t
                        }
                    }
                }, {
                    code: "e",
                    name: "finish_step",
                    parse: e => {
                        if (null == e || "object" != typeof e || !("finishReason" in e) || "string" != typeof e.finishReason) throw Error('"finish_step" parts expect an object with a "finishReason" property.');
                        let t = {
                            finishReason: e.finishReason,
                            isContinued: !1
                        };
                        return "usage" in e && null != e.usage && "object" == typeof e.usage && "promptTokens" in e.usage && "completionTokens" in e.usage && (t.usage = {
                            promptTokens: "number" == typeof e.usage.promptTokens ? e.usage.promptTokens : Number.NaN,
                            completionTokens: "number" == typeof e.usage.completionTokens ? e.usage.completionTokens : Number.NaN
                        }), "isContinued" in e && "boolean" == typeof e.isContinued && (t.isContinued = e.isContinued), {
                            type: "finish_step",
                            value: t
                        }
                    }
                }, {
                    code: "f",
                    name: "start_step",
                    parse: e => {
                        if (null == e || "object" != typeof e || !("messageId" in e) || "string" != typeof e.messageId) throw Error('"start_step" parts expect an object with an "id" property.');
                        return {
                            type: "start_step",
                            value: {
                                messageId: e.messageId
                            }
                        }
                    }
                }, {
                    code: "g",
                    name: "reasoning",
                    parse: e => {
                        if ("string" != typeof e) throw Error('"reasoning" parts expect a string value.');
                        return {
                            type: "reasoning",
                            value: e
                        }
                    }
                }, {
                    code: "h",
                    name: "source",
                    parse: e => {
                        if (null == e || "object" != typeof e) throw Error('"source" parts expect a Source object.');
                        return {
                            type: "source",
                            value: e
                        }
                    }
                }],
                P = Object.fromEntries(V.map(e => [e.code, e]));
            Object.fromEntries(V.map(e => [e.name, e.code]));
            var J = V.map(e => e.code),
                B = e => {
                    let t = e.indexOf(":");
                    if (-1 === t) throw Error("Failed to parse stream string. No separator found.");
                    let r = e.slice(0, t);
                    if (!J.includes(r)) throw Error(`Failed to parse stream string. Invalid code ${r}.`);
                    let a = JSON.parse(e.slice(t + 1));
                    return P[r].parse(a)
                };
            async function U({
                stream: e,
                onTextPart: t,
                onReasoningPart: r,
                onSourcePart: a,
                onDataPart: o,
                onErrorPart: n,
                onToolCallStreamingStartPart: s,
                onToolCallDeltaPart: l,
                onToolCallPart: i,
                onToolResultPart: u,
                onMessageAnnotationsPart: c,
                onFinishMessagePart: d,
                onFinishStepPart: p,
                onStartStepPart: f
            }) {
                let g = e.getReader(),
                    h = new TextDecoder,
                    y = [],
                    m = 0;
                for (;;) {
                    let {
                        value: e
                    } = await g.read();
                    if (e && (y.push(e), m += e.length, 10 !== e[e.length - 1])) continue;
                    if (0 === y.length) break;
                    let E = function(e, t) {
                        let r = new Uint8Array(t),
                            a = 0;
                        for (let t of e) r.set(t, a), a += t.length;
                        return e.length = 0, r
                    }(y, m);
                    for (let {
                            type: e,
                            value: g
                        } of (m = 0, h.decode(E, {
                            stream: !0
                        }).split("\n").filter(e => "" !== e).map(B))) switch (e) {
                        case "text":
                            await (null == t ? void 0 : t(g));
                            break;
                        case "reasoning":
                            await (null == r ? void 0 : r(g));
                            break;
                        case "source":
                            await (null == a ? void 0 : a(g));
                            break;
                        case "data":
                            await (null == o ? void 0 : o(g));
                            break;
                        case "error":
                            await (null == n ? void 0 : n(g));
                            break;
                        case "message_annotations":
                            await (null == c ? void 0 : c(g));
                            break;
                        case "tool_call_streaming_start":
                            await (null == s ? void 0 : s(g));
                            break;
                        case "tool_call_delta":
                            await (null == l ? void 0 : l(g));
                            break;
                        case "tool_call":
                            await (null == i ? void 0 : i(g));
                            break;
                        case "tool_result":
                            await (null == u ? void 0 : u(g));
                            break;
                        case "finish_message":
                            await (null == d ? void 0 : d(g));
                            break;
                        case "finish_step":
                            await (null == p ? void 0 : p(g));
                            break;
                        case "start_step":
                            await (null == f ? void 0 : f(g));
                            break;
                        default:
                            throw Error(`Unknown stream part type: ${e}`)
                    }
                }
            }
            async function Y({
                stream: e,
                update: t,
                onToolCall: r,
                onFinish: a,
                generateId: o = k,
                getCurrentDate: n = () => new Date,
                lastMessage: s
            }) {
                var l, i;
                let u, c;
                let d = (null == s ? void 0 : s.role) === "assistant",
                    p = d ? 1 + (null != (i = null == (l = s.toolInvocations) ? void 0 : l.reduce((e, t) => {
                        var r;
                        return Math.max(e, null != (r = t.step) ? r : 0)
                    }, 0)) ? i : 0) : 0,
                    f = d ? structuredClone(s) : {
                        id: o(),
                        createdAt: n(),
                        role: "assistant",
                        content: "",
                        parts: []
                    };

                function g(e, t) {
                    let r = f.parts.find(t => "tool-invocation" === t.type && t.toolInvocation.toolCallId === e);
                    null != r ? r.toolInvocation = t : f.parts.push({
                        type: "tool-invocation",
                        toolInvocation: t
                    })
                }
                let h = [],
                    y = d ? null == s ? void 0 : s.annotations : void 0,
                    m = {},
                    E = {
                        completionTokens: NaN,
                        promptTokens: NaN,
                        totalTokens: NaN
                    },
                    _ = "unknown";

                function I() {
                    let e = [...h];
                    (null == y ? void 0 : y.length) && (f.annotations = y), t({
                        message: { ...structuredClone(f),
                            revisionId: o()
                        },
                        data: e,
                        replaceLastMessage: d
                    })
                }
                await U({
                    stream: e,
                    onTextPart(e) {
                        null == u ? (u = {
                            type: "text",
                            text: e
                        }, f.parts.push(u)) : u.text += e, f.content += e, I()
                    },
                    onReasoningPart(e) {
                        var t;
                        null == c ? (c = {
                            type: "reasoning",
                            reasoning: e
                        }, f.parts.push(c)) : c.reasoning += e, f.reasoning = (null != (t = f.reasoning) ? t : "") + e, I()
                    },
                    onSourcePart(e) {
                        f.parts.push({
                            type: "source",
                            source: e
                        }), I()
                    },
                    onToolCallStreamingStartPart(e) {
                        null == f.toolInvocations && (f.toolInvocations = []), m[e.toolCallId] = {
                            text: "",
                            step: p,
                            toolName: e.toolName,
                            index: f.toolInvocations.length
                        };
                        let t = {
                            state: "partial-call",
                            step: p,
                            toolCallId: e.toolCallId,
                            toolName: e.toolName,
                            args: void 0
                        };
                        f.toolInvocations.push(t), g(e.toolCallId, t), I()
                    },
                    onToolCallDeltaPart(e) {
                        let t = m[e.toolCallId];
                        t.text += e.argsTextDelta;
                        let {
                            value: r
                        } = function(e) {
                            if (void 0 === e) return {
                                value: void 0,
                                state: "undefined-input"
                            };
                            let t = N({
                                text: e
                            });
                            return t.success ? {
                                value: t.value,
                                state: "successful-parse"
                            } : (t = N({
                                text: function(e) {
                                    let t = ["ROOT"],
                                        r = -1,
                                        a = null;

                                    function o(e, o, n) {
                                        switch (e) {
                                            case '"':
                                                r = o, t.pop(), t.push(n), t.push("INSIDE_STRING");
                                                break;
                                            case "f":
                                            case "t":
                                            case "n":
                                                r = o, a = o, t.pop(), t.push(n), t.push("INSIDE_LITERAL");
                                                break;
                                            case "-":
                                                t.pop(), t.push(n), t.push("INSIDE_NUMBER");
                                                break;
                                            case "0":
                                            case "1":
                                            case "2":
                                            case "3":
                                            case "4":
                                            case "5":
                                            case "6":
                                            case "7":
                                            case "8":
                                            case "9":
                                                r = o, t.pop(), t.push(n), t.push("INSIDE_NUMBER");
                                                break;
                                            case "{":
                                                r = o, t.pop(), t.push(n), t.push("INSIDE_OBJECT_START");
                                                break;
                                            case "[":
                                                r = o, t.pop(), t.push(n), t.push("INSIDE_ARRAY_START")
                                        }
                                    }

                                    function n(e, a) {
                                        switch (e) {
                                            case ",":
                                                t.pop(), t.push("INSIDE_OBJECT_AFTER_COMMA");
                                                break;
                                            case "}":
                                                r = a, t.pop()
                                        }
                                    }

                                    function s(e, a) {
                                        switch (e) {
                                            case ",":
                                                t.pop(), t.push("INSIDE_ARRAY_AFTER_COMMA");
                                                break;
                                            case "]":
                                                r = a, t.pop()
                                        }
                                    }
                                    for (let l = 0; l < e.length; l++) {
                                        let i = e[l];
                                        switch (t[t.length - 1]) {
                                            case "ROOT":
                                                o(i, l, "FINISH");
                                                break;
                                            case "INSIDE_OBJECT_START":
                                                switch (i) {
                                                    case '"':
                                                        t.pop(), t.push("INSIDE_OBJECT_KEY");
                                                        break;
                                                    case "}":
                                                        r = l, t.pop()
                                                }
                                                break;
                                            case "INSIDE_OBJECT_AFTER_COMMA":
                                                '"' === i && (t.pop(), t.push("INSIDE_OBJECT_KEY"));
                                                break;
                                            case "INSIDE_OBJECT_KEY":
                                                '"' === i && (t.pop(), t.push("INSIDE_OBJECT_AFTER_KEY"));
                                                break;
                                            case "INSIDE_OBJECT_AFTER_KEY":
                                                ":" === i && (t.pop(), t.push("INSIDE_OBJECT_BEFORE_VALUE"));
                                                break;
                                            case "INSIDE_OBJECT_BEFORE_VALUE":
                                                o(i, l, "INSIDE_OBJECT_AFTER_VALUE");
                                                break;
                                            case "INSIDE_OBJECT_AFTER_VALUE":
                                                n(i, l);
                                                break;
                                            case "INSIDE_STRING":
                                                switch (i) {
                                                    case '"':
                                                        t.pop(), r = l;
                                                        break;
                                                    case "\\":
                                                        t.push("INSIDE_STRING_ESCAPE");
                                                        break;
                                                    default:
                                                        r = l
                                                }
                                                break;
                                            case "INSIDE_ARRAY_START":
                                                "]" === i ? (r = l, t.pop()) : (r = l, o(i, l, "INSIDE_ARRAY_AFTER_VALUE"));
                                                break;
                                            case "INSIDE_ARRAY_AFTER_VALUE":
                                                switch (i) {
                                                    case ",":
                                                        t.pop(), t.push("INSIDE_ARRAY_AFTER_COMMA");
                                                        break;
                                                    case "]":
                                                        r = l, t.pop();
                                                        break;
                                                    default:
                                                        r = l
                                                }
                                                break;
                                            case "INSIDE_ARRAY_AFTER_COMMA":
                                                o(i, l, "INSIDE_ARRAY_AFTER_VALUE");
                                                break;
                                            case "INSIDE_STRING_ESCAPE":
                                                t.pop(), r = l;
                                                break;
                                            case "INSIDE_NUMBER":
                                                switch (i) {
                                                    case "0":
                                                    case "1":
                                                    case "2":
                                                    case "3":
                                                    case "4":
                                                    case "5":
                                                    case "6":
                                                    case "7":
                                                    case "8":
                                                    case "9":
                                                        r = l;
                                                        break;
                                                    case "e":
                                                    case "E":
                                                    case "-":
                                                    case ".":
                                                        break;
                                                    case ",":
                                                        t.pop(), "INSIDE_ARRAY_AFTER_VALUE" === t[t.length - 1] && s(i, l), "INSIDE_OBJECT_AFTER_VALUE" === t[t.length - 1] && n(i, l);
                                                        break;
                                                    case "}":
                                                        t.pop(), "INSIDE_OBJECT_AFTER_VALUE" === t[t.length - 1] && n(i, l);
                                                        break;
                                                    case "]":
                                                        t.pop(), "INSIDE_ARRAY_AFTER_VALUE" === t[t.length - 1] && s(i, l);
                                                        break;
                                                    default:
                                                        t.pop()
                                                }
                                                break;
                                            case "INSIDE_LITERAL":
                                                {
                                                    let o = e.substring(a, l + 1);
                                                    "false".startsWith(o) || "true".startsWith(o) || "null".startsWith(o) ? r = l : (t.pop(), "INSIDE_OBJECT_AFTER_VALUE" === t[t.length - 1] ? n(i, l) : "INSIDE_ARRAY_AFTER_VALUE" === t[t.length - 1] && s(i, l))
                                                }
                                        }
                                    }
                                    let l = e.slice(0, r + 1);
                                    for (let r = t.length - 1; r >= 0; r--) switch (t[r]) {
                                        case "INSIDE_STRING":
                                            l += '"';
                                            break;
                                        case "INSIDE_OBJECT_KEY":
                                        case "INSIDE_OBJECT_AFTER_KEY":
                                        case "INSIDE_OBJECT_AFTER_COMMA":
                                        case "INSIDE_OBJECT_START":
                                        case "INSIDE_OBJECT_BEFORE_VALUE":
                                        case "INSIDE_OBJECT_AFTER_VALUE":
                                            l += "}";
                                            break;
                                        case "INSIDE_ARRAY_START":
                                        case "INSIDE_ARRAY_AFTER_COMMA":
                                        case "INSIDE_ARRAY_AFTER_VALUE":
                                            l += "]";
                                            break;
                                        case "INSIDE_LITERAL":
                                            {
                                                let t = e.substring(a, e.length);
                                                "true".startsWith(t) ? l += "true".slice(t.length) : "false".startsWith(t) ? l += "false".slice(t.length) : "null".startsWith(t) && (l += "null".slice(t.length))
                                            }
                                    }
                                    return l
                                }(e)
                            })).success ? {
                                value: t.value,
                                state: "repaired-parse"
                            } : {
                                value: void 0,
                                state: "failed-parse"
                            }
                        }(t.text), a = {
                            state: "partial-call",
                            step: t.step,
                            toolCallId: e.toolCallId,
                            toolName: t.toolName,
                            args: r
                        };
                        f.toolInvocations[t.index] = a, g(e.toolCallId, a), I()
                    },
                    async onToolCallPart(e) {
                        let t = {
                            state: "call",
                            step: p,
                            ...e
                        };
                        if (null != m[e.toolCallId] ? f.toolInvocations[m[e.toolCallId].index] = t : (null == f.toolInvocations && (f.toolInvocations = []), f.toolInvocations.push(t)), g(e.toolCallId, t), I(), r) {
                            let t = await r({
                                toolCall: e
                            });
                            if (null != t) {
                                let r = {
                                    state: "result",
                                    step: p,
                                    ...e,
                                    result: t
                                };
                                f.toolInvocations[f.toolInvocations.length - 1] = r, g(e.toolCallId, r), I()
                            }
                        }
                    },
                    onToolResultPart(e) {
                        let t = f.toolInvocations;
                        if (null == t) throw Error("tool_result must be preceded by a tool_call");
                        let r = t.findIndex(t => t.toolCallId === e.toolCallId);
                        if (-1 === r) throw Error("tool_result must be preceded by a tool_call with the same toolCallId");
                        let a = { ...t[r],
                            state: "result",
                            ...e
                        };
                        t[r] = a, g(e.toolCallId, a), I()
                    },
                    onDataPart(e) {
                        h.push(...e), I()
                    },
                    onMessageAnnotationsPart(e) {
                        null == y ? y = [...e] : y.push(...e), I()
                    },
                    onFinishStepPart(e) {
                        p += 1, u = e.isContinued ? u : void 0, c = void 0
                    },
                    onStartStepPart(e) {
                        d || (f.id = e.messageId)
                    },
                    onFinishMessagePart(e) {
                        _ = e.finishReason, null != e.usage && (E = function({
                            promptTokens: e,
                            completionTokens: t
                        }) {
                            return {
                                promptTokens: e,
                                completionTokens: t,
                                totalTokens: e + t
                            }
                        }(e.usage))
                    },
                    onErrorPart(e) {
                        throw Error(e)
                    }
                }), null == a || a({
                    message: f,
                    finishReason: _,
                    usage: E
                })
            }
            async function $({
                stream: e,
                onTextPart: t
            }) {
                let r = e.pipeThrough(new TextDecoderStream).getReader();
                for (;;) {
                    let {
                        done: e,
                        value: a
                    } = await r.read();
                    if (e) break;
                    await t(a)
                }
            }
            async function W({
                stream: e,
                update: t,
                onFinish: r,
                getCurrentDate: a = () => new Date,
                generateId: o = k
            }) {
                let n = {
                        type: "text",
                        text: ""
                    },
                    s = {
                        id: o(),
                        createdAt: a(),
                        role: "assistant",
                        content: "",
                        parts: [n]
                    };
                await $({
                    stream: e,
                    onTextPart: e => {
                        s.content += e, n.text += e, t({
                            message: { ...s
                            },
                            data: [],
                            replaceLastMessage: !1
                        })
                    }
                }), null == r || r(s, {
                    usage: {
                        completionTokens: NaN,
                        promptTokens: NaN,
                        totalTokens: NaN
                    },
                    finishReason: "unknown"
                })
            }
            var K = () => fetch;
            async function G({
                api: e,
                body: t,
                streamProtocol: r = "data",
                credentials: a,
                headers: o,
                abortController: n,
                restoreMessagesOnFailure: s,
                onResponse: l,
                onUpdate: i,
                onFinish: u,
                onToolCall: c,
                generateId: d,
                fetch: p = K(),
                lastMessage: f
            }) {
                var g, h;
                let y = await p(e, {
                    method: "POST",
                    body: JSON.stringify(t),
                    headers: {
                        "Content-Type": "application/json",
                        ...o
                    },
                    signal: null == (g = null == n ? void 0 : n()) ? void 0 : g.signal,
                    credentials: a
                }).catch(e => {
                    throw s(), e
                });
                if (l) try {
                    await l(y)
                } catch (e) {
                    throw e
                }
                if (!y.ok) throw s(), Error(null != (h = await y.text()) ? h : "Failed to fetch the chat response.");
                if (!y.body) throw Error("The response body is empty.");
                switch (r) {
                    case "text":
                        await W({
                            stream: y.body,
                            update: i,
                            onFinish: u,
                            generateId: d
                        });
                        return;
                    case "data":
                        await Y({
                            stream: y.body,
                            update: i,
                            lastMessage: f,
                            onToolCall: c,
                            onFinish({
                                message: e,
                                finishReason: t,
                                usage: r
                            }) {
                                u && null != e && u(e, {
                                    usage: r,
                                    finishReason: t
                                })
                            },
                            generateId: d
                        });
                        return;
                    default:
                        throw Error(`Unknown stream protocol: ${r}`)
                }
            }

            function q(e) {
                return null == e ? void 0 : e.reduce((e, t) => {
                    var r;
                    return Math.max(e, null != (r = t.step) ? r : 0)
                }, 0)
            }

            function z(e) {
                var t;
                return null != (t = e.parts) ? t : [...e.toolInvocations ? e.toolInvocations.map(e => ({
                    type: "tool-invocation",
                    toolInvocation: e
                })) : [], ...e.reasoning ? [{
                    type: "reasoning",
                    reasoning: e.reasoning
                }] : [], ...e.content ? [{
                    type: "text",
                    text: e.content
                }] : []]
            }

            function H(e) {
                return e.map(e => ({ ...e,
                    parts: z(e)
                }))
            }
            async function Q(e) {
                if (!e) return [];
                if (e instanceof FileList) return Promise.all(Array.from(e).map(async e => {
                    let {
                        name: t,
                        type: r
                    } = e;
                    return {
                        name: t,
                        contentType: r,
                        url: await new Promise((t, r) => {
                            let a = new FileReader;
                            a.onload = e => {
                                var r;
                                t(null == (r = e.target) ? void 0 : r.result)
                            }, a.onerror = e => r(e), a.readAsDataURL(e)
                        })
                    }
                }));
                if (Array.isArray(e)) return e;
                throw Error("Invalid attachments type")
            }

            function X(e) {
                return "assistant" === e.role && e.parts.filter(e => "tool-invocation" === e.type).every(e => "result" in e.toolInvocation)
            }
            Symbol.for("vercel.ai.schema");
            var Z = r(3486),
                ee = Object.prototype.hasOwnProperty;
            let et = new WeakMap,
                er = () => {},
                ea = er(),
                eo = Object,
                en = e => e === ea,
                es = e => "function" == typeof e,
                el = (e, t) => ({ ...e,
                    ...t
                }),
                ei = e => es(e.then),
                eu = {},
                ec = {},
                ed = "undefined",
                ep = typeof window != ed,
                ef = typeof document != ed,
                eg = ep && "Deno" in window,
                eh = () => ep && typeof window.requestAnimationFrame != ed,
                ey = (e, t) => {
                    let r = et.get(e);
                    return [() => !en(t) && e.get(t) || eu, a => {
                        if (!en(t)) {
                            let o = e.get(t);
                            t in ec || (ec[t] = o), r[5](t, el(o, a), o || eu)
                        }
                    }, r[6], () => !en(t) && t in ec ? ec[t] : !en(t) && e.get(t) || eu]
                },
                em = !0,
                [eE, e_] = ep && window.addEventListener ? [window.addEventListener.bind(window), window.removeEventListener.bind(window)] : [er, er],
                eI = {
                    initFocus: e => (ef && document.addEventListener("visibilitychange", e), eE("focus", e), () => {
                        ef && document.removeEventListener("visibilitychange", e), e_("focus", e)
                    }),
                    initReconnect: e => {
                        let t = () => {
                                em = !0, e()
                            },
                            r = () => {
                                em = !1
                            };
                        return eE("online", t), eE("offline", r), () => {
                            e_("online", t), e_("offline", r)
                        }
                    }
                },
                ev = !i.useId,
                eb = !ep || eg,
                ew = e => eh() ? window.requestAnimationFrame(e) : setTimeout(e, 1),
                eT = eb ? i.useEffect : i.useLayoutEffect,
                eS = "undefined" != typeof navigator && navigator.connection,
                eA = !eb && eS && (["slow-2g", "2g"].includes(eS.effectiveType) || eS.saveData),
                eR = new WeakMap,
                ek = (e, t) => eo.prototype.toString.call(e) === "[object ".concat(t, "]"),
                eC = 0,
                eN = e => {
                    let t, r;
                    let a = typeof e,
                        o = ek(e, "Date"),
                        n = ek(e, "RegExp"),
                        s = ek(e, "Object");
                    if (eo(e) !== e || o || n) t = o ? e.toJSON() : "symbol" == a ? e.toString() : "string" == a ? JSON.stringify(e) : "" + e;
                    else {
                        if (t = eR.get(e)) return t;
                        if (t = ++eC + "~", eR.set(e, t), Array.isArray(e)) {
                            for (r = 0, t = "@"; r < e.length; r++) t += eN(e[r]) + ",";
                            eR.set(e, t)
                        }
                        if (s) {
                            t = "#";
                            let a = eo.keys(e).sort();
                            for (; !en(r = a.pop());) en(e[r]) || (t += r + ":" + eN(e[r]) + ",");
                            eR.set(e, t)
                        }
                    }
                    return t
                },
                ex = e => {
                    if (es(e)) try {
                        e = e()
                    } catch (t) {
                        e = ""
                    }
                    let t = e;
                    return [e = "string" == typeof e ? e : (Array.isArray(e) ? e.length : e) ? eN(e) : "", t]
                },
                eO = 0,
                eD = () => ++eO;
            async function eL() {
                for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                let [a, o, n, s] = t, l = el({
                    populateCache: !0,
                    throwOnError: !0
                }, "boolean" == typeof s ? {
                    revalidate: s
                } : s || {}), i = l.populateCache, u = l.rollbackOnError, c = l.optimisticData, d = e => "function" == typeof u ? u(e) : !1 !== u, p = l.throwOnError;
                if (es(o)) {
                    let e = [];
                    for (let t of a.keys()) !/^\$(inf|sub)\$/.test(t) && o(a.get(t)._k) && e.push(t);
                    return Promise.all(e.map(f))
                }
                return f(o);
                async function f(e) {
                    let r;
                    let [o] = ex(e);
                    if (!o) return;
                    let [s, u] = ey(a, o), [f, g, h, y] = et.get(a), m = () => {
                        let t = f[o];
                        return (es(l.revalidate) ? l.revalidate(s().data, e) : !1 !== l.revalidate) && (delete h[o], delete y[o], t && t[0]) ? t[0](2).then(() => s().data) : s().data
                    };
                    if (t.length < 3) return m();
                    let E = n,
                        _ = eD();
                    g[o] = [_, 0];
                    let I = !en(c),
                        v = s(),
                        b = v.data,
                        w = v._c,
                        T = en(w) ? b : w;
                    if (I && u({
                            data: c = es(c) ? c(T, b) : c,
                            _c: T
                        }), es(E)) try {
                        E = E(T)
                    } catch (e) {
                        r = e
                    }
                    if (E && ei(E)) {
                        if (E = await E.catch(e => {
                                r = e
                            }), _ !== g[o][0]) {
                            if (r) throw r;
                            return E
                        }
                        r && I && d(r) && (i = !0, u({
                            data: T,
                            _c: ea
                        }))
                    }
                    if (i && !r && (es(i) ? u({
                            data: i(E, T),
                            error: ea,
                            _c: ea
                        }) : u({
                            data: E,
                            error: ea,
                            _c: ea
                        })), g[o][1] = eD(), Promise.resolve(m()).then(() => {
                            u({
                                _c: ea
                            })
                        }), r) {
                        if (p) throw r;
                        return
                    }
                    return E
                }
            }
            let eF = (e, t) => {
                    for (let r in e) e[r][0] && e[r][0](t)
                },
                ej = (e, t) => {
                    if (!et.has(e)) {
                        let r = el(eI, t),
                            a = {},
                            o = eL.bind(ea, e),
                            n = er,
                            s = {},
                            l = (e, t) => {
                                let r = s[e] || [];
                                return s[e] = r, r.push(t), () => r.splice(r.indexOf(t), 1)
                            },
                            i = (t, r, a) => {
                                e.set(t, r);
                                let o = s[t];
                                if (o)
                                    for (let e of o) e(r, a)
                            },
                            u = () => {
                                if (!et.has(e) && (et.set(e, [a, {}, {}, {}, o, i, l]), !eb)) {
                                    let t = r.initFocus(setTimeout.bind(ea, eF.bind(ea, a, 0))),
                                        o = r.initReconnect(setTimeout.bind(ea, eF.bind(ea, a, 1)));
                                    n = () => {
                                        t && t(), o && o(), et.delete(e)
                                    }
                                }
                            };
                        return u(), [e, o, u, n]
                    }
                    return [e, et.get(e)[4]]
                },
                [eM, eV] = ej(new Map),
                eP = el({
                    onLoadingSlow: er,
                    onSuccess: er,
                    onError: er,
                    onErrorRetry: (e, t, r, a, o) => {
                        let n = r.errorRetryCount,
                            s = o.retryCount,
                            l = ~~((Math.random() + .5) * (1 << (s < 8 ? s : 8))) * r.errorRetryInterval;
                        (en(n) || !(s > n)) && setTimeout(a, l, o)
                    },
                    onDiscarded: er,
                    revalidateOnFocus: !0,
                    revalidateOnReconnect: !0,
                    revalidateIfStale: !0,
                    shouldRetryOnError: !0,
                    errorRetryInterval: eA ? 1e4 : 5e3,
                    focusThrottleInterval: 5e3,
                    dedupingInterval: 2e3,
                    loadingTimeout: eA ? 5e3 : 3e3,
                    compare: function e(t, r) {
                        var a, o;
                        if (t === r) return !0;
                        if (t && r && (a = t.constructor) === r.constructor) {
                            if (a === Date) return t.getTime() === r.getTime();
                            if (a === RegExp) return t.toString() === r.toString();
                            if (a === Array) {
                                if ((o = t.length) === r.length)
                                    for (; o-- && e(t[o], r[o]););
                                return -1 === o
                            }
                            if (!a || "object" == typeof t) {
                                for (a in o = 0, t)
                                    if (ee.call(t, a) && ++o && !ee.call(r, a) || !(a in r) || !e(t[a], r[a])) return !1;
                                return Object.keys(r).length === o
                            }
                        }
                        return t != t && r != r
                    },
                    isPaused: () => !1,
                    cache: eM,
                    mutate: eV,
                    fallback: {}
                }, {
                    isOnline: () => em,
                    isVisible: () => {
                        let e = ef && document.visibilityState;
                        return en(e) || "hidden" !== e
                    }
                }),
                eJ = (e, t) => {
                    let r = el(e, t);
                    if (t) {
                        let {
                            use: a,
                            fallback: o
                        } = e, {
                            use: n,
                            fallback: s
                        } = t;
                        a && n && (r.use = a.concat(n)), o && s && (r.fallback = el(o, s))
                    }
                    return r
                },
                eB = (0, i.createContext)({}),
                eU = ep && window.__SWR_DEVTOOLS_USE__,
                eY = eU ? window.__SWR_DEVTOOLS_USE__ : [],
                e$ = e => es(e[1]) ? [e[0], e[1], e[2] || {}] : [e[0], null, (null === e[1] ? e[2] : e[1]) || {}],
                eW = () => el(eP, (0, i.useContext)(eB)),
                eK = eY.concat(e => (t, r, a) => {
                    let o = r && ((...e) => {
                        let [a] = ex(t), [, , , o] = et.get(eM);
                        if (a.startsWith("$inf$")) return r(...e);
                        let n = o[a];
                        return en(n) ? r(...e) : (delete o[a], n)
                    });
                    return e(t, o, a)
                }),
                eG = (e, t, r) => {
                    let a = t[e] || (t[e] = []);
                    return a.push(r), () => {
                        let e = a.indexOf(r);
                        e >= 0 && (a[e] = a[a.length - 1], a.pop())
                    }
                };
            eU && (window.__SWR_DEVTOOLS_REACT__ = i);
            let eq = () => {};
            eq(), new WeakMap;
            let ez = i.use || (e => {
                    switch (e.status) {
                        case "pending":
                            throw e;
                        case "fulfilled":
                            return e.value;
                        case "rejected":
                            throw e.reason;
                        default:
                            throw e.status = "pending", e.then(t => {
                                e.status = "fulfilled", e.value = t
                            }, t => {
                                e.status = "rejected", e.reason = t
                            }), e
                    }
                }),
                eH = {
                    dedupe: !0
                };
            eo.defineProperty(e => {
                let {
                    value: t
                } = e, r = (0, i.useContext)(eB), a = es(t), o = (0, i.useMemo)(() => a ? t(r) : t, [a, r, t]), n = (0, i.useMemo)(() => a ? o : eJ(r, o), [a, r, o]), s = o && o.provider, l = (0, i.useRef)(ea);
                s && !l.current && (l.current = ej(s(n.cache || eM), o));
                let u = l.current;
                return u && (n.cache = u[0], n.mutate = u[1]), eT(() => {
                    if (u) return u[2] && u[2](), u[3]
                }, []), (0, i.createElement)(eB.Provider, el(e, {
                    value: n
                }))
            }, "defaultValue", {
                value: eP
            });
            let eQ = (a = (e, t, r) => {
                let {
                    cache: a,
                    compare: o,
                    suspense: n,
                    fallbackData: s,
                    revalidateOnMount: l,
                    revalidateIfStale: u,
                    refreshInterval: c,
                    refreshWhenHidden: d,
                    refreshWhenOffline: p,
                    keepPreviousData: f
                } = r, [g, h, y, m] = et.get(a), [E, _] = ex(e), I = (0, i.useRef)(!1), v = (0, i.useRef)(!1), b = (0, i.useRef)(E), w = (0, i.useRef)(t), T = (0, i.useRef)(r), S = () => T.current, A = () => S().isVisible() && S().isOnline(), [R, k, C, N] = ey(a, E), x = (0, i.useRef)({}).current, O = en(s) ? en(r.fallback) ? ea : r.fallback[E] : s, D = (e, t) => {
                    for (let r in x)
                        if ("data" === r) {
                            if (!o(e[r], t[r]) && (!en(e[r]) || !o(U, t[r]))) return !1
                        } else if (t[r] !== e[r]) return !1;
                    return !0
                }, L = (0, i.useMemo)(() => {
                    let e = !!E && !!t && (en(l) ? !S().isPaused() && !n && !1 !== u : l),
                        r = t => {
                            let r = el(t);
                            return (delete r._k, e) ? {
                                isValidating: !0,
                                isLoading: !0,
                                ...r
                            } : r
                        },
                        a = R(),
                        o = N(),
                        s = r(a),
                        i = a === o ? s : r(o),
                        c = s;
                    return [() => {
                        let e = r(R());
                        return D(e, c) ? (c.data = e.data, c.isLoading = e.isLoading, c.isValidating = e.isValidating, c.error = e.error, c) : (c = e, e)
                    }, () => i]
                }, [a, E]), F = (0, Z.useSyncExternalStore)((0, i.useCallback)(e => C(E, (t, r) => {
                    D(r, t) || e()
                }), [a, E]), L[0], L[1]), j = !I.current, M = g[E] && g[E].length > 0, V = F.data, P = en(V) ? O && ei(O) ? ez(O) : O : V, J = F.error, B = (0, i.useRef)(P), U = f ? en(V) ? en(B.current) ? P : B.current : V : P, Y = (!M || !!en(J)) && (j && !en(l) ? l : !S().isPaused() && (n ? !en(P) && u : en(P) || u)), $ = !!(E && t && j && Y), W = en(F.isValidating) ? $ : F.isValidating, K = en(F.isLoading) ? $ : F.isLoading, G = (0, i.useCallback)(async e => {
                    let t, a;
                    let n = w.current;
                    if (!E || !n || v.current || S().isPaused()) return !1;
                    let s = !0,
                        l = e || {},
                        i = !y[E] || !l.dedupe,
                        u = () => ev ? !v.current && E === b.current && I.current : E === b.current,
                        c = {
                            isValidating: !1,
                            isLoading: !1
                        },
                        d = () => {
                            k(c)
                        },
                        p = () => {
                            let e = y[E];
                            e && e[1] === a && delete y[E]
                        },
                        f = {
                            isValidating: !0
                        };
                    en(R().data) && (f.isLoading = !0);
                    try {
                        if (i && (k(f), r.loadingTimeout && en(R().data) && setTimeout(() => {
                                s && u() && S().onLoadingSlow(E, r)
                            }, r.loadingTimeout), y[E] = [n(_), eD()]), [t, a] = y[E], t = await t, i && setTimeout(p, r.dedupingInterval), !y[E] || y[E][1] !== a) return i && u() && S().onDiscarded(E), !1;
                        c.error = ea;
                        let e = h[E];
                        if (!en(e) && (a <= e[0] || a <= e[1] || 0 === e[1])) return d(), i && u() && S().onDiscarded(E), !1;
                        let l = R().data;
                        c.data = o(l, t) ? l : t, i && u() && S().onSuccess(t, E, r)
                    } catch (r) {
                        p();
                        let e = S(),
                            {
                                shouldRetryOnError: t
                            } = e;
                        !e.isPaused() && (c.error = r, i && u() && (e.onError(r, E, e), (!0 === t || es(t) && t(r)) && (!S().revalidateOnFocus || !S().revalidateOnReconnect || A()) && e.onErrorRetry(r, E, e, e => {
                            let t = g[E];
                            t && t[0] && t[0](3, e)
                        }, {
                            retryCount: (l.retryCount || 0) + 1,
                            dedupe: !0
                        })))
                    }
                    return s = !1, d(), !0
                }, [E, a]), q = (0, i.useCallback)((...e) => eL(a, b.current, ...e), []);
                if (eT(() => {
                        w.current = t, T.current = r, en(V) || (B.current = V)
                    }), eT(() => {
                        if (!E) return;
                        let e = G.bind(ea, eH),
                            t = 0,
                            r = eG(E, g, (r, a = {}) => {
                                if (0 == r) {
                                    let r = Date.now();
                                    S().revalidateOnFocus && r > t && A() && (t = r + S().focusThrottleInterval, e())
                                } else if (1 == r) S().revalidateOnReconnect && A() && e();
                                else if (2 == r) return G();
                                else if (3 == r) return G(a)
                            });
                        return v.current = !1, b.current = E, I.current = !0, k({
                            _k: _
                        }), Y && (en(P) || eb ? e() : ew(e)), () => {
                            v.current = !0, r()
                        }
                    }, [E]), eT(() => {
                        let e;

                        function t() {
                            let t = es(c) ? c(R().data) : c;
                            t && -1 !== e && (e = setTimeout(r, t))
                        }

                        function r() {
                            !R().error && (d || S().isVisible()) && (p || S().isOnline()) ? G(eH).then(t) : t()
                        }
                        return t(), () => {
                            e && (clearTimeout(e), e = -1)
                        }
                    }, [c, d, p, E]), (0, i.useDebugValue)(U), n && en(P) && E) {
                    if (!ev && eb) throw Error("Fallback data is required when using Suspense in SSR.");
                    w.current = t, T.current = r, v.current = !1;
                    let e = m[E];
                    if (en(e) || ez(q(e)), en(J)) {
                        let e = G(eH);
                        en(U) || (e.status = "fulfilled", e.value = !0), ez(e)
                    } else throw J
                }
                return {
                    mutate: q,
                    get data() {
                        return x.data = !0, U
                    },
                    get error() {
                        return x.error = !0, J
                    },
                    get isValidating() {
                        return x.isValidating = !0, W
                    },
                    get isLoading() {
                        return x.isLoading = !0, K
                    }
                }
            }, function(...e) {
                let t = eW(),
                    [r, o, n] = e$(e),
                    s = eJ(t, n),
                    l = a,
                    {
                        use: i
                    } = s,
                    u = (i || []).concat(eK);
                for (let e = u.length; e--;) l = u[e](l);
                return l(r, o || s.fetcher || null, s)
            });
            var eX = r(20940);

            function eZ(e, t) {
                return null != t ? eX(e, t) : e
            }
            var e0 = function({
                api: e = "/api/chat",
                id: t,
                initialMessages: r,
                initialInput: a = "",
                sendExtraMessageFields: o,
                onToolCall: n,
                experimental_prepareRequestBody: s,
                maxSteps: l = 1,
                streamProtocol: u = "data",
                onResponse: c,
                onFinish: d,
                onError: p,
                credentials: f,
                headers: g,
                body: h,
                generateId: y = k,
                fetch: m,
                keepLastMessageOnError: E = !0,
                experimental_throttle: _
            } = {}) {
                let [I] = (0, i.useState)(y), v = null != t ? t : I, b = "string" == typeof e ? [e, v] : v, [w] = (0, i.useState)([]), {
                    data: T,
                    mutate: S
                } = eQ([b, "messages"], null, {
                    fallbackData: null != r ? H(r) : w
                }), A = (0, i.useRef)(T || []);
                (0, i.useEffect)(() => {
                    A.current = T || []
                }, [T]);
                let {
                    data: R,
                    mutate: C
                } = eQ([b, "streamData"], null), N = (0, i.useRef)(R);
                (0, i.useEffect)(() => {
                    N.current = R
                }, [R]);
                let {
                    data: x = "ready",
                    mutate: O
                } = eQ([b, "status"], null), {
                    data: D,
                    mutate: L
                } = eQ([b, "error"], null), F = (0, i.useRef)(null), j = (0, i.useRef)({
                    credentials: f,
                    headers: g,
                    body: h
                });
                (0, i.useEffect)(() => {
                    j.current = {
                        credentials: f,
                        headers: g,
                        body: h
                    }
                }, [f, g, h]);
                let M = (0, i.useCallback)(async t => {
                        var r, a;
                        O("submitted"), L(void 0);
                        let i = H(t.messages),
                            f = i.length,
                            g = q(null == (r = i[i.length - 1]) ? void 0 : r.toolInvocations);
                        try {
                            let r = new AbortController;
                            F.current = r;
                            let l = eZ(S, _),
                                p = eZ(C, _),
                                f = A.current;
                            l(i, !1);
                            let g = o ? i : i.map(({
                                    role: e,
                                    content: t,
                                    experimental_attachments: r,
                                    data: a,
                                    annotations: o,
                                    toolInvocations: n,
                                    parts: s
                                }) => ({
                                    role: e,
                                    content: t,
                                    ...void 0 !== r && {
                                        experimental_attachments: r
                                    },
                                    ...void 0 !== a && {
                                        data: a
                                    },
                                    ...void 0 !== o && {
                                        annotations: o
                                    },
                                    ...void 0 !== n && {
                                        toolInvocations: n
                                    },
                                    ...void 0 !== s && {
                                        parts: s
                                    }
                                })),
                                h = N.current;
                            await G({
                                api: e,
                                body: null != (a = null == s ? void 0 : s({
                                    id: v,
                                    messages: i,
                                    requestData: t.data,
                                    requestBody: t.body
                                })) ? a : {
                                    id: v,
                                    messages: g,
                                    data: t.data,
                                    ...j.current.body,
                                    ...t.body
                                },
                                streamProtocol: u,
                                credentials: j.current.credentials,
                                headers: { ...j.current.headers,
                                    ...t.headers
                                },
                                abortController: () => F.current,
                                restoreMessagesOnFailure() {
                                    E || l(f, !1)
                                },
                                onResponse: c,
                                onUpdate({
                                    message: e,
                                    data: t,
                                    replaceLastMessage: r
                                }) {
                                    O("streaming"), l([...r ? i.slice(0, i.length - 1) : i, e], !1), (null == t ? void 0 : t.length) && p([...null != h ? h : [], ...t], !1)
                                },
                                onToolCall: n,
                                onFinish: d,
                                generateId: y,
                                fetch: m,
                                lastMessage: i[i.length - 1]
                            }), F.current = null, O("ready")
                        } catch (e) {
                            if ("AbortError" === e.name) return F.current = null, O("ready"), null;
                            p && e instanceof Error && p(e), L(e), O("error")
                        }
                        let h = A.current;
                        (function({
                            originalMaxToolInvocationStep: e,
                            originalMessageCount: t,
                            maxSteps: r,
                            messages: a
                        }) {
                            var o;
                            let n;
                            let s = a[a.length - 1];
                            return r > 1 && null != s && (a.length > t || q(s.toolInvocations) !== e) && X(s) && (n = !1, s.parts.forEach(e => {
                                "text" === e.type && (n = !0), "tool-invocation" === e.type && (n = !1)
                            }), !n) && (null != (o = q(s.toolInvocations)) ? o : 0) < r
                        })({
                            originalMaxToolInvocationStep: g,
                            originalMessageCount: f,
                            maxSteps: l,
                            messages: h
                        }) && await M({
                            messages: h
                        })
                    }, [S, O, e, j, c, d, p, L, C, N, u, o, s, n, l, A, F, y, m, E, _, v]),
                    V = (0, i.useCallback)(async (e, {
                        data: t,
                        headers: r,
                        body: a,
                        experimental_attachments: o
                    } = {}) => {
                        var n, s;
                        let l = await Q(o);
                        return M({
                            messages: A.current.concat({ ...e,
                                id: null != (n = e.id) ? n : y(),
                                createdAt: null != (s = e.createdAt) ? s : new Date,
                                experimental_attachments: l.length > 0 ? l : void 0,
                                parts: z(e)
                            }),
                            headers: r,
                            body: a,
                            data: t
                        })
                    }, [M, y]),
                    P = (0, i.useCallback)(async ({
                        data: e,
                        headers: t,
                        body: r
                    } = {}) => {
                        let a = A.current;
                        return 0 === a.length ? null : M({
                            messages: "assistant" === a[a.length - 1].role ? a.slice(0, -1) : a,
                            headers: t,
                            body: r,
                            data: e
                        })
                    }, [M]),
                    J = (0, i.useCallback)(() => {
                        F.current && (F.current.abort(), F.current = null)
                    }, []),
                    B = (0, i.useCallback)(e => {
                        "function" == typeof e && (e = e(A.current));
                        let t = H(e);
                        S(t, !1), A.current = t
                    }, [S]),
                    U = (0, i.useCallback)(e => {
                        "function" == typeof e && (e = e(N.current)), C(e, !1), N.current = e
                    }, [C]),
                    [Y, $] = (0, i.useState)(a),
                    W = (0, i.useCallback)(async (e, t = {}, r) => {
                        var a;
                        if (null == (a = null == e ? void 0 : e.preventDefault) || a.call(e), !Y && !t.allowEmptySubmit) return;
                        r && (j.current = { ...j.current,
                            ...r
                        });
                        let o = await Q(t.experimental_attachments);
                        M({
                            messages: A.current.concat({
                                id: y(),
                                createdAt: new Date,
                                role: "user",
                                content: Y,
                                experimental_attachments: o.length > 0 ? o : void 0,
                                parts: [{
                                    type: "text",
                                    text: Y
                                }]
                            }),
                            headers: t.headers,
                            body: t.body,
                            data: t.data
                        }), $("")
                    }, [Y, y, M]);
                return {
                    messages: null != T ? T : [],
                    id: v,
                    setMessages: B,
                    data: R,
                    setData: U,
                    error: D,
                    append: V,
                    reload: P,
                    stop: J,
                    input: Y,
                    setInput: $,
                    handleInputChange: e => {
                        $(e.target.value)
                    },
                    handleSubmit: W,
                    isLoading: "submitted" === x || "streaming" === x,
                    status: x,
                    addToolResult: (0, i.useCallback)(({
                        toolCallId: e,
                        result: t
                    }) => {
                        let r = A.current;
                        ! function({
                            messages: e,
                            toolCallId: t,
                            toolResult: r
                        }) {
                            var a;
                            let o = e[e.length - 1],
                                n = o.parts.find(e => "tool-invocation" === e.type && e.toolInvocation.toolCallId === t);
                            if (null == n) return;
                            let s = { ...n.toolInvocation,
                                state: "result",
                                result: r
                            };
                            n.toolInvocation = s, o.toolInvocations = null == (a = o.toolInvocations) ? void 0 : a.map(e => e.toolCallId === t ? s : e)
                        }({
                            messages: r,
                            toolCallId: e,
                            toolResult: t
                        }), S(r, !1), X(r[r.length - 1]) && M({
                            messages: r
                        })
                    }, [S, M])
                }
            }
        }
    }
]);