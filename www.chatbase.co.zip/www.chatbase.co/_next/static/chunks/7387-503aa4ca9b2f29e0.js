"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7387], {
        24349: function(e, t, n) {
            let r = n(2265),
                o = r.forwardRef(function(e, t) {
                    let {
                        title: n,
                        titleId: o,
                        ...c
                    } = e;
                    return r.createElement("svg", Object.assign({
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        strokeWidth: 1.5,
                        stroke: "currentColor",
                        "aria-hidden": "true",
                        ref: t,
                        "aria-labelledby": o
                    }, c), n ? r.createElement("title", {
                        id: o
                    }, n) : null, r.createElement("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        d: "M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99"
                    }))
                });
            e.exports = o
        },
        5008: function(e, t, n) {
            let r = n(2265),
                o = r.forwardRef(function(e, t) {
                    let {
                        title: n,
                        titleId: o,
                        ...c
                    } = e;
                    return r.createElement("svg", Object.assign({
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        strokeWidth: 1.5,
                        stroke: "currentColor",
                        "aria-hidden": "true",
                        ref: t,
                        "aria-labelledby": o
                    }, c), n ? r.createElement("title", {
                        id: o
                    }, n) : null, r.createElement("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        d: "M16.5 8.25V6a2.25 2.25 0 00-2.25-2.25H6A2.25 2.25 0 003.75 6v8.25A2.25 2.25 0 006 16.5h2.25m8.25-8.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-7.5A2.25 2.25 0 018.25 18v-1.5m8.25-8.25h-6a2.25 2.25 0 00-2.25 2.25v6"
                    }))
                });
            e.exports = o
        },
        83500: function(e, t, n) {
            let r = n(2265),
                o = r.forwardRef(function(e, t) {
                    let {
                        title: n,
                        titleId: o,
                        ...c
                    } = e;
                    return r.createElement("svg", Object.assign({
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        strokeWidth: 1.5,
                        stroke: "currentColor",
                        "aria-hidden": "true",
                        ref: t,
                        "aria-labelledby": o
                    }, c), n ? r.createElement("title", {
                        id: o
                    }, n) : null, r.createElement("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        d: "M6 18L18 6M6 6l12 12"
                    }))
                });
            e.exports = o
        },
        7405: function(e, t, n) {
            let r = n(2265),
                o = r.forwardRef(function(e, t) {
                    let {
                        title: n,
                        titleId: o,
                        ...c
                    } = e;
                    return r.createElement("svg", Object.assign({
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 24 24",
                        fill: "currentColor",
                        "aria-hidden": "true",
                        ref: t,
                        "aria-labelledby": o
                    }, c), n ? r.createElement("title", {
                        id: o
                    }, n) : null, r.createElement("path", {
                        fillRule: "evenodd",
                        d: "M19.916 4.626a.75.75 0 01.208 1.04l-9 13.5a.75.75 0 01-1.154.114l-6-6a.75.75 0 011.06-1.06l5.353 5.353 8.493-12.739a.75.75 0 011.04-.208z",
                        clipRule: "evenodd"
                    }))
                });
            e.exports = o
        },
        59036: function(e, t, n) {
            let r = n(2265),
                o = r.forwardRef(function(e, t) {
                    let {
                        title: n,
                        titleId: o,
                        ...c
                    } = e;
                    return r.createElement("svg", Object.assign({
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 24 24",
                        fill: "currentColor",
                        "aria-hidden": "true",
                        ref: t,
                        "aria-labelledby": o
                    }, c), n ? r.createElement("title", {
                        id: o
                    }, n) : null, r.createElement("path", {
                        d: "M3.478 2.405a.75.75 0 00-.926.94l2.432 7.905H13.5a.75.75 0 010 1.5H4.984l-2.432 7.905a.75.75 0 00.926.94 60.519 60.519 0 0018.445-8.986.75.75 0 000-1.218A60.517 60.517 0 003.478 2.405z"
                    }))
                });
            e.exports = o
        },
        10306: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("AudioLines", [
                ["path", {
                    d: "M2 10v3",
                    key: "1fnikh"
                }],
                ["path", {
                    d: "M6 6v11",
                    key: "11sgs0"
                }],
                ["path", {
                    d: "M10 3v18",
                    key: "yhl04a"
                }],
                ["path", {
                    d: "M14 8v7",
                    key: "3a1oy3"
                }],
                ["path", {
                    d: "M18 5v13",
                    key: "123xd1"
                }],
                ["path", {
                    d: "M22 10v3",
                    key: "154ddg"
                }]
            ])
        },
        40875: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("ChevronDown", [
                ["path", {
                    d: "m6 9 6 6 6-6",
                    key: "qrunsl"
                }]
            ])
        },
        64719: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("Keyboard", [
                ["path", {
                    d: "M10 8h.01",
                    key: "1r9ogq"
                }],
                ["path", {
                    d: "M12 12h.01",
                    key: "1mp3jc"
                }],
                ["path", {
                    d: "M14 8h.01",
                    key: "1primd"
                }],
                ["path", {
                    d: "M16 12h.01",
                    key: "1l6xoz"
                }],
                ["path", {
                    d: "M18 8h.01",
                    key: "emo2bl"
                }],
                ["path", {
                    d: "M6 8h.01",
                    key: "x9i8wu"
                }],
                ["path", {
                    d: "M7 16h10",
                    key: "wp8him"
                }],
                ["path", {
                    d: "M8 12h.01",
                    key: "czm47f"
                }],
                ["rect", {
                    width: "20",
                    height: "16",
                    x: "2",
                    y: "4",
                    rx: "2",
                    key: "18n3k1"
                }]
            ])
        },
        60730: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("MicOff", [
                ["line", {
                    x1: "2",
                    x2: "22",
                    y1: "2",
                    y2: "22",
                    key: "a6p6uj"
                }],
                ["path", {
                    d: "M18.89 13.23A7.12 7.12 0 0 0 19 12v-2",
                    key: "80xlxr"
                }],
                ["path", {
                    d: "M5 10v2a7 7 0 0 0 12 5",
                    key: "p2k8kg"
                }],
                ["path", {
                    d: "M15 9.34V5a3 3 0 0 0-5.68-1.33",
                    key: "1gzdoj"
                }],
                ["path", {
                    d: "M9 9v3a3 3 0 0 0 5.12 2.12",
                    key: "r2i35w"
                }],
                ["line", {
                    x1: "12",
                    x2: "12",
                    y1: "19",
                    y2: "22",
                    key: "x3vr5v"
                }]
            ])
        },
        48662: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("Mic", [
                ["path", {
                    d: "M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z",
                    key: "131961"
                }],
                ["path", {
                    d: "M19 10v2a7 7 0 0 1-14 0v-2",
                    key: "1vc78b"
                }],
                ["line", {
                    x1: "12",
                    x2: "12",
                    y1: "19",
                    y2: "22",
                    key: "x3vr5v"
                }]
            ])
        },
        99397: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("Plus", [
                ["path", {
                    d: "M5 12h14",
                    key: "1ays0h"
                }],
                ["path", {
                    d: "M12 5v14",
                    key: "s699le"
                }]
            ])
        },
        69076: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("RotateCcw", [
                ["path", {
                    d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",
                    key: "1357e3"
                }],
                ["path", {
                    d: "M3 3v5h5",
                    key: "1xhq8a"
                }]
            ])
        },
        2208: function(e, t, n) {
            t.ZP = void 0;
            var r = n(14273);
            Object.defineProperty(t, "ZP", {
                enumerable: !0,
                get: function() {
                    return r.useWebSocket
                }
            }), n(28433), n(29015), n(88720), n(83420)
        },
        68761: function(e, t, n) {
            var r = this && this.__assign || function() {
                return (r = Object.assign || function(e) {
                    for (var t, n = 1, r = arguments.length; n < r; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }).apply(this, arguments)
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.attachListeners = void 0;
            var o = n(19174),
                c = n(87075),
                a = n(29015),
                u = n(83420),
                s = function(e, t, n, r) {
                    e.onmessage = function(e) {
                        var o;
                        t.current.onMessage && t.current.onMessage(e), "number" == typeof(null == r ? void 0 : r.current) && (r.current = Date.now()), "function" == typeof t.current.filter && !0 !== t.current.filter(e) || t.current.heartbeat && "boolean" != typeof t.current.heartbeat && (null === (o = t.current.heartbeat) || void 0 === o ? void 0 : o.returnMessage) === e.data || n(e)
                    }
                },
                i = function(e, t, n, r, o) {
                    e.onopen = function(u) {
                        if (t.current.onOpen && t.current.onOpen(u), r.current = 0, n(a.ReadyState.OPEN), t.current.heartbeat && e instanceof WebSocket) {
                            var s = "boolean" == typeof t.current.heartbeat ? void 0 : t.current.heartbeat;
                            o.current = Date.now(), (0, c.heartbeat)(e, o, s)
                        }
                    }
                },
                l = function(e, t, n, r, o) {
                    var c;
                    return a.isEventSourceSupported && e instanceof EventSource ? function() {} : ((0, u.assertIsWebSocket)(e, t.current.skipAssert), e.onclose = function(e) {
                        var u;
                        if (t.current.onClose && t.current.onClose(e), n(a.ReadyState.CLOSED), t.current.shouldReconnect && t.current.shouldReconnect(e)) {
                            var s = null !== (u = t.current.reconnectAttempts) && void 0 !== u ? u : a.DEFAULT_RECONNECT_LIMIT;
                            if (o.current < s) {
                                var i = "function" == typeof t.current.reconnectInterval ? t.current.reconnectInterval(o.current) : t.current.reconnectInterval;
                                c = window.setTimeout(function() {
                                    o.current++, r()
                                }, null != i ? i : a.DEFAULT_RECONNECT_INTERVAL_MS)
                            } else t.current.onReconnectStop && t.current.onReconnectStop(s), console.warn("Max reconnect attempts of ".concat(s, " exceeded"))
                        }
                    }, function() {
                        return c && window.clearTimeout(c)
                    })
                },
                f = function(e, t, n, o, c) {
                    var u;
                    return e.onerror = function(s) {
                            var i;
                            if (t.current.onError && t.current.onError(s), a.isEventSourceSupported && e instanceof EventSource && (t.current.onClose && t.current.onClose(r(r({}, s), {
                                    code: 1006,
                                    reason: "An error occurred with the EventSource: ".concat(s),
                                    wasClean: !1
                                })), n(a.ReadyState.CLOSED), e.close()), t.current.retryOnError) {
                                if (c.current < (null !== (i = t.current.reconnectAttempts) && void 0 !== i ? i : a.DEFAULT_RECONNECT_LIMIT)) {
                                    var l = "function" == typeof t.current.reconnectInterval ? t.current.reconnectInterval(c.current) : t.current.reconnectInterval;
                                    u = window.setTimeout(function() {
                                        c.current++, o()
                                    }, null != l ? l : a.DEFAULT_RECONNECT_INTERVAL_MS)
                                } else t.current.onReconnectStop && t.current.onReconnectStop(t.current.reconnectAttempts), console.warn("Max reconnect attempts of ".concat(t.current.reconnectAttempts, " exceeded"))
                            }
                        },
                        function() {
                            return u && window.clearTimeout(u)
                        }
                };
            t.attachListeners = function(e, t, n, r, c, u, d) {
                var p, v, h, S = t.setLastMessage,
                    b = t.setReadyState;
                return n.current.fromSocketIO && (p = (0, o.setUpSocketIOPing)(d)), s(e, n, S, u), i(e, n, b, c, u), v = l(e, n, b, r, c), h = f(e, n, b, r, c),
                    function() {
                        b(a.ReadyState.CLOSING), v(), h(), e.close(), p && clearInterval(p)
                    }
            }
        },
        90657: function(e, t, n) {
            var r = this && this.__assign || function() {
                return (r = Object.assign || function(e) {
                    for (var t, n = 1, r = arguments.length; n < r; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }).apply(this, arguments)
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.attachSharedListeners = void 0;
            var o = n(31677),
                c = n(29015),
                a = n(69366),
                u = n(19174),
                s = n(87075),
                i = function(e, t, n) {
                    e.onmessage = function(e) {
                        (0, a.getSubscribers)(t).forEach(function(t) {
                            var r;
                            t.optionsRef.current.onMessage && t.optionsRef.current.onMessage(e), "number" == typeof(null === (r = null == t ? void 0 : t.lastMessageTime) || void 0 === r ? void 0 : r.current) && (t.lastMessageTime.current = Date.now()), ("function" != typeof t.optionsRef.current.filter || !0 === t.optionsRef.current.filter(e)) && (n && "boolean" != typeof n && (null == n ? void 0 : n.returnMessage) === e.data || t.setLastMessage(e))
                        })
                    }
                },
                l = function(e, t, n) {
                    e.onopen = function(r) {
                        (0, a.getSubscribers)(t).forEach(function(t) {
                            t.reconnectCount.current = 0, t.optionsRef.current.onOpen && t.optionsRef.current.onOpen(r), t.setReadyState(c.ReadyState.OPEN), n && e instanceof WebSocket && (t.lastMessageTime.current = Date.now(), (0, s.heartbeat)(e, t.lastMessageTime, "boolean" == typeof n ? void 0 : n))
                        })
                    }
                },
                f = function(e, t) {
                    e instanceof WebSocket && (e.onclose = function(e) {
                        (0, a.getSubscribers)(t).forEach(function(t) {
                            t.optionsRef.current.onClose && t.optionsRef.current.onClose(e), t.setReadyState(c.ReadyState.CLOSED)
                        }), delete o.sharedWebSockets[t], (0, a.getSubscribers)(t).forEach(function(t) {
                            var n;
                            if (t.optionsRef.current.shouldReconnect && t.optionsRef.current.shouldReconnect(e)) {
                                var r = null !== (n = t.optionsRef.current.reconnectAttempts) && void 0 !== n ? n : c.DEFAULT_RECONNECT_LIMIT;
                                if (t.reconnectCount.current < r) {
                                    var o = "function" == typeof t.optionsRef.current.reconnectInterval ? t.optionsRef.current.reconnectInterval(t.reconnectCount.current) : t.optionsRef.current.reconnectInterval;
                                    setTimeout(function() {
                                        t.reconnectCount.current++, t.reconnect.current()
                                    }, null != o ? o : c.DEFAULT_RECONNECT_INTERVAL_MS)
                                } else t.optionsRef.current.onReconnectStop && t.optionsRef.current.onReconnectStop(t.optionsRef.current.reconnectAttempts), console.warn("Max reconnect attempts of ".concat(r, " exceeded"))
                            }
                        })
                    })
                },
                d = function(e, t) {
                    e.onerror = function(n) {
                        (0, a.getSubscribers)(t).forEach(function(t) {
                            t.optionsRef.current.onError && t.optionsRef.current.onError(n), c.isEventSourceSupported && e instanceof EventSource && (t.optionsRef.current.onClose && t.optionsRef.current.onClose(r(r({}, n), {
                                code: 1006,
                                reason: "An error occurred with the EventSource: ".concat(n),
                                wasClean: !1
                            })), t.setReadyState(c.ReadyState.CLOSED))
                        }), c.isEventSourceSupported && e instanceof EventSource && e.close()
                    }
                };
            t.attachSharedListeners = function(e, t, n, r) {
                var o;
                return n.current.fromSocketIO && (o = (0, u.setUpSocketIOPing)(r)), i(e, t, n.current.heartbeat), f(e, t), l(e, t, n.current.heartbeat), d(e, t),
                    function() {
                        o && clearInterval(o)
                    }
            }
        },
        29015: function(e, t) {
            var n, r;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.isEventSourceSupported = t.isReactNative = t.ReadyState = t.DEFAULT_HEARTBEAT = t.UNPARSABLE_JSON_OBJECT = t.DEFAULT_RECONNECT_INTERVAL_MS = t.DEFAULT_RECONNECT_LIMIT = t.SOCKET_IO_PING_CODE = t.SOCKET_IO_PATH = t.SOCKET_IO_PING_INTERVAL = t.DEFAULT_EVENT_SOURCE_OPTIONS = t.EMPTY_EVENT_HANDLERS = t.DEFAULT_OPTIONS = void 0, t.DEFAULT_OPTIONS = {}, t.EMPTY_EVENT_HANDLERS = {}, t.DEFAULT_EVENT_SOURCE_OPTIONS = {
                withCredentials: !1,
                events: t.EMPTY_EVENT_HANDLERS
            }, t.SOCKET_IO_PING_INTERVAL = 25e3, t.SOCKET_IO_PATH = "/socket.io/?EIO=3&transport=websocket", t.SOCKET_IO_PING_CODE = "2", t.DEFAULT_RECONNECT_LIMIT = 20, t.DEFAULT_RECONNECT_INTERVAL_MS = 5e3, t.UNPARSABLE_JSON_OBJECT = {}, t.DEFAULT_HEARTBEAT = {
                message: "ping",
                timeout: 6e4,
                interval: 25e3
            }, (r = n || (t.ReadyState = n = {}))[r.UNINSTANTIATED = -1] = "UNINSTANTIATED", r[r.CONNECTING = 0] = "CONNECTING", r[r.OPEN = 1] = "OPEN", r[r.CLOSING = 2] = "CLOSING", r[r.CLOSED = 3] = "CLOSED", t.isReactNative = "undefined" != typeof navigator && "ReactNative" === navigator.product, t.isEventSourceSupported = !t.isReactNative && function() {
                try {
                    return "EventSource" in globalThis
                } catch (e) {
                    return !1
                }
            }()
        },
        22057: function(e, t, n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.createOrJoinSocket = void 0;
            var r = n(31677),
                o = n(29015),
                c = n(68761),
                a = n(90657),
                u = n(69366);
            t.createOrJoinSocket = function(e, t, n, s, i, l, f, d, p) {
                if (!o.isEventSourceSupported && s.current.eventSourceOptions) {
                    if (o.isReactNative) throw Error("EventSource is not supported in ReactNative");
                    throw Error("EventSource is not supported")
                }
                if (s.current.share) {
                    var v, h = null;
                    void 0 === r.sharedWebSockets[t] ? (r.sharedWebSockets[t] = s.current.eventSourceOptions ? new EventSource(t, s.current.eventSourceOptions) : new WebSocket(t, s.current.protocols), e.current = r.sharedWebSockets[t], n(o.ReadyState.CONNECTING), h = (0, a.attachSharedListeners)(r.sharedWebSockets[t], t, s, p)) : (e.current = r.sharedWebSockets[t], n(r.sharedWebSockets[t].readyState));
                    var S = {
                        setLastMessage: i,
                        setReadyState: n,
                        optionsRef: s,
                        reconnectCount: f,
                        lastMessageTime: d,
                        reconnect: l
                    };
                    return (0, u.addSubscriber)(t, S), v = h,
                        function() {
                            if ((0, u.removeSubscriber)(t, S), !(0, u.hasSubscribers)(t)) {
                                try {
                                    var e = r.sharedWebSockets[t];
                                    e instanceof WebSocket && (e.onclose = function(e) {
                                        s.current.onClose && s.current.onClose(e), n(o.ReadyState.CLOSED)
                                    }), e.close()
                                } catch (e) {}
                                v && v(), delete r.sharedWebSockets[t]
                            }
                        }
                }
                if (e.current = s.current.eventSourceOptions ? new EventSource(t, s.current.eventSourceOptions) : new WebSocket(t, s.current.protocols), n(o.ReadyState.CONNECTING), !e.current) throw Error("WebSocket failed to be created");
                return (0, c.attachListeners)(e.current, {
                    setLastMessage: i,
                    setReadyState: n
                }, s, l.current, f, d, p)
            }
        },
        87186: function(e, t, n) {
            var r = this && this.__awaiter || function(e, t, n, r) {
                    return new(n || (n = Promise))(function(o, c) {
                        function a(e) {
                            try {
                                s(r.next(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function u(e) {
                            try {
                                s(r.throw(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function s(e) {
                            var t;
                            e.done ? o(e.value) : ((t = e.value) instanceof n ? t : new n(function(e) {
                                e(t)
                            })).then(a, u)
                        }
                        s((r = r.apply(e, t || [])).next())
                    })
                },
                o = this && this.__generator || function(e, t) {
                    var n, r, o, c = {
                            label: 0,
                            sent: function() {
                                if (1 & o[0]) throw o[1];
                                return o[1]
                            },
                            trys: [],
                            ops: []
                        },
                        a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                    return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                        return this
                    }), a;

                    function u(u) {
                        return function(s) {
                            return function(u) {
                                if (n) throw TypeError("Generator is already executing.");
                                for (; a && (a = 0, u[0] && (c = 0)), c;) try {
                                    if (n = 1, r && (o = 2 & u[0] ? r.return : u[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, u[1])).done) return o;
                                    switch (r = 0, o && (u = [2 & u[0], o.value]), u[0]) {
                                        case 0:
                                        case 1:
                                            o = u;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: u[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, r = u[1], u = [0];
                                            continue;
                                        case 7:
                                            u = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = (o = c.trys).length > 0 && o[o.length - 1]) && (6 === u[0] || 2 === u[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === u[0] && (!o || u[1] > o[0] && u[1] < o[3])) {
                                                c.label = u[1];
                                                break
                                            }
                                            if (6 === u[0] && c.label < o[1]) {
                                                c.label = o[1], o = u;
                                                break
                                            }
                                            if (o && c.label < o[2]) {
                                                c.label = o[2], c.ops.push(u);
                                                break
                                            }
                                            o[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    u = t.call(e, c)
                                } catch (e) {
                                    u = [6, e], r = 0
                                } finally {
                                    n = o = 0
                                }
                                if (5 & u[0]) throw u[1];
                                return {
                                    value: u[0] ? u[1] : void 0,
                                    done: !0
                                }
                            }([u, s])
                        }
                    }
                },
                c = this && this.__spreadArray || function(e, t, n) {
                    if (n || 2 == arguments.length)
                        for (var r, o = 0, c = t.length; o < c; o++) !r && o in t || (r || (r = Array.prototype.slice.call(t, 0, o)), r[o] = t[o]);
                    return e.concat(r || Array.prototype.slice.call(t))
                };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.getUrl = void 0;
            var a = n(19174),
                u = n(29015);
            t.getUrl = function(e, n) {
                for (var s = [], i = 2; i < arguments.length; i++) s[i - 2] = arguments[i];
                return r(void 0, c([e, n], s, !0), void 0, function(e, n, r) {
                    var c, s, i, l, f, d, p;
                    return void 0 === r && (r = 0), o(this, function(o) {
                        switch (o.label) {
                            case 0:
                                if ("function" != typeof e) return [3, 10];
                                o.label = 1;
                            case 1:
                                return o.trys.push([1, 3, , 9]), [4, e()];
                            case 2:
                                return c = o.sent(), [3, 9];
                            case 3:
                                var v;
                                if (o.sent(), !n.current.retryOnError) return [3, 7];
                                if (s = null !== (f = n.current.reconnectAttempts) && void 0 !== f ? f : u.DEFAULT_RECONNECT_LIMIT, !(r < s)) return [3, 5];
                                return [4, (v = null != (i = "function" == typeof n.current.reconnectInterval ? n.current.reconnectInterval(r) : n.current.reconnectInterval) ? i : u.DEFAULT_RECONNECT_INTERVAL_MS, new Promise(function(e) {
                                    return window.setTimeout(e, v)
                                }))];
                            case 4:
                                return o.sent(), [2, (0, t.getUrl)(e, n, r + 1)];
                            case 5:
                                return null === (p = (d = n.current).onReconnectStop) || void 0 === p || p.call(d, r), [2, null];
                            case 6:
                                return [3, 8];
                            case 7:
                                return [2, null];
                            case 8:
                                return [3, 9];
                            case 9:
                                return [3, 11];
                            case 10:
                                c = e, o.label = 11;
                            case 11:
                                return l = n.current.fromSocketIO ? (0, a.parseSocketIOUrl)(c) : c, [2, n.current.queryParams ? (0, a.appendQueryParams)(l, n.current.queryParams) : l]
                        }
                    })
                })
            }
        },
        31677: function(e, t) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.resetWebSockets = t.sharedWebSockets = void 0, t.sharedWebSockets = {}, t.resetWebSockets = function(e) {
                if (e && t.sharedWebSockets.hasOwnProperty(e)) delete t.sharedWebSockets[e];
                else
                    for (var n in t.sharedWebSockets) t.sharedWebSockets.hasOwnProperty(n) && delete t.sharedWebSockets[n]
            }
        },
        87075: function(e, t, n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.heartbeat = function(e, t, n) {
                var o = n || {},
                    c = o.interval,
                    a = void 0 === c ? r.DEFAULT_HEARTBEAT.interval : c,
                    u = o.timeout,
                    s = void 0 === u ? r.DEFAULT_HEARTBEAT.timeout : u,
                    i = o.message,
                    l = void 0 === i ? r.DEFAULT_HEARTBEAT.message : i,
                    f = setInterval(function() {
                        if (t.current + s <= Date.now()) console.warn("Heartbeat timed out, closing connection, last message was seen ".concat(Date.now() - t.current, "ms ago")), e.close();
                        else if (t.current + a <= Date.now()) try {
                            "function" == typeof l ? e.send(l()) : e.send(l)
                        } catch (t) {
                            console.error("Heartbeat failed, closing connection", t instanceof Error ? t.message : t), e.close()
                        }
                    }, a);
                return e.addEventListener("close", function() {
                        clearInterval(f)
                    }),
                    function() {}
            };
            var r = n(29015)
        },
        69366: function(e, t) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.resetSubscribers = t.removeSubscriber = t.addSubscriber = t.hasSubscribers = t.getSubscribers = void 0;
            var n = {},
                r = [];
            t.getSubscribers = function(e) {
                return (0, t.hasSubscribers)(e) ? Array.from(n[e]) : r
            }, t.hasSubscribers = function(e) {
                var t;
                return (null === (t = n[e]) || void 0 === t ? void 0 : t.size) > 0
            }, t.addSubscriber = function(e, t) {
                n[e] = n[e] || new Set, n[e].add(t)
            }, t.removeSubscriber = function(e, t) {
                n[e].delete(t)
            }, t.resetSubscribers = function(e) {
                if (e && n.hasOwnProperty(e)) delete n[e];
                else
                    for (var t in n) n.hasOwnProperty(t) && delete n[t]
            }
        },
        96116: function(e, t) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.websocketWrapper = void 0, t.websocketWrapper = function(e, t) {
                return new Proxy(e, {
                    get: function(e, n) {
                        var r = e[n];
                        return "reconnect" === n ? t : "function" == typeof r ? (console.error("Calling methods directly on the websocket is not supported at this moment. You must use the methods returned by useWebSocket."), function() {}) : r
                    },
                    set: function(e, t, n) {
                        return /^on/.test(t) ? (console.warn("The websocket's event handlers should be defined through the options object passed into useWebSocket."), !1) : (e[t] = n, !0)
                    }
                })
            }, t.default = t.websocketWrapper
        },
        19174: function(e, t, n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.setUpSocketIOPing = t.appendQueryParams = t.parseSocketIOUrl = void 0;
            var r = n(29015);
            t.parseSocketIOUrl = function(e) {
                if (e) {
                    var t = /^https|wss/.test(e),
                        n = e.replace(/^(https?|wss?)(:\/\/)?/, "").replace(/\/$/, ""),
                        o = t ? "wss" : "ws";
                    return "".concat(o, "://").concat(n).concat(r.SOCKET_IO_PATH)
                }
                if ("" === e) {
                    var t = /^https/.test(window.location.protocol),
                        o = t ? "wss" : "ws",
                        c = window.location.port ? ":".concat(window.location.port) : "";
                    return "".concat(o, "://").concat(window.location.hostname).concat(c).concat(r.SOCKET_IO_PATH)
                }
                return e
            }, t.appendQueryParams = function(e, t) {
                void 0 === t && (t = {});
                var n = /\?([\w]+=[\w]+)/.test(e),
                    r = "".concat(Object.entries(t).reduce(function(e, t) {
                        var n = t[0],
                            r = t[1];
                        return e + "".concat(n, "=").concat(r, "&")
                    }, "").slice(0, -1));
                return "".concat(e).concat(n ? "&" : "?").concat(r)
            }, t.setUpSocketIOPing = function(e, t) {
                return void 0 === t && (t = r.SOCKET_IO_PING_INTERVAL), window.setInterval(function() {
                    return e(r.SOCKET_IO_PING_CODE)
                }, t)
            }
        },
        88720: function(e, t, n) {
            var r = this && this.__assign || function() {
                    return (r = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }).apply(this, arguments)
                },
                o = this && this.__rest || function(e, t) {
                    var n = {};
                    for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && 0 > t.indexOf(r) && (n[r] = e[r]);
                    if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                        for (var o = 0, r = Object.getOwnPropertySymbols(e); o < r.length; o++) 0 > t.indexOf(r[o]) && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (n[r[o]] = e[r[o]]);
                    return n
                };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.useEventSource = void 0;
            var c = n(2265),
                a = n(14273),
                u = n(29015);
            t.useEventSource = function(e, t, n) {
                void 0 === t && (t = u.DEFAULT_EVENT_SOURCE_OPTIONS);
                var s = t.withCredentials,
                    i = t.events,
                    l = o(t, ["withCredentials", "events"]);
                void 0 === n && (n = !0);
                var f = r(r({}, l), {
                        eventSourceOptions: {
                            withCredentials: s
                        }
                    }),
                    d = (0, c.useRef)(u.EMPTY_EVENT_HANDLERS);
                i && (d.current = i);
                var p = (0, a.useWebSocket)(e, f, n),
                    v = p.lastMessage,
                    h = p.readyState,
                    S = p.getWebSocket;
                return (0, c.useEffect)(function() {
                    (null == v ? void 0 : v.type) && Object.entries(d.current).forEach(function(e) {
                        var t = e[0],
                            n = e[1];
                        t === v.type && n(v)
                    })
                }, [v]), {
                    lastEvent: v,
                    readyState: h,
                    getEventSource: S
                }
            }
        },
        28433: function(e, t, n) {
            var r = this && this.__assign || function() {
                return (r = Object.assign || function(e) {
                    for (var t, n = 1, r = arguments.length; n < r; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }).apply(this, arguments)
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.useSocketIO = void 0;
            var o = n(2265),
                c = n(14273),
                a = n(29015),
                u = {
                    type: "empty",
                    payload: null
                },
                s = function(e) {
                    if (!e || !e.data) return u;
                    var t = e.data.match(/\[.*]/);
                    if (!t) return u;
                    var n = JSON.parse(t);
                    return Array.isArray(n) && n[1] ? {
                        type: n[0],
                        payload: n[1]
                    } : u
                };
            t.useSocketIO = function(e, t, n) {
                void 0 === t && (t = a.DEFAULT_OPTIONS), void 0 === n && (n = !0);
                var u = (0, o.useMemo)(function() {
                        return r(r({}, t), {
                            fromSocketIO: !0
                        })
                    }, []),
                    i = (0, c.useWebSocket)(e, u, n),
                    l = i.sendMessage,
                    f = i.sendJsonMessage,
                    d = i.lastMessage,
                    p = i.readyState,
                    v = i.getWebSocket,
                    h = (0, o.useMemo)(function() {
                        return s(d)
                    }, [d]);
                return {
                    sendMessage: l,
                    sendJsonMessage: f,
                    lastMessage: h,
                    lastJsonMessage: h,
                    readyState: p,
                    getWebSocket: v
                }
            }
        },
        14273: function(e, t, n) {
            var r = this && this.__assign || function() {
                    return (r = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }).apply(this, arguments)
                },
                o = this && this.__awaiter || function(e, t, n, r) {
                    return new(n || (n = Promise))(function(o, c) {
                        function a(e) {
                            try {
                                s(r.next(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function u(e) {
                            try {
                                s(r.throw(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function s(e) {
                            var t;
                            e.done ? o(e.value) : ((t = e.value) instanceof n ? t : new n(function(e) {
                                e(t)
                            })).then(a, u)
                        }
                        s((r = r.apply(e, t || [])).next())
                    })
                },
                c = this && this.__generator || function(e, t) {
                    var n, r, o, c = {
                            label: 0,
                            sent: function() {
                                if (1 & o[0]) throw o[1];
                                return o[1]
                            },
                            trys: [],
                            ops: []
                        },
                        a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                    return a.next = u(0), a.throw = u(1), a.return = u(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                        return this
                    }), a;

                    function u(u) {
                        return function(s) {
                            return function(u) {
                                if (n) throw TypeError("Generator is already executing.");
                                for (; a && (a = 0, u[0] && (c = 0)), c;) try {
                                    if (n = 1, r && (o = 2 & u[0] ? r.return : u[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, u[1])).done) return o;
                                    switch (r = 0, o && (u = [2 & u[0], o.value]), u[0]) {
                                        case 0:
                                        case 1:
                                            o = u;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: u[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, r = u[1], u = [0];
                                            continue;
                                        case 7:
                                            u = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = (o = c.trys).length > 0 && o[o.length - 1]) && (6 === u[0] || 2 === u[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === u[0] && (!o || u[1] > o[0] && u[1] < o[3])) {
                                                c.label = u[1];
                                                break
                                            }
                                            if (6 === u[0] && c.label < o[1]) {
                                                c.label = o[1], o = u;
                                                break
                                            }
                                            if (o && c.label < o[2]) {
                                                c.label = o[2], c.ops.push(u);
                                                break
                                            }
                                            o[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    u = t.call(e, c)
                                } catch (e) {
                                    u = [6, e], r = 0
                                } finally {
                                    n = o = 0
                                }
                                if (5 & u[0]) throw u[1];
                                return {
                                    value: u[0] ? u[1] : void 0,
                                    done: !0
                                }
                            }([u, s])
                        }
                    }
                },
                a = this && this.__importDefault || function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.useWebSocket = void 0;
            var u = n(2265),
                s = n(54887),
                i = n(29015),
                l = n(22057),
                f = n(87186),
                d = a(n(96116)),
                p = n(83420);
            t.useWebSocket = function(e, t, n) {
                void 0 === t && (t = i.DEFAULT_OPTIONS), void 0 === n && (n = !0);
                var a = (0, u.useState)(null),
                    v = a[0],
                    h = a[1],
                    S = (0, u.useState)({}),
                    b = S[0],
                    E = S[1],
                    y = (0, u.useMemo)(function() {
                        if (v) try {
                            return JSON.parse(v.data)
                        } catch (e) {
                            return i.UNPARSABLE_JSON_OBJECT
                        }
                        return null
                    }, [v]),
                    O = (0, u.useRef)(null),
                    _ = (0, u.useRef)(null),
                    w = (0, u.useRef)(function() {}),
                    k = (0, u.useRef)(0),
                    T = (0, u.useRef)(Date.now()),
                    g = (0, u.useRef)([]),
                    R = (0, u.useRef)(null),
                    N = (0, u.useRef)(t);
                N.current = t;
                var m = O.current && void 0 !== b[O.current] ? b[O.current] : null !== e && !0 === n ? i.ReadyState.CONNECTING : i.ReadyState.UNINSTANTIATED,
                    C = t.queryParams ? JSON.stringify(t.queryParams) : null,
                    I = (0, u.useCallback)(function(e, t) {
                        var n;
                        if (void 0 === t && (t = !0), i.isEventSourceSupported && _.current instanceof EventSource) {
                            console.warn("Unable to send a message from an eventSource");
                            return
                        }(null === (n = _.current) || void 0 === n ? void 0 : n.readyState) === i.ReadyState.OPEN ? ((0, p.assertIsWebSocket)(_.current, N.current.skipAssert), _.current.send(e)) : t && g.current.push(e)
                    }, []),
                    M = (0, u.useCallback)(function(e, t) {
                        void 0 === t && (t = !0), I(JSON.stringify(e), t)
                    }, [I]),
                    A = (0, u.useCallback)(function() {
                        return !0 !== N.current.share || i.isEventSourceSupported && _.current instanceof EventSource ? _.current : (null === R.current && _.current && ((0, p.assertIsWebSocket)(_.current, N.current.skipAssert), R.current = (0, d.default)(_.current, w)), R.current)
                    }, []);
                return (0, u.useEffect)(function() {
                    if (null !== e && !0 === n) {
                        var t, a = !1,
                            u = !0,
                            d = function() {
                                return o(void 0, void 0, void 0, function() {
                                    var n, o, d;
                                    return c(this, function(c) {
                                        switch (c.label) {
                                            case 0:
                                                return n = O, [4, (0, f.getUrl)(e, N)];
                                            case 1:
                                                if (n.current = c.sent(), null === O.current) return console.error("Failed to get a valid URL. WebSocket connection aborted."), O.current = "ABORTED", (0, s.flushSync)(function() {
                                                    return E(function(e) {
                                                        return r(r({}, e), {
                                                            ABORTED: i.ReadyState.CLOSED
                                                        })
                                                    })
                                                }), [2];
                                                return o = function(e) {
                                                    a || (0, s.flushSync)(function() {
                                                        return h(e)
                                                    })
                                                }, d = function(e) {
                                                    a || (0, s.flushSync)(function() {
                                                        return E(function(t) {
                                                            var n;
                                                            return r(r({}, t), O.current && ((n = {})[O.current] = e, n))
                                                        })
                                                    })
                                                }, u && (t = (0, l.createOrJoinSocket)(_, O.current, d, N, o, w, k, T, I)), [2]
                                        }
                                    })
                                })
                            };
                        return w.current = function() {
                                a || (R.current && (R.current = null), null == t || t(), d())
                            }, d(),
                            function() {
                                a = !0, u = !1, R.current && (R.current = null), null == t || t(), h(null)
                            }
                    }(null === e || !1 === n) && (k.current = 0, E(function(e) {
                        var t;
                        return r(r({}, e), O.current && ((t = {})[O.current] = i.ReadyState.CLOSED, t))
                    }))
                }, [e, n, C, I]), (0, u.useEffect)(function() {
                    m === i.ReadyState.OPEN && g.current.splice(0).forEach(function(e) {
                        I(e)
                    })
                }, [m]), {
                    sendMessage: I,
                    sendJsonMessage: M,
                    lastMessage: v,
                    lastJsonMessage: y,
                    readyState: m,
                    getWebSocket: A
                }
            }
        },
        83420: function(e, t, n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.assertIsWebSocket = function(e, t) {
                if (!t && e instanceof WebSocket == !1) throw Error("")
            }, t.resetGlobalState = function(e) {
                (0, o.resetSubscribers)(e), (0, r.resetWebSockets)(e)
            };
            var r = n(31677),
                o = n(69366)
        }
    }
]);