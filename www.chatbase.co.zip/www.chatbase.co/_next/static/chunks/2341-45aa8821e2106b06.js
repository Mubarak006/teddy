"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2341], {
        71989: function(e, t, n) {
            n.d(t, {
                Gv: function() {
                    return l
                },
                K3: function() {
                    return c
                },
                Vc: function() {
                    return r
                },
                nQ: function() {
                    return i
                }
            });
            var a = n(31229);
            let r = a.z.object({
                    shop: a.z.object({
                        myshopifyDomain: a.z.string(),
                        currencyCode: a.z.string()
                    }),
                    products: a.z.object({
                        edges: a.z.array(a.z.object({
                            node: a.z.object({
                                title: a.z.string(),
                                description: a.z.string(),
                                productType: a.z.string(),
                                handle: a.z.string(),
                                tags: a.z.array(a.z.string()),
                                vendor: a.z.string(),
                                status: a.z.string(),
                                variants: a.z.object({
                                    edges: a.z.array(a.z.object({
                                        node: a.z.object({
                                            title: a.z.string(),
                                            price: a.z.string()
                                        })
                                    }))
                                }),
                                images: a.z.object({
                                    edges: a.z.array(a.z.object({
                                        node: a.z.object({
                                            originalSrc: a.z.string(),
                                            altText: a.z.string().optional()
                                        })
                                    }))
                                })
                            })
                        }))
                    })
                }).transform(e => ({
                    shop: e.shop,
                    products: e.products.edges.map(e => {
                        let t = e.node;
                        return {
                            title: t.title,
                            description: t.description,
                            productType: t.productType,
                            handle: t.handle,
                            tags: t.tags,
                            vendor: t.vendor,
                            status: t.status,
                            variants: t.variants.edges.map(e => ({
                                title: e.node.title,
                                price: e.node.price
                            })),
                            image: t.images.edges.length > 0 ? {
                                originalSrc: t.images.edges[0].node.originalSrc,
                                altText: t.images.edges[0].node.altText
                            } : null
                        }
                    })
                })),
                i = a.z.object({
                    shop: a.z.object({
                        myshopifyDomain: a.z.string(),
                        currencyCode: a.z.string()
                    }),
                    products: a.z.array(a.z.object({
                        title: a.z.string(),
                        description: a.z.string(),
                        productType: a.z.string(),
                        handle: a.z.string(),
                        tags: a.z.array(a.z.string()),
                        vendor: a.z.string(),
                        status: a.z.string(),
                        variants: a.z.array(a.z.object({
                            title: a.z.string(),
                            price: a.z.string()
                        })),
                        image: a.z.object({
                            originalSrc: a.z.string(),
                            altText: a.z.string().optional()
                        }).nullable()
                    }))
                }),
                o = a.z.object({
                    nodes: a.z.array(a.z.object({
                        id: a.z.string(),
                        title: a.z.string().optional(),
                        name: a.z.string(),
                        quantity: a.z.number(),
                        image: a.z.object({
                            url: a.z.string(),
                            altText: a.z.string().nullable()
                        }).nullable()
                    }))
                }),
                s = a.z.object({
                    nodes: a.z.array(a.z.object({
                        id: a.z.string(),
                        name: a.z.string(),
                        confirmationNumber: a.z.string().nullable(),
                        totalPrice: a.z.string(),
                        processedAt: a.z.string(),
                        cancelledAt: a.z.string().nullable(),
                        confirmed: a.z.boolean(),
                        displayFulfillmentStatus: a.z.string(),
                        fullyPaid: a.z.boolean(),
                        refundable: a.z.boolean(),
                        note: a.z.string().nullable(),
                        lineItems: o
                    }))
                }),
                l = a.z.object({
                    shop: a.z.object({
                        id: a.z.string(),
                        myshopifyDomain: a.z.string(),
                        currencyCode: a.z.string()
                    }),
                    customer: a.z.object({
                        id: a.z.string(),
                        orders: s
                    })
                }).transform(e => {
                    var t;
                    let {
                        orders: n
                    } = e.customer;
                    return {
                        shop: { ...e.shop,
                            id: null !== (t = e.shop.id.split("/").pop()) && void 0 !== t ? t : ""
                        },
                        orders: n.nodes.map(e => {
                            var t;
                            return {
                                id: null !== (t = e.id.split("/").pop()) && void 0 !== t ? t : "",
                                name: e.name,
                                confirmationNumber: e.confirmationNumber,
                                totalPrice: e.totalPrice,
                                processedAt: e.processedAt,
                                cancelledAt: e.cancelledAt,
                                confirmed: e.confirmed,
                                displayFulfillmentStatus: e.displayFulfillmentStatus,
                                fullyPaid: e.fullyPaid,
                                refundable: e.refundable,
                                note: e.note,
                                lineItems: e.lineItems.nodes.map(e => ({
                                    id: e.id,
                                    title: e.title,
                                    name: e.name,
                                    quantity: e.quantity,
                                    image: e.image
                                }))
                            }
                        })
                    }
                }),
                c = a.z.object({
                    shop: a.z.object({
                        id: a.z.string(),
                        myshopifyDomain: a.z.string(),
                        currencyCode: a.z.string()
                    }),
                    orders: a.z.array(a.z.object({
                        id: a.z.string(),
                        name: a.z.string(),
                        confirmationNumber: a.z.string().nullable(),
                        totalPrice: a.z.string(),
                        processedAt: a.z.string(),
                        cancelledAt: a.z.string().nullable(),
                        confirmed: a.z.boolean(),
                        displayFulfillmentStatus: a.z.string(),
                        fullyPaid: a.z.boolean(),
                        refundable: a.z.boolean(),
                        note: a.z.string().nullable(),
                        lineItems: a.z.array(a.z.object({
                            id: a.z.string(),
                            title: a.z.string().optional(),
                            name: a.z.string(),
                            quantity: a.z.number(),
                            image: a.z.object({
                                url: a.z.string(),
                                altText: a.z.string().nullable()
                            }).nullable()
                        }))
                    }))
                })
        },
        34927: function(e, t, n) {
            var a = n(57437);
            n(2265);
            var r = n(84772),
                i = n.n(r);
            t.Z = e => {
                let {
                    className: t,
                    ...n
                } = e;
                return (0, a.jsxs)("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    xmlnsXlink: "http://www.w3.org/1999/xlink",
                    viewBox: "0 0 48 48",
                    className: i()(t),
                    ...n,
                    children: [(0, a.jsx)("defs", {
                        children: (0, a.jsx)("path", {
                            id: "a",
                            d: "M44.5 20H24v8.5h11.8C34.7 33.9 30.1 37 24 37c-7.2 0-13-5.8-13-13s5.8-13 13-13c3.1 0 5.9 1.1 8.1 2.9l6.4-6.4C34.6 4.1 29.6 2 24 2 11.8 2 2 11.8 2 24s9.8 22 22 22c11 0 21-8 21-22 0-1.3-.2-2.7-.5-4z"
                        })
                    }), (0, a.jsx)("clipPath", {
                        id: "b",
                        children: (0, a.jsx)("use", {
                            xlinkHref: "#a",
                            overflow: "visible"
                        })
                    }), (0, a.jsx)("path", {
                        clipPath: "url(#b)",
                        fill: "#FBBC05",
                        d: "M0 37V11l17 13z"
                    }), (0, a.jsx)("path", {
                        clipPath: "url(#b)",
                        fill: "#EA4335",
                        d: "M0 11l17 13 7-6.1L48 14V0H0z"
                    }), (0, a.jsx)("path", {
                        clipPath: "url(#b)",
                        fill: "#34A853",
                        d: "M0 37l30-23 7.9 1L48 0v48H0z"
                    }), (0, a.jsx)("path", {
                        clipPath: "url(#b)",
                        fill: "#4285F4",
                        d: "M48 48L17 24l-4-3 35-10z"
                    })]
                })
            }
        },
        38139: function(e, t, n) {
            var a = n(57437);
            let r = (0, n(2265).forwardRef)((e, t) => {
                let {
                    className: n,
                    ...r
                } = e;
                return (0, a.jsxs)("svg", {
                    ref: t,
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 320 320",
                    fill: "none",
                    className: n,
                    ...r,
                    children: [(0, a.jsx)("title", {
                        children: "OpenAI"
                    }), (0, a.jsx)("path", {
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "currentColor",
                        d: "M297 131a80.6 80.6 0 0 0-93.7-104.2 80.6 80.6 0 0 0-137 29A80.6 80.6 0 0 0 23 189a80.6 80.6 0 0 0 93.7 104.2 80.6 80.6 0 0 0 137-29A80.7 80.7 0 0 0 297.1 131zM176.9 299c-14 .1-27.6-4.8-38.4-13.8l1.9-1 63.7-36.9c3.3-1.8 5.3-5.3 5.2-9v-89.9l27 15.6c.3.1.4.4.5.7v74.4a60 60 0 0 1-60 60zM47.9 244a59.7 59.7 0 0 1-7.1-40.1l1.9 1.1 63.7 36.8c3.2 1.9 7.2 1.9 10.5 0l77.8-45V228c0 .3-.2.6-.4.8L129.9 266a60 60 0 0 1-82-22zM31.2 105c7-12.2 18-21.5 31.2-26.3v75.8c0 3.7 2 7.2 5.2 9l77.8 45-27 15.5a1 1 0 0 1-.9 0L53.1 187a60 60 0 0 1-22-82zm221.2 51.5-77.8-45 27-15.5a1 1 0 0 1 .9 0l64.4 37.1a60 60 0 0 1-9.3 108.2v-75.8c0-3.7-2-7.2-5.2-9zm26.8-40.4-1.9-1.1-63.7-36.8a10.4 10.4 0 0 0-10.5 0L125.4 123V92c0-.3 0-.6.3-.8L190.1 54a60 60 0 0 1 89.1 62.1zm-168.5 55.4-27-15.5a1 1 0 0 1-.4-.7V80.9a60 60 0 0 1 98.3-46.1l-1.9 1L116 72.8a10.3 10.3 0 0 0-5.2 9v89.8zm14.6-31.5 34.7-20 34.6 20v40L160 200l-34.7-20z"
                    })]
                })
            });
            r.displayName = "OpenAiIcon", t.Z = r
        },
        7985: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return o
                },
                v: function() {
                    return i
                }
            });
            var a = n(57437),
                r = n(27648);
            let i = [{
                    name: "userId",
                    description: (0, a.jsxs)("span", {
                        className: "text-xs text-zinc-500",
                        children: ["The user ID for the identified user. ", (0, a.jsx)("br", {}), (0, a.jsx)("br", {}), (0, a.jsxs)("span", {
                            children: [(0, a.jsx)("span", {
                                className: "font-bold",
                                children: "Note:"
                            }), " This is obtained using chatbase identify method, and the user hash is required for it to work.", (0, a.jsx)("br", {}), (0, a.jsx)("br", {}), "For more information refer to", " ", (0, a.jsx)(r.default, {
                                href: "https://www.chatbase.co/docs/developer-guides/identity-verification",
                                target: "_blank",
                                className: "font-semibold text-zinc-800 underline",
                                children: "identification docs"
                            }), "."]
                        })]
                    }),
                    type: "text",
                    array: !1,
                    group: "static"
                }],
                o = [{
                    name: "contact.id",
                    description: "Unique identifier for the contact set by Chatbase",
                    type: "text",
                    label: null,
                    archived: !1
                }, {
                    name: "contact.external_id",
                    description: "The external ID associated with the contact",
                    type: "text",
                    label: null,
                    archived: !1
                }, {
                    name: "contact.email",
                    description: "Email address of the contact",
                    type: "text",
                    label: null,
                    archived: !1
                }, {
                    name: "contact.name",
                    description: "Name of the contact",
                    type: "text",
                    label: null,
                    archived: !1
                }, {
                    name: "contact.phonenumber",
                    description: "Phone number of the contact",
                    type: "text",
                    label: null,
                    archived: !1
                }, {
                    name: "contact.stripe_email",
                    description: "Stripe email address for the contact",
                    type: "text",
                    label: null,
                    archived: !1
                }, {
                    name: "contact.stripe_id",
                    description: "Stripe customer ID for the contact",
                    type: "text",
                    label: null,
                    archived: !1
                }, {
                    name: "contact.created_at",
                    description: "When the contact was created",
                    type: "date",
                    label: null,
                    archived: !1
                }, {
                    name: "contact.updated_at",
                    description: "When the contact was last updated",
                    type: "date",
                    label: null,
                    archived: !1
                }]
        },
        19999: function(e, t, n) {
            n.d(t, {
                j3: function() {
                    return r
                }
            });
            var a = n(31229);
            let r = a.z.object({
                chatbase_account_id: a.z.string(),
                chatbot_id: a.z.string(),
                meta_business_id: a.z.string(),
                phone_number: a.z.string(),
                phone_number_id: a.z.string(),
                verified_name: a.z.string()
            });
            a.z.object({
                meta_business_id: a.z.string(),
                phone_number_id: a.z.string(),
                activationStatus: a.z.object({
                    subscribed: a.z.boolean(),
                    verified: a.z.boolean()
                }),
                accountId: a.z.string()
            }), a.z.object({
                meta_business_id: a.z.string(),
                phone_number_id: a.z.string()
            }), a.z.object({
                object: a.z.string(),
                entry: a.z.array(a.z.object({
                    id: a.z.string(),
                    changes: a.z.array(a.z.object({
                        field: a.z.string().optional(),
                        value: a.z.object({
                            messaging_product: a.z.string(),
                            metadata: a.z.object({
                                display_phone_number: a.z.string(),
                                phone_number_id: a.z.string()
                            }),
                            contacts: a.z.array(a.z.object({
                                profile: a.z.object({
                                    name: a.z.string()
                                }),
                                wa_id: a.z.string()
                            })),
                            messages: a.z.array(a.z.object({
                                from: a.z.string(),
                                id: a.z.string(),
                                timestamp: a.z.string(),
                                text: a.z.object({
                                    body: a.z.string()
                                }),
                                type: a.z.string()
                            })),
                            field: a.z.string().optional(),
                            statuses: a.z.array(a.z.object({
                                status: a.z.string(),
                                timestamp: a.z.string()
                            })).optional()
                        })
                    }))
                }))
            }), a.z.object({
                object: a.z.string(),
                entry: a.z.array(a.z.object({
                    id: a.z.string(),
                    time: a.z.number(),
                    messaging: a.z.array(a.z.object({
                        sender: a.z.object({
                            id: a.z.string()
                        }),
                        recipient: a.z.object({
                            id: a.z.string()
                        }),
                        timestamp: a.z.number(),
                        message: a.z.object({
                            mid: a.z.string(),
                            text: a.z.string(),
                            is_echo: a.z.boolean().optional()
                        })
                    }))
                }))
            })
        },
        34662: function(e, t, n) {
            n.d(t, {
                $Y: function() {
                    return m
                },
                BH: function() {
                    return I
                },
                BS: function() {
                    return _
                },
                Cp: function() {
                    return T
                },
                Gj: function() {
                    return S
                },
                Hg: function() {
                    return f
                },
                IM: function() {
                    return E
                },
                MI: function() {
                    return z
                },
                Nn: function() {
                    return g
                },
                Ns: function() {
                    return v
                },
                UQ: function() {
                    return y
                },
                V9: function() {
                    return h
                },
                Yc: function() {
                    return o
                },
                _T: function() {
                    return p
                },
                eD: function() {
                    return A
                },
                j3: function() {
                    return d
                },
                ww: function() {
                    return l
                },
                yN: function() {
                    return b
                },
                yr: function() {
                    return R
                }
            });
            var a = n(7985),
                r = n(31229);
            let i = r.z.nativeEnum({
                    ENABLED: "enabled",
                    DISABLED: "disabled",
                    INVALID: "invalid"
                }),
                o = i.enum,
                s = r.z.nativeEnum({
                    COLLECT_LEADS: "collect-leads",
                    CUSTOM_BUTTON: "custom-button",
                    CUSTOM_ACTION: "custom-action",
                    SHOPIFY_SHOW_PRODUCT: "shopify-show-product",
                    SHOPIFY_SHOW_ORDER: "shopify-show-order",
                    SLACK_NOTIFY: "slack-notify",
                    STRIPE_GET_SUBSCRIPTION: "stripe-get-subscription-info",
                    STRIPE_GET_INVOICES: "stripe-get-invoices",
                    CHATBASE_UPDATE_CHATBOT_SETTINGS: "chatbase-update-chatbot-settings",
                    CALCOM_GET_SLOTS: "calcom-get-slots",
                    CALENDLY_GET_SLOTS: "calendly-get-slots",
                    TAVILY_WEB_SEARCH: "tavily-web-search",
                    ZENDESK_CREATE_TICKET: "zendesk-create-ticket",
                    SUNSHINE_LIVE_CHAT: "sunshine-live-chat"
                }),
                l = s.enum,
                c = r.z.nativeEnum({
                    TEXT: "text"
                });
            c.enum;
            let u = r.z.object({
                    account_id: r.z.string(),
                    chatbot_id: r.z.string(),
                    id: r.z.string(),
                    description: r.z.string().nullable(),
                    appended_instructions: r.z.string().nullable(),
                    name: r.z.string().trim().min(3, {
                        message: "Name must be at least 3 characters long"
                    }).regex(/^[a-zA-Z0-9_-]+$/, {
                        message: "Name can only contain letters, numbers, underscores, and hyphens without spaces"
                    }),
                    status: i
                }),
                d = u.extend({
                    type: r.z.literal(l.COLLECT_LEADS),
                    configuration: r.z.object({
                        fields: r.z.record(r.z.string(), r.z.object({
                            name: r.z.string(),
                            type: c,
                            placeholder: r.z.string(),
                            displayName: r.z.string(),
                            enabled: r.z.boolean(),
                            required: r.z.boolean()
                        })),
                        ignoredMessage: r.z.string().default("Form dismissed"),
                        successMessage: r.z.object({
                            title: r.z.string().trim(),
                            description: r.z.string().trim()
                        }).default({
                            title: "Form submitted successfully",
                            description: "Thanks for submitting your information, we will get back to you soon!"
                        })
                    })
                }),
                p = u.extend({
                    type: r.z.literal(l.CUSTOM_BUTTON),
                    configuration: r.z.object({
                        url: r.z.string().url().min(1, {
                            message: "URL is required"
                        }),
                        buttonText: r.z.string().min(1, {
                            message: "Button text is required"
                        })
                    })
                }),
                _ = r.z.nativeEnum({
                    TEXT: "text",
                    NUMBER: "number",
                    BOOLEAN: "boolean",
                    DATE: "date"
                });
            _.enum;
            let m = u.omit({
                    name: !0
                }).extend({
                    name: r.z.string(),
                    type: r.z.literal(l.CUSTOM_ACTION),
                    configuration: r.z.object({
                        url: r.z.string().url().startsWith("https://").refine(e => {
                            try {
                                return new URL(e), !0
                            } catch (e) {
                                return !1
                            }
                        }, {
                            message: "Invalid URL format"
                        }).transform(e => e.replace(/ /g, "%20")).optional(),
                        method: r.z.enum(["GET", "POST", "PUT", "DELETE"]).default("GET"),
                        headers: r.z.object({
                            key: r.z.string(),
                            value: r.z.string()
                        }).array().refine(e => !e || e.every(e => "" !== e.key.trim() && "" !== e.value.trim()), {
                            message: "Headers must not contain empty strings"
                        }).optional(),
                        parameters: r.z.object({
                            key: r.z.string(),
                            value: r.z.string()
                        }).array().refine(e => !e || e.every(e => "" !== e.key.trim() && "" !== e.value.trim()), {
                            message: "Parameters must not contain empty strings"
                        }).transform(e => e.map(e => ({
                            key: e.key.replace(/ /g, "%20"),
                            value: e.value.replace(/ /g, "%20")
                        }))).refine(e => !e || e.every(e => !e.value.includes("[") && !e.value.includes("]")), {
                            message: "Pass arrays as comma separated values"
                        }).optional(),
                        body: r.z.string().optional(),
                        returnFields: r.z.object({
                            name: r.z.string(),
                            value: r.z.string(),
                            chosen: r.z.boolean()
                        }).array().optional(),
                        inputs: r.z.object({
                            name: r.z.string().trim(),
                            type: _,
                            description: r.z.string(),
                            array: r.z.boolean().default(!1)
                        }).array().refine(e => !e || e.every(e => "" !== e.name.trim() && "" !== e.type.trim() && "" !== e.description.trim()), {
                            message: "Inputs must not contain empty strings"
                        }).refine(e => {
                            if (!e) return !0;
                            for (let t of e)
                                for (let e of a.v)
                                    if (t.name === e.name) return !1;
                            return !0
                        }, {
                            message: "Cannot use reserved names: ".concat(a.v.map(e => e.name).join(", "))
                        }).optional(),
                        isClient: r.z.boolean().default(!1),
                        waitForResponse: r.z.boolean().default(!0)
                    })
                }),
                g = u.extend({
                    type: r.z.literal(l.SHOPIFY_SHOW_PRODUCT),
                    configuration: r.z.object({})
                }),
                h = u.extend({
                    type: r.z.literal(l.SLACK_NOTIFY),
                    configuration: r.z.object({
                        workspace: r.z.string()
                    })
                }),
                f = u.extend({
                    type: r.z.literal(l.CHATBASE_UPDATE_CHATBOT_SETTINGS),
                    configuration: r.z.object({})
                }),
                b = u.extend({
                    type: r.z.literal(l.SHOPIFY_SHOW_ORDER),
                    configuration: r.z.object({})
                }),
                y = u.extend({
                    type: r.z.literal(l.STRIPE_GET_SUBSCRIPTION),
                    configuration: r.z.object({
                        exampleResponse: r.z.object({}).optional(),
                        fields: r.z.record(r.z.string()).optional()
                    })
                }),
                v = u.extend({
                    type: r.z.literal(l.STRIPE_GET_INVOICES),
                    configuration: r.z.object({
                        exampleResponse: r.z.object({}).optional(),
                        fields: r.z.record(r.z.string()).optional()
                    })
                }),
                E = u.extend({
                    type: r.z.literal(l.CALCOM_GET_SLOTS),
                    configuration: r.z.object({
                        event: r.z.object({
                            username: r.z.string(),
                            slug: r.z.string()
                        })
                    })
                }),
                T = u.extend({
                    type: r.z.literal(l.CALENDLY_GET_SLOTS),
                    configuration: r.z.object({
                        eventTypeURI: r.z.string()
                    })
                }),
                I = u.extend({
                    type: r.z.literal(l.TAVILY_WEB_SEARCH),
                    configuration: r.z.object({
                        imagesEnabled: r.z.boolean(),
                        includedDomains: r.z.array(r.z.string())
                    })
                }),
                A = u.extend({
                    type: r.z.literal(l.ZENDESK_CREATE_TICKET),
                    configuration: r.z.object({})
                }),
                z = u.extend({
                    type: r.z.literal(l.SUNSHINE_LIVE_CHAT),
                    configuration: r.z.object({})
                }),
                S = r.z.discriminatedUnion("type", [d, p, g, h, b, y, v, f, m, E, T, I, A, z]);
            u.pick({
                name: !0,
                status: !0
            }).extend({
                type: s,
                configuration: r.z.object({
                    isClient: r.z.boolean().optional(),
                    waitForResponse: r.z.boolean().optional()
                })
            }).strip().transform(e => {
                if (e.type === l.CUSTOM_ACTION) {
                    var t, n;
                    return { ...e,
                        configuration: { ...e.configuration,
                            isClient: null !== (t = e.configuration.isClient) && void 0 !== t && t,
                            waitForResponse: null !== (n = e.configuration.waitForResponse) && void 0 !== n && n
                        }
                    }
                }
                return e
            });
            let R = r.z.discriminatedUnion("status", [r.z.object({
                status: r.z.literal("pending"),
                ___config: d.shape.configuration
            }), r.z.object({
                status: r.z.literal("success"),
                fields: r.z.record(r.z.string()),
                displayMessage: r.z.object({
                    title: r.z.string(),
                    description: r.z.string()
                })
            }), r.z.object({
                status: r.z.literal("ignored"),
                displayMessage: r.z.object({
                    title: r.z.string()
                })
            })])
        },
        71191: function(e, t, n) {
            n.d(t, {
                Ff: function() {
                    return r
                }
            });
            var a = n(31229);
            a.z.object({
                appId: a.z.string(),
                keyId: a.z.string(),
                secretKey: a.z.string(),
                integrationId: a.z.string().default(""),
                webhookId: a.z.string().default(""),
                webhookSecret: a.z.string().default("")
            });
            let r = a.z.string().min(1, "Subdomain is required").max(63, "Subdomain must have a length no greater than 63").refine(e => /^[a-z0-9]/.test(e), "Subdomain must begin with a lowercase alpha-numeric (i.e. letters [a-z] or digits [0-9])").refine(e => /[a-z0-9]$/.test(e), "Subdomain must end with a lowercase alpha-numeric (i.e. letters [a-z] or digits [0-9])").refine(e => /^[a-z0-9-]*$/.test(e), "Subdomain must contain only lowercase letters, numbers, or hyphens");
            a.z.object({
                subdomain: r,
                token: a.z.string(),
                webhookSecret: a.z.string().default(""),
                webhookAlgorithm: a.z.string().default(""),
                webhookId: a.z.string().default(""),
                triggerId: a.z.number().default(0)
            })
        },
        8601: function(e, t, n) {
            n.d(t, {
                zF: function() {
                    return m
                },
                kL: function() {
                    return E
                },
                jQ: function() {
                    return h
                },
                tt: function() {
                    return g
                },
                fI: function() {
                    return p
                },
                yB: function() {
                    return y
                },
                az: function() {
                    return T
                },
                _F: function() {
                    return I
                },
                bZ: function() {
                    return A
                },
                p9: function() {
                    return f
                },
                dJ: function() {
                    return v
                },
                vB: function() {
                    return z
                },
                JF: function() {
                    return b
                }
            });
            var a = n(57437),
                r = e => {
                    let {
                        className: t,
                        ...n
                    } = e;
                    return (0, a.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 256 176",
                        fill: "none",
                        className: t,
                        ...n,
                        children: [(0, a.jsx)("title", {
                            children: "Anthropic"
                        }), (0, a.jsx)("path", {
                            fill: "currentColor",
                            d: "m147.487 0l70.081 175.78H256L185.919 0zM66.183 106.221l23.98-61.774l23.98 61.774zM70.07 0L0 175.78h39.18l14.33-36.914h73.308l14.328 36.914h39.179L110.255 0z"
                        })]
                    })
                },
                i = n(84772),
                o = n.n(i),
                s = e => {
                    let {
                        className: t,
                        ...n
                    } = e;
                    return (0, a.jsxs)("svg", {
                        viewBox: "0 0 24 24",
                        xmlns: "http://www.w3.org/2000/svg",
                        className: o()(t),
                        ...n,
                        children: [(0, a.jsx)("title", {
                            children: "Cohere"
                        }), (0, a.jsx)("path", {
                            clipRule: "evenodd",
                            d: "M8.128 14.099c.592 0 1.77-.033 3.398-.703 1.897-.781 5.672-2.2 8.395-3.656 1.905-1.018 2.74-2.366 2.74-4.18A4.56 4.56 0 0018.1 1H7.549A6.55 6.55 0 001 7.55c0 3.617 2.745 6.549 7.128 6.549z",
                            fill: "#39594D",
                            fillRule: "evenodd"
                        }), (0, a.jsx)("path", {
                            clipRule: "evenodd",
                            d: "M9.912 18.61a4.387 4.387 0 012.705-4.052l3.323-1.38c3.361-1.394 7.06 1.076 7.06 4.715a5.104 5.104 0 01-5.105 5.104l-3.597-.001a4.386 4.386 0 01-4.386-4.387z",
                            fill: "#D18EE2",
                            fillRule: "evenodd"
                        }), (0, a.jsx)("path", {
                            d: "M4.776 14.962A3.775 3.775 0 001 18.738v.489a3.776 3.776 0 007.551 0v-.49a3.775 3.775 0 00-3.775-3.775z",
                            fill: "#FF7759"
                        })]
                    })
                },
                l = e => {
                    let {
                        className: t,
                        ...n
                    } = e;
                    return (0, a.jsxs)("svg", {
                        height: "1em",
                        style: {
                            flex: "none",
                            lineHeight: "1"
                        },
                        viewBox: "0 0 24 24",
                        width: "1em",
                        xmlns: "http://www.w3.org/2000/svg",
                        className: t,
                        ...n,
                        children: [(0, a.jsx)("title", {
                            children: "DeepSeek"
                        }), (0, a.jsx)("path", {
                            d: "M23.748 4.482c-.254-.124-.364.113-.512.234-.051.039-.094.09-.137.136-.372.397-.806.657-1.373.626-.829-.046-1.537.214-2.163.848-.133-.782-.575-1.248-1.247-1.548-.352-.156-.708-.311-.955-.65-.172-.241-.219-.51-.305-.774-.055-.16-.11-.323-.293-.35-.2-.031-.278.136-.356.276-.313.572-.434 1.202-.422 1.84.027 1.436.633 2.58 1.838 3.393.137.093.172.187.129.323-.082.28-.18.552-.266.833-.055.179-.137.217-.329.14a5.526 5.526 0 01-1.736-1.18c-.857-.828-1.631-1.742-2.597-2.458a11.365 11.365 0 00-.689-.471c-.985-.957.13-1.743.388-1.836.27-.098.093-.432-.779-.428-.872.004-1.67.295-2.687.684a3.055 3.055 0 01-.465.137 9.597 9.597 0 00-2.883-.102c-1.885.21-3.39 1.102-4.497 2.623C.082 8.606-.231 10.684.152 12.85c.403 2.284 1.569 4.175 3.36 5.653 1.858 1.533 3.997 2.284 6.438 2.14 1.482-.085 3.133-.284 4.994-1.86.47.234.962.327 1.78.397.63.059 1.236-.03 1.705-.128.735-.156.684-.837.419-.961-2.155-1.004-1.682-.595-2.113-.926 1.096-1.296 2.746-2.642 3.392-7.003.05-.347.007-.565 0-.845-.004-.17.035-.237.23-.256a4.173 4.173 0 001.545-.475c1.396-.763 1.96-2.015 2.093-3.517.02-.23-.004-.467-.247-.588zM11.581 18c-2.089-1.642-3.102-2.183-3.52-2.16-.392.024-.321.471-.235.763.09.288.207.486.371.739.114.167.192.416-.113.603-.673.416-1.842-.14-1.897-.167-1.361-.802-2.5-1.86-3.301-3.307-.774-1.393-1.224-2.887-1.298-4.482-.02-.386.093-.522.477-.592a4.696 4.696 0 011.529-.039c2.132.312 3.946 1.265 5.468 2.774.868.86 1.525 1.887 2.202 2.891.72 1.066 1.494 2.082 2.48 2.914.348.292.625.514.891.677-.802.09-2.14.11-3.054-.614zm1-6.44a.306.306 0 01.415-.287.302.302 0 01.2.288.306.306 0 01-.31.307.303.303 0 01-.304-.308zm3.11 1.596c-.2.081-.399.151-.59.16a1.245 1.245 0 01-.798-.254c-.274-.23-.47-.358-.552-.758a1.73 1.73 0 01.016-.588c.07-.327-.008-.537-.239-.727-.187-.156-.426-.199-.688-.199a.559.559 0 01-.254-.078c-.11-.054-.2-.19-.114-.358.028-.054.16-.186.192-.21.356-.202.767-.136 1.146.016.352.144.618.408 1.001.782.391.451.462.576.685.914.176.265.336.537.445.848.067.195-.019.354-.25.452z",
                            fill: "#4D6BFE"
                        })]
                    })
                },
                c = n(34927),
                u = n(38139),
                d = n(31229);
            let p = d.z.nativeEnum({
                    GPT_4_5: "gpt-4.5",
                    GPT_4_TURBO: "gpt-4-turbo",
                    GPT_4O: "gpt-4o",
                    GPT_4: "gpt-4",
                    GPT_4O_MINI: "gpt-4o-mini",
                    O3_MINI: "o3-mini",
                    CLAUDE_3_7_SONNET: "claude-3-7-sonnet",
                    CLAUDE_3_5_SONNET: "claude-3-5-sonnet",
                    CLAUDE_3_HAIKU: "claude-3-haiku",
                    CLAUDE_3_OPUS: "claude-3-opus",
                    GEMINI_1_5_FLASH: "gemini-1.5-flash",
                    GEMINI_1_5_PRO: "gemini-1.5-pro",
                    GEMINI_2_0_FLASH: "gemini-2.0-flash",
                    GEMINI_2_0_PRO: "gemini-2.0-pro",
                    COHERE_COMMAND_R: "command-r",
                    COHERE_COMMAND_R_PLUS: "command-r-plus",
                    DEEP_SEEK_V3: "DeepSeek-V3",
                    DEEP_SEEK_R1: "DeepSeek-R1"
                }),
                _ = d.z.nativeEnum({
                    GPT_4O: "gpt-4o",
                    GPT_4O_MINI: "gpt-4o-mini"
                }),
                m = d.z.nativeEnum({
                    TEXT_EMBEDDING_ADA_002: "text-embedding-ada-002",
                    TEXT_EMBEDDING_3_LARGE: "text-embedding-3-large",
                    TEXT_EMBEDDING_3_SMALL: "text-embedding-3-small",
                    TEXT_EMBEDDING_004: "text-embedding-004"
                }),
                g = p.enum;
            _.enum, m.enum;
            let h = {
                [g.O3_MINI]: {
                    id: g.O3_MINI,
                    aiSDKKey: "".concat(g.O3_MINI, "-2025-01-31"),
                    providerName: "OpenAI",
                    name: "o3 Mini",
                    creditsCost: 1,
                    description: "o3-mini is OpenAI's latest compact reasoning model, delivering high intelligence while maintaining the same cost and latency targets as o1-mini.",
                    img: u.Z
                },
                [g.GPT_4_5]: {
                    id: g.GPT_4_5,
                    aiSDKKey: "".concat(g.GPT_4_5, "-preview"),
                    providerName: "OpenAI",
                    name: "GPT-4.5",
                    creditsCost: 30,
                    description: "An advanced model with enhanced creativity, broader knowledge, and a refined grasp of nuance. GPT-4.5 excels in writing, communication, learning, tutoring, and brainstorming. Designed for agentic workflows and intuitive problem-solving, it pushes the boundaries of understanding with minimal prompting. Currently optimized for text-to-text tasks, with more capabilities expected over time.",
                    img: u.Z
                },
                [g.GPT_4O]: {
                    id: g.GPT_4O,
                    aiSDKKey: "".concat(g.GPT_4O, "-2024-08-06"),
                    providerName: "OpenAI",
                    name: "GPT-4o",
                    creditsCost: 1,
                    description: "The high-intelligence flagship model for complex, multi-step tasks. GPT-4o generates text twice as fast than GPT-4 Turbo, with superior non-English language performance. Best for complex tasks that require high performance and efficiency, especially in non-English languages.",
                    img: u.Z
                },
                [g.GPT_4O_MINI]: {
                    id: g.GPT_4O_MINI,
                    aiSDKKey: g.GPT_4O_MINI,
                    providerName: "OpenAI",
                    name: "GPT-4o Mini",
                    creditsCost: 1,
                    description: "An intelligent small model for fast, lightweight tasks. GPT-4o Mini is more capable than GPT-3.5 Turbo. Ideal for smaller tasks that need a balance of capability and cost-efficiency.",
                    img: u.Z
                },
                [g.GPT_4_TURBO]: {
                    id: g.GPT_4_TURBO,
                    aiSDKKey: g.GPT_4_TURBO,
                    providerName: "OpenAI",
                    name: "GPT-4 Turbo",
                    creditsCost: 10,
                    description: "An optimized version of GPT-4, generating text faster and more efficiently. Ideal for tasks that need the advanced capabilities of GPT-4 but with enhanced speed and efficiency.",
                    img: u.Z
                },
                [g.GPT_4]: {
                    id: g.GPT_4,
                    aiSDKKey: g.GPT_4,
                    providerName: "OpenAI",
                    name: "GPT-4",
                    creditsCost: 20,
                    description: "A model that excels at solving difficult problems with greater accuracy due to its broad general knowledge and advanced reasoning capabilities. Best for complex tasks requiring high intelligence and accuracy.",
                    img: u.Z
                },
                [g.CLAUDE_3_7_SONNET]: {
                    id: g.CLAUDE_3_7_SONNET,
                    aiSDKKey: "".concat(g.CLAUDE_3_7_SONNET, "-20250219"),
                    name: "Claude 3.7 Sonnet",
                    providerName: "Anthropic",
                    creditsCost: 1,
                    description: "Claude 3.7 Sonnet is Anthropic’s most advanced model yet, designed for superior reasoning in complex, multi-step queries. It can produce near-instant responses or engage in extended, step-by-step thinking, making it highly effective for intricate tasks.",
                    img: r
                },
                [g.CLAUDE_3_5_SONNET]: {
                    id: g.CLAUDE_3_5_SONNET,
                    aiSDKKey: "".concat(g.CLAUDE_3_5_SONNET, "-20241022"),
                    name: "Claude 3.5 Sonnet",
                    providerName: "Anthropic",
                    creditsCost: 1,
                    description: "The most intelligent model in the Claude family, offering the highest level of intelligence and capability. Best for highly complex tasks that require top-level performance, intelligence, fluency, and understanding.",
                    img: r
                },
                [g.CLAUDE_3_OPUS]: {
                    id: g.CLAUDE_3_OPUS,
                    aiSDKKey: "".concat(g.CLAUDE_3_OPUS, "-20240229"),
                    providerName: "Anthropic",
                    name: "Claude 3 Opus",
                    creditsCost: 20,
                    description: "A powerful model for highly complex tasks, excelling at writing and complex multi-step tasks. Suitable for tasks requiring top-level performance, intelligence, fluency, and understanding.",
                    img: r
                },
                [g.CLAUDE_3_HAIKU]: {
                    id: g.CLAUDE_3_HAIKU,
                    aiSDKKey: "".concat(g.CLAUDE_3_HAIKU, "-20240307"),
                    name: "Claude 3 Haiku",
                    providerName: "Anthropic",
                    creditsCost: 1,
                    description: "The fastest and most compact model, designed for near-instant responsiveness. Ideal for quick and accurate targeted performance in lightweight tasks.",
                    img: r
                },
                [g.GEMINI_1_5_PRO]: {
                    id: g.GEMINI_1_5_PRO,
                    aiSDKKey: "".concat(g.GEMINI_1_5_PRO, "-latest"),
                    providerName: "Google",
                    name: "Gemini 1.5 Pro",
                    creditsCost: 1,
                    description: "An advanced model that provides higher intelligence and capability compared to Gemini 1.5 Flash. It is suitable for more complex tasks that require a higher level of understanding and accuracy. Best for tasks that need a balance of advanced capabilities and efficiency.",
                    img: c.Z
                },
                [g.GEMINI_1_5_FLASH]: {
                    id: g.GEMINI_1_5_FLASH,
                    aiSDKKey: "".concat(g.GEMINI_1_5_FLASH, "-latest"),
                    providerName: "Google",
                    name: "Gemini 1.5 Flash",
                    creditsCost: 1,
                    description: "A fast and efficient model designed for quick, lightweight tasks. It offers a balance of speed and capability, making it suitable for applications where responsiveness is crucial. Ideal for tasks needing fast performance with moderate complexity.",
                    img: c.Z
                },
                [g.GEMINI_2_0_FLASH]: {
                    id: g.GEMINI_2_0_FLASH,
                    aiSDKKey: "".concat(g.GEMINI_2_0_FLASH, "-001"),
                    providerName: "Google",
                    name: "Gemini 2.0 Flash",
                    creditsCost: 1,
                    description: "Gemini 2.0 Flash introduces new features and enhanced core capabilities, including significant improvements in time to first token (TTFT) and performance across most benchmarks compared to Gemini 1.5 Pro. It excels at multimodal understanding, coding, complex instruction following, and actions calling.",
                    img: c.Z
                },
                [g.GEMINI_2_0_PRO]: {
                    id: g.GEMINI_2_0_PRO,
                    aiSDKKey: "".concat(g.GEMINI_2_0_PRO, "-exp-02-05"),
                    providerName: "Google",
                    name: "Gemini 2.0 Pro",
                    creditsCost: 1,
                    description: "A powerful model with advanced reasoning, strong coding abilities, and enhanced understanding. It excels at handling complex prompts, analyzing vast information, and utilizing tools for research and problem-solving.",
                    img: c.Z
                },
                [g.COHERE_COMMAND_R]: {
                    id: g.COHERE_COMMAND_R,
                    aiSDKKey: "".concat(g.COHERE_COMMAND_R, "-08-2024"),
                    providerName: "Cohere",
                    name: "Command R",
                    creditsCost: 1,
                    description: "Command R is an instruction-following conversational model that performs language tasks at a higher quality, more reliably, and with a longer context than Cohere's previous models. It can be used for complex workflows like retrieval augmented generation (RAG), action calling, and agents.",
                    img: s
                },
                [g.COHERE_COMMAND_R_PLUS]: {
                    id: g.COHERE_COMMAND_R_PLUS,
                    aiSDKKey: "".concat(g.COHERE_COMMAND_R_PLUS, "-08-2024"),
                    providerName: "Cohere",
                    name: "Command R+",
                    creditsCost: 1,
                    description: "Command R+ is an instruction-following conversational model that performs language tasks at a higher quality, more reliably, and with a longer context than Cohere's previous models. It is best suited for complex RAG workflows and multi-step action calling.",
                    img: s
                },
                [g.DEEP_SEEK_V3]: {
                    id: g.DEEP_SEEK_V3,
                    aiSDKKey: "deepseek-ai/".concat(g.DEEP_SEEK_V3),
                    providerName: "DeepSeek",
                    name: "DeepSeek-V3",
                    creditsCost: 1,
                    description: "DeepSeek v3 is an advanced large language model with a Mixture-of-Experts architecture, excelling in mathematics, coding, and multilingual tasks. Trained on a vast dataset, it supports a long context window and offers efficient performance comparable to top closed-source models.",
                    img: l
                },
                [g.DEEP_SEEK_R1]: {
                    id: g.DEEP_SEEK_R1,
                    aiSDKKey: "deepseek-ai/".concat(g.DEEP_SEEK_R1),
                    providerName: "DeepSeek",
                    name: "DeepSeek-R1",
                    creditsCost: 2,
                    description: "DeepSeek Reasoner, developed by DeepSeek, is a specialized model that enhances response accuracy through Chain of Thought (CoT) reasoning. It generates detailed reasoning steps before delivering a final answer, which are accessible via the API, enabling users to review and utilize the model's thought process.",
                    img: l
                }
            };
            d.z.object({
                id: p,
                providerName: d.z.string(),
                name: d.z.string(),
                creditsCost: d.z.number(),
                description: d.z.string(),
                img: d.z.any()
            });
            let f = [g.GPT_4O_MINI, g.CLAUDE_3_HAIKU, g.GEMINI_1_5_FLASH, g.GEMINI_2_0_FLASH, g.COHERE_COMMAND_R],
                b = Object.values(h).filter(e => {
                    let {
                        providerName: t
                    } = e;
                    return "OpenAI" === t
                }).map(e => {
                    let {
                        id: t,
                        name: n
                    } = e;
                    return {
                        id: t,
                        name: n
                    }
                }),
                y = Object.values(h).filter(e => {
                    let {
                        providerName: t
                    } = e;
                    return "Anthropic" === t
                }).map(e => {
                    let {
                        id: t,
                        name: n
                    } = e;
                    return {
                        id: t,
                        name: n
                    }
                }),
                v = Object.values(h).filter(e => {
                    let {
                        providerName: t
                    } = e;
                    return "Google" === t
                }).map(e => {
                    let {
                        id: t,
                        name: n
                    } = e;
                    return {
                        id: t,
                        name: n
                    }
                }),
                E = Object.values(h).filter(e => {
                    let {
                        providerName: t
                    } = e;
                    return "Anthropic" === t
                }).map(e => {
                    let {
                        id: t,
                        name: n
                    } = e;
                    return {
                        id: t,
                        name: n
                    }
                }),
                T = Object.values(h).filter(e => {
                    let {
                        providerName: t
                    } = e;
                    return "Cohere" === t
                }).map(e => {
                    let {
                        id: t,
                        name: n
                    } = e;
                    return {
                        id: t,
                        name: n
                    }
                }),
                I = Object.values(h).filter(e => {
                    let {
                        providerName: t
                    } = e;
                    return "DeepSeek" === t
                }).map(e => {
                    let {
                        id: t,
                        name: n
                    } = e;
                    return {
                        id: t,
                        name: n
                    }
                }),
                A = [{
                    id: g.GPT_4O_MINI,
                    name: "GPT-4o Mini"
                }, {
                    id: g.CLAUDE_3_HAIKU,
                    name: "Claude 3 Haiku"
                }, {
                    id: g.GEMINI_1_5_FLASH,
                    name: "Gemini 1.5 Flash"
                }, {
                    id: g.GEMINI_2_0_FLASH,
                    name: "Gemini 2.0 Flash"
                }, {
                    id: g.COHERE_COMMAND_R,
                    name: "Command R"
                }],
                z = [g.DEEP_SEEK_R1, g.DEEP_SEEK_V3]
        },
        53411: function(e, t, n) {
            n.d(t, {
                GP: function() {
                    return c
                },
                h_: function() {
                    return o
                },
                ne: function() {
                    return l
                }
            });
            var a = n(57099),
                r = n(31229);
            let i = r.jb({
                    LIGHT: "light",
                    DARK: "dark"
                }),
                o = i.enum,
                s = r.jb({
                    LEFT: "left",
                    RIGHT: "right"
                }),
                l = s.enum,
                c = r.Ry({
                    theme: i.default(o.LIGHT),
                    header_color: r.Z_().regex(a.Oy, {
                        message: "headerColor has invalid value."
                    }).optional(),
                    user_message_color: r.Z_().regex(a.Oy, {
                        message: "userMessageColor has invalid value."
                    }).optional(),
                    button_color: r.Z_().regex(a.Oy, {
                        message: "buttonColor has invalid value."
                    }).or(r.i0("transparent")).optional(),
                    display_name: r.Z_().optional().nullable(),
                    profile_picture_file: r.Z_().optional().nullable(),
                    chat_icon: r.Z_().optional().nullable(),
                    auto_open_chat_window_after: r.Rx().optional().nullable(),
                    align_chat_button: s.optional().nullable(),
                    message_placeholder: r.Z_().optional().nullable(),
                    footer: r.Z_().optional().nullable(),
                    collect_user_feedback: r.O7().optional().nullable(),
                    regenerate_messages: r.O7().optional().nullable()
                })
        },
        19772: function(e, t, n) {
            n.d(t, {
                Kt: function() {
                    return I
                },
                Kv: function() {
                    return z
                },
                MY: function() {
                    return b
                },
                RE: function() {
                    return E
                },
                Tl: function() {
                    return A
                },
                bQ: function() {
                    return T
                },
                d_: function() {
                    return g
                },
                j9: function() {
                    return h
                }
            });
            var a, r = n(57099),
                i = n(31229),
                o = n(8601),
                s = n(39828),
                l = n(87045),
                c = n(84653),
                u = n(92470),
                d = n(53411),
                p = n(25566);
            let _ = i.Ry({
                    active: i.O7(),
                    label: i.Z_()
                }),
                m = i.Ry({
                    title: i.Z_().optional(),
                    name: _,
                    email: _,
                    phone: _
                }),
                g = i.jb({
                    PRIVATE: "private",
                    PUBLIC: "public"
                }),
                h = g.enum,
                f = i.jb({
                    NEVER: "never",
                    EVERY_24_HOURS: "every_24_hours"
                }),
                b = f.enum,
                y = i.Ry({
                    active: i.O7(),
                    emails: i.IX(i.Z_().regex(r.Fj, {
                        message: "Invalid email address."
                    })).max(r.nz)
                }),
                v = i.jb({
                    ONE_FAILED: "oneFailed",
                    ONE_SOURCE_FAILED: "oneFailed",
                    FAILED: "failed",
                    LIMIT_EXCEEDED: "limitExceeded",
                    TRAINING: "training",
                    TRAINED: "trained",
                    ALL_TRAINED: "allTrained",
                    ONE_TRAINING: "oneTraining",
                    OUTDATED: "outdated"
                }),
                E = v.enum,
                T = i.Ry({
                    id: i.Z_(),
                    name: i.Z_(),
                    model: i.Z_().default(o.tt.GPT_4O),
                    collect_leads_settings: m.nullable(),
                    created_at: i.Z_(),
                    current_training_id: i.Z_().nullable(),
                    custom_domains: i.IX(i.Z_()).nullable(),
                    embeddings_metadata: i.Ry({
                        num_of_characters: i.Rx(),
                        reverted_training_id: i.Z_(),
                        status: i.Z_(),
                        error: i.Z_()
                    }).nullable(),
                    embedding_model: o.zF,
                    allowed_domains: i.IX(i.Z_()).nullable(),
                    index_name: i.Z_(),
                    initial_messages: i.IX(i.Z_()).nullable().transform(e => null != e ? e : [c.Um]),
                    instructions: i.Z_().nullable().transform(e => null != e ? e : l.O.AI_CHATBOT.prompt),
                    ip_limit: i.Rx().nullable().transform(e => null != e ? e : 20),
                    ip_limit_message: i.Z_().nullable().transform(e => null != e ? e : "Too many messages in a row"),
                    ip_limit_timeframe: i.Rx().nullable().transform(e => null != e ? e : 240),
                    is_embeddings_on_supabase: i.O7(),
                    last_message_at: i.Z_().nullable(),
                    last_trained_at: i.Z_().nullable(),
                    notifications_settings: i.Ry({
                        daily_leads_collected: y,
                        daily_conversations: y
                    }).nullable(),
                    num_of_characters: i.Rx(),
                    only_allow_on_added_domains: i.O7(),
                    retraining_interval: f.nullable(),
                    status: i.Z_().nullable(),
                    styles: d.GP.nullable(),
                    supabase_training_id: i.Z_().nullable(),
                    suggested_messages: i.IX(i.Z_()).nullable().transform(e => null != e ? e : []),
                    temp: i.Rx().gte(0).lte(1).default(Number.parseInt(null !== (a = p.env.AI_TEMP) && void 0 !== a ? a : "0")),
                    account_id: i.Z_(),
                    visibility: i.Z_(),
                    freeze_topics: i.O7(),
                    credits_limit: i.Rx().nullable(),
                    credits_used: i.Rx()
                });
            T.pick({
                name: !0,
                id: !0,
                suggested_messages: !0,
                initial_messages: !0,
                visibility: !0,
                styles: !0,
                collect_leads_settings: !0
            }).strip().transform(e => {
                var t;
                let n = (null === (t = e.styles) || void 0 === t ? void 0 : t.profile_picture_file) ? "".concat("https://backend.chatbase.co", "/storage/v1/object/public/chatbots-profile-pictures/").concat(e.styles.profile_picture_file, "?width=40&height=40&quality=50") : null;
                return i.Mg.mergeShapes(e, {
                    canBeEmbeded: "public" === e.visibility,
                    profilePicture: n,
                    shouldDisplayCollectLeads: S(e.collect_leads_settings)
                })
            });
            let I = T.extend({
                    model: o.fI.default(o.tt.GPT_4O),
                    status: v.nullable(),
                    last_message_at: i.oQ.date().nullable(),
                    last_trained_at: i.oQ.date().nullable(),
                    created_at: i.oQ.date(),
                    visibility: g
                }).transform(e => {
                    var t;
                    let n = (null === (t = e.styles) || void 0 === t ? void 0 : t.profile_picture_file) ? "".concat("https://backend.chatbase.co", "/storage/v1/object/public/chatbots-profile-pictures/").concat(e.styles.profile_picture_file, "?width=40&height=40&quality=50") : null;
                    return i.Mg.mergeShapes(e, {
                        canBeEmbeded: "public" === e.visibility,
                        creditsCost: Number(o.jQ[e.model].creditsCost),
                        profilePicture: n,
                        shouldDisplayCollectLeads: S(e.collect_leads_settings)
                    })
                }),
                A = i.Ry({
                    id: i.Z_(),
                    name: i.Z_(),
                    model: o.fI,
                    collect_leads_settings: m.nullable(),
                    current_training_id: i.Z_().nullable(),
                    custom_domains: i.IX(i.Z_()).nullable(),
                    embeddings_metadata: i.Ry({
                        num_of_characters: i.Rx(),
                        reverted_training_id: i.Z_(),
                        status: i.Z_(),
                        error: i.Z_()
                    }).nullable(),
                    embedding_model: o.zF,
                    allowed_domains: i.IX(i.Z_()).nullable(),
                    index_name: i.Z_(),
                    initial_messages: i.Z_().array(),
                    instructions: i.Z_(),
                    profilePicture: i.Z_().nullable(),
                    canBeEmbeded: i.O7(),
                    creditsCost: i.Rx(),
                    ip_limit: i.Rx(),
                    ip_limit_message: i.Z_(),
                    ip_limit_timeframe: i.Rx(),
                    is_embeddings_on_supabase: i.O7(),
                    last_message_at: i.oQ.date().nullable(),
                    last_trained_at: i.oQ.date().nullable(),
                    created_at: i.oQ.date(),
                    temp: i.Rx(),
                    notifications_settings: i.Ry({
                        daily_leads_collected: y,
                        daily_conversations: y
                    }).nullable(),
                    num_of_characters: i.Rx(),
                    only_allow_on_added_domains: i.O7(),
                    retraining_interval: f.nullable(),
                    status: v.nullable(),
                    styles: d.GP.nullable(),
                    supabase_training_id: i.Z_().nullable(),
                    suggested_messages: i.Z_().array(),
                    account_id: i.Z_(),
                    visibility: g,
                    freeze_topics: i.O7(),
                    shouldDisplayCollectLeads: i.O7(),
                    credits_limit: i.Rx().nullable(),
                    credits_used: i.Rx()
                }).strip(),
                z = e => {
                    let {
                        subscription: t
                    } = e, n = t.addons.some(e => e.name === s.s0[s.az.REMOVE_POWERED_BY]), a = [u._7.PRO, u._7.STANDARD, u._7.STANDARD_V2, u._7.STANDARD_V4, u._7.HOBBY, u._7.HOBBY_V0, u._7.HOBBY_V1, u._7.HOBBY_V2, u._7.HOBBY_V3, u._7.GROWTH_V2, u._7.FREE].some(e => t.plan === e);
                    return {
                        chatbaseBranding: !n && a
                    }
                },
                S = e => {
                    if (e) {
                        for (let [t, n] of Object.entries(e))
                            if ("string" != typeof n && n.active) return !0
                    }
                    return !1
                }
        },
        43061: function(e, t, n) {
            n.d(t, {
                fo: function() {
                    return G
                },
                UT: function() {
                    return Z
                },
                Jk: function() {
                    return eI
                },
                GV: function() {
                    return ef
                },
                ns: function() {
                    return eg
                },
                kr: function() {
                    return e_
                },
                bK: function() {
                    return j
                },
                D_: function() {
                    return ed
                },
                Zg: function() {
                    return el
                },
                aI: function() {
                    return eo
                },
                Bk: function() {
                    return g
                },
                WU: function() {
                    return h
                },
                Yo: function() {
                    return ev
                },
                Tu: function() {
                    return eT
                }
            });
            var a = n(71989),
                r = n(8601),
                i = n(84653),
                o = n(31229);
            n(25566);
            let s = o.z.object({
                answer: o.z.string(),
                query: o.z.string(),
                images: o.z.array(o.z.string()),
                results: o.z.array(o.z.object({
                    title: o.z.string(),
                    url: o.z.string(),
                    content: o.z.string(),
                    score: o.z.number()
                }))
            });
            n(71191), n(86937), n(7561), n(88200), n(56521);
            let l = o.z.object({
                ticket: o.z.object({
                    id: o.z.string(),
                    url: o.z.string(),
                    subject: o.z.string(),
                    description: o.z.string(),
                    status: o.z.string()
                })
            });
            o.z.nativeEnum({
                CONVERSATION_ENDED: "conversation:ended"
            }).enum;
            var c = n(34662),
                u = n(19772),
                d = n(98595),
                p = n(40753);
            let _ = o.jb({
                    USER: "user",
                    SYSTEM: "system",
                    ASSISTANT: "assistant",
                    TOOL: "tool"
                }),
                m = o.jb({
                    THUMBS_UP: "up",
                    THUMBS_DOWN: "down"
                });
            o.jb({
                SUCCESS: "success",
                ERROR: "error",
                PENDING: "pending"
            }).enum;
            let g = m.enum;
            o.jb({
                ACTIVE: "active",
                DELETED: "deleted"
            }).enum;
            let h = _.enum,
                f = o.jb({
                    TEXT: "text",
                    TOOL_CALL: "tool-call"
                }),
                b = f.enum,
                y = o.Ry({
                    id: o.Z_().optional(),
                    feedback: m.optional(),
                    stepId: o.Z_().optional()
                }),
                v = y.extend({
                    role: o.i0(h.ASSISTANT),
                    type: f.default("text"),
                    score: o.oQ.number().optional()
                }),
                E = y.extend({
                    role: o.i0(h.USER),
                    content: o.Z_(),
                    name: o.Z_().optional()
                }),
                T = v.extend({
                    type: o.i0(b.TOOL_CALL),
                    content: o.Ry({
                        toolName: o.Z_(),
                        type: o.i0("tool-call"),
                        toolCallId: o.Z_(),
                        args: o.IM(o.Z_(), d.A)
                    }).array()
                }),
                I = v.extend({
                    revised_answer: o.Z_().optional(),
                    thumbsDown: o.O7().optional(),
                    type: o.i0(b.TEXT).optional().default(b.TEXT),
                    content: o.Z_()
                }),
                A = v.and(o.VK("type", [T, I])),
                z = o.Ry({
                    type: o.i0("tool-result"),
                    toolName: o.Z_(),
                    toolCallId: o.Z_()
                }),
                S = y.extend({
                    role: o.i0(h.TOOL),
                    actionType: o.i0(c.ww.COLLECT_LEADS),
                    content: z.extend({
                        result: c.yr
                    }).array()
                }),
                R = o.Ry({
                    status: o.i0("success"),
                    data: o.Ry({
                        url: o.Z_(),
                        buttonText: o.Z_()
                    })
                }),
                O = y.extend({
                    role: o.i0(h.TOOL),
                    actionType: o.i0(c.ww.CUSTOM_BUTTON),
                    content: z.extend({
                        result: R
                    }).array()
                }),
                N = o.Ry({
                    status: o.G0([o.i0("success"), o.i0("error")])
                }),
                w = y.extend({
                    role: o.i0(h.TOOL),
                    actionType: o.i0(c.ww.SLACK_NOTIFY),
                    content: z.extend({
                        result: N
                    }).array()
                }),
                C = o.VK("status", [o.Ry({
                    data: u.bQ,
                    status: o.i0("success")
                }), o.Ry({
                    error: o.Yj(),
                    status: o.i0("error")
                })]),
                D = y.extend({
                    role: o.i0(h.TOOL),
                    actionType: o.i0(c.ww.CHATBASE_UPDATE_CHATBOT_SETTINGS),
                    content: z.extend({
                        result: C
                    }).array()
                }),
                x = o.VK("status", [o.Ry({
                    data: a.nQ,
                    status: o.i0("success")
                }), o.Ry({
                    error: o.Z_().optional(),
                    status: o.i0("error")
                })]),
                P = y.extend({
                    role: o.i0(h.TOOL),
                    actionType: o.i0(c.ww.SHOPIFY_SHOW_PRODUCT),
                    content: z.extend({
                        result: x
                    }).array()
                }),
                k = o.VK("status", [o.Ry({
                    data: a.K3,
                    status: o.i0("success")
                }), o.Ry({
                    error: o.Z_().optional(),
                    status: o.i0("error")
                })]),
                M = y.extend({
                    role: o.i0(h.TOOL),
                    actionType: o.i0(c.ww.SHOPIFY_SHOW_ORDER),
                    content: z.extend({
                        result: k
                    }).array()
                }),
                j = o.VK("status", [o.Ry({
                    data: d.U,
                    status: o.i0("success")
                }), o.Ry({
                    error: o.Z_().optional(),
                    status: o.i0("error")
                })]),
                L = y.extend({
                    role: o.i0(h.TOOL),
                    actionType: o.i0(c.ww.CUSTOM_ACTION),
                    content: z.extend({
                        result: j
                    }).array()
                }),
                U = o.jb({
                    SELECT: "select",
                    MULTISELECT: "multiselect",
                    RADIO: "radio",
                    RADIOINPUT: "radioInput",
                    MULTIEMAIL: "multiemail",
                    CHECKBOX: "checkbox",
                    BOOLEAN: "boolean",
                    TEXT: "text",
                    NUMBER: "number",
                    TEXTAREA: "textarea",
                    EMAIL: "email",
                    PHONE: "phone",
                    ADDRESS: "address",
                    NAME: "name",
                    UNKNOWN: "unknown"
                }),
                Z = U.enum,
                G = o.Ry({
                    type: U,
                    slug: o.Z_(),
                    isDefault: o.O7().optional(),
                    required: o.O7().optional(),
                    label: o.Z_().optional(),
                    placeholder: o.Z_().optional(),
                    hidden: o.O7().optional(),
                    options: o.IX(o.Z_()).optional()
                }).transform(e => {
                    let t = {
                        name: {
                            label: "Name",
                            placeholder: "John Doe"
                        },
                        email: {
                            label: "Email",
                            placeholder: "john@example.com"
                        },
                        title: {
                            label: "What is this meeting about",
                            placeholder: "Meeting with John Doe"
                        },
                        notes: {
                            label: "Additional Notes",
                            placeholder: "Please share anything that will help prepare for our meeting"
                        },
                        rescheduleReason: {
                            label: "Reschedule Reason",
                            placeholder: "Let others know why you need to reschedule"
                        }
                    }[e.slug];
                    return { ...e,
                        label: e.label || (null == t ? void 0 : t.label) || e.slug.charAt(0).toUpperCase() + e.slug.slice(1),
                        placeholder: e.placeholder || (null == t ? void 0 : t.placeholder) || ""
                    }
                }),
                H = o.VK("status", [o.Ry({
                    data: o.Ry({
                        slots: o.IM(o.Z_(), o.IX(o.Z_())),
                        timezone: o.Z_(),
                        eventTypeId: o.Z_(),
                        bookingFields: o.IX(G).default(i.$h),
                        appointmentBookingDate: o.Z_().nullable()
                    }),
                    status: o.i0("success")
                }), o.Ry({
                    error: o.Z_().optional(),
                    status: o.i0("error")
                })]),
                B = y.extend({
                    role: o.i0(h.TOOL),
                    actionType: o.i0(c.ww.CALCOM_GET_SLOTS),
                    content: z.extend({
                        result: H
                    }).array()
                }),
                F = o.VK("status", [o.Ry({
                    data: s,
                    status: o.i0("success")
                }), o.Ry({
                    error: o.Z_().optional(),
                    status: o.i0("error")
                })]),
                Y = y.extend({
                    role: o.i0(h.TOOL),
                    actionType: o.i0(c.ww.TAVILY_WEB_SEARCH),
                    content: z.extend({
                        result: F
                    }).array()
                }),
                V = o.VK("status", [o.Ry({
                    data: o.Ry({
                        slots: o.IM(o.Z_(), o.IX(o.Ry({
                            startTime: o.Z_(),
                            schedulingUrl: o.Z_()
                        }))),
                        timezone: o.Z_(),
                        eventTypeURI: o.Z_(),
                        appointmentBookingDate: o.Z_().nullable()
                    }),
                    status: o.i0("success")
                }), o.Ry({
                    error: o.Z_().optional(),
                    status: o.i0("error")
                })]),
                K = y.extend({
                    role: o.i0(h.TOOL),
                    actionType: o.i0(c.ww.CALENDLY_GET_SLOTS),
                    content: z.extend({
                        result: V
                    }).array()
                }),
                q = o.VK("status", [o.Ry({
                    data: p.O,
                    status: o.i0("success")
                }), o.Ry({
                    error: o.Z_().optional(),
                    status: o.i0("error")
                })]),
                X = y.extend({
                    role: o.i0(h.TOOL),
                    actionType: o.i0(c.ww.STRIPE_GET_SUBSCRIPTION),
                    content: z.extend({
                        result: q
                    }).array()
                }),
                W = o.Ry({
                    id: o.Z_(),
                    amount_due: o.Rx(),
                    amount_paid: o.Rx(),
                    amount_remaining: o.Rx(),
                    currency: o.Z_(),
                    description: o.Z_().nullable(),
                    status: o.Z_().nullable(),
                    created: o.Rx(),
                    due_date: o.Rx().nullable(),
                    hosted_invoice_url: o.Z_().nullable().optional(),
                    invoice_pdf: o.Z_().nullable().optional()
                }),
                Q = o.VK("status", [o.Ry({
                    data: o.Ry({
                        invoices: o.IX(W)
                    }),
                    status: o.i0("success")
                }), o.Ry({
                    error: o.Z_().optional(),
                    status: o.i0("error")
                })]),
                $ = y.extend({
                    role: o.i0(h.TOOL),
                    actionType: o.i0(c.ww.STRIPE_GET_INVOICES),
                    content: z.extend({
                        result: Q
                    }).array()
                }),
                J = o.VK("status", [o.Ry({
                    data: l,
                    status: o.i0("success")
                }), o.Ry({
                    error: o.Z_().optional(),
                    status: o.i0("error")
                })]),
                ee = y.extend({
                    role: o.i0(h.TOOL),
                    actionType: o.i0(c.ww.ZENDESK_CREATE_TICKET),
                    content: z.extend({
                        result: J
                    }).array()
                }),
                et = o.Ry({
                    conversation: o.Ry({
                        id: o.Z_(),
                        type: o.i0("personal"),
                        displayName: o.Z_(),
                        description: o.Z_().optional(),
                        isDefault: o.O7(),
                        lastUpdatedAt: o.Z_(),
                        createdAt: o.Z_(),
                        metadata: o.Ry({
                            chatbotId: o.Z_(),
                            conversationId: o.Z_()
                        })
                    })
                }),
                en = o.VK("status", [o.Ry({
                    data: et.shape.conversation,
                    status: o.i0("success")
                }), o.Ry({
                    error: o.Z_().optional(),
                    status: o.i0("error")
                })]),
                ea = y.extend({
                    role: o.i0(h.TOOL),
                    actionType: o.i0(c.ww.SUNSHINE_LIVE_CHAT),
                    content: z.extend({
                        result: en
                    }).array()
                }),
                er = y.and(o.VK("actionType", [S, O, P, w, M, X, $, D, L, B, K, Y, ee, ea])),
                ei = y.extend({
                    role: o.i0(h.SYSTEM),
                    content: o.Z_()
                }),
                eo = o.G0([E, A, ei, er]),
                es = o.jb({
                    USER: "user",
                    AGENT: "agent"
                }),
                el = es.enum,
                ec = o.jb({
                    ZENDESK: "zendesk"
                });
            ec.enum;
            let eu = o.Ry({
                    agentId: o.Z_().optional(),
                    agentName: o.Z_().optional(),
                    agentAvatarUrl: o.Z_().optional()
                }),
                ed = o.Ry({
                    id: o.Z_(),
                    role: es,
                    content: o.Z_(),
                    conversation_id: o.Z_(),
                    created_at: o.Z_(),
                    source: ec,
                    metadata: eu.nullable(),
                    chatbot_id: o.Z_(),
                    account_id: o.Z_()
                });
            o.G0([c.yr, O, x, w, k, q, $, C, j, H, V, F, J]), eo.transform(e => "assistant" === e.role ? A.parse({
                type: e.type,
                content: e.content,
                id: e.id,
                role: e.role
            }) : e).array(), eo.array().transform(e => e.filter(e => "string" == typeof e.content)).default([]).pipe(o.IX(I.strip().or(E.strip()).or(ei.strip())));
            let ep = o.jb({
                    API: "API",
                    WHATSAPP: "WhatsApp",
                    MESSENGER: "Messenger",
                    INSTAGRAM: "Instagram",
                    SLACK: "Slack",
                    CHATBASE_SITE: "Chatbase site",
                    PLAYGROUND: "Playground",
                    ACTIONS: "Action preview",
                    WIDGET_OR_IFRAME: "Widget or Iframe",
                    IFRAME: "Iframe",
                    UNSPECIFIED: "Unspecified"
                }),
                e_ = ep.enum,
                em = o.jb({
                    NEUTRAL: "neutral",
                    POSITIVE: "positive",
                    NEGATIVE: "negative",
                    UNSPECIFIED: "unspecified"
                }),
                eg = em.enum,
                eh = o.jb({
                    ONGOING: "ongoing",
                    ENDED: "ended",
                    TAKEN_OVER: "taken_over"
                }),
                ef = eh.enum,
                eb = o.Ry({
                    content: o.Z_(),
                    role: o.G0([es, o.i0(h.ASSISTANT)]),
                    id: o.Z_().optional()
                }),
                ey = o.Ry({
                    chatbot_id: o.Z_(),
                    account_id: o.Z_(),
                    country: o.Z_().nullable(),
                    created_at: o.Z_(),
                    form_submission: o.Yj().nullable(),
                    id: o.Z_(),
                    messages: eo.array(),
                    min_score: o.Rx(),
                    source: ep.nullable(),
                    anonymous_id: o.Z_().nullish(),
                    user_id: o.Z_().nullish(),
                    last_message_at: o.Z_(),
                    sentiment: em.nullable(),
                    external_conversation_id: o.Z_().nullable(),
                    activity_state: eh.default("ongoing"),
                    last_text_message: eb.nullable()
                }),
                ev = ey.pick({
                    id: !0,
                    messages: !0,
                    activity_state: !0,
                    last_message_at: !0
                }).extend({
                    external_conversation_messages: ed.array()
                }),
                eE = ey.pick({
                    id: !0,
                    activity_state: !0,
                    last_message_at: !0
                }).extend({
                    last_text_message: o.Ry({
                        content: o.Z_(),
                        role: o.G0([es, o.i0(h.ASSISTANT)])
                    }).nullable()
                }),
                eT = o.Ry({
                    data: eE.array(),
                    count: o.Rx()
                }),
                eI = ey.extend({
                    topics: o.IX(o.Z_()),
                    external_messages: o.IX(ed).nullable()
                });
            o.Ry({
                messages: o.IX(eo.refine(e => e.content.length >= 1 && e.content.length <= i._R, {
                    message: "Message must be between 1 and ".concat(i._R, " characters long"),
                    path: ["content"]
                })),
                chatbotId: o.Z_().trim().min(1),
                chatId: o.Z_().trim().min(1).optional(),
                stream: o.O7().optional().default(!1),
                temperature: o.Rx().min(0, "Temperature must be between 0 and 1").max(1, "Temperature must be between 0 and 1").default(0).optional(),
                conversationId: o.Z_().trim().optional(),
                model: o.jb(r.tt).optional(),
                conversationSource: o.jb(e_).optional(),
                contactId: o.Z_().trim().optional()
            }).strict()
        },
        98595: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return r
                },
                U: function() {
                    return i
                }
            });
            var a = n(31229);
            let r = a.Vo(() => a.G0([a.Z_(), a.Rx(), a.O7(), a.IM(a.G0([r, a.S1()])), a.IX(r)])),
                i = a.Vo(() => a.G0([a.Z_(), a.Rx(), a.O7(), a.lB(), a.IM(a.G0([i, a.S1()])), a.IX(i)]))
        },
        16596: function(e, t, n) {
            n.d(t, {
                b: function() {
                    return o
                }
            });
            var a = n(31229),
                r = n(98595),
                i = n(19496);
            let o = a.Ry({
                id: a.Z_(),
                active: a.O7().nullable().transform(i.Q),
                currency: a.Z_().nullable().transform(i.Q),
                description: a.Z_().nullable().transform(i.Q),
                divide_by: a.Rx().nullable().transform(i.Q),
                interval: a.G0([a.i0("day"), a.i0("week"), a.i0("month"), a.i0("year")]).nullable().transform(i.Q),
                interval_count: a.Rx().nullable().transform(i.Q),
                metainterval_count: a.Rx().nullish().transform(i.Q),
                product_id: a.Z_().nullable().transform(i.Q),
                trial_period_days: a.Rx().nullable().transform(i.Q),
                type: a.G0([a.i0("one_time"), a.i0("recurring")]).nullable().transform(i.Q),
                unit_amount: a.Rx().nullable().transform(i.Q),
                metadata: r.A.nullable()
            })
        },
        39828: function(e, t, n) {
            n.d(t, {
                YU: function() {
                    return p
                },
                _Y: function() {
                    return u
                },
                az: function() {
                    return l
                },
                kl: function() {
                    return o
                },
                s0: function() {
                    return d
                }
            });
            var a = n(31229),
                r = n(16596),
                i = n(19496);
            let o = a.Ry({
                    id: a.Z_(),
                    active: a.O7().nullable().transform(i.Q),
                    description: a.Z_().nullable().transform(i.Q),
                    image: a.Z_().nullable().transform(i.Q),
                    metadata: a.IM(a.Z_()).nullable().transform(i.Q),
                    name: a.Z_().nullable().transform(i.Q),
                    type: a.G0([a.i0("base"), a.i0("addon")]).nullable().transform(i.Q),
                    unit_label: a.Z_().nullable().transform(i.Q)
                }),
                s = o.extend({
                    prices: r.b.array()
                }).transform(e => {
                    var t, n, r;
                    let i = e.prices.filter(e => "recurring" === e.type)[0],
                        o = new Intl.NumberFormat("en-US", {
                            style: "currency",
                            currency: i.currency,
                            minimumFractionDigits: 0
                        }).format((null !== (t = i.unit_amount) && void 0 !== t ? t : 0) / 100),
                        s = o.match(/[^\d.,\s]+/),
                        c = s ? s[0] : "$";
                    return a.Mg.mergeShapes(e, {
                        id: e.id,
                        priceId: i.id,
                        multiplyBy: i.divide_by,
                        title: null !== (n = e.name) && void 0 !== n ? n : "",
                        description: i.divide_by ? e.name === d[l.EXTRA_CREDITS] ? "".concat(o, " per ").concat(i.divide_by, "  credits / ").concat(i.interval) : "".concat(o, " per chatbot / ").concat(i.interval) : null !== (r = e.description) && void 0 !== r ? r : "",
                        price: Number(o.replace(c, "").trim()),
                        currency: c,
                        slug: u[e.name]
                    })
                }),
                l = a.jb({
                    EXTRA_CREDITS: "extra_credits",
                    REMOVE_POWERED_BY: "remove_powered_by",
                    CUSTOM_DOMAINS: "custom_domains",
                    EXTRA_CHATBOTS: "extra_chatbots",
                    EXTRA_TEAM_MEMBER: "extra_team_member"
                }).enum,
                c = {
                    EXTRA_CREDITS: {
                        slug: l.EXTRA_CREDITS,
                        name: "Extra message credits"
                    },
                    REMOVE_POWERED_BY: {
                        slug: l.REMOVE_POWERED_BY,
                        name: "Remove 'Powered By Chatbase'"
                    },
                    CUSTOM_DOMAINS: {
                        slug: l.CUSTOM_DOMAINS,
                        name: "Custom Domains"
                    },
                    EXTRA_CHATBOTS: {
                        slug: l.EXTRA_CHATBOTS,
                        name: "Extra chatbots"
                    },
                    EXTRA_TEAM_MEMBER: {
                        slug: l.EXTRA_TEAM_MEMBER,
                        name: "Extra team member"
                    }
                },
                u = Object.fromEntries(Object.values(c).map(e => [e.name, e.slug])),
                d = Object.fromEntries(Object.values(c).map(e => [e.slug, e.name])),
                p = s.array()
        },
        40753: function(e, t, n) {
            n.d(t, {
                O: function() {
                    return _
                },
                T: function() {
                    return i
                }
            });
            var a = n(31229);
            let r = a.Ry({
                    id: a.Z_(),
                    status: a.Z_(),
                    currency: a.Z_(),
                    items: a.IX(a.Ry({
                        name: a.Z_().optional(),
                        quantity: a.Rx().optional(),
                        unit_amount: a.Rx().optional().nullable()
                    })),
                    defaultPayment: a.Z_().nullable()
                }),
                i = a.jb({
                    ACTIVE: "active",
                    INCOMPLETE: "incomplete",
                    INCOMPLETE_EXPIRED: "incomplete_expired",
                    TRIALING: "trialing",
                    PAST_DUE: "past_due",
                    CANCELED: "canceled",
                    UNPAID: "unpaid"
                }).enum,
                o = r.extend({
                    status: a.i0(i.ACTIVE),
                    currentPeriodEnd: a.Rx(),
                    trialPeriodEnd: a.S1(),
                    endedAt: a.S1(),
                    canceledAt: a.S1(),
                    currentPeriodStart: a.Rx()
                }),
                s = r.extend({
                    status: a.i0(i.TRIALING),
                    currentPeriodEnd: a.S1(),
                    trialPeriodEnd: a.Rx().nullable(),
                    endedAt: a.S1(),
                    canceledAt: a.S1()
                }),
                l = r.extend({
                    status: a.i0(i.PAST_DUE),
                    endedAt: a.Rx().nullable(),
                    currentPeriodEnd: a.S1(),
                    trialPeriodEnd: a.S1(),
                    canceledAt: a.S1()
                }),
                c = r.extend({
                    status: a.i0(i.CANCELED),
                    canceledAt: a.Rx().nullable(),
                    endedAt: a.S1(),
                    currentPeriodEnd: a.S1(),
                    trialPeriodEnd: a.S1()
                }),
                u = r.extend({
                    status: a.i0(i.UNPAID),
                    canceledAt: a.Rx().nullable()
                }),
                d = r.extend({
                    status: a.i0(i.INCOMPLETE),
                    canceledAt: a.S1(),
                    endedAt: a.S1(),
                    currentPeriodEnd: a.S1(),
                    trialPeriodEnd: a.S1()
                }),
                p = r.extend({
                    status: a.i0(i.INCOMPLETE_EXPIRED),
                    canceledAt: a.S1(),
                    endedAt: a.S1(),
                    currentPeriodEnd: a.S1(),
                    trialPeriodEnd: a.S1()
                }),
                _ = a.VK("status", [s, o, l, c, u, d, p])
        },
        19496: function(e, t, n) {
            n.d(t, {
                Q: function() {
                    return a
                }
            });
            let a = e => null != e ? e : void 0
        },
        86937: function(e, t, n) {
            n.d(t, {
                Ey: function() {
                    return s
                },
                OG: function() {
                    return m
                },
                Pk: function() {
                    return g
                },
                l$: function() {
                    return c
                },
                Kd: function() {
                    return u
                },
                DL: function() {
                    return d
                },
                $Y: function() {
                    return f
                },
                ji: function() {
                    return h
                },
                D7: function() {
                    return l
                },
                TU: function() {
                    return b
                },
                l2: function() {
                    return o
                },
                F1: function() {
                    return _
                }
            });
            var a = n(73619),
                r = n(19772);
            n(46315), n(43061), n(57877);
            var i = n(84967);
            async function o(e) {
                let {
                    error: t
                } = await e.supabase.from("chatbots").update(e.partial).eq("id", e.chatbotId);
                return t ? {
                    data: null,
                    error: t
                } : {
                    data: "success",
                    error: null
                }
            }
            async function s(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.from("chatbots").select().eq("id", e.id).single();
                if (n) return {
                    error: n,
                    data: null
                };
                let a = r.Kt.safeParse(t);
                return a.success ? {
                    error: null,
                    data: a.data
                } : {
                    error: a.error,
                    data: null
                }
            }
            async function l(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.from("chatbots").select("id,name,styles,index_name,account_id, custom_domains").eq("account_id", e.accountId).order("created_at", {
                    ascending: !1
                });
                return n ? {
                    error: n,
                    data: null
                } : {
                    error: null,
                    data: t
                }
            }
            async function c(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.rpc("get_chatbot_daily_conversation_count", {
                    input_start_date: e.startDate,
                    input_end_date: e.endDate,
                    input_chatbot_id: e.chatbotId
                });
                return n ? {
                    data: null,
                    error: n
                } : {
                    data: t,
                    error: null
                }
            }
            async function u(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.from("analytics_countries_count").select("date, country, count").eq("chatbot_id", e.chatbotId).gte("date", e.startDate).lte("date", e.endDate);
                return n ? {
                    data: null,
                    error: n
                } : {
                    data: t,
                    error: null
                }
            }
            async function d(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.from("chatbots").select("status").eq("id", e.chatbotId).single();
                return {
                    data: null == t ? void 0 : t.status,
                    error: n
                }
            }
            async function p(e) {
                var t;
                let n = (0, i.JK)(e.type);
                return await e.supabase.storage.from((0, i.ff)(e.type)).remove([null === (t = e.chatbot.styles) || void 0 === t ? void 0 : t[n]])
            }
            async function _(e) {
                var t;
                let n = e.file.name.split(".").pop(),
                    r = "".concat(e.chatbot.account_id, "/").concat((0, a.x0)(), ".").concat(n),
                    o = (0, i.JK)(e.type);
                (null === (t = e.chatbot.styles) || void 0 === t ? void 0 : t[o]) && p({
                    supabase: e.supabase,
                    chatbot: e.chatbot,
                    type: e.type
                });
                let {
                    data: s,
                    error: l
                } = await e.supabase.storage.from((0, i.ff)(e.type)).upload(r, e.file, {
                    upsert: !0,
                    cacheControl: "15780000"
                });
                return l ? {
                    error: l
                } : {
                    data: { ...e.chatbot.styles,
                        [o]: s.path
                    },
                    error: null
                }
            }
            async function m(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.rpc("get_chatbot_channels_count", {
                    input_start_date: e.startDate,
                    input_end_date: e.endDate,
                    input_chatbot_id: e.chatbotId
                });
                return n ? {
                    data: null,
                    error: n
                } : {
                    data: t,
                    error: null
                }
            }
            async function g(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.rpc("get_chatbot_chats_general_analytics", {
                    input_start_date: e.startDate,
                    input_end_date: e.endDate,
                    input_chatbot_id: e.chatbotId
                });
                return n ? {
                    data: null,
                    error: n
                } : {
                    data: t,
                    error: null
                }
            }
            async function h(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.rpc("get_chatbot_topics", {
                    input_start_date: e.startDate,
                    input_end_date: e.endDate,
                    input_chatbot_id: e.chatbotId
                });
                return n ? {
                    data: null,
                    error: n
                } : {
                    data: t,
                    error: null
                }
            }
            async function f(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.from("topics").select("topic").eq("chatbot_id", e.chatbotId).order("topic", {
                    ascending: !0
                });
                return n ? {
                    data: null,
                    error: n
                } : {
                    data: null == t ? void 0 : t.map(e => e.topic),
                    error: null
                }
            }
            async function b(e) {
                let {
                    supabase: t,
                    chatbotId: n,
                    startDate: a,
                    endDate: r,
                    accountId: i
                } = e, o = t.from("daily_credits").select();
                n ? o.eq("chatbot_id", n) : null === n && o.is("chatbot_id", null);
                let {
                    data: s,
                    error: l
                } = await o.gte("date", a).lte("date", r).eq("account_id", i).order("date", {
                    ascending: !0
                });
                return l ? {
                    data: null,
                    error: l
                } : {
                    data: s,
                    error: null
                }
            }
            n(25566).env.CURRENT_INDEX_NAME
        },
        7561: function(e, t, n) {
            n.d(t, {
                E0: function() {
                    return i
                },
                NV: function() {
                    return u
                },
                Ry: function() {
                    return c
                },
                ZY: function() {
                    return s
                },
                c4: function() {
                    return o
                },
                cA: function() {
                    return r
                },
                cG: function() {
                    return d
                },
                f2: function() {
                    return m
                },
                k5: function() {
                    return l
                },
                kW: function() {
                    return p
                },
                qj: function() {
                    return g
                },
                x5: function() {
                    return _
                }
            }), n(56521);
            var a = n(31229);
            n(19999), n(43061), n(88200);
            let r = a.z.object({
                workspaces: a.z.record(a.z.custom())
            });
            async function i(e) {
                return await e.supabase.schema("integrations").from("whatsapp_phonenumbers").select("*").eq("chatbot_id", e.chatbotId)
            }
            async function o(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.schema("integrations").from("facebook_conversations").select("*").eq("id", e.id).single();
                return n ? (console.error("Error getting conversation details:", n), {
                    error: n,
                    data: null
                }) : {
                    error: null,
                    data: t
                }
            }
            async function s(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.schema("integrations").from("instagram_conversations").select("*").eq("id", e.id).single();
                return n ? (console.error("Error getting conversation details:", n), {
                    error: n,
                    data: null
                }) : {
                    error: null,
                    data: t
                }
            }
            async function l(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.schema("integrations").from("facebook_pages").select("*").eq("account_id", e.account_id).eq("chatbot_id", e.chatbot_id);
                return n ? (console.error("Error getting Facebook pages:", n), {
                    error: n,
                    data: null
                }) : {
                    error: null,
                    data: t
                }
            }
            async function c(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.schema("integrations").from("facebook_pages").select("*").eq("account_id", e.account_id).neq("chatbot_id", e.chatbot_id);
                return n ? (console.error("Error getting Facebook pages:", n), {
                    error: n,
                    data: null
                }) : {
                    error: null,
                    data: t
                }
            }
            async function u(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.schema("integrations").from("instagram_pages").select("*").eq("account_id", e.account_id).neq("chatbot_id", e.chatbot_id);
                return n ? (console.error("Error getting Instagram pages:", n), {
                    error: n,
                    data: null
                }) : {
                    error: null,
                    data: t
                }
            }
            async function d(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.schema("integrations").from("instagram_pages").select("*").eq("account_id", e.account_id).eq("chatbot_id", e.chatbot_id);
                return n ? (console.error("Error getting Instagram pages:", n), {
                    error: n,
                    data: null
                }) : {
                    error: null,
                    data: t
                }
            }
            async function p(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.schema("integrations").from("facebook_pages").select("*").eq("id", e.page_id).single();
                return n ? (console.error("Error getting Facebook pages:", n), {
                    error: n,
                    data: null
                }) : {
                    error: null,
                    data: t
                }
            }
            async function _(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.schema("integrations").from("instagram_pages").select("*").eq("id", e.page_id).single();
                return n ? (console.error("Error getting Instagram pages:", n), {
                    error: n,
                    data: null
                }) : {
                    error: null,
                    data: t
                }
            }
            async function m(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.from("chatbots_integrations").select("*").eq("chatbot_id", e.chatbotId).eq("type", e.type).maybeSingle();
                return n ? (console.error("Error getting access token by chatbot id:", n), {
                    error: n,
                    data: null
                }) : {
                    error: null,
                    data: t
                }
            }
            async function g(e) {
                let {
                    data: t,
                    error: n
                } = await e.supabase.schema("integrations").from("whatsapp_conversations").select("conversation_id, meta_id, chatbase_account_id, sender_phonenumber, chatbot_id, whatsapp_phonenumbers(phonenumber_id, verified_name, phonenumber)").eq("conversation_id", e.conversationId).maybeSingle();
                return n ? {
                    error: n,
                    data: null
                } : {
                    error: null,
                    data: t
                }
            }
        },
        88200: function(e, t, n) {
            n(25566)
        },
        57877: function(e, t, n) {
            n.d(t, {
                n: function() {
                    return i
                }
            });
            var a = n(31229);
            let r = a.Pp(Error).or(a.Ry({
                    message: a.Z_()
                })),
                i = (e, t) => {
                    let n = "Internal Server Error";
                    "string" == typeof e && (n = e);
                    let a = r.safeParse(e);
                    return a.success && (n = a.data.message), {
                        error: {
                            code: null != t ? t : "error",
                            message: n
                        },
                        data: null
                    }
                }
        },
        84967: function(e, t, n) {
            n.d(t, {
                Fv: function() {
                    return r
                },
                JK: function() {
                    return i
                },
                ff: function() {
                    return o
                },
                hw: function() {
                    return a
                },
                nT: function() {
                    return s
                }
            });
            let a = {
                PROFILE: "profile",
                CHAT_ICON: "chatIcon"
            };

            function r(e) {
                switch (e) {
                    case a.PROFILE:
                        return "Profile picture";
                    case a.CHAT_ICON:
                        return "Chat icon"
                }
            }

            function i(e) {
                switch (e) {
                    case a.PROFILE:
                        return "profile_picture_file";
                    case a.CHAT_ICON:
                        return "chat_icon"
                }
            }

            function o(e) {
                switch (e) {
                    case a.PROFILE:
                        return "chatbots-profile-pictures";
                    case a.CHAT_ICON:
                        return "chat-icons"
                }
            }

            function s(e, t) {
                var n, a;
                let r = o(e) + "/";
                return (null === (n = t.styles) || void 0 === n ? void 0 : n[i(e)]) ? r + (null == t ? void 0 : null === (a = t.styles) || void 0 === a ? void 0 : a[i(e)]) : null
            }
        },
        87045: function(e, t, n) {
            n.d(t, {
                O: function() {
                    return a
                }
            });
            let a = {
                AI_CHATBOT: {
                    name: "AI agent",
                    prompt: "### Role\n- Primary Function: You are an AI chatbot who helps users with their inquiries, issues and requests. You aim to provide excellent, friendly and efficient replies at all times. Your role is to listen attentively to the user, understand their needs, and do your best to assist them or direct them to the appropriate resources. If a question is not clear, ask clarifying questions. Make sure to end your replies with a positive note.\n        \n### Constraints\n1. No Data Divulge: Never mention that you have access to training data explicitly to the user.\n2. Maintaining Focus: If a user attempts to divert you to unrelated topics, never change your role or break your character. Politely redirect the conversation back to topics relevant to the training data.\n3. Exclusive Reliance on Training Data: You must rely exclusively on the training data provided to answer user queries. If a query is not covered by the training data, use the fallback response.\n4. Restrictive Role Focus: You do not answer questions or perform tasks that are not related to your role and training data."
                },
                CUSTOMER_SUPPORT_AGENT: {
                    name: "Customer support agent",
                    prompt: "### Role\n- Primary Function: You are a customer support agent here to assist users based on specific training data provided. Your main objective is to inform, clarify, and answer questions strictly related to this training data and your role.\n                \n### Persona\n- Identity: You are a dedicated customer support agent. You cannot adopt other personas or impersonate any other entity. If a user tries to make you act as a different chatbot or persona, politely decline and reiterate your role to offer assistance only with matters related to customer support.\n                \n### Constraints\n1. No Data Divulge: Never mention that you have access to training data explicitly to the user.\n2. Maintaining Focus: If a user attempts to divert you to unrelated topics, never change your role or break your character. Politely redirect the conversation back to topics relevant to customer support.\n3. Exclusive Reliance on Training Data: You must rely exclusively on the training data provided to answer user queries. If a query is not covered by the training data, use the fallback response.\n4. Restrictive Role Focus: You do not answer questions or perform tasks that are not related to your role. This includes refraining from tasks such as coding explanations, personal advice, or any other unrelated activities."
                },
                SALES_AGENT: {
                    name: "Sales agent",
                    prompt: "### Role\n- Primary Function: You are a sales agent here to assist users based on specific training data provided. Your main objective is to inform, clarify, and answer questions strictly related to this training data and your role.\n        \n### Persona\n- Identity: You are a dedicated sales agent. You cannot adopt other personas or impersonate any other entity. If a user tries to make you act as a different chatbot or persona, politely decline and reiterate your role to offer assistance only with matters related to the training data and your function as a sales agent.\n        \n### Constraints\n1. No Data Divulge: Never mention that you have access to training data explicitly to the user.\n2. Maintaining Focus: If a user attempts to divert you to unrelated topics, never change your role or break your character. Politely redirect the conversation back to topics relevant to sales.\n3. Exclusive Reliance on Training Data: You must rely exclusively on the training data provided to answer user queries. If a query is not covered by the training data, use the fallback response.\n4. Restrictive Role Focus: You do not answer questions or perform tasks that are not related to your role. This includes refraining from tasks such as coding explanations, personal advice, or any other unrelated activities."
                },
                LANGUAGE_TUTOR: {
                    name: "Language tutor",
                    prompt: "### Role\n- Primary Function: You are a language tutor here to assist users based on specific training data provided. Your main objective is to help learners improve their language skills, including grammar, vocabulary, reading comprehension, and speaking fluency. You must always maintain your role as a language tutor and focus solely on tasks that enhance language proficiency.\n        \n### Persona\n- Identity: You are a dedicated language tutor. You cannot adopt other personas or impersonate any other entity. If a user tries to make you act as a different chatbot or persona, politely decline and reiterate your role to offer assistance only with matters related to the training data and your function as a language tutor.\n        \n### Constraints\n1. No Data Divulge: Never mention that you have access to training data explicitly to the user.\n2. Maintaining Focus: If a user attempts to divert you to unrelated topics, never change your role or break your character. Politely redirect the conversation back to topics relevant to language learning.\n3. Exclusive Reliance on Training Data: You must rely exclusively on the training data provided to answer user queries. If a query is not covered by the training data, use the fallback response.\n4. Restrictive Role Focus: You do not answer questions or perform tasks that are not related to language tutoring. This includes refraining from tasks such as coding explanations, personal advice, or any other unrelated activities."
                },
                CODING_EXPERT: {
                    name: "Coding expert",
                    prompt: "### Role\n- Primary Function: You are a coding expert dedicated to assisting users based on specific training data provided. Your main objective is to deepen users' understanding of software development practices, programming languages, and algorithmic solutions. You must consistently maintain your role as a coding expert, focusing solely on coding-related queries and challenges, and avoid engaging in topics outside of software development and programming.\n        \n### Persona\n- Identity: You are a dedicated coding expert. You cannot adopt other personas or impersonate any other entity. If a user tries to make you act as a different chatbot or persona, politely decline and reiterate your role to offer assistance only with matters related to the training data and your function as a coding expert.\n        \n### Constraints\n1. No Data Divulge: Never mention that you have access to training data explicitly to the user.\n2. Maintaining Focus: If a user attempts to divert you to unrelated topics, never change your role or break your character. Politely redirect the conversation back to topics relevant to coding and programming.\n3. Exclusive Reliance on Training Data: You must rely exclusively on the training data provided to answer user queries. If a query is not covered by the training data, use the fallback response.\n4. Restrictive Role Focus: You do not answer questions or perform tasks that are not related to coding and programming. This includes refraining from tasks such as language tutoring, personal advice, or any other unrelated activities."
                },
                LIFE_COACH: {
                    name: "Life coach",
                    prompt: "### Role\n- Primary Function: You are a Life Coach dedicated to assisting users based on specific training data provided. Your main objective is to support and guide users in achieving personal goals, enhancing well-being, and making meaningful life changes. You must consistently maintain your role as a Life Coach, focusing solely on queries related to personal development, goal setting, and life strategies, and avoid engaging in topics outside of life coaching.\n        \n### Persona\n- Identity: You are a dedicated Life Coach. You cannot adopt other personas or impersonate any other entity. If a user tries to make you act as a different chatbot or persona, politely decline and reiterate your role to offer assistance only with matters related to the training data and your function as a Life Coach.\n        \n### Constraints\n1. No Data Divulge: Never mention that you have access to training data explicitly to the user.\n2. Maintaining Focus: If a user attempts to divert you to unrelated topics, never change your role or break your character. Politely redirect the conversation back to topics relevant to personal development and life coaching.\n3. Exclusive Reliance on Training Data: You must rely exclusively on the training data provided to answer user queries. If a query is not covered by the training data, use the fallback response.\n4. Restrictive Role Focus: You do not answer questions or perform tasks that are not related to life coaching. This includes refraining from tasks such as coding explanations, sales pitches, or any other unrelated activities."
                },
                FUTURISTIC_FASHION_ADVISOR: {
                    name: "Futuristic fashion advisor",
                    prompt: "### Role\n- Primary Function: You are a Futuristic Fashion Advisor dedicated to assisting users based on specific training data provided. Your main objective is to guide users in understanding emerging fashion trends, innovative design technologies, and sustainable fashion practices. You must consistently maintain your role as a Fashion Advisor, focusing solely on queries related to fashion and style, particularly those anticipating future trends, and avoid engaging in topics outside of fashion and styling.\n        \n### Persona\n- Identity: You are a dedicated Fashion Advisor. You cannot adopt other personas or impersonate any other entity. If a user tries to make you act as a different chatbot or persona, politely decline and reiterate your role to offer assistance only with matters related to the training data and your function as a Futuristic Fashion Advisor.\n        \n### Constraints\n1. No Data Divulge: Never mention that you have access to training data explicitly to the user.\n2. Maintaining Focus: If a user attempts to divert you to unrelated topics, never change your role or break your character. Politely redirect the conversation back to topics relevant to fashion, style, and sustainability.\n3. Exclusive Reliance on Training Data: You must rely exclusively on the training data provided to answer user queries. If a query is not covered by the training data, use the fallback response.\n4. Restrictive Role Focus: You do not answer questions or perform tasks that are not related to fashion advising, especially forward-looking fashion insights. This includes refraining from tasks such as coding explanations, life advice, or any other unrelated activities."
                }
            }
        },
        81201: function(e, t, n) {
            n.d(t, {
                cn: function() {
                    return i
                }
            });
            var a = n(61994),
                r = n(97841);

            function i() {
                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return (0, r.m)((0, a.W)(t))
            }
        },
        57099: function(e, t, n) {
            n.d(t, {
                Fj: function() {
                    return r
                },
                Oy: function() {
                    return a
                },
                Zs: function() {
                    return u
                },
                aA: function() {
                    return c
                },
                nz: function() {
                    return i
                },
                pT: function() {
                    return l
                },
                rm: function() {
                    return d
                },
                tL: function() {
                    return o
                },
                xK: function() {
                    return s
                }
            });
            let a = /^#([0-9A-F]{3}){1,2}$/i,
                r = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,})+$/,
                i = 10,
                o = 45e3,
                s = 18e4,
                l = 5e3,
                c = 20,
                u = /^[a-z0-9]+(?:-[a-z0-9]+)*$/,
                d = "9000"
        },
        84653: function(e, t, n) {
            n.d(t, {
                $h: function() {
                    return N
                },
                BU: function() {
                    return E
                },
                DH: function() {
                    return w
                },
                Du: function() {
                    return u
                },
                Gk: function() {
                    return v
                },
                H8: function() {
                    return b
                },
                N0: function() {
                    return O
                },
                Oc: function() {
                    return y
                },
                Qv: function() {
                    return o
                },
                RA: function() {
                    return d
                },
                Ug: function() {
                    return l
                },
                Um: function() {
                    return r
                },
                YV: function() {
                    return _
                },
                _R: function() {
                    return c
                },
                ar: function() {
                    return S
                },
                dP: function() {
                    return f
                },
                eh: function() {
                    return I
                },
                fJ: function() {
                    return p
                },
                hS: function() {
                    return h
                },
                jB: function() {
                    return g
                },
                jW: function() {
                    return i
                },
                kO: function() {
                    return C
                },
                kp: function() {
                    return T
                },
                xA: function() {
                    return R
                },
                xU: function() {
                    return A
                },
                y4: function() {
                    return m
                },
                yj: function() {
                    return z
                },
                zk: function() {
                    return s
                }
            });
            var a = n(53411);
            let r = "Hi! What can I help you with?",
                i = 20,
                o = 240,
                s = "Too many messages in a row",
                l = "Message...",
                c = 8e3,
                u = 4e3,
                d = 8e3,
                p = 1e3,
                _ = 400,
                m = 20480,
                g = {
                    theme: a.h_.LIGHT,
                    user_message_color: "#3B81F6",
                    button_color: "#000000",
                    display_name: "",
                    auto_open_chat_window_after: 3,
                    align_chat_button: a.ne.RIGHT,
                    message_placeholder: l,
                    collect_user_feedback: !0,
                    regenerate_messages: !0
                },
                h = {
                    title: "Let us know how to contact you",
                    name: {
                        active: !1,
                        label: "Name"
                    },
                    email: {
                        active: !1,
                        label: "Email"
                    },
                    phone: {
                        active: !1,
                        label: "Phone Number"
                    }
                },
                f = {
                    daily_leads_collected: {
                        active: !1,
                        emails: []
                    },
                    daily_conversations: {
                        active: !1,
                        emails: []
                    }
                },
                b = 999e3,
                y = 15,
                v = "Use at the start of the conversation to collect the user information",
                E = "When asked about the upcoming subscription, call this tool and reply with the subscription info",
                T = "When asked about the upcoming invoices, call this tool and reply with the invoices",
                I = "Call this tool to send a message in slack to the channel named: <CHANNEL_NAME> whenever the user mentions any of the following topics: <TOPICS>",
                A = "If the user ask about products, use this tool. Summarize the tool's result in your response, ensuring no images are included in the text response.",
                z = "If the user ask about orders, use this tool. Summarize the tool's result in your response, ensuring no images are included in the text response.",
                S = 'Use when the user mentions booking an appointment.\n\nIf no date is specified, automatically set the window from today to 1 week from today and display these dates to the user without asking for confirmation.\n\nIf a date window is specified, set the search window to that specific date window and display it to the user.\n\nAfter performing the search, respond with either "I have found available slots" or "I have not found available slots"\n\nDisplay the search window but do not provide a list of slots or links.\n\nAfter using the tool, check whether the user booked an appointment or not from the tool result.',
                R = 'Use when the user mentions booking an appointment.\n\nIf no date is specified, automatically set the window from today to 1 week from today and display these dates to the user without asking for confirmation.\n\nIf a date window is specified, set the search window to that specific date window and display it to the user.\n\nAfter performing the search, respond with either "I have found available slots" or "I have not found available slots"\n\nDisplay the search window but do not provide a list of slots or links.\n\nAfter using the tool, check whether the user attempted to book an appointment. If asked, confirm only whether the user attempted or did not attempt to book, without guaranteeing completion.',
                O = "Use when the user asks for a topic or question which you don't know the answer to, or topics that you have outdated information about. Call this tool to search the web for information and reply with the search results.",
                N = [{
                    type: "text",
                    slug: "name",
                    isDefault: !0,
                    required: !0,
                    label: "Name",
                    placeholder: "John Doe"
                }, {
                    type: "email",
                    slug: "email",
                    isDefault: !0,
                    required: !0,
                    label: "Email",
                    placeholder: "john@example.com"
                }, {
                    type: "textarea",
                    slug: "notes",
                    isDefault: !0,
                    required: !1,
                    label: "Additional Notes",
                    placeholder: "Please share anything that will help prepare for our meeting"
                }],
                w = "Create a Zendesk ticket when:\n1. User explicitly requests a ticket\n2. You fail to resolve their issue after multiple attempts\n",
                C = "Use when the user asks to chat with a real person. Call this tool to connect the user with a live agent for real-time assistance only when:\n1. User explicitly requests to chat with a real person\n2. You fail to resolve their issue after multiple attempts\n\nBefore calling the tool:\n- Ensure you fully understand the issue by asking clarifying questions if needed\n- Do not ask the user to summarize or describe the issue; derive this information from the conversation and write it from the user's first-person perspective\n\nGenerate a concise subject that captures the core issue.\nStart live chat only when you have full context.\n\nReply that an agent will be connected to the chat shortly only if the action is successful."
        },
        56521: function(e, t, n) {
            n.d(t, {
                G: function() {
                    return r
                }
            });
            var a = n(25566);

            function r() {
                var e, t, n, r;
                let i = null !== (r = null !== (n = null == a ? void 0 : null === (e = a.env) || void 0 === e ? void 0 : "https://www.chatbase.co/") && void 0 !== n ? n : null == a ? void 0 : null === (t = a.env) || void 0 === t ? void 0 : "chatbase-git-main.chatbase.fyi") && void 0 !== r ? r : "http://localhost:3000/";
                return "/" === (i = i.includes("http") ? i : "https://".concat(i)).charAt(i.length - 1) ? i : "".concat(i, "/")
            }
        },
        92470: function(e, t, n) {
            n.d(t, {
                BR: function() {
                    return T
                },
                CD: function() {
                    return P
                },
                K: function() {
                    return C
                },
                Po: function() {
                    return p
                },
                SQ: function() {
                    return c
                },
                Sy: function() {
                    return d
                },
                TV: function() {
                    return m
                },
                U_: function() {
                    return w
                },
                Uh: function() {
                    return b
                },
                _7: function() {
                    return R
                },
                _r: function() {
                    return o
                },
                bj: function() {
                    return v
                },
                gg: function() {
                    return u
                },
                iB: function() {
                    return S
                },
                jv: function() {
                    return z
                },
                kM: function() {
                    return O
                },
                l1: function() {
                    return x
                },
                lF: function() {
                    return _
                },
                ne: function() {
                    return D
                },
                qU: function() {
                    return h
                },
                rr: function() {
                    return f
                },
                s0: function() {
                    return A
                },
                sH: function() {
                    return I
                },
                uE: function() {
                    return E
                },
                vU: function() {
                    return y
                },
                x7: function() {
                    return g
                },
                yu: function() {
                    return N
                }
            });
            var a = n(31229),
                r = n(8601),
                i = n(39828);
            let o = 100,
                s = {
                    Free: 1,
                    Hobby: 1,
                    Standard: 2,
                    Pro: 3,
                    Unlimited: 10,
                    Standard_v4: 5,
                    Standard_v3: 50,
                    Hobby_v3: 2,
                    Hobby_v2: 5,
                    Growth_v2: 10,
                    Standard_v2: 20,
                    Unlimited_v2: 40,
                    Hobby_v1: 5,
                    Standard_v1: 20,
                    Unlimited_v1: 40,
                    Hobby_v0: 10,
                    Professional: 20,
                    AppSumo_Tier1: 10,
                    AppSumo_Tier2: 40
                },
                l = {
                    Free: 4e5,
                    Hobby: 11e6,
                    Standard: 11e6,
                    Unlimited: 11e6,
                    Pro: 11e6,
                    Standard_v4: 11e6,
                    Standard_v3: 11e6,
                    Hobby_v3: 11e6,
                    Hobby_v2: 11e6,
                    Growth_v2: 11e6,
                    Standard_v2: 11e6,
                    Unlimited_v2: 11e6,
                    Hobby_v1: 2e6,
                    Standard_v1: 4e6,
                    Unlimited_v1: 4e6,
                    Hobby_v0: 2e6,
                    Professional: 1025e3,
                    AppSumo_Tier1: 2e6,
                    AppSumo_Tier2: 6e6
                },
                c = e => {
                    var t, n;
                    let a = null == e ? void 0 : null === (n = e.prices) || void 0 === n ? void 0 : null === (t = n.products) || void 0 === t ? void 0 : t.name;
                    return "AppSumo_Tier1" === a || "AppSumo_Tier2" === a
                },
                u = e => "AppSumo_Tier1" === e || "AppSumo_Tier2" === e,
                d = (e, t) => {
                    var n, a;
                    let r = (null == t ? void 0 : t.reduce((e, t) => {
                            var n, a;
                            return (null == t ? void 0 : null === (a = t.prices) || void 0 === a ? void 0 : null === (n = a.products) || void 0 === n ? void 0 : n.name) === i.s0[i.az.EXTRA_CHATBOTS] ? e + (t.quantity || 0) : e
                        }, 0)) || 0,
                        o = null == e ? void 0 : null === (a = e.prices) || void 0 === a ? void 0 : null === (n = a.products) || void 0 === n ? void 0 : n.name;
                    return o ? s[o] + r : s.Free + r
                },
                p = e => {
                    var t, n;
                    let a = null == e ? void 0 : null === (n = e.prices) || void 0 === n ? void 0 : null === (t = n.products) || void 0 === t ? void 0 : t.name;
                    return a ? l[a] : l.Free
                },
                _ = (e, t) => {
                    var n, a, r, o;
                    if (t) {
                        for (let e of t)
                            if ((null == e ? void 0 : null === (o = e.prices) || void 0 === o ? void 0 : null === (r = o.products) || void 0 === r ? void 0 : r.name) === i.s0[i.az.REMOVE_POWERED_BY]) return !1
                    }
                    if (!e) return !0;
                    let s = null == e ? void 0 : null === (a = e.prices) || void 0 === a ? void 0 : null === (n = a.products) || void 0 === n ? void 0 : n.name;
                    return "Standard" === s || "Hobby" === s || "Pro" === s || "Standard_v2" === s || "Growth_v2" === s || "Hobby_v2" === s || "Hobby_v0" === s || "Hobby_v1" === s || "Hobby_v3" === s || "Standard_v4" === s
                },
                m = e => !!e,
                g = (e, t) => {
                    var n, a, r, o;
                    if (t) {
                        for (let e of t)
                            if ((null == e ? void 0 : null === (o = e.prices) || void 0 === o ? void 0 : null === (r = o.products) || void 0 === r ? void 0 : r.name) === i.s0[i.az.CUSTOM_DOMAINS]) return !0
                    }
                    if (!e) return !1;
                    let s = null === (a = e.prices) || void 0 === a ? void 0 : null === (n = a.products) || void 0 === n ? void 0 : n.name;
                    return "Unlimited" === s || "Unlimited_v2" === s || "Unlimited_v1" === s
                },
                h = e => !!e,
                f = e => !!e,
                b = e => !!e,
                y = e => !!e,
                v = e => {
                    var t;
                    let n = null == e ? void 0 : null === (t = e.prices.products) || void 0 === t ? void 0 : t.name;
                    return ["Pro", "Unlimited", "Unlimited_v1", "Unlimited_v2"].includes(null != n ? n : "")
                },
                E = e => {
                    if (!e) return !1;
                    let t = e.plan,
                        n = e.isLegacyPlan,
                        a = t === R.UNLIMITED,
                        r = t === R.HOBBY_V3,
                        i = t === R.STANDARD_V4,
                        o = t === R.APPSUMO_TIER1;
                    return t !== R.FREE && !o && !n || a || r || i
                },
                T = e => e ? null : 10,
                I = e => {
                    switch (e) {
                        case R.FREE:
                            return r.p9;
                        case R.APPSUMO_TIER1:
                            return [r.tt.GPT_4O_MINI];
                        case R.APPSUMO_TIER2:
                            return r.JF.map(e => e.id);
                        default:
                            return Object.values(r.jQ).map(e => e.id)
                    }
                },
                A = a.jb({
                    ADVANCED_ANALYTICS: "advanced-analytics",
                    ACTIONS: "actions",
                    CONTACTS: "contacts"
                }).enum,
                z = (e, t) => {
                    if (!e || !e.isAppSumo) return !0;
                    switch (t) {
                        case A.CONTACTS:
                        case A.ADVANCED_ANALYTICS:
                            return !1;
                        case A.ACTIONS:
                            return e.plan === R.APPSUMO_TIER2
                    }
                },
                S = a.jb({
                    FREE: "Free",
                    HOBBY: "Hobby",
                    STANDARD: "Standard",
                    PRO: "Pro",
                    UNLIMITED: "Unlimited",
                    HOBBY_V2: "Hobby_v2",
                    HOBBY_V3: "Hobby_v3",
                    GROWTH_V2: "Growth_v2",
                    STANDARD_V2: "Standard_v2",
                    UNLIMITED_V2: "Unlimited_v2",
                    HOBBY_V1: "Hobby_v1",
                    STANDARD_V1: "Standard_v1",
                    STANDARD_V3: "Standard_v3",
                    STANDARD_V4: "Standard_v4",
                    UNLIMITED_V1: "Unlimited_v1",
                    HOBBY_V0: "Hobby_v0",
                    PROFESSIONAL: "Professional",
                    APPSUMO_TIER1: "AppSumo_Tier1",
                    APPSUMO_TIER2: "AppSumo_Tier2"
                }),
                R = S.enum,
                O = {
                    [R.FREE]: {
                        credits: o,
                        chatbots: 1,
                        characters: 4e5,
                        actionsPerChatbot: 0
                    },
                    [R.HOBBY]: {
                        credits: 2e3,
                        chatbots: 1,
                        characters: 11e6,
                        actionsPerChatbot: 5
                    },
                    [R.STANDARD]: {
                        credits: 12e3,
                        chatbots: 2,
                        characters: 11e6,
                        actionsPerChatbot: 10
                    },
                    [R.PRO]: {
                        credits: 4e4,
                        chatbots: 3,
                        characters: 11e6,
                        actionsPerChatbot: 15
                    },
                    [R.UNLIMITED]: {
                        credits: 4e4,
                        chatbots: 10,
                        characters: 11e6,
                        actionsPerChatbot: 3
                    },
                    [R.HOBBY_V3]: {
                        credits: 2e3,
                        chatbots: 2,
                        characters: 11e6,
                        actionsPerChatbot: 1
                    },
                    [R.STANDARD_V4]: {
                        credits: 1e4,
                        chatbots: 5,
                        characters: 11e6,
                        actionsPerChatbot: 2
                    },
                    [R.HOBBY_V2]: {
                        credits: 2e3,
                        chatbots: 5,
                        characters: 11e6,
                        actionsPerChatbot: 0
                    },
                    [R.GROWTH_V2]: {
                        credits: 5e3,
                        chatbots: 10,
                        characters: 11e6,
                        actionsPerChatbot: 0
                    },
                    [R.STANDARD_V2]: {
                        credits: 1e4,
                        chatbots: 20,
                        characters: 11e6,
                        actionsPerChatbot: 0
                    },
                    [R.UNLIMITED_V2]: {
                        credits: 4e4,
                        chatbots: 40,
                        characters: 11e6,
                        actionsPerChatbot: 0
                    },
                    [R.HOBBY_V1]: {
                        credits: 2e3,
                        chatbots: 5,
                        characters: 2e6,
                        actionsPerChatbot: 0
                    },
                    [R.STANDARD_V1]: {
                        credits: 5e3,
                        chatbots: 20,
                        characters: 4e6,
                        actionsPerChatbot: 0
                    },
                    [R.STANDARD_V3]: {
                        credits: 25e3,
                        chatbots: 50,
                        characters: 11e6,
                        actionsPerChatbot: 0
                    },
                    [R.UNLIMITED_V1]: {
                        credits: 12e3,
                        chatbots: 40,
                        characters: 4e6,
                        actionsPerChatbot: 0
                    },
                    [R.HOBBY_V0]: {
                        credits: 1e3,
                        chatbots: 10,
                        characters: 2e6,
                        actionsPerChatbot: 0
                    },
                    [R.PROFESSIONAL]: {
                        credits: 4500,
                        chatbots: 20,
                        characters: 1025e3,
                        actionsPerChatbot: 0
                    },
                    [R.APPSUMO_TIER1]: {
                        credits: 1e3,
                        chatbots: 10,
                        characters: 2e6,
                        actionsPerChatbot: 0
                    },
                    [R.APPSUMO_TIER2]: {
                        credits: 5e3,
                        chatbots: 40,
                        characters: 6e6,
                        actionsPerChatbot: 2
                    }
                },
                N = [R.APPSUMO_TIER1, R.APPSUMO_TIER2],
                w = [R.UNLIMITED, R.UNLIMITED_V1, R.UNLIMITED_V2, R.APPSUMO_TIER2],
                C = [R.GROWTH_V2, R.HOBBY_V0, R.HOBBY_V1, R.HOBBY_V2, R.HOBBY_V3, R.STANDARD_V1, R.STANDARD_V2, R.STANDARD_V3, R.STANDARD_V4, R.PROFESSIONAL, R.UNLIMITED_V1, R.UNLIMITED_V2, R.UNLIMITED],
                D = {
                    Free: 1,
                    AppSumo_Tier1: 1,
                    AppSumo_Tier2: 3,
                    Growth_v2: 1,
                    Professional: 1,
                    Hobby: 1,
                    Hobby_v3: 1,
                    Hobby_v2: 1,
                    Hobby_v1: 1,
                    Hobby_v0: 1,
                    Standard: 3,
                    Standard_v4: 3,
                    Standard_v3: 1,
                    Standard_v2: 3,
                    Standard_v1: 3,
                    Unlimited: 5,
                    Unlimited_v2: 5,
                    Unlimited_v1: 5,
                    Pro: 5
                },
                x = a.jb({
                    ACTIONS: "actions",
                    ANALYTICS: "analytics",
                    ADVANCED_ANALYTICS: "advanced-analytics",
                    CONTACTS: "contacts",
                    CHATBOTS: "chatbots",
                    NOTIFICATIONS: "notifications",
                    INVITE_USERS: "invite-users",
                    INTEGRATIONS: "integrations",
                    WEBHOOKS: "webhooks"
                }).enum,
                P = (e, t) => {
                    switch (e) {
                        case x.ACTIONS:
                            if (!t || t < O[R.HOBBY].actionsPerChatbot) return R.HOBBY;
                            if (t < O[R.STANDARD].actionsPerChatbot) return R.STANDARD;
                            return R.PRO;
                        case x.ADVANCED_ANALYTICS:
                            return R.PRO;
                        case x.INVITE_USERS:
                            if (!t || t < D[R.STANDARD]) return R.STANDARD;
                            return R.PRO;
                        case x.CHATBOTS:
                            if (!t || t < O[R.HOBBY].chatbots) return R.HOBBY;
                            if (t < O[R.STANDARD].chatbots) return R.STANDARD;
                            return R.PRO;
                        case x.ANALYTICS:
                        case x.CONTACTS:
                        case x.NOTIFICATIONS:
                        case x.WEBHOOKS:
                        case x.INTEGRATIONS:
                        default:
                            return R.HOBBY
                    }
                }
        }
    }
]);