"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4522], {
        6705: function(e, t, a) {
            a.d(t, {
                K: function() {
                    return I
                }
            });
            var n = a(57437),
                l = a(43061),
                r = a(12381),
                s = a(69076),
                i = a(53206),
                o = a(51945),
                c = a(67948),
                d = a(5008),
                u = a(24349),
                m = a(7405),
                h = a(80222),
                v = a(36174),
                x = a(34021),
                g = a(2551),
                p = a(71488),
                f = a(2265),
                b = a(81201),
                k = a(83535);

            function j(e) {
                var t;
                let {
                    messageId: a,
                    isLast: l,
                    collectUserFeedback: s,
                    allowRegenerateMessages: i
                } = e, o = (0, k.m)(), c = null == o ? void 0 : o.messages.find(e => {
                    var t, n;
                    return (null === (n = e.annotations) || void 0 === n ? void 0 : null === (t = n[0]) || void 0 === t ? void 0 : t.id) === a || e.id === a
                }), [j, w] = (0, f.useState)({
                    copyButtonClicked: !1,
                    feedback: null !== (t = null == c ? void 0 : c.feedback) && void 0 !== t ? t : null
                }), C = (0, f.useCallback)(e => {
                    let t = document.createElement("textarea");
                    t.value = e, document.body.appendChild(t), t.focus(), t.select();
                    try {
                        document.execCommand("copy")
                    } catch (e) {
                        console.error("Fallback: Oops, unable to copy", e)
                    }
                    document.body.removeChild(t)
                }, []), z = (0, f.useCallback)(async () => {
                    let e = null == c ? void 0 : c.content;
                    try {
                        await navigator.clipboard.writeText(e)
                    } catch (t) {
                        C(e)
                    }
                    w(e => ({ ...e,
                        copyButtonClicked: !0
                    })), setTimeout(() => {
                        w(e => ({ ...e,
                            copyButtonClicked: !1
                        }))
                    }, 2e3)
                }, [C]), N = (0, f.useCallback)(() => {
                    if (!(null == o ? void 0 : o.registerResponseFeedback)) return;
                    let e = "down" === j.feedback ? null : "down";
                    o.registerResponseFeedback(a, e), w(t => (t.feedback = e, t))
                }, [a, null == o ? void 0 : o.registerResponseFeedback, j.feedback]), y = (0, f.useCallback)(() => {
                    if (!(null == o ? void 0 : o.registerResponseFeedback)) return;
                    let e = "up" === j.feedback ? null : "up";
                    o.registerResponseFeedback(a, e), w(t => (t.feedback = e, t))
                }, [a, null == o ? void 0 : o.registerResponseFeedback, j.feedback]), S = (0, f.useCallback)(() => {
                    var e;
                    null == o || null === (e = o.retryMessage) || void 0 === e || e.call(o, a)
                }, [a, null == o ? void 0 : o.retryMessage]);
                return (0, n.jsxs)("div", {
                    className: (0, b.cn)("absolute top-full align-middle", {
                        "-mt-2 left-2 hidden border border-zinc-200": !l
                    }, "rounded-xl bg-white p-0.5 text-zinc-800 group-hover/message:block lg:w-fit group-data-[theme=dark]:border-zinc-600 group-data-[theme=dark]:bg-black group-data-[theme=dark]:text-zinc-300"),
                    children: [(0, n.jsx)(p.pn, {
                        children: (0, n.jsxs)(p.u, {
                            children: [(0, n.jsx)(p.aJ, {
                                asChild: !0,
                                children: (0, n.jsx)(r.z, {
                                    onClick: z,
                                    variant: "ghost",
                                    size: "sm",
                                    className: "mt-0.5 h-6 px-1 group-data-[theme=dark]:hover:bg-zinc-800",
                                    children: j.copyButtonClicked ? (0, n.jsx)(m, {
                                        className: "h-4 w-4 text-zinc-600 group-data-[theme=dark]:text-zinc-400"
                                    }) : (0, n.jsx)(d, {
                                        className: "h-4 w-4 text-zinc-600 group-data-[theme=dark]:text-zinc-400"
                                    })
                                })
                            }), (0, n.jsx)(p._v, {
                                className: "mt-1 w-fit p-2 group-data-[theme=dark]:border-zinc-600 group-data-[theme=dark]:bg-zinc-900 group-data-[theme=dark]:text-zinc-300 ".concat(j.copyButtonClicked && "invisible"),
                                children: (0, n.jsx)("p", {
                                    className: "w-fit text-xs",
                                    children: "Copy"
                                })
                            })]
                        })
                    }), (null == o ? void 0 : o.registerResponseFeedback) && s && (0, n.jsxs)(n.Fragment, {
                        children: [(0, n.jsx)(p.pn, {
                            children: (0, n.jsxs)(p.u, {
                                children: [(0, n.jsx)(p.aJ, {
                                    asChild: !0,
                                    children: (0, n.jsx)(r.z, {
                                        onClick: y,
                                        variant: "ghost",
                                        size: "sm",
                                        className: "mt-0.5 h-6 px-1 group-data-[theme=dark]:hover:bg-zinc-800",
                                        disabled: o.actionLoading,
                                        children: "up" === j.feedback ? (0, n.jsx)(x.Z, {
                                            className: "h-4 w-4 text-zinc-600 group-data-[theme=dark]:text-zinc-400"
                                        }) : (0, n.jsx)(g.Z, {
                                            className: "h-4 w-4 text-zinc-600 group-data-[theme=dark]:text-zinc-400"
                                        })
                                    })
                                }), (0, n.jsx)(p._v, {
                                    className: "mt-1 w-fit p-2 group-data-[theme=dark]:border-zinc-600 group-data-[theme=dark]:bg-zinc-900 group-data-[theme=dark]:text-zinc-300",
                                    children: (0, n.jsx)("p", {
                                        className: "w-fit text-xs",
                                        children: "Good response"
                                    })
                                })]
                            })
                        }), (0, n.jsx)(p.pn, {
                            children: (0, n.jsxs)(p.u, {
                                children: [(0, n.jsx)(p.aJ, {
                                    asChild: !0,
                                    children: (0, n.jsx)(r.z, {
                                        onClick: N,
                                        variant: "ghost",
                                        size: "sm",
                                        className: "mt-0.5 h-6 px-1 group-data-[theme=dark]:hover:bg-zinc-800",
                                        disabled: o.actionLoading,
                                        children: "down" === j.feedback ? (0, n.jsx)(h.Z, {
                                            className: "h-4 w-4 scale-x-[-1] text-zinc-600 group-data-[theme=dark]:text-zinc-400"
                                        }) : (0, n.jsx)(v.Z, {
                                            className: "h-4 w-4 scale-x-[-1] text-zinc-600 group-data-[theme=dark]:text-zinc-400"
                                        })
                                    })
                                }), (0, n.jsx)(p._v, {
                                    className: "mt-1 w-fit p-2 group-data-[theme=dark]:border-zinc-600 group-data-[theme=dark]:bg-zinc-900 group-data-[theme=dark]:text-zinc-300",
                                    children: (0, n.jsx)("p", {
                                        className: "w-fit text-xs",
                                        children: "Bad response"
                                    })
                                })]
                            })
                        })]
                    }), (null == o ? void 0 : o.retryMessage) && i && "conversation-ended" !== o.status && !o.isChatTakenOver && (0, n.jsx)(p.pn, {
                        children: (0, n.jsxs)(p.u, {
                            children: [(0, n.jsx)(p.aJ, {
                                asChild: !0,
                                children: (0, n.jsx)(r.z, {
                                    onClick: S,
                                    variant: "ghost",
                                    size: "sm",
                                    className: "mt-0.5 h-6 px-1 group-data-[theme=dark]:hover:bg-zinc-800",
                                    disabled: o.actionLoading || o.isLoading,
                                    children: (0, n.jsx)(u, {
                                        className: "h-4 w-4 text-zinc-600 group-data-[theme=dark]:text-zinc-400"
                                    })
                                })
                            }), (0, n.jsx)(p._v, {
                                className: "mt-1 w-fit p-2 group-data-[theme=dark]:border-zinc-200/50 group-data-[theme=dark]:bg-zinc-800 group-data-[theme=dark]:text-zinc-300",
                                children: (0, n.jsx)("p", {
                                    className: "w-fit text-xs",
                                    children: "Retry"
                                })
                            })]
                        })
                    })]
                })
            }
            var w = a(39984),
                C = a(83500),
                z = a(59036),
                N = a(69007),
                y = a(48249),
                S = a(84653),
                L = function(e) {
                    var t, a, l, s, i, o, d, u, m, h, v, x, g, p, j, w, L, T, I;
                    let [A, R] = (0, f.useState)(""), [M, Z] = (0, f.useState)(""), [E, B] = (0, f.useState)(""), [F, U] = (0, f.useState)(!1), _ = (0, k.m)(), O = (0, y.j)({
                        conversationId: e.conversationId,
                        chatbotId: e.chatbotId,
                        userId: null !== (T = null !== (L = null == _ ? void 0 : null === (t = _.user) || void 0 === t ? void 0 : t.user_id) && void 0 !== L ? L : null == _ ? void 0 : null === (a = _.user) || void 0 === a ? void 0 : a.anon_user_id) && void 0 !== T ? T : "",
                        userHash: null !== (I = null == _ ? void 0 : null === (l = _.user) || void 0 === l ? void 0 : l.user_hash) && void 0 !== I ? I : void 0
                    }), H = async t => {
                        var a, n;
                        t.preventDefault();
                        try {
                            let t = {
                                conversationId: e.conversationId,
                                customerEmail: A,
                                customerName: M,
                                customerPhone: E,
                                chatbotId: e.chatbotId
                            };
                            await O.mutateAsync({
                                email: t.customerEmail,
                                name: t.customerName,
                                phone: t.customerPhone
                            }), (0, N.Wd)(e.conversationId, {
                                ignoreForm: !1,
                                savedToDB: !0,
                                data: t
                            }), U(!0), null === (a = e.onSuccess) || void 0 === a || a.call(e)
                        } catch (t) {
                            U(!0), null === (n = e.onError) || void 0 === n || n.call(e)
                        }
                    };
                    return F ? null : (0, n.jsx)(c.am, {
                        children: (0, n.jsx)("div", {
                            className: "float-left clear-both",
                            children: (0, n.jsx)("div", {
                                className: "flex space-x-3",
                                children: (0, n.jsx)("div", {
                                    className: "flex-1 gap-4",
                                    children: (0, n.jsx)("div", {
                                        className: "text-left text-inherit",
                                        children: (0, n.jsxs)("form", {
                                            onSubmit: H,
                                            children: [(0, n.jsxs)("div", {
                                                className: "mb-4 flex items-start justify-between",
                                                children: [(0, n.jsx)("h4", {
                                                    className: "pr-8 font-semibold text-sm",
                                                    children: null === (s = e.collectLeadsSettings) || void 0 === s ? void 0 : s.title
                                                }), (0, n.jsx)(r.z, {
                                                    variant: "link",
                                                    type: "button",
                                                    size: "icon",
                                                    onClick: () => {
                                                        var t;
                                                        (0, N.Wd)(e.conversationId, {
                                                            ignoreForm: !0,
                                                            savedToDB: !0,
                                                            data: null
                                                        }), null === (t = e.onIgnore) || void 0 === t || t.call(e), U(!0)
                                                    },
                                                    className: (0, b.cn)("absolute top-0 right-0 p-0", "group-data-[theme=dark]:hover:text-zinc-400 group-data-[theme=dark]:text-zinc-300", "text-zinc-700 hover:text-zinc-600"),
                                                    "aria-label": "Close contact form",
                                                    title: "Close contact form",
                                                    children: (0, n.jsx)(C, {
                                                        className: "h-4 w-4"
                                                    })
                                                })]
                                            }), (null === (i = e.collectLeadsSettings) || void 0 === i ? void 0 : i.name.active) && (0, n.jsxs)("div", {
                                                className: "mb-4",
                                                children: [(0, n.jsx)("label", {
                                                    className: "mb-1 block font-medium text-sm",
                                                    htmlFor: "name",
                                                    children: (null === (o = e.collectLeadsSettings) || void 0 === o ? void 0 : o.name.label) || S.hS.name.label
                                                }), (0, n.jsx)("div", {
                                                    className: (0, b.cn)("flex w-full rounded", "group-data-[theme=dark]:bg-black", "bg-white"),
                                                    children: (0, n.jsx)("input", {
                                                        id: "name",
                                                        name: "name",
                                                        autoComplete: "name",
                                                        className: (0, b.cn)("w-full min-w-0 flex-auto appearance-none rounded border bg-inherit p-1 px-3 py-2 sm:text-sm focus:outline-none focus:ring-none", "group-data-[theme=dark]:border-[#5f5f5e]", "border-[#cfcfce]"),
                                                        value: M,
                                                        onChange: e => {
                                                            Z(e.target.value)
                                                        },
                                                        maxLength: 70,
                                                        "aria-label": (null === (d = e.collectLeadsSettings) || void 0 === d ? void 0 : d.name.label) || S.hS.name.label,
                                                        title: (null === (u = e.collectLeadsSettings) || void 0 === u ? void 0 : u.name.label) || S.hS.name.label
                                                    })
                                                })]
                                            }), (null === (m = e.collectLeadsSettings) || void 0 === m ? void 0 : m.email.active) && (0, n.jsxs)("div", {
                                                className: "mb-4",
                                                children: [(0, n.jsx)("label", {
                                                    className: "mb-1 block font-medium text-sm",
                                                    htmlFor: "email",
                                                    children: (null === (h = e.collectLeadsSettings) || void 0 === h ? void 0 : h.email.label) || S.hS.email.label
                                                }), (0, n.jsx)("div", {
                                                    className: (0, b.cn)("flex w-full rounded", "group-data-[theme=dark]:bg-black", "bg-white"),
                                                    children: (0, n.jsx)("input", {
                                                        id: "email",
                                                        name: "email",
                                                        autoComplete: "email",
                                                        type: "email",
                                                        required: !0,
                                                        className: (0, b.cn)("w-full min-w-0 flex-auto rounded border bg-inherit p-1 px-3 py-2 sm:text-sm focus:outline-none focus:ring-none", "group-data-[theme=dark]:border-[#5f5f5e]", "border-[#cfcfce]"),
                                                        value: A,
                                                        onChange: e => {
                                                            R(e.target.value)
                                                        },
                                                        "aria-label": (null === (v = e.collectLeadsSettings) || void 0 === v ? void 0 : v.email.label) || S.hS.email.label,
                                                        title: (null === (x = e.collectLeadsSettings) || void 0 === x ? void 0 : x.email.label) || S.hS.email.label
                                                    })
                                                })]
                                            }), (null === (g = e.collectLeadsSettings) || void 0 === g ? void 0 : g.phone.active) && (0, n.jsxs)("div", {
                                                className: "mb-4",
                                                children: [(0, n.jsx)("label", {
                                                    className: "mb-1 block font-medium text-sm",
                                                    htmlFor: "phone",
                                                    children: (null === (p = e.collectLeadsSettings) || void 0 === p ? void 0 : p.phone.label) || S.hS.phone.label
                                                }), (0, n.jsx)("div", {
                                                    className: (0, b.cn)("flex w-full rounded", "group-data-[theme=dark]:bg-black", "bg-white"),
                                                    children: (0, n.jsx)("input", {
                                                        id: "phone",
                                                        name: "phone",
                                                        autoComplete: "tel",
                                                        type: "tel",
                                                        required: !0,
                                                        className: (0, b.cn)("w-full min-w-0 flex-auto appearance-none rounded border bg-inherit p-1 px-3 py-2 sm:text-sm focus:outline-none focus:ring-none", "group-data-[theme=dark]:border-[#5f5f5e]", "border-[#cfcfce]"),
                                                        value: E,
                                                        onChange: e => {
                                                            B(e.target.value)
                                                        },
                                                        "aria-label": (null === (j = e.collectLeadsSettings) || void 0 === j ? void 0 : j.phone.label) || S.hS.phone.label,
                                                        title: (null === (w = e.collectLeadsSettings) || void 0 === w ? void 0 : w.phone.label) || S.hS.phone.label
                                                    })
                                                })]
                                            }), (0, n.jsx)("div", {
                                                className: "flex items-end justify-between",
                                                children: (0, n.jsx)(r.z, {
                                                    loading: O.isPending,
                                                    "aria-label": "Send your contact info",
                                                    title: "Send your contact info",
                                                    type: "submit",
                                                    children: !O.isPending && (0, n.jsx)(z, {
                                                        className: "h-4 w-4"
                                                    })
                                                })
                                            })]
                                        })
                                    })
                                })
                            })
                        })
                    })
                },
                T = a(62713);

            function I(e) {
                let t = (0, k.m)();
                if (!t) return (0, n.jsxs)(n.Fragment, {
                    children: [e.initialMessages.map(t => t ? (0, n.jsx)(c.Mp, {
                        avatarUrl: e.profilePicture,
                        children: (0, n.jsx)(c.am, {
                            children: (0, n.jsx)("div", {
                                className: "prose h-full w-full max-w-none text-sm text-zinc-950 group-data-[theme=dark]:text-zinc-300",
                                children: t
                            })
                        })
                    }, t) : null), (0, n.jsx)("div", {
                        className: "relative flex w-full flex-col items-end gap-2",
                        children: (0, n.jsx)(c.cA, {
                            chatbotStyles: e.chatbotStyles,
                            children: "Hello"
                        })
                    })]
                });
                let a = t.groupedMessages,
                    d = t.groupedLiveChatMessages,
                    u = t.collectLeads;
                return (0, n.jsxs)(n.Fragment, {
                    children: [null == a ? void 0 : a.map((r, s) => {
                        let i = s === a.length - 1 && (!d || 0 === d.length),
                            o = r[0],
                            m = r.findLast(e => e.content);
                        switch (o.role) {
                            case l.WU.SYSTEM:
                                return null;
                            case l.WU.USER:
                                return (0, n.jsx)("div", {
                                    className: "relative flex w-full flex-col items-end gap-2",
                                    children: (0, n.jsx)(c.cA, {
                                        chatbotStyles: e.chatbotStyles,
                                        children: o.content
                                    })
                                }, o.id);
                            case l.WU.ASSISTANT:
                                {
                                    var h, v, x, g, p, f, b;
                                    if (0 === r.length || r.every(e => !e.content)) return null;
                                    let l = i && t.isLoading && 1 !== a.length;
                                    return (0, n.jsx)(c.fy, {
                                        isLoading: l,
                                        avatarUrl: e.profilePicture,
                                        isLast: i,
                                        children: (0, n.jsxs)("div", {
                                            className: "relative flex w-fit max-w-full flex-col items-baseline gap-2",
                                            children: [r.map(a => i && a.toolInvocations && t.isLoading ? null : (0, n.jsx)(w.xO, {
                                                message: a,
                                                chatbotStyles: e.chatbotStyles,
                                                chatbotActions: t.chatbotActions,
                                                isLastMessage: i,
                                                shouldAnimate: l,
                                                showToolCalls: void 0 === t.isSendingLiveChatMessage
                                            }, "m-".concat(a.id))), i && (t.isLoadingStream || t.isLoading) || 0 === s ? null : (0, n.jsx)(j, {
                                                messageId: null !== (p = null == m ? void 0 : null === (v = m.annotations) || void 0 === v ? void 0 : null === (h = v[0]) || void 0 === h ? void 0 : h.id) && void 0 !== p ? p : o.id,
                                                collectUserFeedback: null === (f = null === (x = e.chatbotStyles) || void 0 === x ? void 0 : x.collect_user_feedback) || void 0 === f || f,
                                                allowRegenerateMessages: null === (b = null === (g = e.chatbotStyles) || void 0 === g ? void 0 : g.regenerate_messages) || void 0 === b || b,
                                                isLast: i && !t.isLoadingStream && !t.isChatTakenOver
                                            }, "a-".concat(o.id)), (null == u ? void 0 : u.settings) && (null == u ? void 0 : u.messageId) === o.id && (0, n.jsx)(L, {
                                                collectLeadsSettings: u.settings,
                                                chatbotId: u.chatbotId,
                                                conversationId: u.conversationId
                                            })]
                                        })
                                    }, "r-".concat(o.id))
                                }
                        }
                    }), d && d.length > 0 ? (0, n.jsx)(T.U, {}) : null, null == d ? void 0 : d.map(t => {
                        switch (t[0].role) {
                            case l.Zg.USER:
                                return (0, n.jsx)("div", {
                                    className: "relative flex w-full flex-col items-end gap-2",
                                    children: t.map(t => (0, n.jsx)(c.cA, {
                                        chatbotStyles: e.chatbotStyles,
                                        children: t.content
                                    }, t.id))
                                }, "".concat(t[0].id, "-u"));
                            case l.Zg.AGENT:
                                var a, r;
                                return (0, n.jsx)(c.lF, {
                                    agentAvatarUrl: null === (r = t.find(e => {
                                        var t;
                                        return null === (t = e.metadata) || void 0 === t ? void 0 : t.agentAvatarUrl
                                    })) || void 0 === r ? void 0 : null === (a = r.metadata) || void 0 === a ? void 0 : a.agentAvatarUrl,
                                    children: t.map(e => {
                                        var t, a;
                                        return (0, n.jsx)(c.eY, {
                                            agentName: null !== (a = null === (t = e.metadata) || void 0 === t ? void 0 : t.agentName) && void 0 !== a ? a : "Agent",
                                            children: (0, n.jsx)(o.V, {
                                                children: e.content
                                            })
                                        }, e.id)
                                    })
                                }, "".concat(t[0].id, "-r"))
                        }
                    }), !t.error || t.isLoadingStream || t.isSendingLiveChatMessage ? null : (0, n.jsx)(c.fy, {
                        avatarUrl: e.profilePicture,
                        className: "flex items-center",
                        children: (0, n.jsxs)("div", {
                            className: "flex items-center gap-1",
                            children: [(0, n.jsx)(w.T2, {
                                error: t.error
                            }), !t.isChatTakenOver && (0, n.jsx)(r.z, {
                                onClick: t.reload,
                                variant: "ghost",
                                size: "sm",
                                className: "mt-0.5 h-6 px-1 group-data-[theme=dark]:hover:bg-zinc-800",
                                children: (0, n.jsx)(s.Z, {
                                    className: "h-4 w-4 text-zinc-600 group-data-[theme=dark]:text-zinc-400"
                                })
                            })]
                        })
                    }, "error"), "waiting-for-stream" === t.status && (0, n.jsx)(c.fy, {
                        avatarUrl: e.profilePicture,
                        children: (0, n.jsx)(c.am, {
                            children: (0, n.jsx)(i.Z, {})
                        })
                    }, "loading")]
                })
            }
        },
        62035: function(e, t, a) {
            a.d(t, {
                S: function() {
                    return m
                }
            });
            var n = a(57437),
                l = a(2265),
                r = a(59744);
            let s = e => {
                    e && e.scrollTo({
                        top: 2 * e.scrollHeight,
                        behavior: "smooth"
                    })
                },
                i = () => {
                    let e = (0, l.useRef)(null),
                        t = (0, l.useRef)(null),
                        [a, n] = (0, l.useState)(!0),
                        i = (0, r.N)(a, 300),
                        o = (0, l.useRef)(!1),
                        c = (0, l.useRef)(!1),
                        d = (0, l.useRef)(!1),
                        u = (0, l.useCallback)(function() {
                            let t = !(arguments.length > 0) || void 0 === arguments[0] || arguments[0];
                            e.current && t && (o.current = !0, s(e.current))
                        }, []),
                        m = (0, l.useCallback)(() => {
                            if (e.current) {
                                let t = [...e.current.querySelectorAll("[data-user]")].at(-1);
                                if (t && !o.current) {
                                    let a = e.current,
                                        n = t.getBoundingClientRect().top,
                                        l = a.getBoundingClientRect().top;
                                    a.scrollTo({
                                        top: n - l + a.scrollTop - 10,
                                        behavior: "smooth"
                                    })
                                }
                            }
                        }, []);
                    return (0, l.useEffect)(() => {
                        if (t.current) {
                            let a = new IntersectionObserver(e => {
                                for (let t of e) t.isIntersecting ? n(!0) : n(!1)
                            }, {
                                root: e.current,
                                rootMargin: "0px 0px 80px 0px"
                            });
                            return a.observe(t.current), () => {
                                a.disconnect()
                            }
                        }
                    }, []), (0, l.useEffect)(() => {
                        let t, a = 0;
                        if (!e.current) return;
                        let n = () => {
                            requestAnimationFrame(() => {
                                o.current = !0
                            }), clearTimeout(t), t = setTimeout(() => {
                                c.current || (o.current = !1)
                            }, 1e4)
                        };
                        window.addEventListener("wheel", n), window.addEventListener("touchmove", n, {
                            passive: !0
                        });
                        let l = new ResizeObserver(t => {
                                if (e.current)
                                    for (let n of t) {
                                        let t = [...e.current.querySelectorAll("[data-loading-assistant]")].at(-1);
                                        c.current = (null == t ? void 0 : t.getAttribute("data-loading-assistant")) === "true", c.current && (d.current = !0), d.current && new Date().getTime() - a > 200 && (a = new Date().getTime(), m())
                                    }
                            }),
                            r = new MutationObserver(t => {
                                for (let a of t)
                                    if ("childList" === a.type && a.target === e.current)
                                        for (let e of a.addedNodes) e instanceof Element && (l.observe(e), o.current = !1, e.hasAttribute("data-user") && u())
                            });
                        return r.observe(e.current, {
                            childList: !0,
                            subtree: !0
                        }), () => {
                            r.disconnect(), l.disconnect(), window.removeEventListener("wheel", n), window.removeEventListener("touchmove", n), clearTimeout(t)
                        }
                    }, []), (0, l.useEffect)(() => {
                        u()
                    }, []), {
                        messagesRef: e,
                        visibilityRef: t,
                        scrollToBottom: u,
                        isAtBottom: !0 === a ? a : i
                    }
                };
            var o = a(12381),
                c = a(40875),
                d = a(81201);

            function u(e) {
                let {
                    className: t,
                    isAtBottom: a,
                    scrollToBottom: l,
                    ...r
                } = e;
                return (0, n.jsxs)(o.z, {
                    variant: "ghost",
                    size: "icon",
                    className: (0, d.cn)("absolute right-8 bottom-4 z-10 animate-in rounded-full border border-zinc-300 bg-zinc-50 text-zinc-500 transition-opacity duration-300 group-data-[theme=dark]:border-zinc-600 group-data-[theme=dark]:bg-zinc-700 group-data-[theme=dark]:text-white", a ? "opacity-0" : "opacity-100", t),
                    onClick: () => l(),
                    ...r,
                    children: [(0, n.jsx)(c.Z, {}), (0, n.jsx)("span", {
                        className: "sr-only",
                        children: "Scroll to bottom"
                    })]
                })
            }

            function m(e) {
                let {
                    visibilityRef: t,
                    messagesRef: a,
                    scrollToBottom: l,
                    isAtBottom: r
                } = i();
                return (0, n.jsx)("div", {
                    className: "relative flex flex-1 basis-full flex-col overflow-y-hidden scroll-smooth ".concat(e.className),
                    children: (0, n.jsxs)("div", {
                        ref: a,
                        className: "flex w-full flex-1 flex-col space-y-5 overflow-y-auto px-5 pt-5 pb-4 sm:overscroll-contain",
                        children: [e.children, (0, n.jsx)("div", {
                            className: "h-px w-full shrink-0 bg-transparent",
                            ref: t
                        }), (0, n.jsx)(u, {
                            scrollToBottom: l,
                            isAtBottom: r
                        })]
                    })
                })
            }
        },
        61315: function(e, t, a) {
            a.d(t, {
                O: function() {
                    return d
                }
            });
            var n = a(57437),
                l = a(12381),
                r = a(23675),
                s = (a(10306), a(2265)),
                i = a(81201),
                o = a(84653),
                c = a(83535);

            function d(e) {
                let {
                    className: t,
                    disableButton: a,
                    ...d
                } = e, [m, h] = (0, s.useState)(""), {
                    ref: v,
                    resize: x
                } = (0, r.E)(), g = (0, c.m)();
                return null == g || g.enableRealtimeAudioMode, (0, s.useEffect)(() => {
                    x()
                }, [m, x]), (0, n.jsxs)("div", {
                    className: "flex min-h-16 items-end border-zinc-200 border-t group-data-[theme=dark]:border-zinc-800",
                    children: [(0, n.jsx)(r.g, {
                        id: "message",
                        name: "message",
                        ref: v,
                        value: m,
                        maxLength: (null == g ? void 0 : g.isChatTakenOver) ? o.Du : o._R,
                        onInput: e => h(e.currentTarget.value),
                        className: (0, i.cn)("my-auto max-h-40 min-h-8 resize-none rounded-none border-0 placeholder-zinc-400 group-data-[mobile=true]:text-[16px] sm:text-sm focus-visible:ring-0 focus-visible:ring-offset-0", "pointer-events-auto overflow-y-auto p-3", "group-data-[theme=dark]:bg-black group-data-[theme=dark]:text-white", t),
                        rows: 1,
                        tabIndex: 0,
                        ...d,
                        enterKeyHint: "enter"
                    }), (e.value, (0, n.jsx)(l.z, {
                        disabled: a,
                        size: "icon",
                        className: "my-3 mr-2 size-5 bg-transparent shadow-none group-data-[theme=dark]:hover:bg-zinc-800/90 hover:bg-zinc-100/90",
                        type: "submit",
                        onClick: () => e.onSubmit(),
                        children: (0, n.jsx)(u, {
                            className: "size-5 text-zinc-700 group-data-[theme=dark]:text-white"
                        })
                    }))]
                })
            }

            function u(e) {
                return (0, n.jsxs)("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 20 20",
                    ...e,
                    children: [(0, n.jsx)("title", {
                        children: "Paper Plane"
                    }), (0, n.jsx)("path", {
                        fill: "currentColor",
                        d: "M15.44 1.68c.69-.05 1.47.08 2.13.74.66.67.8 1.45.75 2.14-.03.47-.15 1-.25 1.4l-.09.35a43.7 43.7 0 0 1-3.83 10.67A2.52 2.52 0 0 1 9.7 17l-1.65-3.03a.83.83 0 0 1 .14-1l3.1-3.1a.83.83 0 1 0-1.18-1.17l-3.1 3.1a.83.83 0 0 1-.99.14L2.98 10.3a2.52 2.52 0 0 1 .04-4.45 43.7 43.7 0 0 1 11.02-3.9c.4-.1.92-.23 1.4-.26Z"
                    })]
                })
            }
        },
        35461: function(e, t, a) {
            a.d(t, {
                B: function() {
                    return s
                }
            });
            var n = a(57437),
                l = a(12381),
                r = a(81201);

            function s(e) {
                let {
                    messages: t,
                    onSelect: a,
                    ...s
                } = e;
                return e.messages.length <= 0 ? null : (0, n.jsx)("div", {
                    className: "flex w-full items-center gap-4 overflow-x-auto px-4 pt-2 pb-2 text-zinc-700 group-data-[theme=dark]:text-zinc-300",
                    children: e.messages.map((t, a) => (0, n.jsx)(l.z, {
                        variant: "default",
                        size: "sm",
                        onClick: a => {
                            var n;
                            a.preventDefault(), null === (n = e.onSelect) || void 0 === n || n.call(e, t)
                        },
                        type: "button",
                        className: (0, r.cn)("h-8 whitespace-nowrap rounded-md border px-3 py-2 font-normal text-sm shadow-none", "group-data-[theme=dark]:border-zinc-800 group-data-[theme=dark]:bg-zinc-900 group-data-[theme=dark]:hover:bg-zinc-800 group-data-[theme=dark]:text-zinc-50", "border-zinc-200 bg-zinc-100 text-black hover:bg-zinc-200"),
                        "aria-label": t,
                        title: t,
                        ...s,
                        children: t
                    }, t + a.toString()))
                })
            }
        },
        62713: function(e, t, a) {
            a.d(t, {
                U: function() {
                    return r
                }
            });
            var n = a(57437),
                l = a(31593);

            function r() {
                return (0, n.jsxs)("div", {
                    className: "flex items-center gap-4",
                    children: [(0, n.jsx)(l.Separator, {
                        className: "flex-1"
                    }), (0, n.jsx)("span", {
                        className: "text-sm text-zinc-600 group-data-[theme=dark]:text-zinc-300",
                        children: "Live Chat"
                    }), (0, n.jsx)(l.Separator, {
                        className: "flex-1"
                    })]
                })
            }
        },
        80222: function(e, t, a) {
            var n = a(57437),
                l = a(2265),
                r = a(81201);
            let s = (0, l.forwardRef)((e, t) => {
                let {
                    className: a,
                    ...l
                } = e;
                return (0, n.jsxs)("svg", {
                    ref: t,
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 14 14",
                    fill: "none",
                    className: (0, r.cn)(a, "scale-y-[-1]"),
                    ...l,
                    children: [(0, n.jsx)("title", {
                        children: "Thumbs Down"
                    }), (0, n.jsx)("path", {
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "currentColor",
                        d: "M8.93 1.16a1.33 1.33 0 0 0-1.84.16l-.14.18L4.9 4.45c-.29.41-.5.71-.66 1A2.33 2.33 0 0 0 .33 7.16v4a2.33 2.33 0 0 0 4.1 1.52c.2.21.43.38.7.52.32.16.66.23 1.04.26.36.03.8.03 1.34.03H9.9c.47 0 .85 0 1.17-.03.34-.02.64-.08.94-.21.46-.21.86-.55 1.13-.98.18-.27.28-.57.36-.9.07-.3.12-.7.2-1.15l.36-2.42.1-.78c0-.23 0-.48-.1-.73-.14-.36-.4-.66-.73-.85a1.7 1.7 0 0 0-.71-.2c-.22-.02-.49-.02-.78-.02H9.88a.33.33 0 0 1-.27-.4l.02-.06.1-.25.04-.1.11-.31c.27-.88.07-1.84-.53-2.53l-.23-.24c-.06-.06-.12-.13-.2-.18Zm-5.26 6v4a1 1 0 0 1-2 0v-4a1 1 0 0 1 2 0Z"
                    })]
                })
            });
            s.displayName = "ThumbsDownIcon", t.Z = s
        },
        36174: function(e, t, a) {
            var n = a(57437),
                l = a(2265),
                r = a(81201);
            let s = (0, l.forwardRef)((e, t) => {
                let {
                    className: a,
                    ...l
                } = e;
                return (0, n.jsxs)("svg", {
                    ref: t,
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 18 17",
                    fill: "none",
                    className: (0, r.cn)(a, "scale-y-[-1]"),
                    ...l,
                    children: [(0, n.jsx)("title", {
                        children: "Thumbs Down Outline Icon"
                    }), (0, n.jsx)("path", {
                        d: "M11.6346 4.97423L11.6744 4.8712C11.7439 4.69143 11.7786 4.6015 11.8047 4.5166C12.0576 3.6926 11.8682 2.79646 11.3035 2.14528C11.2453 2.07817 11.1771 2.01002 11.0408 1.87373C10.9619 1.79481 10.9224 1.75534 10.8875 1.72721C10.5386 1.4463 10.03 1.49148 9.73608 1.82951C9.70664 1.86336 9.67475 1.90916 9.61098 2.00077L7.10112 5.60583C6.56828 6.37119 6.30186 6.75386 6.11296 7.17044C5.94531 7.54015 5.82331 7.92891 5.74966 8.32812C5.66667 8.77792 5.66667 9.24421 5.66667 10.1768V11.6662C5.66667 13.0664 5.66667 13.7664 5.93915 14.3012C6.17883 14.7716 6.56129 15.1541 7.03169 15.3937C7.56647 15.6662 8.26653 15.6662 9.66666 15.6662H12.5908C13.8135 15.6662 14.4248 15.6662 14.9178 15.4421C15.3524 15.2445 15.7213 14.9267 15.9809 14.5262C16.2755 14.0717 16.366 13.4671 16.5468 12.2579L16.9899 9.29541C17.1083 8.50407 17.1675 8.10839 17.0491 7.80068C16.9452 7.53058 16.7507 7.30491 16.499 7.16218C16.2122 6.99956 15.8121 6.99956 15.0119 6.99956H13.0232C12.7137 6.99956 12.559 6.99956 12.4449 6.97819C11.7671 6.85122 11.3201 6.19933 11.4461 5.52133C11.4673 5.40721 11.523 5.26288 11.6346 4.97423Z",
                        stroke: "currentColor",
                        strokeWidth: "1.25",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), (0, n.jsx)("path", {
                        d: "M1.5 8.58289C1.5 7.4323 2.43274 6.49956 3.58333 6.49956C4.73393 6.49956 5.66667 7.4323 5.66667 8.58289V13.5829C5.66667 14.7335 4.73393 15.6662 3.58333 15.6662C2.43274 15.6662 1.5 14.7335 1.5 13.5829V8.58289Z",
                        stroke: "currentColor",
                        strokeWidth: "1.25",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })]
                })
            });
            s.displayName = "ThumbsDownOutlineIcon", t.Z = s
        },
        34021: function(e, t, a) {
            var n = a(57437);
            let l = (0, a(2265).forwardRef)((e, t) => {
                let {
                    className: a,
                    ...l
                } = e;
                return (0, n.jsxs)("svg", {
                    ref: t,
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 15 15",
                    fill: "none",
                    className: a,
                    ...l,
                    children: [(0, n.jsx)("title", {
                        children: "Thumbs Up Icon"
                    }), (0, n.jsx)("path", {
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "currentColor",
                        d: "M8.93 1.16a1.33 1.33 0 0 0-1.84.16l-.14.18L4.9 4.45c-.29.41-.5.71-.66 1A2.33 2.33 0 0 0 .33 7.16v4a2.33 2.33 0 0 0 4.1 1.52c.2.21.43.38.7.52.32.16.66.23 1.04.26.36.03.8.03 1.34.03H9.9c.47 0 .85 0 1.17-.03.34-.02.64-.08.94-.21.46-.21.86-.55 1.13-.98.18-.27.28-.57.36-.9.07-.3.12-.7.2-1.15l.36-2.42.1-.78c0-.23 0-.48-.1-.73-.14-.36-.4-.66-.73-.85a1.7 1.7 0 0 0-.71-.2c-.22-.02-.49-.02-.78-.02H9.88a.33.33 0 0 1-.27-.4l.02-.06.1-.25.04-.1.11-.31c.27-.88.07-1.84-.53-2.53l-.23-.24c-.06-.06-.12-.13-.2-.18Zm-5.26 6v4a1 1 0 0 1-2 0v-4a1 1 0 0 1 2 0Z"
                    })]
                })
            });
            l.displayName = "ThumbsUpIcon", t.Z = l
        },
        2551: function(e, t, a) {
            var n = a(57437);
            let l = (0, a(2265).forwardRef)((e, t) => {
                let {
                    className: a,
                    ...l
                } = e;
                return (0, n.jsxs)("svg", {
                    ref: t,
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 19 18",
                    fill: "none",
                    className: a,
                    ...l,
                    children: [(0, n.jsx)("title", {
                        children: "Thumbs Up Outline Icon"
                    }), (0, n.jsx)("path", {
                        d: "M11.6346 4.97423L11.6744 4.8712C11.7439 4.69143 11.7786 4.6015 11.8047 4.5166C12.0576 3.6926 11.8682 2.79646 11.3035 2.14528C11.2453 2.07817 11.1771 2.01002 11.0408 1.87373C10.9619 1.79481 10.9224 1.75534 10.8875 1.72721C10.5386 1.4463 10.03 1.49148 9.73608 1.82951C9.70664 1.86336 9.67475 1.90916 9.61098 2.00077L7.10112 5.60583C6.56828 6.37119 6.30186 6.75386 6.11296 7.17044C5.94531 7.54015 5.82331 7.92891 5.74966 8.32812C5.66667 8.77792 5.66667 9.24421 5.66667 10.1768V11.6662C5.66667 13.0664 5.66667 13.7664 5.93915 14.3012C6.17883 14.7716 6.56129 15.1541 7.03169 15.3937C7.56647 15.6662 8.26653 15.6662 9.66666 15.6662H12.5908C13.8135 15.6662 14.4248 15.6662 14.9178 15.4421C15.3524 15.2445 15.7213 14.9267 15.9809 14.5262C16.2755 14.0717 16.366 13.4671 16.5468 12.2579L16.9899 9.29541C17.1083 8.50407 17.1675 8.10839 17.0491 7.80068C16.9452 7.53058 16.7507 7.30491 16.499 7.16218C16.2122 6.99956 15.8121 6.99956 15.0119 6.99956H13.0232C12.7137 6.99956 12.559 6.99956 12.4449 6.97819C11.7671 6.85122 11.3201 6.19933 11.4461 5.52133C11.4673 5.40721 11.523 5.26288 11.6346 4.97423Z",
                        stroke: "currentColor",
                        strokeWidth: "1.25",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), (0, n.jsx)("path", {
                        d: "M1.5 8.58289C1.5 7.4323 2.43274 6.49956 3.58333 6.49956C4.73393 6.49956 5.66667 7.4323 5.66667 8.58289V13.5829C5.66667 14.7335 4.73393 15.6662 3.58333 15.6662C2.43274 15.6662 1.5 14.7335 1.5 13.5829V8.58289Z",
                        stroke: "currentColor",
                        strokeWidth: "1.25",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })]
                })
            });
            l.displayName = "ThumbsUpOutlineIcon", t.Z = l
        },
        59744: function(e, t, a) {
            a.d(t, {
                N: function() {
                    return l
                }
            });
            var n = a(2265);

            function l(e, t) {
                let [a, l] = (0, n.useState)(e);
                return (0, n.useEffect)(() => {
                    let a = setTimeout(() => {
                        l(e)
                    }, t);
                    return () => {
                        clearTimeout(a)
                    }
                }, [e, t]), a
            }
        }
    }
]);