(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2529], {
        22529: function(e, t, n) {
            Promise.resolve().then(n.t.bind(n, 72972, 23)), Promise.resolve().then(n.bind(n, 26836)), Promise.resolve().then(n.bind(n, 43022)), Promise.resolve().then(n.bind(n, 96246))
        },
        71533: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("EllipsisVertical", [
                ["circle", {
                    cx: "12",
                    cy: "12",
                    r: "1",
                    key: "41hilf"
                }],
                ["circle", {
                    cx: "12",
                    cy: "5",
                    r: "1",
                    key: "gxeob9"
                }],
                ["circle", {
                    cx: "12",
                    cy: "19",
                    r: "1",
                    key: "lyex9k"
                }]
            ])
        },
        65621: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("History", [
                ["path", {
                    d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",
                    key: "1357e3"
                }],
                ["path", {
                    d: "M3 3v5h5",
                    key: "1xhq8a"
                }],
                ["path", {
                    d: "M12 7v5l4 2",
                    key: "1fdv2h"
                }]
            ])
        },
        91903: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("MessageCirclePlus", [
                ["path", {
                    d: "M7.9 20A9 9 0 1 0 4 16.1L2 22Z",
                    key: "vv11sd"
                }],
                ["path", {
                    d: "M8 12h8",
                    key: "1wcyev"
                }],
                ["path", {
                    d: "M12 8v8",
                    key: "napkw2"
                }]
            ])
        },
        22481: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("MessageCircleX", [
                ["path", {
                    d: "M7.9 20A9 9 0 1 0 4 16.1L2 22Z",
                    key: "vv11sd"
                }],
                ["path", {
                    d: "m15 9-6 6",
                    key: "1uzhvr"
                }],
                ["path", {
                    d: "m9 9 6 6",
                    key: "z0biqf"
                }]
            ])
        },
        32489: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("X", [
                ["path", {
                    d: "M18 6 6 18",
                    key: "1bl5f8"
                }],
                ["path", {
                    d: "m6 6 12 12",
                    key: "d8bk6v"
                }]
            ])
        },
        49360: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return l
                }
            });
            for (var r, a = {
                    randomUUID: "undefined" != typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto)
                }, i = new Uint8Array(16), o = [], s = 0; s < 256; ++s) o.push((s + 256).toString(16).slice(1));
            var l = function(e, t, n) {
                if (a.randomUUID && !t && !e) return a.randomUUID();
                var s = (e = e || {}).random || (e.rng || function() {
                    if (!r && !(r = "undefined" != typeof crypto && crypto.getRandomValues && crypto.getRandomValues.bind(crypto))) throw Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
                    return r(i)
                })();
                if (s[6] = 15 & s[6] | 64, s[8] = 63 & s[8] | 128, t) {
                    n = n || 0;
                    for (var l = 0; l < 16; ++l) t[n + l] = s[l];
                    return t
                }
                return function(e, t = 0) {
                    return (o[e[t + 0]] + o[e[t + 1]] + o[e[t + 2]] + o[e[t + 3]] + "-" + o[e[t + 4]] + o[e[t + 5]] + "-" + o[e[t + 6]] + o[e[t + 7]] + "-" + o[e[t + 8]] + o[e[t + 9]] + "-" + o[e[t + 10]] + o[e[t + 11]] + o[e[t + 12]] + o[e[t + 13]] + o[e[t + 14]] + o[e[t + 15]]).toLowerCase()
                }(s)
            }
        },
        69007: function(e, t, n) {
            "use strict";
            n.d(t, {
                Aw: function() {
                    return f
                },
                DU: function() {
                    return g
                },
                O2: function() {
                    return u
                },
                Wd: function() {
                    return x
                },
                Yo: function() {
                    return c
                },
                r: function() {
                    return d
                },
                yv: function() {
                    return p
                }
            });
            var r = n(8234),
                a = n(31229);
            let i = e => "".concat("cb_conv", "___").concat(e),
                o = e => "".concat("cb_c_", "___").concat(e),
                s = e => "".concat("cb_anon", "___").concat(e),
                l = e => "".concat("cb_user", "___").concat(e),
                c = e => {
                    var t, n;
                    return null !== (n = null === (t = window.localStorage.getItem(i(e))) || void 0 === t ? void 0 : t.split(",")) && void 0 !== n ? n : []
                },
                d = e => window.localStorage.getItem(l(e)),
                u = (e, t) => {
                    {
                        let n = l(e);
                        window.localStorage.setItem(n, t)
                    }
                },
                f = (e, t) => {
                    {
                        let n = new Set([t, ...c(e)]);
                        window.localStorage.setItem(i(e), Array.from(n).join(","))
                    }
                },
                m = a.z.object({
                    ignoreForm: a.z.boolean(),
                    savedToDB: a.z.boolean(),
                    data: a.z.object({
                        chatbotId: a.z.string(),
                        customerEmail: a.z.string().nullish(),
                        customerName: a.z.string().nullish(),
                        customerPhone: a.z.string().nullish(),
                        conversationId: a.z.string().nullish()
                    }).nullish()
                }).partial().nullish(),
                h = a.z.null().or(a.z.string().transform(e => JSON.parse(e)).catch(() => null).pipe(m)),
                p = e => {
                    {
                        let t = o(e);
                        return h.parse(window.localStorage.getItem(t))
                    }
                },
                v = (e, t) => {
                    {
                        let n = s(e);
                        window.localStorage.setItem(n, t)
                    }
                },
                g = e => {
                    {
                        let t = s(e),
                            n = window.localStorage.getItem(t);
                        if (n) return n;
                        let a = (0, r.D)();
                        return v(e, a), a
                    }
                },
                x = (e, t) => {
                    {
                        let n = m.safeParse(t);
                        if (n.success) {
                            let t = o(e),
                                r = p(e);
                            window.localStorage.setItem(t, JSON.stringify({ ...r,
                                ...n.data
                            }))
                        } else console.warn(n.error.issues)
                    }
                }
        },
        26836: function(e, t, n) {
            "use strict";
            n.d(t, {
                ChatExitButton: function() {
                    return s
                }
            });
            var r = n(57437),
                a = n(32489),
                i = n(12381);

            function o() {
                window.parent.postMessage({
                    type: "close"
                }, "*")
            }

            function s() {
                return (0, r.jsx)(i.z, {
                    title: "close chat bubble",
                    variant: null,
                    className: "hidden h-8 w-8 p-0 text-inherit opacity-70 group-data-[mobile=true]:block hover:opacity-85",
                    size: "icon",
                    onClick: o,
                    children: (0, r.jsx)(a.Z, {
                        className: "h-full w-full p-1"
                    })
                })
            }
        },
        43022: function(e, t, n) {
            "use strict";
            n.d(t, {
                ChatbotHeaderActions: function() {
                    return p
                }
            });
            var r = n(57437),
                a = n(69007),
                i = n(12381),
                o = n(32060),
                s = n(71533),
                l = n(91903),
                c = n(22481),
                d = n(65621),
                u = n(27648),
                f = n(2265),
                m = n(81201),
                h = n(83535);
            let p = e => {
                var t, n, p, v, g;
                let {
                    chatbotId: x
                } = e, b = (0, h.m)(), y = (0, a.yv)(null !== (g = null == b ? void 0 : b.conversationId) && void 0 !== g ? g : ""), w = (0, f.useCallback)(() => {
                    null == b || b.resetConversation(null == b ? void 0 : b.clientInitialMessages)
                }, [null == b ? void 0 : b.resetConversation, null == b ? void 0 : b.clientInitialMessages]);
                return (0, r.jsxs)(o.h_, {
                    children: [(0, r.jsx)(o.$F, {
                        asChild: !0,
                        children: (0, r.jsxs)(i.z, {
                            variant: null,
                            className: (0, m.cn)("flex h-9 w-9 p-0 opacity-70 disabled:cursor-not-allowed hover:opacity-85 focus-visible:ring-0"),
                            disabled: null == b ? void 0 : b.isLoading,
                            children: [(0, r.jsx)(s.Z, {
                                className: "h-5"
                            }), (0, r.jsx)("span", {
                                className: "sr-only",
                                children: "Open menu"
                            })]
                        })
                    }), (0, r.jsxs)(o.AW, {
                        className: (0, m.cn)((null == b ? void 0 : null === (t = b.chatbot.styles) || void 0 === t ? void 0 : t.theme) === "dark" ? "border-zinc-800 bg-zinc-800 [&>*]:bg-zinc-800 [&>*]:text-zinc-300" : "text-zinc-600"),
                        children: [(0, r.jsxs)(o.Xi, {
                            className: (0, m.cn)("flex cursor-pointer justify-start gap-2 py-2.5 font-medium", (null == b ? void 0 : null === (n = b.chatbot.styles) || void 0 === n ? void 0 : n.theme) === "dark" ? "hover:!text-zinc-300 focus:bg-zinc-700 hover:bg-zinc-700" : ""),
                            onClick: w,
                            children: [(0, r.jsx)(l.Z, {
                                className: "w-5"
                            }), "Start a new chat"]
                        }), (0, r.jsx)(o.Xi, {
                            asChild: !0,
                            disabled: !(null == y ? void 0 : y.savedToDB) || (null == b ? void 0 : b.status) === "conversation-ended",
                            children: (0, r.jsxs)(u.default, {
                                href: "/chatbot-iframe/".concat(x, "/end-chat"),
                                className: (0, m.cn)("flex cursor-pointer justify-start gap-2 py-2.5 font-medium", (null == b ? void 0 : null === (p = b.chatbot.styles) || void 0 === p ? void 0 : p.theme) === "dark" ? "hover:!text-zinc-300 focus:bg-zinc-700 hover:bg-zinc-700" : ""),
                                children: [(0, r.jsx)(c.Z, {
                                    className: "w-5"
                                }), "End chat"]
                            })
                        }), (0, r.jsx)(o.Xi, {
                            asChild: !0,
                            children: (0, r.jsxs)(u.default, {
                                href: "/chatbot-iframe/".concat(x, "/recent-chats"),
                                className: (0, m.cn)("flex cursor-pointer justify-start gap-2 py-2.5 font-medium", (null == b ? void 0 : null === (v = b.chatbot.styles) || void 0 === v ? void 0 : v.theme) === "dark" ? "hover:!text-zinc-300 focus:bg-zinc-700 hover:bg-zinc-700" : ""),
                                children: [(0, r.jsx)(d.Z, {
                                    className: "w-5"
                                }), "View recent chats"]
                            })
                        })]
                    })]
                })
            }
        },
        83535: function(e, t, n) {
            "use strict";
            n.d(t, {
                m: function() {
                    return i
                },
                p: function() {
                    return a
                }
            });
            var r = n(2265);
            let a = (0, r.createContext)(null);

            function i() {
                return (0, r.useContext)(a)
            }
        },
        29356: function(e, t, n) {
            "use strict";
            var r = n(57437);
            t.Z = e => (0, r.jsxs)("svg", {
                viewBox: "0 0 25 25",
                className: e.className,
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                ...e,
                children: [(0, r.jsx)("title", {
                    children: "loading"
                }), (0, r.jsxs)("g", {
                    fill: "currentColor",
                    children: [(0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        opacity: ".14"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(30 12 12)",
                        opacity: ".29"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(60 12 12)",
                        opacity: ".43"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(90 12 12)",
                        opacity: ".57"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(120 12 12)",
                        opacity: ".71"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(150 12 12)",
                        opacity: ".86"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(180 12 12)"
                    }), (0, r.jsx)("animateTransform", {
                        attributeName: "transform",
                        type: "rotate",
                        calcMode: "discrete",
                        dur: "0.75s",
                        values: "0 12 12;30 12 12;60 12 12;90 12 12;120 12 12;150 12 12;180 12 12;210 12 12;240 12 12;270 12 12;300 12 12;330 12 12;360 12 12",
                        repeatCount: "indefinite"
                    })]
                })]
            })
        },
        96246: function(e, t, n) {
            "use strict";
            n.d(t, {
                Avatar: function() {
                    return s
                },
                F: function() {
                    return l
                },
                Q: function() {
                    return c
                }
            });
            var r = n(57437),
                a = n(2265),
                i = n(70650),
                o = n(81201);
            let s = a.forwardRef((e, t) => {
                let {
                    className: n,
                    ...a
                } = e;
                return (0, r.jsx)(i.fC, {
                    ref: t,
                    className: (0, o.cn)("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", n),
                    ...a
                })
            });
            s.displayName = i.fC.displayName;
            let l = a.forwardRef((e, t) => {
                let {
                    className: n,
                    ...a
                } = e;
                return (0, r.jsx)(i.Ee, {
                    ref: t,
                    className: (0, o.cn)("aspect-square h-full w-full", n),
                    ...a
                })
            });
            l.displayName = i.Ee.displayName;
            let c = a.forwardRef((e, t) => {
                let {
                    className: n,
                    ...a
                } = e;
                return (0, r.jsx)(i.NY, {
                    ref: t,
                    className: (0, o.cn)("flex h-full w-full items-center justify-center rounded-full bg-zinc-100 dark:bg-zinc-800", n),
                    ...a
                })
            });
            c.displayName = i.NY.displayName
        },
        12381: function(e, t, n) {
            "use strict";
            n.d(t, {
                d: function() {
                    return c
                },
                z: function() {
                    return d
                }
            });
            var r = n(57437),
                a = n(2265),
                i = n(98482),
                o = n(77712),
                s = n(29356),
                l = n(81201);
            let c = (0, o.j)("inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-80", {
                    variants: {
                        variant: {
                            default: "bg-zinc-900 text-zinc-50 shadow hover:bg-zinc-800/90 dark:bg-zinc-50 dark:text-zinc-900 dark:hover:bg-zinc-50/90",
                            destructive: "bg-red-500 text-zinc-50 shadow-sm hover:bg-red-500/90 dark:bg-red-900 dark:text-zinc-50 dark:hover:bg-red-900/90",
                            outline: "border border-zinc-200 bg-transparent hover:bg-zinc-100/70 hover:text-zinc-900 dark:border-zinc-800 dark:hover:bg-zinc-800 dark:hover:text-zinc-50 rounded-xl disabled:bg-zinc-100/60",
                            secondary: "bg-zinc-100 text-zinc-900 shadow-sm hover:bg-zinc-200/90 dark:bg-zinc-800 dark:text-zinc-50 dark:hover:bg-zinc-800/80",
                            ghost: "hover:bg-zinc-100 hover:text-zinc-900 dark:hover:bg-zinc-800 dark:hover:text-zinc-50 disabled:text-zinc-600",
                            link: "text-zinc-900 underline-offset-4 hover:underline dark:text-zinc-50",
                            destructiveGhost: "text-red-500 hover:bg-red-50 hover:text-red-600 bg-transparent"
                        },
                        size: {
                            default: "h-9 px-4 py-1",
                            sm: "h-7 rounded-md px-3",
                            lg: "h-10 rounded-md px-8",
                            icon: "h-9 w-9"
                        }
                    },
                    defaultVariants: {
                        variant: "default",
                        size: "default"
                    }
                }),
                d = a.forwardRef((e, t) => {
                    let {
                        className: n,
                        variant: a = "default",
                        size: o,
                        loading: d = !1,
                        asChild: u = !1,
                        hideContentOnLoading: f = !1,
                        ...m
                    } = e, h = u ? i.g7 : "button";
                    return d ? (0, r.jsxs)(h, {
                        className: (0, l.cn)(c({
                            variant: a,
                            size: o,
                            className: n
                        }), "flex flex-row items-center gap-2"),
                        ref: t,
                        disabled: !0,
                        ...m,
                        children: [(0, r.jsx)(s.Z, {
                            className: (0, l.cn)({
                                "h-[0.9rem] w-[0.9rem]": "sm" === o,
                                "h-[1.2rem] w-[1.2rem]": "sm" !== o,
                                "fill-zinc-50": "default" === a || "destructive" === a,
                                "fill-zinc-900": "default" !== a && "destructive" !== a,
                                "fill-red-500": "destructiveGhost" === a
                            })
                        }), !f && m.children]
                    }) : (0, r.jsx)(h, {
                        className: (0, l.cn)(c({
                            variant: a,
                            size: o,
                            className: n
                        })),
                        ref: t,
                        ...m
                    })
                });
            d.displayName = "Button"
        },
        32060: function(e, t, n) {
            "use strict";
            n.d(t, {
                $F: function() {
                    return u
                },
                AW: function() {
                    return m
                },
                Ju: function() {
                    return v
                },
                Qk: function() {
                    return f
                },
                VD: function() {
                    return g
                },
                Xi: function() {
                    return h
                },
                bO: function() {
                    return p
                },
                h_: function() {
                    return d
                }
            });
            var r = n(57437),
                a = n(2265),
                i = n(28119),
                o = n(10407),
                s = n(30401),
                l = n(40519),
                c = n(81201);
            let d = i.fC,
                u = i.xz,
                f = i.ZA;
            i.Uv, i.Tr, i.Ee, a.forwardRef((e, t) => {
                let {
                    className: n,
                    inset: a,
                    children: s,
                    ...l
                } = e;
                return (0, r.jsxs)(i.fF, {
                    ref: t,
                    className: (0, c.cn)("flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-zinc-100 data-[state=open]:bg-zinc-100 dark:focus:bg-zinc-800 dark:data-[state=open]:bg-zinc-800", a && "pl-8", n),
                    ...l,
                    children: [s, (0, r.jsx)(o.Z, {
                        className: "ml-auto h-4 w-4"
                    })]
                })
            }).displayName = i.fF.displayName, a.forwardRef((e, t) => {
                let {
                    className: n,
                    ...a
                } = e;
                return (0, r.jsx)(i.tu, {
                    ref: t,
                    className: (0, c.cn)("z-50 min-w-[8rem] overflow-hidden rounded-md border border-zinc-200 bg-white p-1 text-zinc-950 shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-50", n),
                    ...a
                })
            }).displayName = i.tu.displayName;
            let m = a.forwardRef((e, t) => {
                let {
                    className: n,
                    sideOffset: a = 4,
                    ...o
                } = e;
                return (0, r.jsx)(i.Uv, {
                    children: (0, r.jsx)(i.VY, {
                        ref: t,
                        sideOffset: a,
                        className: (0, c.cn)("z-50 min-w-[8rem] overflow-hidden rounded-md border border-zinc-200 bg-white p-1 text-zinc-950 shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-50", n),
                        ...o
                    })
                })
            });
            m.displayName = i.VY.displayName;
            let h = a.forwardRef((e, t) => {
                let {
                    className: n,
                    inset: a,
                    ...o
                } = e;
                return (0, r.jsx)(i.ck, {
                    ref: t,
                    className: (0, c.cn)("relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-zinc-100 focus:text-zinc-900 data-[disabled]:pointer-events-none data-[disabled]:opacity-50 dark:focus:bg-zinc-800 dark:focus:text-zinc-50", a && "pl-8", n),
                    ...o
                })
            });
            h.displayName = i.ck.displayName;
            let p = a.forwardRef((e, t) => {
                let {
                    className: n,
                    children: a,
                    checked: o,
                    ...l
                } = e;
                return (0, r.jsxs)(i.oC, {
                    ref: t,
                    className: (0, c.cn)("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-zinc-100 focus:text-zinc-900 data-[disabled]:pointer-events-none data-[disabled]:opacity-50 dark:focus:bg-zinc-800 dark:focus:text-zinc-50", n),
                    checked: o,
                    ...l,
                    children: [(0, r.jsx)("span", {
                        className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                        children: (0, r.jsx)(i.wU, {
                            children: (0, r.jsx)(s.Z, {
                                className: "h-4 w-4"
                            })
                        })
                    }), a]
                })
            });
            p.displayName = i.oC.displayName, a.forwardRef((e, t) => {
                let {
                    className: n,
                    children: a,
                    ...o
                } = e;
                return (0, r.jsxs)(i.Rk, {
                    ref: t,
                    className: (0, c.cn)("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-zinc-100 focus:text-zinc-900 data-[disabled]:pointer-events-none data-[disabled]:opacity-50 dark:focus:bg-zinc-800 dark:focus:text-zinc-50", n),
                    ...o,
                    children: [(0, r.jsx)("span", {
                        className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                        children: (0, r.jsx)(i.wU, {
                            children: (0, r.jsx)(l.Z, {
                                className: "h-2 w-2 fill-current"
                            })
                        })
                    }), a]
                })
            }).displayName = i.Rk.displayName;
            let v = a.forwardRef((e, t) => {
                let {
                    className: n,
                    inset: a,
                    ...o
                } = e;
                return (0, r.jsx)(i.__, {
                    ref: t,
                    className: (0, c.cn)("px-2 py-1.5 text-sm font-semibold", a && "pl-8", n),
                    ...o
                })
            });
            v.displayName = i.__.displayName;
            let g = a.forwardRef((e, t) => {
                let {
                    className: n,
                    ...a
                } = e;
                return (0, r.jsx)(i.Z0, {
                    ref: t,
                    className: (0, c.cn)("-mx-1 my-1 h-px bg-zinc-100 dark:bg-zinc-800", n),
                    ...a
                })
            });
            g.displayName = i.Z0.displayName
        },
        8234: function(e, t, n) {
            "use strict";
            n.d(t, {
                D: function() {
                    return a
                }
            });
            var r = n(49360);
            let a = () => (0, r.Z)()
        },
        81201: function(e, t, n) {
            "use strict";
            n.d(t, {
                cn: function() {
                    return i
                }
            });
            var r = n(61994),
                a = n(97841);

            function i() {
                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return (0, a.m)((0, r.W)(t))
            }
        },
        70650: function(e, t, n) {
            "use strict";
            n.d(t, {
                Ee: function() {
                    return x
                },
                NY: function() {
                    return b
                },
                fC: function() {
                    return g
                }
            });
            var r = n(1119),
                a = n(2265),
                i = n(73966),
                o = n(26606),
                s = n(61188),
                l = n(82912);
            let c = "Avatar",
                [d, u] = (0, i.b)(c),
                [f, m] = d(c),
                h = (0, a.forwardRef)((e, t) => {
                    let {
                        __scopeAvatar: n,
                        ...i
                    } = e, [o, s] = (0, a.useState)("idle");
                    return (0, a.createElement)(f, {
                        scope: n,
                        imageLoadingStatus: o,
                        onImageLoadingStatusChange: s
                    }, (0, a.createElement)(l.WV.span, (0, r.Z)({}, i, {
                        ref: t
                    })))
                }),
                p = (0, a.forwardRef)((e, t) => {
                    let {
                        __scopeAvatar: n,
                        src: i,
                        onLoadingStatusChange: c = () => {},
                        ...d
                    } = e, u = m("AvatarImage", n), f = function(e) {
                        let [t, n] = (0, a.useState)("idle");
                        return (0, s.b)(() => {
                            if (!e) {
                                n("error");
                                return
                            }
                            let t = !0,
                                r = new window.Image,
                                a = e => () => {
                                    t && n(e)
                                };
                            return n("loading"), r.onload = a("loaded"), r.onerror = a("error"), r.src = e, () => {
                                t = !1
                            }
                        }, [e]), t
                    }(i), h = (0, o.W)(e => {
                        c(e), u.onImageLoadingStatusChange(e)
                    });
                    return (0, s.b)(() => {
                        "idle" !== f && h(f)
                    }, [f, h]), "loaded" === f ? (0, a.createElement)(l.WV.img, (0, r.Z)({}, d, {
                        ref: t,
                        src: i
                    })) : null
                }),
                v = (0, a.forwardRef)((e, t) => {
                    let {
                        __scopeAvatar: n,
                        delayMs: i,
                        ...o
                    } = e, s = m("AvatarFallback", n), [c, d] = (0, a.useState)(void 0 === i);
                    return (0, a.useEffect)(() => {
                        if (void 0 !== i) {
                            let e = window.setTimeout(() => d(!0), i);
                            return () => window.clearTimeout(e)
                        }
                    }, [i]), c && "loaded" !== s.imageLoadingStatus ? (0, a.createElement)(l.WV.span, (0, r.Z)({}, o, {
                        ref: t
                    })) : null
                }),
                g = h,
                x = p,
                b = v
        },
        98482: function(e, t, n) {
            "use strict";
            n.d(t, {
                g7: function() {
                    return i
                }
            });
            var r = n(2265),
                a = n(57437),
                i = r.forwardRef((e, t) => {
                    let {
                        children: n,
                        ...i
                    } = e, s = r.Children.toArray(n), c = s.find(l);
                    if (c) {
                        let e = c.props.children,
                            n = s.map(t => t !== c ? t : r.Children.count(e) > 1 ? r.Children.only(null) : r.isValidElement(e) ? e.props.children : null);
                        return (0, a.jsx)(o, { ...i,
                            ref: t,
                            children: r.isValidElement(e) ? r.cloneElement(e, void 0, n) : null
                        })
                    }
                    return (0, a.jsx)(o, { ...i,
                        ref: t,
                        children: n
                    })
                });
            i.displayName = "Slot";
            var o = r.forwardRef((e, t) => {
                let {
                    children: n,
                    ...a
                } = e;
                if (r.isValidElement(n)) {
                    let e, i;
                    let o = (e = Object.getOwnPropertyDescriptor(n.props, "ref") ? .get) && "isReactWarning" in e && e.isReactWarning ? n.ref : (e = Object.getOwnPropertyDescriptor(n, "ref") ? .get) && "isReactWarning" in e && e.isReactWarning ? n.props.ref : n.props.ref || n.ref;
                    return r.cloneElement(n, { ... function(e, t) {
                            let n = { ...t
                            };
                            for (let r in t) {
                                let a = e[r],
                                    i = t[r];
                                /^on[A-Z]/.test(r) ? a && i ? n[r] = (...e) => {
                                    i(...e), a(...e)
                                } : a && (n[r] = a) : "style" === r ? n[r] = { ...a,
                                    ...i
                                } : "className" === r && (n[r] = [a, i].filter(Boolean).join(" "))
                            }
                            return { ...e,
                                ...n
                            }
                        }(a, n.props),
                        ref: t ? function(...e) {
                            return t => e.forEach(e => {
                                "function" == typeof e ? e(t) : null != e && (e.current = t)
                            })
                        }(t, o) : o
                    })
                }
                return r.Children.count(n) > 1 ? r.Children.only(null) : null
            });
            o.displayName = "SlotClone";
            var s = ({
                children: e
            }) => (0, a.jsx)(a.Fragment, {
                children: e
            });

            function l(e) {
                return r.isValidElement(e) && e.type === s
            }
        },
        77712: function(e, t, n) {
            "use strict";
            n.d(t, {
                j: function() {
                    return i
                }
            });
            let r = e => "boolean" == typeof e ? "".concat(e) : 0 === e ? "0" : e,
                a = function() {
                    for (var e, t, n = 0, r = ""; n < arguments.length;)(e = arguments[n++]) && (t = function e(t) {
                        var n, r, a = "";
                        if ("string" == typeof t || "number" == typeof t) a += t;
                        else if ("object" == typeof t) {
                            if (Array.isArray(t))
                                for (n = 0; n < t.length; n++) t[n] && (r = e(t[n])) && (a && (a += " "), a += r);
                            else
                                for (n in t) t[n] && (a && (a += " "), a += n)
                        }
                        return a
                    }(e)) && (r && (r += " "), r += t);
                    return r
                },
                i = (e, t) => n => {
                    var i;
                    if ((null == t ? void 0 : t.variants) == null) return a(e, null == n ? void 0 : n.class, null == n ? void 0 : n.className);
                    let {
                        variants: o,
                        defaultVariants: s
                    } = t, l = Object.keys(o).map(e => {
                        let t = null == n ? void 0 : n[e],
                            a = null == s ? void 0 : s[e];
                        if (null === t) return null;
                        let i = r(t) || r(a);
                        return o[e][i]
                    }), c = n && Object.entries(n).reduce((e, t) => {
                        let [n, r] = t;
                        return void 0 === r || (e[n] = r), e
                    }, {});
                    return a(e, l, null == t ? void 0 : null === (i = t.compoundVariants) || void 0 === i ? void 0 : i.reduce((e, t) => {
                        let {
                            class: n,
                            className: r,
                            ...a
                        } = t;
                        return Object.entries(a).every(e => {
                            let [t, n] = e;
                            return Array.isArray(n) ? n.includes({ ...s,
                                ...c
                            }[t]) : ({ ...s,
                                ...c
                            })[t] === n
                        }) ? [...e, n, r] : e
                    }, []), null == n ? void 0 : n.class, null == n ? void 0 : n.className)
                }
        }
    }
]);