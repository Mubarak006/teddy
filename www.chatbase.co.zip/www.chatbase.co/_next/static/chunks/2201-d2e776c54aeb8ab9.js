"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2201], {
        30401: function(e, n, t) {
            t.d(n, {
                Z: function() {
                    return r
                }
            });
            let r = (0, t(79205).Z)("Check", [
                ["path", {
                    d: "M20 6 9 17l-5-5",
                    key: "1gmf2c"
                }]
            ])
        },
        10407: function(e, n, t) {
            t.d(n, {
                Z: function() {
                    return r
                }
            });
            let r = (0, t(79205).Z)("ChevronRight", [
                ["path", {
                    d: "m9 18 6-6-6-6",
                    key: "mthhwq"
                }]
            ])
        },
        40519: function(e, n, t) {
            t.d(n, {
                Z: function() {
                    return r
                }
            });
            let r = (0, t(79205).Z)("Circle", [
                ["circle", {
                    cx: "12",
                    cy: "12",
                    r: "10",
                    key: "1mglay"
                }]
            ])
        },
        28119: function(e, n, t) {
            t.d(n, {
                oC: function() {
                    return e1
                },
                VY: function() {
                    return eJ
                },
                ZA: function() {
                    return eQ
                },
                ck: function() {
                    return e0
                },
                wU: function() {
                    return e5
                },
                __: function() {
                    return e$
                },
                Uv: function() {
                    return eq
                },
                Ee: function() {
                    return e2
                },
                Rk: function() {
                    return e9
                },
                fC: function() {
                    return ej
                },
                Z0: function() {
                    return e7
                },
                Tr: function() {
                    return e6
                },
                tu: function() {
                    return e8
                },
                fF: function() {
                    return e3
                },
                xz: function() {
                    return eH
                }
            });
            var r = t(1119),
                o = t(2265),
                a = t(6741),
                l = t(98575),
                u = t(73966),
                c = t(80886),
                i = t(82912),
                d = t(71605),
                s = t(29114),
                p = t(15278),
                f = t(86097),
                m = t(99103),
                v = t(99255),
                g = t(77331),
                h = t(83832),
                w = t(71599),
                E = t(1353);
            let M = (0, o.forwardRef)((e, n) => {
                let {
                    children: t,
                    ...a
                } = e, l = o.Children.toArray(t), u = l.find(y);
                if (u) {
                    let e = u.props.children,
                        t = l.map(n => n !== u ? n : o.Children.count(e) > 1 ? o.Children.only(null) : (0, o.isValidElement)(e) ? e.props.children : null);
                    return (0, o.createElement)(_, (0, r.Z)({}, a, {
                        ref: n
                    }), (0, o.isValidElement)(e) ? (0, o.cloneElement)(e, void 0, t) : null)
                }
                return (0, o.createElement)(_, (0, r.Z)({}, a, {
                    ref: n
                }), t)
            });
            M.displayName = "Slot";
            let _ = (0, o.forwardRef)((e, n) => {
                let {
                    children: t,
                    ...r
                } = e;
                return (0, o.isValidElement)(t) ? (0, o.cloneElement)(t, { ... function(e, n) {
                        let t = { ...n
                        };
                        for (let r in n) {
                            let o = e[r],
                                a = n[r];
                            /^on[A-Z]/.test(r) ? o && a ? t[r] = (...e) => {
                                a(...e), o(...e)
                            } : o && (t[r] = o) : "style" === r ? t[r] = { ...o,
                                ...a
                            } : "className" === r && (t[r] = [o, a].filter(Boolean).join(" "))
                        }
                        return { ...e,
                            ...t
                        }
                    }(r, t.props),
                    ref: n ? (0, l.F)(n, t.ref) : t.ref
                }) : o.Children.count(t) > 1 ? o.Children.only(null) : null
            });
            _.displayName = "SlotClone";
            let C = ({
                children: e
            }) => (0, o.createElement)(o.Fragment, null, e);

            function y(e) {
                return (0, o.isValidElement)(e) && e.type === C
            }
            var b = t(26606),
                D = t(5478),
                R = t(60703);
            let k = ["Enter", " "],
                Z = ["ArrowUp", "PageDown", "End"],
                P = ["ArrowDown", "PageUp", "Home", ...Z],
                O = {
                    ltr: [...k, "ArrowRight"],
                    rtl: [...k, "ArrowLeft"]
                },
                x = {
                    ltr: ["ArrowLeft"],
                    rtl: ["ArrowRight"]
                },
                T = "Menu",
                [I, F, S] = (0, d.B)(T),
                [K, V] = (0, u.b)(T, [S, g.D7, E.Pc]),
                A = (0, g.D7)(),
                L = (0, E.Pc)(),
                [W, U] = K(T),
                [G, B] = K(T),
                z = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeMenu: t,
                        ...a
                    } = e, l = A(t);
                    return (0, o.createElement)(g.ee, (0, r.Z)({}, l, a, {
                        ref: n
                    }))
                }),
                X = "MenuPortal",
                [N, Y] = K(X, {
                    forceMount: void 0
                }),
                j = "MenuContent",
                [H, q] = K(j),
                J = (0, o.forwardRef)((e, n) => {
                    let t = Y(j, e.__scopeMenu),
                        {
                            forceMount: a = t.forceMount,
                            ...l
                        } = e,
                        u = U(j, e.__scopeMenu),
                        c = B(j, e.__scopeMenu);
                    return (0, o.createElement)(I.Provider, {
                        scope: e.__scopeMenu
                    }, (0, o.createElement)(w.z, {
                        present: a || u.open
                    }, (0, o.createElement)(I.Slot, {
                        scope: e.__scopeMenu
                    }, c.modal ? (0, o.createElement)(Q, (0, r.Z)({}, l, {
                        ref: n
                    })) : (0, o.createElement)($, (0, r.Z)({}, l, {
                        ref: n
                    })))))
                }),
                Q = (0, o.forwardRef)((e, n) => {
                    let t = U(j, e.__scopeMenu),
                        u = (0, o.useRef)(null),
                        c = (0, l.e)(n, u);
                    return (0, o.useEffect)(() => {
                        let e = u.current;
                        if (e) return (0, D.Ry)(e)
                    }, []), (0, o.createElement)(ee, (0, r.Z)({}, e, {
                        ref: c,
                        trapFocus: t.open,
                        disableOutsidePointerEvents: t.open,
                        disableOutsideScroll: !0,
                        onFocusOutside: (0, a.M)(e.onFocusOutside, e => e.preventDefault(), {
                            checkForDefaultPrevented: !1
                        }),
                        onDismiss: () => t.onOpenChange(!1)
                    }))
                }),
                $ = (0, o.forwardRef)((e, n) => {
                    let t = U(j, e.__scopeMenu);
                    return (0, o.createElement)(ee, (0, r.Z)({}, e, {
                        ref: n,
                        trapFocus: !1,
                        disableOutsidePointerEvents: !1,
                        disableOutsideScroll: !1,
                        onDismiss: () => t.onOpenChange(!1)
                    }))
                }),
                ee = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeMenu: t,
                        loop: u = !1,
                        trapFocus: c,
                        onOpenAutoFocus: i,
                        onCloseAutoFocus: d,
                        disableOutsidePointerEvents: s,
                        onEntryFocus: v,
                        onEscapeKeyDown: h,
                        onPointerDownOutside: w,
                        onFocusOutside: _,
                        onInteractOutside: C,
                        onDismiss: y,
                        disableOutsideScroll: b,
                        ...D
                    } = e, k = U(j, t), O = B(j, t), x = A(t), T = L(t), I = F(t), [S, K] = (0, o.useState)(null), V = (0, o.useRef)(null), W = (0, l.e)(n, V, k.onContentChange), G = (0, o.useRef)(0), z = (0, o.useRef)(""), X = (0, o.useRef)(0), N = (0, o.useRef)(null), Y = (0, o.useRef)("right"), q = (0, o.useRef)(0), J = b ? R.Z : o.Fragment, Q = e => {
                        var n, t;
                        let r = z.current + e,
                            o = I().filter(e => !e.disabled),
                            a = document.activeElement,
                            l = null === (n = o.find(e => e.ref.current === a)) || void 0 === n ? void 0 : n.textValue,
                            u = function(e, n, t) {
                                var r;
                                let o = n.length > 1 && Array.from(n).every(e => e === n[0]) ? n[0] : n,
                                    a = (r = Math.max(t ? e.indexOf(t) : -1, 0), e.map((n, t) => e[(r + t) % e.length]));
                                1 === o.length && (a = a.filter(e => e !== t));
                                let l = a.find(e => e.toLowerCase().startsWith(o.toLowerCase()));
                                return l !== t ? l : void 0
                            }(o.map(e => e.textValue), r, l),
                            c = null === (t = o.find(e => e.textValue === u)) || void 0 === t ? void 0 : t.ref.current;
                        ! function e(n) {
                            z.current = n, window.clearTimeout(G.current), "" !== n && (G.current = window.setTimeout(() => e(""), 1e3))
                        }(r), c && setTimeout(() => c.focus())
                    };
                    (0, o.useEffect)(() => () => window.clearTimeout(G.current), []), (0, f.EW)();
                    let $ = (0, o.useCallback)(e => {
                        var n, t, r;
                        return Y.current === (null === (n = N.current) || void 0 === n ? void 0 : n.side) && !!(r = null === (t = N.current) || void 0 === t ? void 0 : t.area) && function(e, n) {
                            let {
                                x: t,
                                y: r
                            } = e, o = !1;
                            for (let e = 0, a = n.length - 1; e < n.length; a = e++) {
                                let l = n[e].x,
                                    u = n[e].y,
                                    c = n[a].x,
                                    i = n[a].y;
                                u > r != i > r && t < (c - l) * (r - u) / (i - u) + l && (o = !o)
                            }
                            return o
                        }({
                            x: e.clientX,
                            y: e.clientY
                        }, r)
                    }, []);
                    return (0, o.createElement)(H, {
                        scope: t,
                        searchRef: z,
                        onItemEnter: (0, o.useCallback)(e => {
                            $(e) && e.preventDefault()
                        }, [$]),
                        onItemLeave: (0, o.useCallback)(e => {
                            var n;
                            $(e) || (null === (n = V.current) || void 0 === n || n.focus(), K(null))
                        }, [$]),
                        onTriggerLeave: (0, o.useCallback)(e => {
                            $(e) && e.preventDefault()
                        }, [$]),
                        pointerGraceTimerRef: X,
                        onPointerGraceIntentChange: (0, o.useCallback)(e => {
                            N.current = e
                        }, [])
                    }, (0, o.createElement)(J, b ? {
                        as: M,
                        allowPinchZoom: !0
                    } : void 0, (0, o.createElement)(m.M, {
                        asChild: !0,
                        trapped: c,
                        onMountAutoFocus: (0, a.M)(i, e => {
                            var n;
                            e.preventDefault(), null === (n = V.current) || void 0 === n || n.focus()
                        }),
                        onUnmountAutoFocus: d
                    }, (0, o.createElement)(p.XB, {
                        asChild: !0,
                        disableOutsidePointerEvents: s,
                        onEscapeKeyDown: h,
                        onPointerDownOutside: w,
                        onFocusOutside: _,
                        onInteractOutside: C,
                        onDismiss: y
                    }, (0, o.createElement)(E.fC, (0, r.Z)({
                        asChild: !0
                    }, T, {
                        dir: O.dir,
                        orientation: "vertical",
                        loop: u,
                        currentTabStopId: S,
                        onCurrentTabStopIdChange: K,
                        onEntryFocus: (0, a.M)(v, e => {
                            O.isUsingKeyboardRef.current || e.preventDefault()
                        })
                    }), (0, o.createElement)(g.VY, (0, r.Z)({
                        role: "menu",
                        "aria-orientation": "vertical",
                        "data-state": ey(k.open),
                        "data-radix-menu-content": "",
                        dir: O.dir
                    }, x, D, {
                        ref: W,
                        style: {
                            outline: "none",
                            ...D.style
                        },
                        onKeyDown: (0, a.M)(D.onKeyDown, e => {
                            let n = e.target.closest("[data-radix-menu-content]") === e.currentTarget,
                                t = e.ctrlKey || e.altKey || e.metaKey,
                                r = 1 === e.key.length;
                            n && ("Tab" === e.key && e.preventDefault(), !t && r && Q(e.key));
                            let o = V.current;
                            if (e.target !== o || !P.includes(e.key)) return;
                            e.preventDefault();
                            let a = I().filter(e => !e.disabled).map(e => e.ref.current);
                            Z.includes(e.key) && a.reverse(),
                                function(e) {
                                    let n = document.activeElement;
                                    for (let t of e)
                                        if (t === n || (t.focus(), document.activeElement !== n)) return
                                }(a)
                        }),
                        onBlur: (0, a.M)(e.onBlur, e => {
                            e.currentTarget.contains(e.target) || (window.clearTimeout(G.current), z.current = "")
                        }),
                        onPointerMove: (0, a.M)(e.onPointerMove, eR(e => {
                            let n = e.target,
                                t = q.current !== e.clientX;
                            if (e.currentTarget.contains(n) && t) {
                                let n = e.clientX > q.current ? "right" : "left";
                                Y.current = n, q.current = e.clientX
                            }
                        }))
                    })))))))
                }),
                en = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeMenu: t,
                        ...a
                    } = e;
                    return (0, o.createElement)(i.WV.div, (0, r.Z)({
                        role: "group"
                    }, a, {
                        ref: n
                    }))
                }),
                et = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeMenu: t,
                        ...a
                    } = e;
                    return (0, o.createElement)(i.WV.div, (0, r.Z)({}, a, {
                        ref: n
                    }))
                }),
                er = "MenuItem",
                eo = "menu.itemSelect",
                ea = (0, o.forwardRef)((e, n) => {
                    let {
                        disabled: t = !1,
                        onSelect: u,
                        ...c
                    } = e, d = (0, o.useRef)(null), s = B(er, e.__scopeMenu), p = q(er, e.__scopeMenu), f = (0, l.e)(n, d), m = (0, o.useRef)(!1);
                    return (0, o.createElement)(el, (0, r.Z)({}, c, {
                        ref: f,
                        disabled: t,
                        onClick: (0, a.M)(e.onClick, () => {
                            let e = d.current;
                            if (!t && e) {
                                let n = new CustomEvent(eo, {
                                    bubbles: !0,
                                    cancelable: !0
                                });
                                e.addEventListener(eo, e => null == u ? void 0 : u(e), {
                                    once: !0
                                }), (0, i.jH)(e, n), n.defaultPrevented ? m.current = !1 : s.onClose()
                            }
                        }),
                        onPointerDown: n => {
                            var t;
                            null === (t = e.onPointerDown) || void 0 === t || t.call(e, n), m.current = !0
                        },
                        onPointerUp: (0, a.M)(e.onPointerUp, e => {
                            var n;
                            m.current || null === (n = e.currentTarget) || void 0 === n || n.click()
                        }),
                        onKeyDown: (0, a.M)(e.onKeyDown, e => {
                            let n = "" !== p.searchRef.current;
                            !t && (!n || " " !== e.key) && k.includes(e.key) && (e.currentTarget.click(), e.preventDefault())
                        })
                    }))
                }),
                el = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeMenu: t,
                        disabled: u = !1,
                        textValue: c,
                        ...d
                    } = e, s = q(er, t), p = L(t), f = (0, o.useRef)(null), m = (0, l.e)(n, f), [v, g] = (0, o.useState)(!1), [h, w] = (0, o.useState)("");
                    return (0, o.useEffect)(() => {
                        let e = f.current;
                        if (e) {
                            var n;
                            w((null !== (n = e.textContent) && void 0 !== n ? n : "").trim())
                        }
                    }, [d.children]), (0, o.createElement)(I.ItemSlot, {
                        scope: t,
                        disabled: u,
                        textValue: null != c ? c : h
                    }, (0, o.createElement)(E.ck, (0, r.Z)({
                        asChild: !0
                    }, p, {
                        focusable: !u
                    }), (0, o.createElement)(i.WV.div, (0, r.Z)({
                        role: "menuitem",
                        "data-highlighted": v ? "" : void 0,
                        "aria-disabled": u || void 0,
                        "data-disabled": u ? "" : void 0
                    }, d, {
                        ref: m,
                        onPointerMove: (0, a.M)(e.onPointerMove, eR(e => {
                            u ? s.onItemLeave(e) : (s.onItemEnter(e), e.defaultPrevented || e.currentTarget.focus())
                        })),
                        onPointerLeave: (0, a.M)(e.onPointerLeave, eR(e => s.onItemLeave(e))),
                        onFocus: (0, a.M)(e.onFocus, () => g(!0)),
                        onBlur: (0, a.M)(e.onBlur, () => g(!1))
                    }))))
                }),
                eu = (0, o.forwardRef)((e, n) => {
                    let {
                        checked: t = !1,
                        onCheckedChange: l,
                        ...u
                    } = e;
                    return (0, o.createElement)(ef, {
                        scope: e.__scopeMenu,
                        checked: t
                    }, (0, o.createElement)(ea, (0, r.Z)({
                        role: "menuitemcheckbox",
                        "aria-checked": eb(t) ? "mixed" : t
                    }, u, {
                        ref: n,
                        "data-state": eD(t),
                        onSelect: (0, a.M)(u.onSelect, () => null == l ? void 0 : l(!!eb(t) || !t), {
                            checkForDefaultPrevented: !1
                        })
                    })))
                }),
                [ec, ei] = K("MenuRadioGroup", {
                    value: void 0,
                    onValueChange: () => {}
                }),
                ed = (0, o.forwardRef)((e, n) => {
                    let {
                        value: t,
                        onValueChange: a,
                        ...l
                    } = e, u = (0, b.W)(a);
                    return (0, o.createElement)(ec, {
                        scope: e.__scopeMenu,
                        value: t,
                        onValueChange: u
                    }, (0, o.createElement)(en, (0, r.Z)({}, l, {
                        ref: n
                    })))
                }),
                es = (0, o.forwardRef)((e, n) => {
                    let {
                        value: t,
                        ...l
                    } = e, u = ei("MenuRadioItem", e.__scopeMenu), c = t === u.value;
                    return (0, o.createElement)(ef, {
                        scope: e.__scopeMenu,
                        checked: c
                    }, (0, o.createElement)(ea, (0, r.Z)({
                        role: "menuitemradio",
                        "aria-checked": c
                    }, l, {
                        ref: n,
                        "data-state": eD(c),
                        onSelect: (0, a.M)(l.onSelect, () => {
                            var e;
                            return null === (e = u.onValueChange) || void 0 === e ? void 0 : e.call(u, t)
                        }, {
                            checkForDefaultPrevented: !1
                        })
                    })))
                }),
                ep = "MenuItemIndicator",
                [ef, em] = K(ep, {
                    checked: !1
                }),
                ev = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeMenu: t,
                        forceMount: a,
                        ...l
                    } = e, u = em(ep, t);
                    return (0, o.createElement)(w.z, {
                        present: a || eb(u.checked) || !0 === u.checked
                    }, (0, o.createElement)(i.WV.span, (0, r.Z)({}, l, {
                        ref: n,
                        "data-state": eD(u.checked)
                    })))
                }),
                eg = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeMenu: t,
                        ...a
                    } = e;
                    return (0, o.createElement)(i.WV.div, (0, r.Z)({
                        role: "separator",
                        "aria-orientation": "horizontal"
                    }, a, {
                        ref: n
                    }))
                }),
                eh = ((e, n) => {
                    let {
                        __scopeMenu: t,
                        ...a
                    } = e, l = A(t);
                    return (0, o.createElement)(g.Eh, (0, r.Z)({}, l, a, {
                        ref: n
                    }))
                }, "MenuSub"),
                [ew, eE] = K(eh),
                eM = "MenuSubTrigger",
                e_ = (0, o.forwardRef)((e, n) => {
                    let t = U(eM, e.__scopeMenu),
                        u = B(eM, e.__scopeMenu),
                        c = eE(eM, e.__scopeMenu),
                        i = q(eM, e.__scopeMenu),
                        d = (0, o.useRef)(null),
                        {
                            pointerGraceTimerRef: s,
                            onPointerGraceIntentChange: p
                        } = i,
                        f = {
                            __scopeMenu: e.__scopeMenu
                        },
                        m = (0, o.useCallback)(() => {
                            d.current && window.clearTimeout(d.current), d.current = null
                        }, []);
                    return (0, o.useEffect)(() => m, [m]), (0, o.useEffect)(() => {
                        let e = s.current;
                        return () => {
                            window.clearTimeout(e), p(null)
                        }
                    }, [s, p]), (0, o.createElement)(z, (0, r.Z)({
                        asChild: !0
                    }, f), (0, o.createElement)(el, (0, r.Z)({
                        id: c.triggerId,
                        "aria-haspopup": "menu",
                        "aria-expanded": t.open,
                        "aria-controls": c.contentId,
                        "data-state": ey(t.open)
                    }, e, {
                        ref: (0, l.F)(n, c.onTriggerChange),
                        onClick: n => {
                            var r;
                            null === (r = e.onClick) || void 0 === r || r.call(e, n), e.disabled || n.defaultPrevented || (n.currentTarget.focus(), t.open || t.onOpenChange(!0))
                        },
                        onPointerMove: (0, a.M)(e.onPointerMove, eR(n => {
                            i.onItemEnter(n), n.defaultPrevented || e.disabled || t.open || d.current || (i.onPointerGraceIntentChange(null), d.current = window.setTimeout(() => {
                                t.onOpenChange(!0), m()
                            }, 100))
                        })),
                        onPointerLeave: (0, a.M)(e.onPointerLeave, eR(e => {
                            var n, r;
                            m();
                            let o = null === (n = t.content) || void 0 === n ? void 0 : n.getBoundingClientRect();
                            if (o) {
                                let n = null === (r = t.content) || void 0 === r ? void 0 : r.dataset.side,
                                    a = "right" === n,
                                    l = o[a ? "left" : "right"],
                                    u = o[a ? "right" : "left"];
                                i.onPointerGraceIntentChange({
                                    area: [{
                                        x: e.clientX + (a ? -5 : 5),
                                        y: e.clientY
                                    }, {
                                        x: l,
                                        y: o.top
                                    }, {
                                        x: u,
                                        y: o.top
                                    }, {
                                        x: u,
                                        y: o.bottom
                                    }, {
                                        x: l,
                                        y: o.bottom
                                    }],
                                    side: n
                                }), window.clearTimeout(s.current), s.current = window.setTimeout(() => i.onPointerGraceIntentChange(null), 300)
                            } else {
                                if (i.onTriggerLeave(e), e.defaultPrevented) return;
                                i.onPointerGraceIntentChange(null)
                            }
                        })),
                        onKeyDown: (0, a.M)(e.onKeyDown, n => {
                            let r = "" !== i.searchRef.current;
                            if (!e.disabled && (!r || " " !== n.key) && O[u.dir].includes(n.key)) {
                                var o;
                                t.onOpenChange(!0), null === (o = t.content) || void 0 === o || o.focus(), n.preventDefault()
                            }
                        })
                    })))
                }),
                eC = (0, o.forwardRef)((e, n) => {
                    let t = Y(j, e.__scopeMenu),
                        {
                            forceMount: u = t.forceMount,
                            ...c
                        } = e,
                        i = U(j, e.__scopeMenu),
                        d = B(j, e.__scopeMenu),
                        s = eE("MenuSubContent", e.__scopeMenu),
                        p = (0, o.useRef)(null),
                        f = (0, l.e)(n, p);
                    return (0, o.createElement)(I.Provider, {
                        scope: e.__scopeMenu
                    }, (0, o.createElement)(w.z, {
                        present: u || i.open
                    }, (0, o.createElement)(I.Slot, {
                        scope: e.__scopeMenu
                    }, (0, o.createElement)(ee, (0, r.Z)({
                        id: s.contentId,
                        "aria-labelledby": s.triggerId
                    }, c, {
                        ref: f,
                        align: "start",
                        side: "rtl" === d.dir ? "left" : "right",
                        disableOutsidePointerEvents: !1,
                        disableOutsideScroll: !1,
                        trapFocus: !1,
                        onOpenAutoFocus: e => {
                            var n;
                            d.isUsingKeyboardRef.current && (null === (n = p.current) || void 0 === n || n.focus()), e.preventDefault()
                        },
                        onCloseAutoFocus: e => e.preventDefault(),
                        onFocusOutside: (0, a.M)(e.onFocusOutside, e => {
                            e.target !== s.trigger && i.onOpenChange(!1)
                        }),
                        onEscapeKeyDown: (0, a.M)(e.onEscapeKeyDown, e => {
                            d.onClose(), e.preventDefault()
                        }),
                        onKeyDown: (0, a.M)(e.onKeyDown, e => {
                            let n = e.currentTarget.contains(e.target),
                                t = x[d.dir].includes(e.key);
                            if (n && t) {
                                var r;
                                i.onOpenChange(!1), null === (r = s.trigger) || void 0 === r || r.focus(), e.preventDefault()
                            }
                        })
                    })))))
                });

            function ey(e) {
                return e ? "open" : "closed"
            }

            function eb(e) {
                return "indeterminate" === e
            }

            function eD(e) {
                return eb(e) ? "indeterminate" : e ? "checked" : "unchecked"
            }

            function eR(e) {
                return n => "mouse" === n.pointerType ? e(n) : void 0
            }
            let ek = e => {
                    let {
                        __scopeMenu: n,
                        open: t = !1,
                        children: r,
                        dir: a,
                        onOpenChange: l,
                        modal: u = !0
                    } = e, c = A(n), [i, d] = (0, o.useState)(null), p = (0, o.useRef)(!1), f = (0, b.W)(l), m = (0, s.gm)(a);
                    return (0, o.useEffect)(() => {
                        let e = () => {
                                p.current = !0, document.addEventListener("pointerdown", n, {
                                    capture: !0,
                                    once: !0
                                }), document.addEventListener("pointermove", n, {
                                    capture: !0,
                                    once: !0
                                })
                            },
                            n = () => p.current = !1;
                        return document.addEventListener("keydown", e, {
                            capture: !0
                        }), () => {
                            document.removeEventListener("keydown", e, {
                                capture: !0
                            }), document.removeEventListener("pointerdown", n, {
                                capture: !0
                            }), document.removeEventListener("pointermove", n, {
                                capture: !0
                            })
                        }
                    }, []), (0, o.createElement)(g.fC, c, (0, o.createElement)(W, {
                        scope: n,
                        open: t,
                        onOpenChange: f,
                        content: i,
                        onContentChange: d
                    }, (0, o.createElement)(G, {
                        scope: n,
                        onClose: (0, o.useCallback)(() => f(!1), [f]),
                        isUsingKeyboardRef: p,
                        dir: m,
                        modal: u
                    }, r)))
                },
                eZ = e => {
                    let {
                        __scopeMenu: n,
                        forceMount: t,
                        children: r,
                        container: a
                    } = e, l = U(X, n);
                    return (0, o.createElement)(N, {
                        scope: n,
                        forceMount: t
                    }, (0, o.createElement)(w.z, {
                        present: t || l.open
                    }, (0, o.createElement)(h.h, {
                        asChild: !0,
                        container: a
                    }, r)))
                },
                eP = e => {
                    let {
                        __scopeMenu: n,
                        children: t,
                        open: r = !1,
                        onOpenChange: a
                    } = e, l = U(eh, n), u = A(n), [c, i] = (0, o.useState)(null), [d, s] = (0, o.useState)(null), p = (0, b.W)(a);
                    return (0, o.useEffect)(() => (!1 === l.open && p(!1), () => p(!1)), [l.open, p]), (0, o.createElement)(g.fC, u, (0, o.createElement)(W, {
                        scope: n,
                        open: r,
                        onOpenChange: p,
                        content: d,
                        onContentChange: s
                    }, (0, o.createElement)(ew, {
                        scope: n,
                        contentId: (0, v.M)(),
                        triggerId: (0, v.M)(),
                        trigger: c,
                        onTriggerChange: i
                    }, t)))
                },
                eO = "DropdownMenu",
                [ex, eT] = (0, u.b)(eO, [V]),
                eI = V(),
                [eF, eS] = ex(eO),
                eK = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeDropdownMenu: t,
                        disabled: u = !1,
                        ...c
                    } = e, d = eS("DropdownMenuTrigger", t), s = eI(t);
                    return (0, o.createElement)(z, (0, r.Z)({
                        asChild: !0
                    }, s), (0, o.createElement)(i.WV.button, (0, r.Z)({
                        type: "button",
                        id: d.triggerId,
                        "aria-haspopup": "menu",
                        "aria-expanded": d.open,
                        "aria-controls": d.open ? d.contentId : void 0,
                        "data-state": d.open ? "open" : "closed",
                        "data-disabled": u ? "" : void 0,
                        disabled: u
                    }, c, {
                        ref: (0, l.F)(n, d.triggerRef),
                        onPointerDown: (0, a.M)(e.onPointerDown, e => {
                            u || 0 !== e.button || !1 !== e.ctrlKey || (d.onOpenToggle(), d.open || e.preventDefault())
                        }),
                        onKeyDown: (0, a.M)(e.onKeyDown, e => {
                            !u && (["Enter", " "].includes(e.key) && d.onOpenToggle(), "ArrowDown" === e.key && d.onOpenChange(!0), ["Enter", " ", "ArrowDown"].includes(e.key) && e.preventDefault())
                        })
                    })))
                }),
                eV = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeDropdownMenu: t,
                        ...l
                    } = e, u = eS("DropdownMenuContent", t), c = eI(t), i = (0, o.useRef)(!1);
                    return (0, o.createElement)(J, (0, r.Z)({
                        id: u.contentId,
                        "aria-labelledby": u.triggerId
                    }, c, l, {
                        ref: n,
                        onCloseAutoFocus: (0, a.M)(e.onCloseAutoFocus, e => {
                            var n;
                            i.current || null === (n = u.triggerRef.current) || void 0 === n || n.focus(), i.current = !1, e.preventDefault()
                        }),
                        onInteractOutside: (0, a.M)(e.onInteractOutside, e => {
                            let n = e.detail.originalEvent,
                                t = 0 === n.button && !0 === n.ctrlKey,
                                r = 2 === n.button || t;
                            (!u.modal || r) && (i.current = !0)
                        }),
                        style: { ...e.style,
                            "--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
                            "--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
                            "--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
                            "--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
                            "--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
                        }
                    }))
                }),
                eA = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeDropdownMenu: t,
                        ...a
                    } = e, l = eI(t);
                    return (0, o.createElement)(en, (0, r.Z)({}, l, a, {
                        ref: n
                    }))
                }),
                eL = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeDropdownMenu: t,
                        ...a
                    } = e, l = eI(t);
                    return (0, o.createElement)(et, (0, r.Z)({}, l, a, {
                        ref: n
                    }))
                }),
                eW = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeDropdownMenu: t,
                        ...a
                    } = e, l = eI(t);
                    return (0, o.createElement)(ea, (0, r.Z)({}, l, a, {
                        ref: n
                    }))
                }),
                eU = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeDropdownMenu: t,
                        ...a
                    } = e, l = eI(t);
                    return (0, o.createElement)(eu, (0, r.Z)({}, l, a, {
                        ref: n
                    }))
                }),
                eG = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeDropdownMenu: t,
                        ...a
                    } = e, l = eI(t);
                    return (0, o.createElement)(ed, (0, r.Z)({}, l, a, {
                        ref: n
                    }))
                }),
                eB = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeDropdownMenu: t,
                        ...a
                    } = e, l = eI(t);
                    return (0, o.createElement)(es, (0, r.Z)({}, l, a, {
                        ref: n
                    }))
                }),
                ez = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeDropdownMenu: t,
                        ...a
                    } = e, l = eI(t);
                    return (0, o.createElement)(ev, (0, r.Z)({}, l, a, {
                        ref: n
                    }))
                }),
                eX = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeDropdownMenu: t,
                        ...a
                    } = e, l = eI(t);
                    return (0, o.createElement)(eg, (0, r.Z)({}, l, a, {
                        ref: n
                    }))
                }),
                eN = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeDropdownMenu: t,
                        ...a
                    } = e, l = eI(t);
                    return (0, o.createElement)(e_, (0, r.Z)({}, l, a, {
                        ref: n
                    }))
                }),
                eY = (0, o.forwardRef)((e, n) => {
                    let {
                        __scopeDropdownMenu: t,
                        ...a
                    } = e, l = eI(t);
                    return (0, o.createElement)(eC, (0, r.Z)({}, l, a, {
                        ref: n,
                        style: { ...e.style,
                            "--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
                            "--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
                            "--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
                            "--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
                            "--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
                        }
                    }))
                }),
                ej = e => {
                    let {
                        __scopeDropdownMenu: n,
                        children: t,
                        dir: a,
                        open: l,
                        defaultOpen: u,
                        onOpenChange: i,
                        modal: d = !0
                    } = e, s = eI(n), p = (0, o.useRef)(null), [f = !1, m] = (0, c.T)({
                        prop: l,
                        defaultProp: u,
                        onChange: i
                    });
                    return (0, o.createElement)(eF, {
                        scope: n,
                        triggerId: (0, v.M)(),
                        triggerRef: p,
                        contentId: (0, v.M)(),
                        open: f,
                        onOpenChange: m,
                        onOpenToggle: (0, o.useCallback)(() => m(e => !e), [m]),
                        modal: d
                    }, (0, o.createElement)(ek, (0, r.Z)({}, s, {
                        open: f,
                        onOpenChange: m,
                        dir: a,
                        modal: d
                    }), t))
                },
                eH = eK,
                eq = e => {
                    let {
                        __scopeDropdownMenu: n,
                        ...t
                    } = e, a = eI(n);
                    return (0, o.createElement)(eZ, (0, r.Z)({}, a, t))
                },
                eJ = eV,
                eQ = eA,
                e$ = eL,
                e0 = eW,
                e1 = eU,
                e2 = eG,
                e9 = eB,
                e5 = ez,
                e7 = eX,
                e6 = e => {
                    let {
                        __scopeDropdownMenu: n,
                        children: t,
                        open: a,
                        onOpenChange: l,
                        defaultOpen: u
                    } = e, i = eI(n), [d = !1, s] = (0, c.T)({
                        prop: a,
                        defaultProp: u,
                        onChange: l
                    });
                    return (0, o.createElement)(eP, (0, r.Z)({}, i, {
                        open: d,
                        onOpenChange: s
                    }), t)
                },
                e3 = eN,
                e8 = eY
        }
    }
]);