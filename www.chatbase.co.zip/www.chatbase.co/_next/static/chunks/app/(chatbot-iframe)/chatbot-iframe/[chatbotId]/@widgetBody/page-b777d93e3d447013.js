(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1680], {
        48401: function(e, t, n) {
            Promise.resolve().then(n.t.bind(n, 72972, 23)), Promise.resolve().then(n.bind(n, 5382))
        },
        33245: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("Info", [
                ["circle", {
                    cx: "12",
                    cy: "12",
                    r: "10",
                    key: "1mglay"
                }],
                ["path", {
                    d: "M12 16v-4",
                    key: "1dtifu"
                }],
                ["path", {
                    d: "M12 8h.01",
                    key: "e9boi3"
                }]
            ])
        },
        32489: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("X", [
                ["path", {
                    d: "M18 6 6 18",
                    key: "1bl5f8"
                }],
                ["path", {
                    d: "m6 6 12 12",
                    key: "d8bk6v"
                }]
            ])
        },
        99376: function(e, t, n) {
            "use strict";
            n.r(t);
            var r = n(35475),
                i = {};
            for (var o in r) "default" !== o && (i[o] = (function(e) {
                return r[e]
            }).bind(0, o));
            n.d(t, i)
        },
        27399: function(e, t, n) {
            "use strict";
            var r = n(57437),
                i = n(71488);
            t.Z = e => {
                let {
                    children: t,
                    content: n,
                    show: o = !0,
                    delayDuration: s,
                    asChild: a = !0
                } = e;
                return o ? (0, r.jsx)(i.pn, {
                    delayDuration: s,
                    children: (0, r.jsxs)(i.u, {
                        children: [(0, r.jsx)(i.aJ, {
                            asChild: a,
                            children: t
                        }), (0, r.jsx)(i._v, {
                            children: n
                        })]
                    })
                }) : (0, r.jsx)(r.Fragment, {
                    children: t
                })
            }
        },
        50430: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return j
                }
            });
            var r = n(57437);
            class i {
                async init(e) {
                    let t = new AudioContext({
                        sampleRate: e
                    });
                    await t.audioWorklet.addModule("/audio-playback-worklet.js"), this.playbackNode = new AudioWorkletNode(t, "audio-playback-worklet"), this.playbackNode.connect(t.destination)
                }
                play(e) {
                    this.playbackNode && this.playbackNode.port.postMessage(e)
                }
                stop() {
                    this.playbackNode && this.playbackNode.port.postMessage(null)
                }
                constructor() {
                    this.playbackNode = null
                }
            }
            var o = n(2265);
            class s {
                async start(e) {
                    try {
                        this.audioContext && await this.audioContext.close(), this.audioContext = new AudioContext({
                            sampleRate: 24e3
                        }), await this.audioContext.audioWorklet.addModule("/audio-processor-worklet.js"), this.mediaStream = e, this.mediaStreamSource = this.audioContext.createMediaStreamSource(this.mediaStream), this.gainNode = this.audioContext.createGain(), this.gainNode.gain.value = this.isMuted ? 0 : 1, this.workletNode = new AudioWorkletNode(this.audioContext, "audio-processor-worklet"), this.workletNode.port.onmessage = e => {
                            this.onDataAvailable(e.data.buffer)
                        }, this.analyser = this.audioContext.createAnalyser(), this.analyser.fftSize = 256, this.mediaStreamSource.connect(this.gainNode), this.gainNode.connect(this.analyser), this.analyser.connect(this.workletNode), this.workletNode.connect(this.audioContext.destination), this.isActive = !0, this.startVolumeCheck()
                    } catch (e) {
                        this.stop()
                    }
                }
                async stop() {
                    this.isActive = !1, this.mediaStream && (this.mediaStream.getTracks().forEach(e => e.stop()), this.mediaStream = null), this.audioContext && (await this.audioContext.close(), this.audioContext = null), this.mediaStreamSource = null, this.gainNode = null, this.workletNode = null, this.analyser = null
                }
                startVolumeCheck() {
                    if (!this.analyser) return;
                    let e = () => {
                        if (!this.isActive || !this.analyser) return;
                        let t = new Uint8Array(this.analyser.frequencyBinCount);
                        this.analyser.getByteFrequencyData(t);
                        let n = t.reduce((e, t) => e + t, 0) / t.length;
                        this.onUserSpeakingChange(n > 30), requestAnimationFrame(e)
                    };
                    e()
                }
                onUserSpeakingChange(e) {
                    console.log("User is speaking:", e)
                }
                isRecording() {
                    return this.isActive
                }
                mute() {
                    this.gainNode && (this.gainNode.gain.value = 0, this.isMuted = !0)
                }
                unmute() {
                    this.gainNode && (this.gainNode.gain.value = 1, this.isMuted = !1)
                }
                isAudioMuted() {
                    return this.isMuted
                }
                constructor(e) {
                    this.audioContext = null, this.mediaStream = null, this.mediaStreamSource = null, this.gainNode = null, this.workletNode = null, this.analyser = null, this.isActive = !1, this.isMuted = !1, this.onDataAvailable = e
                }
            }
            var a = n(71989),
                u = n(43061),
                l = n(2208),
                c = n(31229),
                d = n(25566);
            c.z.object({
                text: c.z.string().optional(),
                role: c.z.nativeEnum(u.WU),
                item_id: c.z.string(),
                tool_name: c.z.string().optional(),
                tool_result: c.z.union([a.Vc, a.Gv]).optional()
            });
            var f = n(1845),
                h = n(60730),
                p = n(48662),
                m = n(64719),
                v = n(99376),
                g = n(81201),
                b = n(67948),
                y = n(62035),
                x = n(83535),
                w = n(12465),
                k = n(25109),
                j = e => {
                    let {
                        chatbot: t
                    } = e, n = (0, x.m)(), a = null == n ? void 0 : n.disableRealtimeAudioMode, [c, j] = (0, o.useState)(!1), [z, N] = (0, o.useState)([]), {
                        addUserAudio: S,
                        inputAudioBufferClear: C
                    } = function(e) {
                        let {
                            enableInputAudioTranscription: t,
                            onWebSocketOpen: n,
                            onWebSocketClose: r,
                            onWebSocketError: i,
                            onWebSocketMessage: o,
                            onReceivedResponseDone: s,
                            onReceivedResponseAudioDelta: a,
                            onReceivedResponseAudioTranscriptDelta: u,
                            onReceivedInputAudioBufferSpeechStarted: c,
                            onReceivedExtensionMiddleTierToolResponse: f,
                            onReceivedInputAudioTranscriptionCompleted: h,
                            onReceivedResponseFunctionCallArgumentsDelta: p,
                            onReceivedResponseToolCallOutput: m,
                            onReceivedResponseConversationInterruption: v,
                            onReceivedError: g
                        } = e, {
                            sendJsonMessage: b
                        } = (0, l.ZP)("".concat(d.env.NEXT_PUBLIC_VOICE_CHATBOT_SERVER, "?chatbotId=").concat(d.env.NEXT_PUBLIC_VOICE_CHATBOT_ID) || "http://localhost:8081", {
                            onOpen: () => null == n ? void 0 : n(),
                            onClose: () => null == r ? void 0 : r(),
                            onError: e => null == i ? void 0 : i(e),
                            onMessage: e => y(e),
                            shouldReconnect: () => !0
                        }), y = e => {
                            let t;
                            null == o || o(e);
                            try {
                                t = JSON.parse(e.data)
                            } catch (e) {
                                throw console.error("Failed to parse JSON message:", e), e
                            }
                            switch (t.type) {
                                case "response.done":
                                    null == s || s(t);
                                    break;
                                case "response.audio.delta":
                                    null == a || a(t);
                                    break;
                                case "response.audio_transcript.delta":
                                    null == u || u(t);
                                    break;
                                case "response.conversation.interruption":
                                    console.log("response.conversation.interruption"), null == v || v(t);
                                    break;
                                case "input_audio_buffer.speech_started":
                                case "response.audio_buffer.speech_started":
                                    null == c || c(t);
                                    break;
                                case "conversation.item.input_audio_transcription.completed":
                                    null == h || h(t);
                                    break;
                                case "extension.middle_tier_tool_response":
                                    null == f || f(t);
                                    break;
                                case "conversation.item.create":
                                    null == m || m(t), console.log("conversation.item.create", t);
                                    break;
                                case "error":
                                    null == g || g(t)
                            }
                        };
                        return {
                            addUserAudio: e => {
                                b({
                                    type: "input_audio_buffer.append",
                                    audio: e
                                })
                            },
                            inputAudioBufferClear: () => {
                                b({
                                    type: "input_audio_buffer.clear"
                                })
                            }
                        }
                    }({
                        onWebSocketOpen: () => console.log("WebSocket connection opened"),
                        onWebSocketClose: () => console.log("WebSocket connection closed"),
                        onWebSocketError: e => console.error("WebSocket error:", e),
                        onReceivedError: e => console.error("error", e),
                        onReceivedResponseAudioDelta: e => {
                            c && T(e.delta)
                        },
                        onReceivedInputAudioBufferSpeechStarted: () => {
                            A()
                        },
                        onReceivedResponseFunctionCallArgumentsDelta: e => {
                            console.log("message", e)
                        },
                        onReceivedInputAudioTranscriptionCompleted: e => {
                            N(t => [...t, {
                                text: e.transcript,
                                role: u.WU.USER,
                                item_id: e.item_id
                            }])
                        },
                        onReceivedResponseConversationInterruption: e => {
                            A()
                        },
                        onReceivedResponseToolCallOutput: e => {
                            N(t => [...t, {
                                role: u.WU.TOOL,
                                item_id: e.item.id,
                                tool_name: e.tool_name,
                                tool_result: JSON.parse(e.item.output)
                            }])
                        },
                        onReceivedResponseAudioTranscriptDelta: e => {
                            if (z.find(t => t.item_id === e.item_id)) N(z.map(t => t.item_id === e.item_id ? { ...t,
                                text: t.text + e.delta
                            } : t));
                            else {
                                let t = { ...e,
                                    text: e.delta,
                                    role: u.WU.ASSISTANT
                                };
                                N(e => [...e, t])
                            }
                        }
                    }), {
                        reset: E,
                        play: T,
                        stop: A
                    } = function() {
                        let e = (0, o.useRef)();
                        return {
                            reset: () => {
                                e.current = new i, e.current.init(24e3)
                            },
                            play: t => {
                                var n;
                                let r = atob(t),
                                    i = new Int16Array(Uint8Array.from(r, e => e.charCodeAt(0)).buffer);
                                null === (n = e.current) || void 0 === n || n.play(i)
                            },
                            stop: () => {
                                var t;
                                null === (t = e.current) || void 0 === t || t.stop()
                            }
                        }
                    }(), {
                        start: _,
                        stop: R,
                        isUserSpeaking: O,
                        mute: L,
                        unmute: M,
                        isMuted: P
                    } = function(e) {
                        let {
                            onAudioRecorded: t
                        } = e, n = (0, o.useRef)(), [r, i] = (0, o.useState)(!1), [a, u] = (0, o.useState)(!1), [l, c] = (0, o.useState)(!1), d = new Uint8Array, f = e => {
                            let t = new Uint8Array(d.length + e.length);
                            t.set(d), t.set(e, d.length), d = t
                        }, h = e => {
                            if (f(new Uint8Array(e)), d.length >= 4800) {
                                let e = new Uint8Array(d.slice(0, 4800));
                                d = new Uint8Array(d.slice(4800)), t(btoa(String.fromCharCode(...e)))
                            }
                        }, p = (0, o.useCallback)(e => {
                            u(e)
                        }, []);
                        return {
                            start: async () => {
                                n.current || (n.current = new s(h), n.current.onUserSpeakingChange = p);
                                let e = await navigator.mediaDevices.getUserMedia({
                                    audio: {
                                        noiseSuppression: !0,
                                        echoCancellation: !0,
                                        autoGainControl: !1
                                    }
                                });
                                try {
                                    await n.current.start(e), i(!0)
                                } catch (e) {
                                    console.error("Error starting audio recording:", e)
                                }
                            },
                            stop: async () => {
                                var e;
                                await (null === (e = n.current) || void 0 === e ? void 0 : e.stop()), i(!1), u(!1)
                            },
                            isRecording: r,
                            isUserSpeaking: a,
                            mute: () => {
                                var e;
                                null === (e = n.current) || void 0 === e || e.mute(), c(!0)
                            },
                            unmute: () => {
                                var e;
                                null === (e = n.current) || void 0 === e || e.unmute(), c(!1)
                            },
                            isMuted: l
                        }
                    }({
                        onAudioRecorded: S
                    }), U = async () => {
                        c || (await _(), E(), j(!0))
                    }, I = async () => {
                        await R(), A(), C(), j(!1), null == a || a()
                    };
                    return (0, o.useEffect)(() => {
                        U()
                    }, []), (0, v.notFound)(), (0, r.jsxs)("div", {
                        className: "relative flex h-[calc(100vh-73px)] flex-col border-t",
                        children: [(0, r.jsx)("div", {
                            className: "flex flex-1 overflow-y-scroll",
                            children: (0, r.jsx)(y.S, {
                                children: z.map((e, n) => {
                                    switch (z.length, e.role) {
                                        case u.WU.TOOL:
                                            if ("get_shopify_products" === e.tool_name) return (0, r.jsx)(k.o, {
                                                result: {
                                                    data: e.tool_result,
                                                    status: "success"
                                                }
                                            });
                                            if ("get_shopify_orders" === e.tool_name) return (0, r.jsx)(w.A, {
                                                result: {
                                                    data: e.tool_result,
                                                    status: "success"
                                                }
                                            });
                                            return null;
                                        case u.WU.USER:
                                            return (0, r.jsx)("div", {
                                                className: "relative flex w-full flex-col items-end gap-2",
                                                children: (0, r.jsx)(b.cA, {
                                                    chatbotStyles: t.styles,
                                                    children: e.text
                                                }, e.item_id)
                                            });
                                        case u.WU.ASSISTANT:
                                            return (0, r.jsxs)(b.Mp, {
                                                avatarUrl: t.profilePicture,
                                                children: [(0, r.jsx)(b.am, {
                                                    children: (0, r.jsx)("div", {
                                                        className: "prose h-full w-full max-w-none text-sm text-zinc-950 group-data-[theme=dark]:text-zinc-300",
                                                        children: e.text
                                                    })
                                                }), " "]
                                            }, e.item_id)
                                    }
                                })
                            })
                        }), (0, r.jsxs)("div", {
                            className: "flex h-36 items-center justify-between bg-transparent px-5",
                            children: [(0, r.jsx)("div", {
                                className: "flex h-16 w-16 cursor-pointer items-center justify-center rounded-full border border-zinc-200 bg-white",
                                onClick: P ? M : L,
                                children: P ? (0, r.jsx)(h.Z, {
                                    className: "h-6 w-6 text-zinc-600"
                                }) : (0, r.jsx)(p.Z, {
                                    className: "h-6 w-6 text-zinc-600"
                                })
                            }), (0, r.jsx)("div", {
                                className: (0, g.cn)("mx-auto flex h-[200px] w-[200px] flex-1 items-center justify-center bg-transparent transition-transform duration-300", {
                                    "animate-pulseScale": O
                                }),
                                children: (0, r.jsx)(f.nI, {
                                    src: "/orb-2.lottie",
                                    loop: !0,
                                    autoplay: !0,
                                    style: {
                                        width: "150px",
                                        height: "150px"
                                    }
                                })
                            }), (0, r.jsx)("div", {
                                className: "flex h-16 w-16 cursor-pointer items-center justify-center rounded-full border border-zinc-200 bg-white",
                                onClick: I,
                                children: (0, r.jsx)(m.Z, {
                                    className: "h-6 w-6 text-zinc-600"
                                })
                            })]
                        })]
                    })
                }
        },
        5382: function(e, t, n) {
            "use strict";
            n.d(t, {
                ChatbotBody: function() {
                    return d
                }
            });
            var r = n(57437),
                i = n(12381),
                o = n(99397),
                s = n(2265),
                a = n(6705),
                u = (n(50430), n(62035)),
                l = n(82002),
                c = n(83535);

            function d(e) {
                var t;
                let n = (0, c.m)(),
                    d = (null == n || n.realtimeAudioMode, (0, s.useCallback)(() => {
                        null == n || n.resetConversation(null == n ? void 0 : n.clientInitialMessages)
                    }, [null == n ? void 0 : n.resetConversation, null == n ? void 0 : n.clientInitialMessages]));
                return (0, r.jsx)(r.Fragment, {
                    children: (0, r.jsxs)(r.Fragment, {
                        children: [(0, r.jsx)(u.S, {
                            className: "shadow-inner",
                            children: (0, r.jsx)(a.K, {
                                chatbotStyles: e.chatbot.styles,
                                profilePicture: e.chatbot.profilePicture,
                                initialMessages: e.chatbot.initial_messages
                            })
                        }), (null == n ? void 0 : n.status) === "conversation-ended" ? (0, r.jsxs)("div", {
                            className: "flex w-full items-center justify-between bg-zinc-50 px-4 py-4 font-medium text-xs text-zinc-500 group-data-[theme=dark]:bg-zinc-900/90 group-data-[theme=dark]:text-zinc-400",
                            children: [(0, r.jsx)("p", {
                                className: "text-sm",
                                children: "Your conversation has ended"
                            }), (0, r.jsxs)(i.z, {
                                variant: "outline",
                                className: "flex items-center gap-2 rounded-md group-data-[theme=dark]:border-zinc-800 group-data-[theme=dark]:hover:bg-zinc-800 group-data-[theme=dark]:hover:text-zinc-50",
                                onClick: d,
                                children: [(0, r.jsx)(o.Z, {
                                    className: "h-4 w-4"
                                }), "Start new chat"]
                            })]
                        }) : (0, r.jsx)("div", {
                            className: "flex w-full shrink-0 flex-col justify-end",
                            children: (0, r.jsx)(l.d, {
                                placeholder: null === (t = e.chatbot.styles) || void 0 === t ? void 0 : t.message_placeholder,
                                suggestedMessages: e.chatbot.suggested_messages
                            })
                        })]
                    })
                })
            }
        },
        82002: function(e, t, n) {
            "use strict";
            n.d(t, {
                d: function() {
                    return d
                }
            });
            var r = n(57437),
                i = n(43061),
                o = n(84653),
                s = n(61315),
                a = n(35461),
                u = n(82174);

            function l() {
                return (0, r.jsxs)("div", {
                    className: "flex flex-col items-center justify-center space-y-2 p-4",
                    children: [(0, r.jsx)(u.E.div, {
                        className: "h-4 w-4",
                        style: {
                            border: "2px solid #E5E7EB",
                            borderTopColor: "#9CA3AF",
                            borderRadius: "50%"
                        },
                        animate: {
                            rotate: 360
                        },
                        transition: {
                            duration: 1,
                            repeat: Number.POSITIVE_INFINITY,
                            ease: "linear"
                        }
                    }), (0, r.jsx)("p", {
                        className: "font-medium text-xs text-zinc-500 group-data-[theme=dark]:text-zinc-400",
                        children: "Waiting for agent to join"
                    })]
                })
            }
            var c = n(83535);

            function d(e) {
                var t, n, u;
                let d = (0, c.m)(),
                    f = () => {
                        null != d && d.isLoading || null == d || d.handleSubmit()
                    },
                    h = null !== (n = null == d ? void 0 : null === (t = d.groupedLiveChatMessages) || void 0 === t ? void 0 : t.some(e => e[0].role === i.Zg.AGENT)) && void 0 !== n && n;
                return (0, r.jsxs)("div", {
                    children: [(null == d ? void 0 : d.isChatTakenOver) ? h || (null == d ? void 0 : d.isLoading) ? null : (0, r.jsx)(l, {}) : (0, r.jsx)(a.B, {
                        onSelect: e => {
                            var t;
                            null != d && d.isLoading || null == d || null === (t = d.sendMessage) || void 0 === t || t.call(d, e.toString())
                        },
                        messages: e.suggestedMessages
                    }), (0, r.jsx)(s.O, {
                        value: null == d ? void 0 : d.input,
                        placeholder: null !== (u = e.placeholder) && void 0 !== u ? u : o.Ug,
                        onInput: e => null == d ? void 0 : d.setInput(e.currentTarget.value),
                        onKeyDown: e => {
                            "Enter" !== e.key || e.shiftKey || (e.preventDefault(), f())
                        },
                        disableButton: null == d ? void 0 : d.isLoading,
                        onSubmit: f,
                        className: "flex-1"
                    })]
                })
            }
        },
        29356: function(e, t, n) {
            "use strict";
            var r = n(57437);
            t.Z = e => (0, r.jsxs)("svg", {
                viewBox: "0 0 25 25",
                className: e.className,
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                ...e,
                children: [(0, r.jsx)("title", {
                    children: "loading"
                }), (0, r.jsxs)("g", {
                    fill: "currentColor",
                    children: [(0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        opacity: ".14"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(30 12 12)",
                        opacity: ".29"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(60 12 12)",
                        opacity: ".43"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(90 12 12)",
                        opacity: ".57"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(120 12 12)",
                        opacity: ".71"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(150 12 12)",
                        opacity: ".86"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(180 12 12)"
                    }), (0, r.jsx)("animateTransform", {
                        attributeName: "transform",
                        type: "rotate",
                        calcMode: "discrete",
                        dur: "0.75s",
                        values: "0 12 12;30 12 12;60 12 12;90 12 12;120 12 12;150 12 12;180 12 12;210 12 12;240 12 12;270 12 12;300 12 12;330 12 12;360 12 12",
                        repeatCount: "indefinite"
                    })]
                })]
            })
        },
        69174: function(e, t, n) {
            "use strict";
            n.d(t, {
                Ct: function() {
                    return a
                },
                Pe: function() {
                    return u
                },
                te: function() {
                    return s
                }
            });
            var r = n(57437),
                i = n(77712),
                o = n(81201);
            let s = (0, i.j)("inline-flex items-center rounded-md border border-zinc-200 px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-zinc-950 focus:ring-offset-2 dark:border-zinc-800 dark:focus:ring-zinc-300", {
                variants: {
                    variant: {
                        default: "border-transparent bg-zinc-900 text-zinc-50 shadow hover:bg-zinc-900/80 dark:bg-zinc-50 dark:text-zinc-900 dark:hover:bg-zinc-50/80",
                        secondary: "border-transparent bg-violet-100 text-violet-600 hover:bg-violet-100/80 dark:bg-violet-800 dark:text-violet-50 dark:hover:bg-violet-800/80",
                        destructive: "border-transparent bg-red-500 text-zinc-50 shadow hover:bg-red-500/80 dark:bg-red-900 dark:text-zinc-50 dark:hover:bg-red-900/80",
                        outline: "text-zinc-950 dark:text-zinc-50"
                    }
                },
                defaultVariants: {
                    variant: "default"
                }
            });

            function a(e) {
                let {
                    className: t,
                    variant: n,
                    ...i
                } = e;
                return (0, r.jsx)("div", {
                    className: (0, o.cn)(s({
                        variant: n
                    }), t),
                    ...i
                })
            }

            function u(e) {
                return (0, r.jsx)(a, {
                    className: (0, o.cn)("select-none rounded-xl px-5 py-2 text-sm font-medium transition-all duration-300 ease-in-out animate-in fade-in", "bg-violet-100 text-violet-600 hover:bg-violet-100 hover:text-violet-600", e.className),
                    children: e.children
                })
            }
        },
        12381: function(e, t, n) {
            "use strict";
            n.d(t, {
                d: function() {
                    return l
                },
                z: function() {
                    return c
                }
            });
            var r = n(57437),
                i = n(2265),
                o = n(98482),
                s = n(77712),
                a = n(29356),
                u = n(81201);
            let l = (0, s.j)("inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-80", {
                    variants: {
                        variant: {
                            default: "bg-zinc-900 text-zinc-50 shadow hover:bg-zinc-800/90 dark:bg-zinc-50 dark:text-zinc-900 dark:hover:bg-zinc-50/90",
                            destructive: "bg-red-500 text-zinc-50 shadow-sm hover:bg-red-500/90 dark:bg-red-900 dark:text-zinc-50 dark:hover:bg-red-900/90",
                            outline: "border border-zinc-200 bg-transparent hover:bg-zinc-100/70 hover:text-zinc-900 dark:border-zinc-800 dark:hover:bg-zinc-800 dark:hover:text-zinc-50 rounded-xl disabled:bg-zinc-100/60",
                            secondary: "bg-zinc-100 text-zinc-900 shadow-sm hover:bg-zinc-200/90 dark:bg-zinc-800 dark:text-zinc-50 dark:hover:bg-zinc-800/80",
                            ghost: "hover:bg-zinc-100 hover:text-zinc-900 dark:hover:bg-zinc-800 dark:hover:text-zinc-50 disabled:text-zinc-600",
                            link: "text-zinc-900 underline-offset-4 hover:underline dark:text-zinc-50",
                            destructiveGhost: "text-red-500 hover:bg-red-50 hover:text-red-600 bg-transparent"
                        },
                        size: {
                            default: "h-9 px-4 py-1",
                            sm: "h-7 rounded-md px-3",
                            lg: "h-10 rounded-md px-8",
                            icon: "h-9 w-9"
                        }
                    },
                    defaultVariants: {
                        variant: "default",
                        size: "default"
                    }
                }),
                c = i.forwardRef((e, t) => {
                    let {
                        className: n,
                        variant: i = "default",
                        size: s,
                        loading: c = !1,
                        asChild: d = !1,
                        hideContentOnLoading: f = !1,
                        ...h
                    } = e, p = d ? o.g7 : "button";
                    return c ? (0, r.jsxs)(p, {
                        className: (0, u.cn)(l({
                            variant: i,
                            size: s,
                            className: n
                        }), "flex flex-row items-center gap-2"),
                        ref: t,
                        disabled: !0,
                        ...h,
                        children: [(0, r.jsx)(a.Z, {
                            className: (0, u.cn)({
                                "h-[0.9rem] w-[0.9rem]": "sm" === s,
                                "h-[1.2rem] w-[1.2rem]": "sm" !== s,
                                "fill-zinc-50": "default" === i || "destructive" === i,
                                "fill-zinc-900": "default" !== i && "destructive" !== i,
                                "fill-red-500": "destructiveGhost" === i
                            })
                        }), !f && h.children]
                    }) : (0, r.jsx)(p, {
                        className: (0, u.cn)(l({
                            variant: i,
                            size: s,
                            className: n
                        })),
                        ref: t,
                        ...h
                    })
                });
            c.displayName = "Button"
        },
        79820: function(e, t, n) {
            "use strict";
            n.d(t, {
                Ol: function() {
                    return a
                },
                SZ: function() {
                    return l
                },
                Zb: function() {
                    return s
                },
                aY: function() {
                    return c
                },
                eW: function() {
                    return d
                },
                ll: function() {
                    return u
                }
            });
            var r = n(57437),
                i = n(2265),
                o = n(81201);
            let s = i.forwardRef((e, t) => {
                let {
                    className: n,
                    ...i
                } = e;
                return (0, r.jsx)("div", {
                    ref: t,
                    className: (0, o.cn)("rounded-lg border border-zinc-200 bg-white text-zinc-950 shadow-sm dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-50", n),
                    ...i
                })
            });
            s.displayName = "Card";
            let a = i.forwardRef((e, t) => {
                let {
                    className: n,
                    ...i
                } = e;
                return (0, r.jsx)("div", {
                    ref: t,
                    className: (0, o.cn)("flex flex-col space-y-1.5 p-6", n),
                    ...i
                })
            });
            a.displayName = "CardHeader";
            let u = i.forwardRef((e, t) => {
                let {
                    className: n,
                    ...i
                } = e;
                return (0, r.jsx)("h3", {
                    ref: t,
                    className: (0, o.cn)("text-2xl font-semibold leading-none tracking-tight", n),
                    ...i
                })
            });
            u.displayName = "CardTitle";
            let l = i.forwardRef((e, t) => {
                let {
                    className: n,
                    ...i
                } = e;
                return (0, r.jsx)("p", {
                    ref: t,
                    className: (0, o.cn)("text-sm text-zinc-500 dark:text-zinc-400", n),
                    ...i
                })
            });
            l.displayName = "CardDescription";
            let c = i.forwardRef((e, t) => {
                let {
                    className: n,
                    ...i
                } = e;
                return (0, r.jsx)("div", {
                    ref: t,
                    className: (0, o.cn)("p-6 pt-0", n),
                    ...i
                })
            });
            c.displayName = "CardContent";
            let d = i.forwardRef((e, t) => {
                let {
                    className: n,
                    ...i
                } = e;
                return (0, r.jsx)("div", {
                    ref: t,
                    className: (0, o.cn)("flex items-center p-6 pt-0", n),
                    ...i
                })
            });
            d.displayName = "CardFooter"
        },
        40279: function(e, t, n) {
            "use strict";
            n.d(t, {
                I: function() {
                    return s
                }
            });
            var r = n(57437),
                i = n(2265),
                o = n(81201);
            let s = i.forwardRef((e, t) => {
                let {
                    className: n,
                    type: i,
                    ...s
                } = e;
                return (0, r.jsx)("input", {
                    type: i,
                    className: (0, o.cn)("flex h-9 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background disabled:cursor-not-allowed file:border-0 focus:border-violet-500 file:bg-transparent file:font-medium file:text-sm placeholder:text-muted-foreground disabled:opacity-50 focus:outline-none focus-visible:ring-ring focus:ring-4 focus:ring-violet-500/10", n),
                    ref: t,
                    ...s
                })
            });
            s.displayName = "Input"
        },
        31593: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                Separator: function() {
                    return a
                }
            });
            var r = n(57437),
                i = n(2265),
                o = n(55156),
                s = n(81201);
            let a = i.forwardRef((e, t) => {
                let {
                    className: n,
                    orientation: i = "horizontal",
                    decorative: a = !0,
                    ...u
                } = e;
                return (0, r.jsx)(o.f, {
                    ref: t,
                    decorative: a,
                    orientation: i,
                    className: (0, s.cn)("shrink-0 bg-zinc-200 dark:bg-zinc-500", "horizontal" === i ? "h-[1px] w-full" : "h-full w-[1px]", n),
                    ...u
                })
            });
            a.displayName = o.f.displayName
        },
        71488: function(e, t, n) {
            "use strict";
            n.d(t, {
                _v: function() {
                    return c
                },
                aJ: function() {
                    return l
                },
                pn: function() {
                    return a
                },
                u: function() {
                    return u
                }
            });
            var r = n(57437),
                i = n(2265),
                o = n(91668),
                s = n(81201);
            let a = o.zt,
                u = o.fC,
                l = o.xz,
                c = i.forwardRef((e, t) => {
                    let {
                        className: n,
                        sideOffset: i = 4,
                        ...a
                    } = e;
                    return (0, r.jsx)(o.VY, {
                        ref: t,
                        sideOffset: i,
                        className: (0, s.cn)("z-50 overflow-hidden rounded-md border border-zinc-700 bg-zinc-950 px-3 py-1.5 text-sm text-zinc-50 shadow-md animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-50", n),
                        ...a
                    })
                });
            c.displayName = o.VY.displayName
        },
        34102: function(e, t, n) {
            "use strict";
            n.d(t, {
                Bt: function() {
                    return o
                },
                KD: function() {
                    return c
                },
                Ob: function() {
                    return u
                },
                Qd: function() {
                    return l
                },
                ZS: function() {
                    return a
                }
            });
            var r = n(31229);
            let i = r.z.nativeEnum({
                    LOW: "Low",
                    NORMAL: "Normal",
                    HIGH: "High",
                    URGENT: "Urgent"
                }),
                o = i.enum,
                s = r.z.nativeEnum({
                    BILLING: "Billing",
                    ACCOUNT: "Account Management",
                    FEATURE_REQUEST: "Feature Request",
                    ISSUE: "Bugs/Issues",
                    AFFILIATE: "Affiliate Program",
                    PARTNERSHIP: "Partnership",
                    GENERAL: "General Inquiries"
                }),
                a = s.enum,
                u = r.z.array(r.z.instanceof(Blob).refine(e => e.size < 5242880, "Max file size is 5MB")).transform(e => {
                    let t = new FormData;
                    return e.forEach(e => t.append("media", e)), t
                }),
                l = r.z.array(r.z.object({
                    name: r.z.string(),
                    size: r.z.number(),
                    token: r.z.string()
                })),
                c = r.z.object({
                    userEmail: r.z.string().email(),
                    userFullName: r.z.string().optional(),
                    userId: r.z.string().min(1),
                    accountSubscription: r.z.string().min(1),
                    subject: r.z.string().min(3, "Please add a subject"),
                    description: r.z.string().min(1, "Please add a description before submitting your request."),
                    type: s,
                    severity: i,
                    account: r.z.string().min(1).nullable(),
                    selectedChatbots: r.z.array(r.z.object({
                        id: r.z.string(),
                        name: r.z.string()
                    })).default([]),
                    attachments: l
                })
        },
        42746: function(e, t, n) {
            "use strict";
            n.d(t, {
                CR: function() {
                    return h
                },
                GT: function() {
                    return l
                },
                K2: function() {
                    return s
                },
                LI: function() {
                    return a
                },
                j6: function() {
                    return f
                },
                p0: function() {
                    return c
                },
                qC: function() {
                    return i
                },
                qx: function() {
                    return d
                },
                tb: function() {
                    return u
                },
                x6: function() {
                    return o
                }
            }), n(99027);
            var r = n(34102);
            n(25566);
            let i = async e => {
                let {
                    url: t,
                    headers: n,
                    data: r
                } = e, i = await fetch(t, {
                    method: "POST",
                    headers: new Headers({
                        "Content-Type": "application/json",
                        ...n
                    }),
                    body: JSON.stringify(r)
                });
                if (!i.ok) {
                    let e = await i.json();
                    throw Error((null == e ? void 0 : e.message) || i.statusText)
                }
                return i.json()
            };

            function o(e) {
                return e.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
            }
            let s = e => {
                try {
                    return new URL(e), !0
                } catch (e) {
                    return !1
                }
            };
            async function a(e) {
                let t = new AbortController,
                    n = setTimeout(() => {
                        t.abort()
                    }, 3e4);
                try {
                    let i = await fetch("/api/get-attachment-token", {
                        method: "POST",
                        body: e,
                        cache: "no-cache",
                        signal: t.signal
                    });
                    if (clearTimeout(n), !i.ok) throw Error("Error uploading support schema attachments", {
                        cause: await i.text()
                    });
                    let o = await i.json();
                    return r.Qd.parse(o.files)
                } catch (e) {
                    throw Error("Error uploading support schema attachments", {
                        cause: e
                    })
                }
            }

            function u(e) {
                return new Date(e).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                    hour12: !0
                })
            }
            let l = e => {
                    let t = e.replace("http://", "").replace("https://", ""),
                        n = (t = t.split("/")[0]).split("."),
                        r = n[n.length - 1];
                    return 2 === r.length && n.length > 3 ? n.slice(-3).join(".") : n.slice(-2).join(".")
                },
                c = e => {
                    let t = l(e);
                    return e === t ? "" : e.slice(0, e.length - t.length - 1)
                },
                d = e => {
                    let t = l(e);
                    return e !== t
                },
                f = (e, t) => (new Date(t).getTime() - new Date(e).getTime()) / 864e5,
                h = e => {
                    let {
                        src: t,
                        width: n,
                        quality: r
                    } = e;
                    return "".concat("https://backend.chatbase.co", "/storage/v1/object/public/").concat(t, "?width=").concat(n, "&quality=").concat(null != r ? r : 50)
                }
        },
        25566: function(e) {
            var t, n, r, i = e.exports = {};

            function o() {
                throw Error("setTimeout has not been defined")
            }

            function s() {
                throw Error("clearTimeout has not been defined")
            }

            function a(e) {
                if (t === setTimeout) return setTimeout(e, 0);
                if ((t === o || !t) && setTimeout) return t = setTimeout, setTimeout(e, 0);
                try {
                    return t(e, 0)
                } catch (n) {
                    try {
                        return t.call(null, e, 0)
                    } catch (n) {
                        return t.call(this, e, 0)
                    }
                }
            }! function() {
                try {
                    t = "function" == typeof setTimeout ? setTimeout : o
                } catch (e) {
                    t = o
                }
                try {
                    n = "function" == typeof clearTimeout ? clearTimeout : s
                } catch (e) {
                    n = s
                }
            }();
            var u = [],
                l = !1,
                c = -1;

            function d() {
                l && r && (l = !1, r.length ? u = r.concat(u) : c = -1, u.length && f())
            }

            function f() {
                if (!l) {
                    var e = a(d);
                    l = !0;
                    for (var t = u.length; t;) {
                        for (r = u, u = []; ++c < t;) r && r[c].run();
                        c = -1, t = u.length
                    }
                    r = null, l = !1,
                        function(e) {
                            if (n === clearTimeout) return clearTimeout(e);
                            if ((n === s || !n) && clearTimeout) return n = clearTimeout, clearTimeout(e);
                            try {
                                n(e)
                            } catch (t) {
                                try {
                                    return n.call(null, e)
                                } catch (t) {
                                    return n.call(this, e)
                                }
                            }
                        }(e)
                }
            }

            function h(e, t) {
                this.fun = e, this.array = t
            }

            function p() {}
            i.nextTick = function(e) {
                var t = Array(arguments.length - 1);
                if (arguments.length > 1)
                    for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                u.push(new h(e, t)), 1 !== u.length || l || a(f)
            }, h.prototype.run = function() {
                this.fun.apply(null, this.array)
            }, i.title = "browser", i.browser = !0, i.env = {}, i.argv = [], i.version = "", i.versions = {}, i.on = p, i.addListener = p, i.once = p, i.off = p, i.removeListener = p, i.removeAllListeners = p, i.emit = p, i.prependListener = p, i.prependOnceListener = p, i.listeners = function(e) {
                return []
            }, i.binding = function(e) {
                throw Error("process.binding is not supported")
            }, i.cwd = function() {
                return "/"
            }, i.chdir = function(e) {
                throw Error("process.chdir is not supported")
            }, i.umask = function() {
                return 0
            }
        },
        55156: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return u
                },
                f: function() {
                    return c
                }
            });
            var r = n(1119),
                i = n(2265),
                o = n(82912);
            let s = "horizontal",
                a = ["horizontal", "vertical"],
                u = (0, i.forwardRef)((e, t) => {
                    let {
                        decorative: n,
                        orientation: a = s,
                        ...u
                    } = e, c = l(a) ? a : s;
                    return (0, i.createElement)(o.WV.div, (0, r.Z)({
                        "data-orientation": c
                    }, n ? {
                        role: "none"
                    } : {
                        "aria-orientation": "vertical" === c ? c : void 0,
                        role: "separator"
                    }, u, {
                        ref: t
                    }))
                });

            function l(e) {
                return a.includes(e)
            }
            u.propTypes = {
                orientation(e, t, n) {
                    let r = e[t],
                        i = String(r);
                    return r && !l(r) ? Error(`Invalid prop \`orientation\` of value \`${i}\` supplied to \`${n}\`, expected one of:
  - horizontal
  - vertical

Defaulting to \`${s}\`.`) : null
                }
            };
            let c = u
        },
        98482: function(e, t, n) {
            "use strict";
            n.d(t, {
                g7: function() {
                    return o
                }
            });
            var r = n(2265),
                i = n(57437),
                o = r.forwardRef((e, t) => {
                    let {
                        children: n,
                        ...o
                    } = e, a = r.Children.toArray(n), l = a.find(u);
                    if (l) {
                        let e = l.props.children,
                            n = a.map(t => t !== l ? t : r.Children.count(e) > 1 ? r.Children.only(null) : r.isValidElement(e) ? e.props.children : null);
                        return (0, i.jsx)(s, { ...o,
                            ref: t,
                            children: r.isValidElement(e) ? r.cloneElement(e, void 0, n) : null
                        })
                    }
                    return (0, i.jsx)(s, { ...o,
                        ref: t,
                        children: n
                    })
                });
            o.displayName = "Slot";
            var s = r.forwardRef((e, t) => {
                let {
                    children: n,
                    ...i
                } = e;
                if (r.isValidElement(n)) {
                    let e, o;
                    let s = (e = Object.getOwnPropertyDescriptor(n.props, "ref") ? .get) && "isReactWarning" in e && e.isReactWarning ? n.ref : (e = Object.getOwnPropertyDescriptor(n, "ref") ? .get) && "isReactWarning" in e && e.isReactWarning ? n.props.ref : n.props.ref || n.ref;
                    return r.cloneElement(n, { ... function(e, t) {
                            let n = { ...t
                            };
                            for (let r in t) {
                                let i = e[r],
                                    o = t[r];
                                /^on[A-Z]/.test(r) ? i && o ? n[r] = (...e) => {
                                    o(...e), i(...e)
                                } : i && (n[r] = i) : "style" === r ? n[r] = { ...i,
                                    ...o
                                } : "className" === r && (n[r] = [i, o].filter(Boolean).join(" "))
                            }
                            return { ...e,
                                ...n
                            }
                        }(i, n.props),
                        ref: t ? function(...e) {
                            return t => e.forEach(e => {
                                "function" == typeof e ? e(t) : null != e && (e.current = t)
                            })
                        }(t, s) : s
                    })
                }
                return r.Children.count(n) > 1 ? r.Children.only(null) : null
            });
            s.displayName = "SlotClone";
            var a = ({
                children: e
            }) => (0, i.jsx)(i.Fragment, {
                children: e
            });

            function u(e) {
                return r.isValidElement(e) && e.type === a
            }
        },
        3392: function(e, t, n) {
            "use strict";
            n.d(t, {
                j: function() {
                    return o
                }
            });
            var r = n(24112),
                i = n(45345),
                o = new class extends r.l {#
                    e;#
                    t;#
                    n;
                    constructor() {
                        super(), this.#n = e => {
                            if (!i.sk && window.addEventListener) {
                                let t = () => e();
                                return window.addEventListener("visibilitychange", t, !1), () => {
                                    window.removeEventListener("visibilitychange", t)
                                }
                            }
                        }
                    }
                    onSubscribe() {
                        this.#t || this.setEventListener(this.#n)
                    }
                    onUnsubscribe() {
                        this.hasListeners() || (this.#t ? .(), this.#t = void 0)
                    }
                    setEventListener(e) {
                        this.#n = e, this.#t ? .(), this.#t = e(e => {
                            "boolean" == typeof e ? this.setFocused(e) : this.onFocus()
                        })
                    }
                    setFocused(e) {
                        this.#e !== e && (this.#e = e, this.onFocus())
                    }
                    onFocus() {
                        let e = this.isFocused();
                        this.listeners.forEach(t => {
                            t(e)
                        })
                    }
                    isFocused() {
                        return "boolean" == typeof this.#e ? this.#e : globalThis.document ? .visibilityState !== "hidden"
                    }
                }
        },
        18238: function(e, t, n) {
            "use strict";
            n.d(t, {
                V: function() {
                    return r
                }
            });
            var r = function() {
                let e = [],
                    t = 0,
                    n = e => {
                        e()
                    },
                    r = e => {
                        e()
                    },
                    i = e => setTimeout(e, 0),
                    o = r => {
                        t ? e.push(r) : i(() => {
                            n(r)
                        })
                    },
                    s = () => {
                        let t = e;
                        e = [], t.length && i(() => {
                            r(() => {
                                t.forEach(e => {
                                    n(e)
                                })
                            })
                        })
                    };
                return {
                    batch: e => {
                        let n;
                        t++;
                        try {
                            n = e()
                        } finally {
                            --t || s()
                        }
                        return n
                    },
                    batchCalls: e => (...t) => {
                        o(() => {
                            e(...t)
                        })
                    },
                    schedule: o,
                    setNotifyFunction: e => {
                        n = e
                    },
                    setBatchNotifyFunction: e => {
                        r = e
                    },
                    setScheduler: e => {
                        i = e
                    }
                }
            }()
        },
        57853: function(e, t, n) {
            "use strict";
            n.d(t, {
                N: function() {
                    return o
                }
            });
            var r = n(24112),
                i = n(45345),
                o = new class extends r.l {#
                    r = !0;#
                    t;#
                    n;
                    constructor() {
                        super(), this.#n = e => {
                            if (!i.sk && window.addEventListener) {
                                let t = () => e(!0),
                                    n = () => e(!1);
                                return window.addEventListener("online", t, !1), window.addEventListener("offline", n, !1), () => {
                                    window.removeEventListener("online", t), window.removeEventListener("offline", n)
                                }
                            }
                        }
                    }
                    onSubscribe() {
                        this.#t || this.setEventListener(this.#n)
                    }
                    onUnsubscribe() {
                        this.hasListeners() || (this.#t ? .(), this.#t = void 0)
                    }
                    setEventListener(e) {
                        this.#n = e, this.#t ? .(), this.#t = e(this.setOnline.bind(this))
                    }
                    setOnline(e) {
                        this.#r !== e && (this.#r = e, this.listeners.forEach(t => {
                            t(e)
                        }))
                    }
                    isOnline() {
                        return this.#r
                    }
                }
        },
        7989: function(e, t, n) {
            "use strict";
            n.d(t, {
                F: function() {
                    return i
                }
            });
            var r = n(45345),
                i = class {#
                    i;
                    destroy() {
                        this.clearGcTimeout()
                    }
                    scheduleGc() {
                        this.clearGcTimeout(), (0, r.PN)(this.gcTime) && (this.#i = setTimeout(() => {
                            this.optionalRemove()
                        }, this.gcTime))
                    }
                    updateGcTime(e) {
                        this.gcTime = Math.max(this.gcTime || 0, e ? ? (r.sk ? 1 / 0 : 3e5))
                    }
                    clearGcTimeout() {
                        this.#i && (clearTimeout(this.#i), this.#i = void 0)
                    }
                }
        },
        11255: function(e, t, n) {
            "use strict";
            n.d(t, {
                DV: function() {
                    return l
                },
                Kw: function() {
                    return a
                },
                Mz: function() {
                    return c
                }
            });
            var r = n(3392),
                i = n(57853),
                o = n(45345);

            function s(e) {
                return Math.min(1e3 * 2 ** e, 3e4)
            }

            function a(e) {
                return (e ? ? "online") !== "online" || i.N.isOnline()
            }
            var u = class extends Error {
                constructor(e) {
                    super("CancelledError"), this.revert = e ? .revert, this.silent = e ? .silent
                }
            };

            function l(e) {
                return e instanceof u
            }

            function c(e) {
                let t, n, l, c = !1,
                    d = 0,
                    f = !1,
                    h = new Promise((e, t) => {
                        n = e, l = t
                    }),
                    p = () => r.j.isFocused() && ("always" === e.networkMode || i.N.isOnline()) && e.canRun(),
                    m = () => a(e.networkMode) && e.canRun(),
                    v = r => {
                        f || (f = !0, e.onSuccess ? .(r), t ? .(), n(r))
                    },
                    g = n => {
                        f || (f = !0, e.onError ? .(n), t ? .(), l(n))
                    },
                    b = () => new Promise(n => {
                        t = e => {
                            (f || p()) && n(e)
                        }, e.onPause ? .()
                    }).then(() => {
                        t = void 0, f || e.onContinue ? .()
                    }),
                    y = () => {
                        let t;
                        if (f) return;
                        let n = 0 === d ? e.initialPromise : void 0;
                        try {
                            t = n ? ? e.fn()
                        } catch (e) {
                            t = Promise.reject(e)
                        }
                        Promise.resolve(t).then(v).catch(t => {
                            if (f) return;
                            let n = e.retry ? ? (o.sk ? 0 : 3),
                                r = e.retryDelay ? ? s,
                                i = "function" == typeof r ? r(d, t) : r,
                                a = !0 === n || "number" == typeof n && d < n || "function" == typeof n && n(d, t);
                            if (c || !a) {
                                g(t);
                                return
                            }
                            d++, e.onFail ? .(d, t), (0, o._v)(i).then(() => p() ? void 0 : b()).then(() => {
                                c ? g(t) : y()
                            })
                        })
                    };
                return {
                    promise: h,
                    cancel: t => {
                        f || (g(new u(t)), e.abort ? .())
                    },
                    continue: () => (t ? .(), h),
                    cancelRetry: () => {
                        c = !0
                    },
                    continueRetry: () => {
                        c = !1
                    },
                    canStart: m,
                    start: () => (m() ? y() : b().then(y), h)
                }
            }
        },
        24112: function(e, t, n) {
            "use strict";
            n.d(t, {
                l: function() {
                    return r
                }
            });
            var r = class {
                constructor() {
                    this.listeners = new Set, this.subscribe = this.subscribe.bind(this)
                }
                subscribe(e) {
                    return this.listeners.add(e), this.onSubscribe(), () => {
                        this.listeners.delete(e), this.onUnsubscribe()
                    }
                }
                hasListeners() {
                    return this.listeners.size > 0
                }
                onSubscribe() {}
                onUnsubscribe() {}
            }
        },
        45345: function(e, t, n) {
            "use strict";
            n.d(t, {
                CN: function() {
                    return N
                },
                Ht: function() {
                    return z
                },
                KC: function() {
                    return u
                },
                Kp: function() {
                    return a
                },
                Nc: function() {
                    return l
                },
                PN: function() {
                    return s
                },
                Q$: function() {
                    return m
                },
                Rm: function() {
                    return f
                },
                SE: function() {
                    return o
                },
                VS: function() {
                    return v
                },
                VX: function() {
                    return j
                },
                Wk: function() {
                    return k
                },
                X7: function() {
                    return d
                },
                Ym: function() {
                    return h
                },
                ZT: function() {
                    return i
                },
                _v: function() {
                    return x
                },
                _x: function() {
                    return c
                },
                cG: function() {
                    return S
                },
                oE: function() {
                    return w
                },
                sk: function() {
                    return r
                },
                to: function() {
                    return p
                }
            });
            var r = "undefined" == typeof window || "Deno" in globalThis;

            function i() {}

            function o(e, t) {
                return "function" == typeof e ? e(t) : e
            }

            function s(e) {
                return "number" == typeof e && e >= 0 && e !== 1 / 0
            }

            function a(e, t) {
                return Math.max(e + (t || 0) - Date.now(), 0)
            }

            function u(e, t) {
                return "function" == typeof e ? e(t) : e
            }

            function l(e, t) {
                return "function" == typeof e ? e(t) : e
            }

            function c(e, t) {
                let {
                    type: n = "all",
                    exact: r,
                    fetchStatus: i,
                    predicate: o,
                    queryKey: s,
                    stale: a
                } = e;
                if (s) {
                    if (r) {
                        if (t.queryHash !== f(s, t.options)) return !1
                    } else if (!p(t.queryKey, s)) return !1
                }
                if ("all" !== n) {
                    let e = t.isActive();
                    if ("active" === n && !e || "inactive" === n && e) return !1
                }
                return ("boolean" != typeof a || t.isStale() === a) && (!i || i === t.state.fetchStatus) && (!o || !!o(t))
            }

            function d(e, t) {
                let {
                    exact: n,
                    status: r,
                    predicate: i,
                    mutationKey: o
                } = e;
                if (o) {
                    if (!t.options.mutationKey) return !1;
                    if (n) {
                        if (h(t.options.mutationKey) !== h(o)) return !1
                    } else if (!p(t.options.mutationKey, o)) return !1
                }
                return (!r || t.state.status === r) && (!i || !!i(t))
            }

            function f(e, t) {
                return (t ? .queryKeyHashFn || h)(e)
            }

            function h(e) {
                return JSON.stringify(e, (e, t) => b(t) ? Object.keys(t).sort().reduce((e, n) => (e[n] = t[n], e), {}) : t)
            }

            function p(e, t) {
                return e === t || typeof e == typeof t && !!e && !!t && "object" == typeof e && "object" == typeof t && !Object.keys(t).some(n => !p(e[n], t[n]))
            }

            function m(e, t) {
                if (e === t) return e;
                let n = g(e) && g(t);
                if (n || b(e) && b(t)) {
                    let r = n ? e : Object.keys(e),
                        i = r.length,
                        o = n ? t : Object.keys(t),
                        s = o.length,
                        a = n ? [] : {},
                        u = 0;
                    for (let i = 0; i < s; i++) {
                        let s = n ? i : o[i];
                        (!n && r.includes(s) || n) && void 0 === e[s] && void 0 === t[s] ? (a[s] = void 0, u++) : (a[s] = m(e[s], t[s]), a[s] === e[s] && void 0 !== e[s] && u++)
                    }
                    return i === s && u === i ? e : a
                }
                return t
            }

            function v(e, t) {
                if (!t || Object.keys(e).length !== Object.keys(t).length) return !1;
                for (let n in e)
                    if (e[n] !== t[n]) return !1;
                return !0
            }

            function g(e) {
                return Array.isArray(e) && e.length === Object.keys(e).length
            }

            function b(e) {
                if (!y(e)) return !1;
                let t = e.constructor;
                if (void 0 === t) return !0;
                let n = t.prototype;
                return !!(y(n) && n.hasOwnProperty("isPrototypeOf")) && Object.getPrototypeOf(e) === Object.prototype
            }

            function y(e) {
                return "[object Object]" === Object.prototype.toString.call(e)
            }

            function x(e) {
                return new Promise(t => {
                    setTimeout(t, e)
                })
            }

            function w(e, t, n) {
                return "function" == typeof n.structuralSharing ? n.structuralSharing(e, t) : !1 !== n.structuralSharing ? m(e, t) : t
            }

            function k(e) {
                return e
            }

            function j(e, t, n = 0) {
                let r = [...e, t];
                return n && r.length > n ? r.slice(1) : r
            }

            function z(e, t, n = 0) {
                let r = [t, ...e];
                return n && r.length > n ? r.slice(0, -1) : r
            }
            var N = Symbol();

            function S(e, t) {
                return !e.queryFn && t ? .initialPromise ? () => t.initialPromise : e.queryFn && e.queryFn !== N ? e.queryFn : () => Promise.reject(Error(`Missing queryFn: '${e.queryHash}'`))
            }
        },
        29827: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                QueryClientContext: function() {
                    return o
                },
                QueryClientProvider: function() {
                    return a
                },
                useQueryClient: function() {
                    return s
                }
            });
            var r = n(2265),
                i = n(57437),
                o = r.createContext(void 0),
                s = e => {
                    let t = r.useContext(o);
                    if (e) return e;
                    if (!t) throw Error("No QueryClient set, use QueryClientProvider to set one");
                    return t
                },
                a = e => {
                    let {
                        client: t,
                        children: n
                    } = e;
                    return r.useEffect(() => (t.mount(), () => {
                        t.unmount()
                    }), [t]), (0, i.jsx)(o.Provider, {
                        value: t,
                        children: n
                    })
                }
        },
        51172: function(e, t, n) {
            "use strict";

            function r(e, t) {
                return "function" == typeof e ? e(...t) : !!e
            }

            function i() {}
            n.d(t, {
                L: function() {
                    return r
                },
                Z: function() {
                    return i
                }
            })
        },
        77712: function(e, t, n) {
            "use strict";
            n.d(t, {
                j: function() {
                    return o
                }
            });
            let r = e => "boolean" == typeof e ? "".concat(e) : 0 === e ? "0" : e,
                i = function() {
                    for (var e, t, n = 0, r = ""; n < arguments.length;)(e = arguments[n++]) && (t = function e(t) {
                        var n, r, i = "";
                        if ("string" == typeof t || "number" == typeof t) i += t;
                        else if ("object" == typeof t) {
                            if (Array.isArray(t))
                                for (n = 0; n < t.length; n++) t[n] && (r = e(t[n])) && (i && (i += " "), i += r);
                            else
                                for (n in t) t[n] && (i && (i += " "), i += n)
                        }
                        return i
                    }(e)) && (r && (r += " "), r += t);
                    return r
                },
                o = (e, t) => n => {
                    var o;
                    if ((null == t ? void 0 : t.variants) == null) return i(e, null == n ? void 0 : n.class, null == n ? void 0 : n.className);
                    let {
                        variants: s,
                        defaultVariants: a
                    } = t, u = Object.keys(s).map(e => {
                        let t = null == n ? void 0 : n[e],
                            i = null == a ? void 0 : a[e];
                        if (null === t) return null;
                        let o = r(t) || r(i);
                        return s[e][o]
                    }), l = n && Object.entries(n).reduce((e, t) => {
                        let [n, r] = t;
                        return void 0 === r || (e[n] = r), e
                    }, {});
                    return i(e, u, null == t ? void 0 : null === (o = t.compoundVariants) || void 0 === o ? void 0 : o.reduce((e, t) => {
                        let {
                            class: n,
                            className: r,
                            ...i
                        } = t;
                        return Object.entries(i).every(e => {
                            let [t, n] = e;
                            return Array.isArray(n) ? n.includes({ ...a,
                                ...l
                            }[t]) : ({ ...a,
                                ...l
                            })[t] === n
                        }) ? [...e, n, r] : e
                    }, []), null == n ? void 0 : n.class, null == n ? void 0 : n.className)
                }
        }
    },
    function(e) {
        e.O(0, [329, 3954, 2486, 2972, 5819, 2957, 1229, 5378, 602, 9027, 8208, 5875, 2855, 3513, 2201, 7399, 3080, 5220, 5041, 357, 9167, 2174, 9121, 7387, 2341, 4611, 5825, 4522, 2971, 2117, 1744], function() {
            return e(e.s = 48401)
        }), _N_E = e.O()
    }
]);