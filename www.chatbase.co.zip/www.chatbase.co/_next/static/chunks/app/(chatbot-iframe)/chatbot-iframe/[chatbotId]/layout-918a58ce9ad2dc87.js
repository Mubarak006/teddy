(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7595], {
        63317: function(e, t, n) {
            Promise.resolve().then(n.t.bind(n, 72972, 23)), Promise.resolve().then(n.bind(n, 62826)), Promise.resolve().then(n.bind(n, 51519)), Promise.resolve().then(n.bind(n, 31593)), Promise.resolve().then(n.bind(n, 81194))
        },
        33245: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("Info", [
                ["circle", {
                    cx: "12",
                    cy: "12",
                    r: "10",
                    key: "1mglay"
                }],
                ["path", {
                    d: "M12 16v-4",
                    key: "1dtifu"
                }],
                ["path", {
                    d: "M12 8h.01",
                    key: "e9boi3"
                }]
            ])
        },
        32489: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return r
                }
            });
            let r = (0, n(79205).Z)("X", [
                ["path", {
                    d: "M18 6 6 18",
                    key: "1bl5f8"
                }],
                ["path", {
                    d: "m6 6 12 12",
                    key: "d8bk6v"
                }]
            ])
        },
        27399: function(e, t, n) {
            "use strict";
            var r = n(57437),
                s = n(71488);
            t.Z = e => {
                let {
                    children: t,
                    content: n,
                    show: a = !0,
                    delayDuration: i,
                    asChild: o = !0
                } = e;
                return a ? (0, r.jsx)(s.pn, {
                    delayDuration: i,
                    children: (0, r.jsxs)(s.u, {
                        children: [(0, r.jsx)(s.aJ, {
                            asChild: o,
                            children: t
                        }), (0, r.jsx)(s._v, {
                            children: n
                        })]
                    })
                }) : (0, r.jsx)(r.Fragment, {
                    children: t
                })
            }
        },
        62826: function(e, t, n) {
            "use strict";
            n.d(t, {
                ChatbotListener: function() {
                    return o
                }
            });
            var r = n(43061),
                s = n(2265),
                a = n(84653),
                i = n(83535);
            let o = () => (u(), null),
                u = () => {
                    let e = (0, s.useRef)(!1),
                        t = (0, i.m)(),
                        n = null == t ? void 0 : t.identifyUser,
                        o = null == t ? void 0 : t.setClientInitialMessages,
                        u = null == t ? void 0 : t.resetConversation,
                        l = null == t ? void 0 : t.messages;
                    (0, s.useEffect)(() => {
                        if (e.current) return;
                        let t = e => {
                            var t, s;
                            if ("identify" === e.data.type && "function" == typeof n && n(e.data.params), "shutdown" === e.data.type && "function" == typeof n && n(null), e.data.windowInnerWidth && (e.data.windowInnerWidth < 640 ? document.body.setAttribute("data-mobile", "true") : document.body.removeAttribute("data-mobile")), (null === (t = e.data) || void 0 === t ? void 0 : t.type) === "setInitialMessages" && Array.isArray(null === (s = e.data) || void 0 === s ? void 0 : s.messages) && e.data.messages.every(e => "string" == typeof e && e.length > 0) && o && u) {
                                let t = e.data.messages;
                                if (t.join("").length > a.fJ) {
                                    let e = a.fJ;
                                    t = t.reduce((t, n) => {
                                        if (e > 0) {
                                            let r = n.slice(0, e);
                                            e -= r.length, t.push(r)
                                        }
                                        return t
                                    }, [])
                                }
                                o(t), (null == l ? void 0 : l.some(e => e.role === r.WU.USER)) || u(t)
                            }
                        };
                        return window.addEventListener("message", t), window.parent.postMessage({
                            type: "iframeReady"
                        }, "*"), () => {
                            window.removeEventListener("message", t)
                        }
                    }, [n, u, o])
                }
        },
        51519: function(e, t, n) {
            "use strict";
            n.d(t, {
                ChatContextProvider: function() {
                    return g
                }
            });
            var r = n(57437),
                s = n(34662),
                a = n(69007),
                i = n(28261),
                o = n(18280),
                u = n(2265),
                l = n(77299),
                d = n(8234);
            let c = (e, t) => {
                let {
                    conversationId: n,
                    newConversation: r
                } = (0, u.useMemo)(() => {
                    var n, r;
                    if (t) {
                        let t = (0, a.r)(e);
                        return t ? {
                            conversationId: t,
                            newConversation: !(null === (r = (0, a.yv)(t)) || void 0 === r ? void 0 : r.savedToDB)
                        } : {
                            conversationId: (0, d.D)(),
                            newConversation: !0
                        }
                    }
                    let s = (0, a.Yo)(e),
                        i = s.length > 0 ? s[0] : null;
                    return i ? {
                        conversationId: i,
                        newConversation: !(null === (n = (0, a.yv)(i)) || void 0 === n ? void 0 : n.savedToDB)
                    } : {
                        conversationId: i = (0, d.D)(),
                        newConversation: !0
                    }
                }, [e, t]);
                return {
                    conversationId: n,
                    newConversation: r
                }
            };
            var h = n(43061),
                f = n(29827),
                v = n(84653),
                m = n(83535);

            function g(e) {
                var t, n;
                let [g, p] = (0, u.useState)([]), y = (0, a.DU)(e.chatbot.id), {
                    iframeUser: b,
                    identifyUser: I
                } = (0, l.w)({
                    anonUserId: y,
                    chatbotId: e.chatbot.id
                }), {
                    conversationId: w,
                    newConversation: C
                } = c((null == b ? void 0 : b.user_hash) ? null !== (t = b.user_id) && void 0 !== t ? t : "" : y, null !== (n = null == b ? void 0 : b.user_hash) && void 0 !== n ? n : void 0), [x, _] = (0, u.useState)(w);
                (0, u.useEffect)(() => {
                    _(w)
                }, [w]);
                let M = (0, f.useQueryClient)();
                (0, u.useEffect)(() => {
                    M.invalidateQueries({
                        queryKey: [i.e1, {
                            conversationId: x
                        }],
                        exact: !1,
                        refetchType: "all"
                    })
                }, [x]);
                let {
                    collectLeads: z,
                    setCollectLeads: k,
                    resetCollectLeads: O
                } = function(e, t) {
                    let n = (0, u.useCallback)(t => {
                            if (!e.shouldDisplayCollectLeads) return {
                                display: !1,
                                messageId: null,
                                conversationId: t,
                                chatbotId: e.id,
                                settings: e.collect_leads_settings
                            };
                            let n = (0, a.yv)(t);
                            return {
                                display: !((null == n ? void 0 : n.ignoreForm) || (null == n ? void 0 : n.data)),
                                messageId: null,
                                conversationId: t,
                                chatbotId: e.id,
                                settings: e.collect_leads_settings
                            }
                        }, [e]),
                        [r, s] = (0, u.useState)(n(t)),
                        i = (0, u.useCallback)(e => {
                            s(n(e))
                        }, [n]);
                    return {
                        collectLeads: r,
                        setCollectLeads: s,
                        resetCollectLeads: i
                    }
                }(e.chatbot, x), E = (0, u.useRef)([]), N = (0, o.d)({
                    type: "iframe",
                    chatbot: e.chatbot,
                    initialMessages: g.length > 0 ? g : e.chatbot.initial_messages,
                    api: "/api/chat/".concat(e.chatbot.id),
                    defaultConversationId: x,
                    iframeUser: b,
                    prepareRequestBody: t => {
                        let n = t.messages.at(-1),
                            r = (null == n ? void 0 : n.role) === h.WU.USER ? null == n ? void 0 : n.content : "";
                        return r && window.parent.postMessage({
                            type: "user-message",
                            data: {
                                content: r
                            }
                        }, "*"), {
                            user: t.user,
                            timezone: t.timezone,
                            chatbotId: e.chatbot.id,
                            conversationId: t.conversationId,
                            message: r,
                            clientInitialMessages: g
                        }
                    },
                    onResetConversation: e => {
                        (null == b ? void 0 : b.user_hash) ? b.user_id && (0, a.O2)(b.user_id, e): (0, a.Aw)(y, e), (0, a.Wd)(e, {
                            savedToDB: !1
                        }), O(e), _(e)
                    },
                    onResponse: e => {
                        e.ok && k(e => (e.conversationId = N.conversationId, e))
                    },
                    onToolCall: async t => {
                        var n;
                        let {
                            toolCall: r,
                            iframeUser: a,
                            saveToolResult: i
                        } = t, {
                            toolName: o,
                            args: u,
                            toolCallId: l
                        } = r, c = { ...u,
                            ...(null == a ? void 0 : a.user_id) && {
                                userId: a.user_id
                            }
                        }, f = null === (n = e.chatbotActions.find(e => e.name === o)) || void 0 === n ? void 0 : n.type;
                        window.parent.postMessage({
                            type: "tool-call",
                            data: {
                                id: l,
                                args: c,
                                type: f,
                                name: o
                            }
                        }, "*");
                        let m = e.chatbotActions.filter(e => e.type === s.ww.CUSTOM_ACTION).find(e => e.name === o);
                        if (!m || !m.configuration.isClient) return;
                        window.parent.postMessage({
                            type: "CHATBOT_TOOL_CALL",
                            toolName: o,
                            args: u,
                            user: a
                        }, "*");
                        let g = m.configuration.waitForResponse ? await new Promise(e => {
                                let t = n => {
                                    if ("CHATBOT_TOOL_RESULT" === n.data.type && n.data.toolName === o) {
                                        window.removeEventListener("message", t);
                                        let r = h.bK.safeParse(n.data.result);
                                        if (r.success) {
                                            if (JSON.stringify(r.data).length > v.y4) return e({
                                                error: "Tool result too large",
                                                status: "error"
                                            });
                                            e(r.data)
                                        } else e({
                                            error: "Invalid tool result",
                                            status: "error"
                                        })
                                    }
                                };
                                window.addEventListener("message", t), setTimeout(() => {
                                    window.removeEventListener("message", t), e({
                                        error: "Tool call timeout",
                                        status: "error"
                                    })
                                }, 6e4)
                            }) : {
                                status: "success",
                                data: "Client notified by action"
                            },
                            p = {
                                id: (0, d.D)(),
                                role: h.WU.ASSISTANT,
                                type: "tool-call",
                                content: [{
                                    type: "tool-call",
                                    toolName: o,
                                    toolCallId: l,
                                    args: c
                                }]
                            },
                            y = {
                                id: (0, d.D)(),
                                role: h.WU.TOOL,
                                actionType: s.ww.CUSTOM_ACTION,
                                content: [{
                                    type: "tool-result",
                                    toolName: o,
                                    toolCallId: l,
                                    result: g
                                }]
                            };
                        try {
                            return await i({
                                toolCall: p,
                                toolResult: y
                            }), g
                        } catch (e) {
                            console.error("Error saving tool result", e);
                            return
                        }
                    },
                    onFinish: (e, t) => {
                        if (e.content && window.parent.postMessage({
                                type: "assistant-message",
                                data: {
                                    content: e.content
                                }
                            }, "*"), k(t => (t.display && !t.messageId && (t.messageId = e.id), t)), "stop" === t.finishReason || "tool-calls" === t.finishReason) {
                            (null == b ? void 0 : b.user_hash) || !C ? (null == b ? void 0 : b.user_hash) && b.user_id && C && (0, a.O2)(b.user_id, N.conversationId) : (0, a.Aw)(y, N.conversationId);
                            let t = (0, a.yv)(N.conversationId);
                            if (null == t ? void 0 : t.savedToDB) S(e);
                            else {
                                var n, r;
                                (0, a.Wd)(N.conversationId, {
                                    savedToDB: !0
                                }), M.invalidateQueries({
                                    queryKey: [i.mm, {
                                        id: null !== (r = null !== (n = null == b ? void 0 : b.user_id) && void 0 !== n ? n : null == b ? void 0 : b.anon_user_id) && void 0 !== r ? r : ""
                                    }],
                                    refetchType: "all"
                                })
                            }
                        }
                    }
                }), S = e => {
                    var t;
                    let n = null !== (t = null == b ? void 0 : b.user_id) && void 0 !== t ? t : null == b ? void 0 : b.anon_user_id;
                    M.setQueryData([i.mm, {
                        id: n
                    }], t => {
                        if (!t) return t;
                        let n = {
                                id: "",
                                last_message_at: "",
                                activity_state: "ongoing",
                                last_text_message: {
                                    role: h.WU.ASSISTANT,
                                    content: ""
                                }
                            },
                            r = t.pages.map(t => {
                                let r = t.data.map(t => {
                                    if (t.id === N.conversationId) {
                                        var r, s;
                                        return n = { ...t,
                                            last_message_at: null !== (s = null === (r = e.createdAt) || void 0 === r ? void 0 : r.toISOString()) && void 0 !== s ? s : "",
                                            last_text_message: { ...t.last_text_message,
                                                role: e.role,
                                                content: e.content
                                            }
                                        }, null
                                    }
                                    return t
                                });
                                return { ...t,
                                    data: r.filter(e => null !== e)
                                }
                            });
                        return r[0].data.unshift(n), { ...t,
                            pages: r
                        }
                    })
                }, P = (0, u.useCallback)(t => {
                    for (let r of t) {
                        var n;
                        if ("result" !== r.state || E.current.includes(r.toolCallId)) continue;
                        let t = null === (n = e.chatbotActions.find(e => e.name === r.toolName)) || void 0 === n ? void 0 : n.type;
                        if (!t) continue;
                        let a = [s.ww.CUSTOM_ACTION],
                            i = t && a.includes(t) ? r.toolName : t;
                        window.parent.postMessage({
                            type: "tool-result",
                            data: {
                                toolCallId: r.toolCallId,
                                name: i,
                                type: t,
                                result: r.result
                            }
                        }, "*"), E.current.push(r.toolCallId)
                    }
                }, [E.current, e.chatbotActions]);
                (0, u.useEffect)(() => {
                    if (N.initialMessages.length >= N.chat.messages.length) return;
                    let e = N.chat.messages.findLastIndex(e => "user" === e.role);
                    for (let t = N.chat.messages.length; t > e; t--) {
                        let e = N.chat.messages[t];
                        (null == e ? void 0 : e.toolInvocations) && P(e.toolInvocations)
                    }
                }, [N.chat.messages, N.initialMessages, P]);
                let T = (0, u.useMemo)(() => ({
                    type: "iframe",
                    chatbot: e.chatbot,
                    conversationId: N.conversationId,
                    setConversationId: _,
                    handleSubmit: N.handleSubmit,
                    messages: N.chat.messages,
                    setMessages: N.chat.setMessages,
                    input: N.chat.input,
                    setInput: N.chat.setInput,
                    append: N.chat.append,
                    reload: N.chat.reload,
                    status: N.status,
                    error: N.error,
                    groupedMessages: N.groupedMessages,
                    groupedLiveChatMessages: N.groupedLiveChatMessages,
                    isLoading: "busy" === N.status || "waiting-for-stream" === N.status || "initializing" === N.status,
                    isLoadingStream: "waiting-for-stream" === N.status,
                    isSendingLiveChatMessage: "sending-live-chat-message" === N.status,
                    actionLoading: "action-loading" === N.status,
                    isChatTakenOver: N.isChatTakenOver,
                    saveToolResult: async e => {
                        window.parent.postMessage({
                            type: "tool-result",
                            data: {
                                toolCallId: e.toolResult.content[0].toolCallId,
                                name: e.toolResult.actionType,
                                type: e.toolResult.actionType,
                                result: e.toolResult.content[0].result
                            }
                        }, "*"), await N.saveToolResult(e)
                    },
                    stopStreaming: () => {
                        throw Error("Function not implemented.")
                    },
                    resetConversation: N.resetConversation,
                    retryMessage: N.retryMessage,
                    registerResponseFeedback: N.registerResponseFeedback,
                    updateConversationActivityState: N.updateConversationActivityState,
                    sendMessage: N.sendMessage,
                    chatbotActions: e.chatbotActions,
                    collectLeads: z,
                    hideCollectLeads: () => {
                        k(e => (e.display = !1, e.messageId = null, e))
                    },
                    identifyUser: I,
                    clientInitialMessages: g,
                    setClientInitialMessages: p,
                    user: b
                }), [N, z, k, e.chatbot, b, I]);
                return (0, r.jsx)(m.p.Provider, {
                    value: T,
                    children: e.children
                })
            }
        },
        29356: function(e, t, n) {
            "use strict";
            var r = n(57437);
            t.Z = e => (0, r.jsxs)("svg", {
                viewBox: "0 0 25 25",
                className: e.className,
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                ...e,
                children: [(0, r.jsx)("title", {
                    children: "loading"
                }), (0, r.jsxs)("g", {
                    fill: "currentColor",
                    children: [(0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        opacity: ".14"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(30 12 12)",
                        opacity: ".29"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(60 12 12)",
                        opacity: ".43"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(90 12 12)",
                        opacity: ".57"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(120 12 12)",
                        opacity: ".71"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(150 12 12)",
                        opacity: ".86"
                    }), (0, r.jsx)("rect", {
                        x: "11",
                        y: "1",
                        width: "2",
                        height: "5",
                        transform: "rotate(180 12 12)"
                    }), (0, r.jsx)("animateTransform", {
                        attributeName: "transform",
                        type: "rotate",
                        calcMode: "discrete",
                        dur: "0.75s",
                        values: "0 12 12;30 12 12;60 12 12;90 12 12;120 12 12;150 12 12;180 12 12;210 12 12;240 12 12;270 12 12;300 12 12;330 12 12;360 12 12",
                        repeatCount: "indefinite"
                    })]
                })]
            })
        },
        69174: function(e, t, n) {
            "use strict";
            n.d(t, {
                Ct: function() {
                    return o
                },
                Pe: function() {
                    return u
                },
                te: function() {
                    return i
                }
            });
            var r = n(57437),
                s = n(77712),
                a = n(81201);
            let i = (0, s.j)("inline-flex items-center rounded-md border border-zinc-200 px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-zinc-950 focus:ring-offset-2 dark:border-zinc-800 dark:focus:ring-zinc-300", {
                variants: {
                    variant: {
                        default: "border-transparent bg-zinc-900 text-zinc-50 shadow hover:bg-zinc-900/80 dark:bg-zinc-50 dark:text-zinc-900 dark:hover:bg-zinc-50/80",
                        secondary: "border-transparent bg-violet-100 text-violet-600 hover:bg-violet-100/80 dark:bg-violet-800 dark:text-violet-50 dark:hover:bg-violet-800/80",
                        destructive: "border-transparent bg-red-500 text-zinc-50 shadow hover:bg-red-500/80 dark:bg-red-900 dark:text-zinc-50 dark:hover:bg-red-900/80",
                        outline: "text-zinc-950 dark:text-zinc-50"
                    }
                },
                defaultVariants: {
                    variant: "default"
                }
            });

            function o(e) {
                let {
                    className: t,
                    variant: n,
                    ...s
                } = e;
                return (0, r.jsx)("div", {
                    className: (0, a.cn)(i({
                        variant: n
                    }), t),
                    ...s
                })
            }

            function u(e) {
                return (0, r.jsx)(o, {
                    className: (0, a.cn)("select-none rounded-xl px-5 py-2 text-sm font-medium transition-all duration-300 ease-in-out animate-in fade-in", "bg-violet-100 text-violet-600 hover:bg-violet-100 hover:text-violet-600", e.className),
                    children: e.children
                })
            }
        },
        12381: function(e, t, n) {
            "use strict";
            n.d(t, {
                d: function() {
                    return l
                },
                z: function() {
                    return d
                }
            });
            var r = n(57437),
                s = n(2265),
                a = n(98482),
                i = n(77712),
                o = n(29356),
                u = n(81201);
            let l = (0, i.j)("inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-80", {
                    variants: {
                        variant: {
                            default: "bg-zinc-900 text-zinc-50 shadow hover:bg-zinc-800/90 dark:bg-zinc-50 dark:text-zinc-900 dark:hover:bg-zinc-50/90",
                            destructive: "bg-red-500 text-zinc-50 shadow-sm hover:bg-red-500/90 dark:bg-red-900 dark:text-zinc-50 dark:hover:bg-red-900/90",
                            outline: "border border-zinc-200 bg-transparent hover:bg-zinc-100/70 hover:text-zinc-900 dark:border-zinc-800 dark:hover:bg-zinc-800 dark:hover:text-zinc-50 rounded-xl disabled:bg-zinc-100/60",
                            secondary: "bg-zinc-100 text-zinc-900 shadow-sm hover:bg-zinc-200/90 dark:bg-zinc-800 dark:text-zinc-50 dark:hover:bg-zinc-800/80",
                            ghost: "hover:bg-zinc-100 hover:text-zinc-900 dark:hover:bg-zinc-800 dark:hover:text-zinc-50 disabled:text-zinc-600",
                            link: "text-zinc-900 underline-offset-4 hover:underline dark:text-zinc-50",
                            destructiveGhost: "text-red-500 hover:bg-red-50 hover:text-red-600 bg-transparent"
                        },
                        size: {
                            default: "h-9 px-4 py-1",
                            sm: "h-7 rounded-md px-3",
                            lg: "h-10 rounded-md px-8",
                            icon: "h-9 w-9"
                        }
                    },
                    defaultVariants: {
                        variant: "default",
                        size: "default"
                    }
                }),
                d = s.forwardRef((e, t) => {
                    let {
                        className: n,
                        variant: s = "default",
                        size: i,
                        loading: d = !1,
                        asChild: c = !1,
                        hideContentOnLoading: h = !1,
                        ...f
                    } = e, v = c ? a.g7 : "button";
                    return d ? (0, r.jsxs)(v, {
                        className: (0, u.cn)(l({
                            variant: s,
                            size: i,
                            className: n
                        }), "flex flex-row items-center gap-2"),
                        ref: t,
                        disabled: !0,
                        ...f,
                        children: [(0, r.jsx)(o.Z, {
                            className: (0, u.cn)({
                                "h-[0.9rem] w-[0.9rem]": "sm" === i,
                                "h-[1.2rem] w-[1.2rem]": "sm" !== i,
                                "fill-zinc-50": "default" === s || "destructive" === s,
                                "fill-zinc-900": "default" !== s && "destructive" !== s,
                                "fill-red-500": "destructiveGhost" === s
                            })
                        }), !h && f.children]
                    }) : (0, r.jsx)(v, {
                        className: (0, u.cn)(l({
                            variant: s,
                            size: i,
                            className: n
                        })),
                        ref: t,
                        ...f
                    })
                });
            d.displayName = "Button"
        },
        79820: function(e, t, n) {
            "use strict";
            n.d(t, {
                Ol: function() {
                    return o
                },
                SZ: function() {
                    return l
                },
                Zb: function() {
                    return i
                },
                aY: function() {
                    return d
                },
                eW: function() {
                    return c
                },
                ll: function() {
                    return u
                }
            });
            var r = n(57437),
                s = n(2265),
                a = n(81201);
            let i = s.forwardRef((e, t) => {
                let {
                    className: n,
                    ...s
                } = e;
                return (0, r.jsx)("div", {
                    ref: t,
                    className: (0, a.cn)("rounded-lg border border-zinc-200 bg-white text-zinc-950 shadow-sm dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-50", n),
                    ...s
                })
            });
            i.displayName = "Card";
            let o = s.forwardRef((e, t) => {
                let {
                    className: n,
                    ...s
                } = e;
                return (0, r.jsx)("div", {
                    ref: t,
                    className: (0, a.cn)("flex flex-col space-y-1.5 p-6", n),
                    ...s
                })
            });
            o.displayName = "CardHeader";
            let u = s.forwardRef((e, t) => {
                let {
                    className: n,
                    ...s
                } = e;
                return (0, r.jsx)("h3", {
                    ref: t,
                    className: (0, a.cn)("text-2xl font-semibold leading-none tracking-tight", n),
                    ...s
                })
            });
            u.displayName = "CardTitle";
            let l = s.forwardRef((e, t) => {
                let {
                    className: n,
                    ...s
                } = e;
                return (0, r.jsx)("p", {
                    ref: t,
                    className: (0, a.cn)("text-sm text-zinc-500 dark:text-zinc-400", n),
                    ...s
                })
            });
            l.displayName = "CardDescription";
            let d = s.forwardRef((e, t) => {
                let {
                    className: n,
                    ...s
                } = e;
                return (0, r.jsx)("div", {
                    ref: t,
                    className: (0, a.cn)("p-6 pt-0", n),
                    ...s
                })
            });
            d.displayName = "CardContent";
            let c = s.forwardRef((e, t) => {
                let {
                    className: n,
                    ...s
                } = e;
                return (0, r.jsx)("div", {
                    ref: t,
                    className: (0, a.cn)("flex items-center p-6 pt-0", n),
                    ...s
                })
            });
            c.displayName = "CardFooter"
        },
        40279: function(e, t, n) {
            "use strict";
            n.d(t, {
                I: function() {
                    return i
                }
            });
            var r = n(57437),
                s = n(2265),
                a = n(81201);
            let i = s.forwardRef((e, t) => {
                let {
                    className: n,
                    type: s,
                    ...i
                } = e;
                return (0, r.jsx)("input", {
                    type: s,
                    className: (0, a.cn)("flex h-9 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background disabled:cursor-not-allowed file:border-0 focus:border-violet-500 file:bg-transparent file:font-medium file:text-sm placeholder:text-muted-foreground disabled:opacity-50 focus:outline-none focus-visible:ring-ring focus:ring-4 focus:ring-violet-500/10", n),
                    ref: t,
                    ...i
                })
            });
            i.displayName = "Input"
        },
        31593: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                Separator: function() {
                    return o
                }
            });
            var r = n(57437),
                s = n(2265),
                a = n(55156),
                i = n(81201);
            let o = s.forwardRef((e, t) => {
                let {
                    className: n,
                    orientation: s = "horizontal",
                    decorative: o = !0,
                    ...u
                } = e;
                return (0, r.jsx)(a.f, {
                    ref: t,
                    decorative: o,
                    orientation: s,
                    className: (0, i.cn)("shrink-0 bg-zinc-200 dark:bg-zinc-500", "horizontal" === s ? "h-[1px] w-full" : "h-full w-[1px]", n),
                    ...u
                })
            });
            o.displayName = a.f.displayName
        },
        71488: function(e, t, n) {
            "use strict";
            n.d(t, {
                _v: function() {
                    return d
                },
                aJ: function() {
                    return l
                },
                pn: function() {
                    return o
                },
                u: function() {
                    return u
                }
            });
            var r = n(57437),
                s = n(2265),
                a = n(91668),
                i = n(81201);
            let o = a.zt,
                u = a.fC,
                l = a.xz,
                d = s.forwardRef((e, t) => {
                    let {
                        className: n,
                        sideOffset: s = 4,
                        ...o
                    } = e;
                    return (0, r.jsx)(a.VY, {
                        ref: t,
                        sideOffset: s,
                        className: (0, i.cn)("z-50 overflow-hidden rounded-md border border-zinc-700 bg-zinc-950 px-3 py-1.5 text-sm text-zinc-50 shadow-md animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-50", n),
                        ...o
                    })
                });
            d.displayName = a.VY.displayName
        },
        28261: function(e, t, n) {
            "use strict";
            n.d(t, {
                R2: function() {
                    return f
                },
                e1: function() {
                    return h
                },
                mm: function() {
                    return v
                },
                pe: function() {
                    return m
                }
            });
            var r = n(52274),
                s = n(71632),
                a = n(47225),
                i = n(2868),
                o = n(69007),
                u = n(45729),
                l = n(43061),
                d = n(8234),
                c = n(45345);
            let h = "public-conversation";

            function f(e) {
                return (0, s.useQuery)((0, r.C)({
                    queryKey: [h, {
                        conversationId: e.conversationId,
                        userId: e.userId
                    }],
                    queryFn: async () => {
                        var t;
                        let n = (0, o.yv)(e.conversationId);
                        if (!(null == n ? void 0 : n.savedToDB)) return {
                            id: e.conversationId,
                            messages: [],
                            uiMessages: [],
                            activity_state: l.GV.ONGOING,
                            external_conversation_messages: [],
                            uiExternalConversationMessages: []
                        };
                        if (!e.userId) throw Error("User ID is required");
                        let {
                            data: r,
                            error: s
                        } = await (0, u.No)({
                            conversationId: e.conversationId,
                            chatbotId: e.chatbotId,
                            userId: e.userId,
                            userHash: e.userHash
                        });
                        if (s) throw s;
                        return { ...r,
                            uiMessages: (t = r.messages).reduce((e, n) => {
                                var r, s;
                                let a = "",
                                    i = [];
                                switch (n.role) {
                                    case "system":
                                    case "tool":
                                        return e;
                                    case "user":
                                        a = n.content;
                                        break;
                                    case "assistant":
                                        switch (n.type) {
                                            case "text":
                                                a = n.content;
                                                break;
                                            case "tool-call":
                                                {
                                                    let r = (s = n.content[0].toolCallId, t.find(e => "tool" === e.role && e.content[0].toolCallId === s));
                                                    if (!r) return e;i.push({
                                                        state: "result",
                                                        toolCallId: n.content[0].toolCallId,
                                                        toolName: n.content[0].toolName,
                                                        result: r.content[0].result,
                                                        args: n.content[0].args
                                                    })
                                                }
                                        }
                                }
                                return e.push({ ...n,
                                    id: null !== (r = n.id) && void 0 !== r ? r : (0, d.D)(),
                                    role: n.role,
                                    content: a,
                                    toolInvocations: i.length > 0 ? i : void 0
                                }), e
                            }, []),
                            uiExternalConversationMessages: r.external_conversation_messages.map(e => ({
                                id: e.id,
                                role: e.role,
                                content: e.content,
                                metadata: e.metadata
                            }))
                        }
                    }
                }))
            }
            let v = "user-public-conversations";

            function m(e) {
                return (0, i.useInfiniteQuery)((0, a.t)({
                    queryKey: [v, {
                        id: e.userId
                    }],
                    queryFn: async t => {
                        let {
                            pageParam: n
                        } = t;
                        if (!e.userId) return {
                            data: [],
                            hasMoreConversations: !1,
                            currentPage: 0
                        };
                        let r = e.userHash ? void 0 : (0, o.Yo)(e.userId).slice(0, 15),
                            {
                                data: s,
                                totalCount: a,
                                error: i
                            } = await (0, u.pC)({
                                userId: e.userId,
                                userHash: e.userHash,
                                chatbotId: e.chatbotId,
                                page: n,
                                limit: 15,
                                conversationIds: r
                            });
                        if (i) throw i;
                        return {
                            data: s,
                            hasMoreConversations: n < Math.ceil(a / 15) - 1,
                            currentPage: n
                        }
                    },
                    initialPageParam: 0,
                    getNextPageParam: e => e.hasMoreConversations ? e.currentPage + 1 : null,
                    staleTime: 3e5,
                    placeholderData: c.Wk,
                    refetchOnMount: !0
                }))
            }
        },
        18280: function(e, t, n) {
            "use strict";
            n.d(t, {
                d: function() {
                    return g
                }
            });
            var r = n(29827),
                s = n(21770),
                a = n(54012),
                i = n(39984),
                o = n(2265),
                u = n(43061),
                l = n(8234),
                d = n(45729),
                c = n(28261);
            let h = e => {
                    e.queryClient.setQueryData([c.mm, {
                        id: e.userId
                    }], t => {
                        if (!t) return t;
                        let n = {
                                id: "",
                                last_message_at: "",
                                activity_state: "taken_over",
                                last_text_message: {
                                    role: e.role,
                                    content: ""
                                }
                            },
                            r = t.pages.map(t => {
                                let r = t.data.map(t => t.id === e.conversationId ? (n = { ...t,
                                    last_message_at: new Date().toISOString(),
                                    last_text_message: { ...t.last_text_message,
                                        content: e.message,
                                        role: e.role
                                    }
                                }, null) : t);
                                return { ...t,
                                    data: r.filter(e => null !== e)
                                }
                            });
                        return r[0].data.unshift(n), { ...t,
                            pages: r
                        }
                    })
                },
                f = e => {
                    e.queryClient.setQueryData([c.e1, {
                        conversationId: e.conversationId,
                        userId: e.userId
                    }], t => t ? { ...t,
                        activity_state: e.activityState
                    } : t), e.queryClient.setQueryData([c.mm, {
                        id: e.userId
                    }], t => {
                        if (!t) return t;
                        let n = t.pages.map(t => {
                            let n = t.data.map(t => t.id === e.conversationId ? { ...t,
                                activity_state: e.activityState
                            } : t);
                            return { ...t,
                                data: n
                            }
                        });
                        return { ...t,
                            pages: n
                        }
                    })
                };
            var v = n(88933);
            let m = e => {
                    let {
                        conversationId: t,
                        isChatTakenOver: n,
                        onConversationEnd: r,
                        onAgentMessageInsert: s
                    } = e;
                    (0, o.useEffect)(() => {
                        if (!n) return;
                        let e = (0, v.e)(),
                            a = e.channel("conversation-".concat(t)).on("broadcast", {
                                event: "EXTERNAL_CONVERSATION_MESSAGE_INSERT"
                            }, e => {
                                let t = e.payload;
                                t.role === u.Zg.AGENT && s(t)
                            }).on("broadcast", {
                                event: "CONVERSATION_END"
                            }, r).subscribe();
                        return () => {
                            e.removeChannel(a)
                        }
                    }, [n, t, s, r])
                },
                g = e => {
                    var t, n, v, g, y, b, I, w, C, x, _, M, z, k, O, E, N, S, P, T;
                    let R = (0, r.useQueryClient)(),
                        A = e.iframeUser,
                        [q, D] = (0, o.useState)([]),
                        j = e.defaultConversationId,
                        {
                            realtimeAudioMode: Q,
                            enableRealtimeAudioMode: F,
                            disableRealtimeAudioMode: H
                        } = p(),
                        L = (0, c.R2)({
                            conversationId: j,
                            chatbotId: e.chatbot.id,
                            userId: null !== (b = null !== (y = null == A ? void 0 : A.user_id) && void 0 !== y ? y : null == A ? void 0 : A.anon_user_id) && void 0 !== b ? b : "",
                            userHash: null == A ? void 0 : A.user_hash
                        });
                    (0, o.useEffect)(() => {
                        L.error && er()
                    }, [L.error]);
                    let U = (S = {
                            conversationId: j,
                            chatbotId: e.chatbot.id,
                            userId: null !== (w = null !== (I = null == A ? void 0 : A.user_id) && void 0 !== I ? I : null == A ? void 0 : A.anon_user_id) && void 0 !== w ? w : "",
                            userHash: null !== (C = null == A ? void 0 : A.user_hash) && void 0 !== C ? C : void 0
                        }, (0, s.useMutation)({
                            mutationKey: ["truncate-chat"],
                            mutationFn: async e => {
                                let {
                                    error: t
                                } = await (0, d.pH)({
                                    conversationId: S.conversationId,
                                    chatbotId: S.chatbotId,
                                    messageId: e,
                                    userId: S.userId,
                                    userHash: S.userHash
                                });
                                if (t) throw t
                            }
                        })),
                        V = (P = {
                            conversationId: j,
                            chatbotId: e.chatbot.id,
                            userId: null !== (_ = null !== (x = null == A ? void 0 : A.user_id) && void 0 !== x ? x : null == A ? void 0 : A.anon_user_id) && void 0 !== _ ? _ : "",
                            userHash: null !== (M = null == A ? void 0 : A.user_hash) && void 0 !== M ? M : void 0
                        }, (0, s.useMutation)({
                            mutationKey: ["save-tool-result"],
                            mutationFn: async e => {
                                let {
                                    error: t
                                } = await (0, d.rJ)({
                                    conversationId: P.conversationId,
                                    chatbotId: P.chatbotId,
                                    toolResult: e.toolResult,
                                    toolCall: e.toolCall,
                                    userId: P.userId,
                                    userHash: P.userHash
                                });
                                if (t) throw t
                            }
                        })),
                        Z = function(e) {
                            let t = (0, r.useQueryClient)();
                            return (0, s.useMutation)({
                                mutationKey: ["live-chat"],
                                mutationFn: async t => {
                                    let {
                                        error: n
                                    } = await (0, d.PV)({
                                        conversationId: e.conversationId,
                                        chatbotId: e.chatbotId,
                                        message: t.message,
                                        userId: t.userId,
                                        userHash: t.userHash
                                    });
                                    if (n) throw n;
                                    return {
                                        message: t.message,
                                        role: u.Zg.USER,
                                        conversationId: e.conversationId,
                                        userId: t.userId
                                    }
                                },
                                onSuccess: e => {
                                    h({
                                        queryClient: t,
                                        message: e.message,
                                        role: e.role,
                                        conversationId: e.conversationId,
                                        userId: e.userId
                                    })
                                }
                            })
                        }({
                            conversationId: j,
                            chatbotId: e.chatbot.id
                        }),
                        K = (T = {
                            conversationId: j,
                            chatbotId: e.chatbot.id,
                            userId: null !== (k = null !== (z = null == A ? void 0 : A.user_id) && void 0 !== z ? z : null == A ? void 0 : A.anon_user_id) && void 0 !== k ? k : "",
                            userHash: null !== (O = null == A ? void 0 : A.user_hash) && void 0 !== O ? O : void 0
                        }, (0, s.useMutation)({
                            mutationKey: ["register-message-feedback"],
                            mutationFn: async e => {
                                let {
                                    error: t
                                } = await (0, d.Fv)({
                                    conversationId: T.conversationId,
                                    chatbotId: T.chatbotId,
                                    messageId: e.messageId,
                                    feedback: e.feedback,
                                    userId: T.userId,
                                    userHash: T.userHash
                                });
                                if (t) throw t
                            }
                        })),
                        B = (0, o.useCallback)(e => {
                            var t, n;
                            D(t => [...t, {
                                id: e.id,
                                role: e.role,
                                content: e.content,
                                metadata: e.metadata
                            }]), h({
                                queryClient: R,
                                message: e.content,
                                role: e.role,
                                conversationId: j,
                                userId: null !== (n = null !== (t = null == A ? void 0 : A.user_id) && void 0 !== t ? t : null == A ? void 0 : A.anon_user_id) && void 0 !== n ? n : ""
                            })
                        }, [R, j, A]),
                        W = (0, o.useCallback)(() => {
                            var e, t;
                            f({
                                queryClient: R,
                                userId: null !== (t = null !== (e = null == A ? void 0 : A.user_id) && void 0 !== e ? e : null == A ? void 0 : A.anon_user_id) && void 0 !== t ? t : "",
                                conversationId: j,
                                activityState: u.GV.ENDED
                            })
                        }, [R, j, A]),
                        G = (0, o.useCallback)(async (e, t) => {
                            await K.mutateAsync({
                                messageId: e,
                                feedback: t
                            })
                        }, [K]),
                        J = (0, o.useMemo)(() => {
                            var t;
                            return L.isLoading ? [] : (null === (t = L.data) || void 0 === t ? void 0 : t.uiMessages.length) ? L.data.uiMessages : e.initialMessages.map(e => ({
                                role: u.WU.ASSISTANT,
                                content: e,
                                id: (0, l.D)()
                            }))
                        }, [L.isLoading, null === (t = L.data) || void 0 === t ? void 0 : t.uiMessages, e.initialMessages]),
                        [Y, X] = (0, o.useState)(j);
                    (0, o.useEffect)(() => {
                        X((0, l.D)()), en(void 0)
                    }, [j]);
                    let $ = (0, a.RJ)({
                            id: Y,
                            api: e.api,
                            initialInput: "",
                            initialMessages: J,
                            keepLastMessageOnError: !0,
                            maxSteps: 5,
                            onToolCall: async t => {
                                let {
                                    toolCall: n
                                } = t;
                                return await e.onToolCall({
                                    toolCall: n,
                                    iframeUser: A,
                                    saveToolResult: V.mutateAsync
                                })
                            },
                            experimental_prepareRequestBody(t) {
                                let n = {
                                    messages: t.messages,
                                    conversationId: j,
                                    chatbotId: e.chatbot.id,
                                    user: A,
                                    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
                                };
                                return e.prepareRequestBody(n)
                            },
                            onError(e) {
                                en(e)
                            },
                            onResponse: async t => {
                                var n;
                                t.ok && en(void 0), null === (n = e.onResponse) || void 0 === n || n.call(e, t)
                            },
                            onFinish: e.onFinish
                        }),
                        ee = (0, o.useMemo)(() => {
                            var e;
                            let t = $.messages.some(e => {
                                    var t;
                                    return null === (t = e.toolInvocations) || void 0 === t ? void 0 : t.some(e => "result" === e.state && "Sunshine_Live_Chat" === e.toolName && "success" === e.result.status)
                                }),
                                n = (null === (e = L.data) || void 0 === e ? void 0 : e.activity_state) === u.GV.TAKEN_OVER;
                            return t || n
                        }, [null === (n = L.data) || void 0 === n ? void 0 : n.activity_state, $.messages]);
                    m({
                        conversationId: j,
                        isChatTakenOver: ee,
                        onAgentMessageInsert: B,
                        onConversationEnd: W
                    });
                    let [et, en] = (0, o.useState)(void 0), er = (0, o.useCallback)(t => {
                        var n;
                        let r = (0, l.D)();
                        en(void 0);
                        let s = ((null == t ? void 0 : t.length) ? t : e.chatbot.initial_messages).map(e => ({
                            role: u.WU.ASSISTANT,
                            content: e,
                            id: (0, l.D)()
                        }));
                        null === (n = e.onResetConversation) || void 0 === n || n.call(e, r), $.setMessages(s)
                    }, [$.setMessages, e.chatbot, e.onResetConversation]), es = function(e) {
                        let t = (0, r.useQueryClient)();
                        return (0, s.useMutation)({
                            mutationKey: ["update-conversation-activity-state"],
                            mutationFn: async t => {
                                let {
                                    error: n
                                } = await (0, d.dJ)({
                                    conversationId: t.conversationId,
                                    chatbotId: e.chatbotId,
                                    activityState: t.activityState,
                                    userId: e.userId,
                                    userHash: e.userHash
                                });
                                if (n) throw n
                            },
                            onMutate: async n => {
                                let {
                                    activityState: r,
                                    conversationId: s
                                } = n;
                                f({
                                    queryClient: t,
                                    userId: e.userId,
                                    conversationId: s,
                                    activityState: r
                                })
                            }
                        })
                    }({
                        chatbotId: e.chatbot.id,
                        userId: null !== (N = null !== (E = null == A ? void 0 : A.user_id) && void 0 !== E ? E : null == A ? void 0 : A.anon_user_id) && void 0 !== N ? N : "",
                        userHash: null == A ? void 0 : A.user_hash
                    }), ea = (0, o.useCallback)(async e => {
                        await es.mutateAsync({
                            activityState: e,
                            conversationId: j
                        }), e === u.GV.ENDED && W()
                    }, [es, j, W]), ei = (0, s.useMutation)({
                        mutationKey: ["retry-message"],
                        mutationFn: async e => {
                            if (ee) return;
                            let t = $.messages.findLastIndex(t => {
                                var n, r, s;
                                return (null !== (s = null === (r = t.annotations) || void 0 === r ? void 0 : null === (n = r[0]) || void 0 === n ? void 0 : n.id) && void 0 !== s ? s : t.id) === e
                            });
                            if (-1 === t) return;
                            let n = $.messages.slice(0, t).findLastIndex(e => e.role === u.WU.USER);
                            if (-1 !== n) {
                                en(void 0), $.setMessages(e => e.slice(0, n + 1));
                                try {
                                    await U.mutateAsync(e), $.reload()
                                } catch (e) {
                                    en(Error("Failed to retry message"))
                                }
                            }
                        }
                    }), eo = (0, o.useMemo)(() => {
                        var e;
                        if (L.isLoading) return "initializing";
                        if ((null === (e = L.data) || void 0 === e ? void 0 : e.activity_state) === "ended") return "conversation-ended";
                        if (ei.isPending) return "waiting-for-stream";
                        if ($.isLoading) {
                            let e = $.messages.at(-1);
                            return (null == e ? void 0 : e.role) === u.WU.ASSISTANT && e.content ? "busy" : "waiting-for-stream"
                        }
                        return K.isPending || V.isPending ? "action-loading" : Z.isPending ? "sending-live-chat-message" : "ready"
                    }, [L.isLoading, null === (v = L.data) || void 0 === v ? void 0 : v.activity_state, K.isPending, V.isPending, ei.isPending, Z.isPending, $.isLoading, $.messages]);
                    (0, o.useEffect)(() => {
                        var e, t;
                        D(null !== (t = null === (e = L.data) || void 0 === e ? void 0 : e.uiExternalConversationMessages) && void 0 !== t ? t : [])
                    }, [null === (g = L.data) || void 0 === g ? void 0 : g.uiExternalConversationMessages]);
                    let eu = (0, o.useCallback)(async e => {
                            if (e) {
                                if (D(t => et ? [...t.slice(0, -1), {
                                        id: (0, l.D)(),
                                        role: u.Zg.USER,
                                        content: e
                                    }] : [...t, {
                                        id: (0, l.D)(),
                                        role: u.Zg.USER,
                                        content: e
                                    }]), !(null == A ? void 0 : A.user_id)) return en(Error("User not found"));
                                try {
                                    var t;
                                    await Z.mutateAsync({
                                        message: e,
                                        userId: A.user_id,
                                        userHash: null !== (t = A.user_hash) && void 0 !== t ? t : void 0
                                    }), en(void 0)
                                } catch (e) {
                                    en(e)
                                }
                            }
                        }, [A, Z, et]),
                        el = (0, o.useCallback)(async e => {
                            if (ee) await eu(e);
                            else {
                                var t;
                                (null === (t = $.messages.at(-1)) || void 0 === t ? void 0 : t.role) === u.WU.USER && $.setMessages(e => e.slice(0, -1)), $.append({
                                    id: (0, l.D)(),
                                    role: u.WU.USER,
                                    content: e
                                })
                            }
                        }, [$.append, $.setMessages, $.messages, ee, eu]),
                        ed = (0, o.useCallback)(async () => {
                            if (ee) {
                                let e = $.input;
                                $.setInput(""), await eu(e)
                            } else {
                                var e;
                                (null === (e = $.messages.at(-1)) || void 0 === e ? void 0 : e.role) === u.WU.USER && $.setMessages(e => e.slice(0, -1)), $.handleSubmit()
                            }
                        }, [$, ee, eu]),
                        ec = (0, o.useMemo)(() => (0, i.uq)($.messages), [$.messages]);
                    return {
                        status: eo,
                        chat: $,
                        error: et,
                        groupedMessages: ec,
                        groupedLiveChatMessages: (0, o.useMemo)(() => (0, i.yH)(q), [q]),
                        sendMessage: el,
                        handleSubmit: ed,
                        retryMessage: ei.mutateAsync,
                        saveToolResult: V.mutateAsync,
                        resetConversation: er,
                        registerResponseFeedback: G,
                        updateConversationActivityState: ea,
                        realtimeAudioMode: Q,
                        enableRealtimeAudioMode: F,
                        disableRealtimeAudioMode: H,
                        conversationId: j,
                        isChatTakenOver: ee,
                        initialMessages: J
                    }
                },
                p = () => {
                    let [e, t] = (0, o.useState)(!1);
                    return {
                        realtimeAudioMode: e,
                        enableRealtimeAudioMode: () => {
                            t(!0)
                        },
                        disableRealtimeAudioMode: () => {
                            t(!1)
                        }
                    }
                }
        },
        77299: function(e, t, n) {
            "use strict";
            n.d(t, {
                w: function() {
                    return s
                }
            });
            var r = n(2265);
            let s = e => {
                let [t, n] = (0, r.useState)(null);
                (0, r.useEffect)(() => {
                    e.anonUserId && a({ ...t,
                        anon_user_id: e.anonUserId
                    })
                }, [e.anonUserId]);
                let s = async t => !!(await fetch("/api/auth/verify-user-identification", {
                        method: "POST",
                        body: JSON.stringify({
                            userId: null == t ? void 0 : t.user_id,
                            userHash: null == t ? void 0 : t.user_hash,
                            chatbotId: e.chatbotId
                        })
                    })).ok,
                    a = (0, r.useCallback)(async t => {
                        var r;
                        let {
                            user_id: a,
                            user_hash: i,
                            ...o
                        } = null != t ? t : {}, u = { ...o,
                            anon_user_id: null !== (r = e.anonUserId) && void 0 !== r ? r : void 0
                        };
                        (null == t ? void 0 : t.user_hash) && (await s(t) ? u = { ...u,
                            user_id: t.user_id,
                            user_hash: t.user_hash
                        } : console.error("Invalid user id or user hash. Please check them.")), n(u)
                    }, [e.anonUserId, s]);
                return {
                    iframeUser: t,
                    identifyUser: a
                }
            }
        },
        34102: function(e, t, n) {
            "use strict";
            n.d(t, {
                Bt: function() {
                    return a
                },
                KD: function() {
                    return d
                },
                Ob: function() {
                    return u
                },
                Qd: function() {
                    return l
                },
                ZS: function() {
                    return o
                }
            });
            var r = n(31229);
            let s = r.z.nativeEnum({
                    LOW: "Low",
                    NORMAL: "Normal",
                    HIGH: "High",
                    URGENT: "Urgent"
                }),
                a = s.enum,
                i = r.z.nativeEnum({
                    BILLING: "Billing",
                    ACCOUNT: "Account Management",
                    FEATURE_REQUEST: "Feature Request",
                    ISSUE: "Bugs/Issues",
                    AFFILIATE: "Affiliate Program",
                    PARTNERSHIP: "Partnership",
                    GENERAL: "General Inquiries"
                }),
                o = i.enum,
                u = r.z.array(r.z.instanceof(Blob).refine(e => e.size < 5242880, "Max file size is 5MB")).transform(e => {
                    let t = new FormData;
                    return e.forEach(e => t.append("media", e)), t
                }),
                l = r.z.array(r.z.object({
                    name: r.z.string(),
                    size: r.z.number(),
                    token: r.z.string()
                })),
                d = r.z.object({
                    userEmail: r.z.string().email(),
                    userFullName: r.z.string().optional(),
                    userId: r.z.string().min(1),
                    accountSubscription: r.z.string().min(1),
                    subject: r.z.string().min(3, "Please add a subject"),
                    description: r.z.string().min(1, "Please add a description before submitting your request."),
                    type: i,
                    severity: s,
                    account: r.z.string().min(1).nullable(),
                    selectedChatbots: r.z.array(r.z.object({
                        id: r.z.string(),
                        name: r.z.string()
                    })).default([]),
                    attachments: l
                })
        },
        88933: function(e, t, n) {
            "use strict";
            n.d(t, {
                e: function() {
                    return s
                }
            });
            var r = n(13085);
            let s = () => (0, r.createBrowserClient)("https://backend.chatbase.co", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNwanZxYXFsYm9yaHR4anljbWdkIiwicm9sZSI6ImFub24iLCJpYXQiOjE2NzM4MDc0OTAsImV4cCI6MTk4OTM4MzQ5MH0.6-gIEwcRpD2ec27Ne2N-ixS5km-nkeWD862XNfrBOpI")
        },
        81194: function(e, t, n) {
            "use strict";
            n.d(t, {
                TanstackQueryProvider: function() {
                    return l
                }
            });
            var r = n(57437),
                s = n(2265),
                a = n(29827),
                i = n(54114),
                o = n(3204);
            let u = {
                defaultOptions: {
                    queries: {
                        staleTime: 3e5,
                        retry: 1
                    }
                }
            };

            function l(e) {
                let t = (0, s.useContext)(a.QueryClientContext),
                    [n] = (0, s.useState)(() => null != t ? t : new i.S(u));
                return (0, r.jsxs)(a.QueryClientProvider, {
                    client: n,
                    children: [e.children, (0, r.jsx)(o.t, {
                        initialIsOpen: !1,
                        buttonPosition: "bottom-left"
                    })]
                })
            }
            s.cache(() => new i.S(u))
        },
        42746: function(e, t, n) {
            "use strict";
            n.d(t, {
                CR: function() {
                    return f
                },
                GT: function() {
                    return l
                },
                K2: function() {
                    return i
                },
                LI: function() {
                    return o
                },
                j6: function() {
                    return h
                },
                p0: function() {
                    return d
                },
                qC: function() {
                    return s
                },
                qx: function() {
                    return c
                },
                tb: function() {
                    return u
                },
                x6: function() {
                    return a
                }
            }), n(99027);
            var r = n(34102);
            n(25566);
            let s = async e => {
                let {
                    url: t,
                    headers: n,
                    data: r
                } = e, s = await fetch(t, {
                    method: "POST",
                    headers: new Headers({
                        "Content-Type": "application/json",
                        ...n
                    }),
                    body: JSON.stringify(r)
                });
                if (!s.ok) {
                    let e = await s.json();
                    throw Error((null == e ? void 0 : e.message) || s.statusText)
                }
                return s.json()
            };

            function a(e) {
                return e.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
            }
            let i = e => {
                try {
                    return new URL(e), !0
                } catch (e) {
                    return !1
                }
            };
            async function o(e) {
                let t = new AbortController,
                    n = setTimeout(() => {
                        t.abort()
                    }, 3e4);
                try {
                    let s = await fetch("/api/get-attachment-token", {
                        method: "POST",
                        body: e,
                        cache: "no-cache",
                        signal: t.signal
                    });
                    if (clearTimeout(n), !s.ok) throw Error("Error uploading support schema attachments", {
                        cause: await s.text()
                    });
                    let a = await s.json();
                    return r.Qd.parse(a.files)
                } catch (e) {
                    throw Error("Error uploading support schema attachments", {
                        cause: e
                    })
                }
            }

            function u(e) {
                return new Date(e).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                    hour12: !0
                })
            }
            let l = e => {
                    let t = e.replace("http://", "").replace("https://", ""),
                        n = (t = t.split("/")[0]).split("."),
                        r = n[n.length - 1];
                    return 2 === r.length && n.length > 3 ? n.slice(-3).join(".") : n.slice(-2).join(".")
                },
                d = e => {
                    let t = l(e);
                    return e === t ? "" : e.slice(0, e.length - t.length - 1)
                },
                c = e => {
                    let t = l(e);
                    return e !== t
                },
                h = (e, t) => (new Date(t).getTime() - new Date(e).getTime()) / 864e5,
                f = e => {
                    let {
                        src: t,
                        width: n,
                        quality: r
                    } = e;
                    return "".concat("https://backend.chatbase.co", "/storage/v1/object/public/").concat(t, "?width=").concat(n, "&quality=").concat(null != r ? r : 50)
                }
        },
        55156: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return u
                },
                f: function() {
                    return d
                }
            });
            var r = n(1119),
                s = n(2265),
                a = n(82912);
            let i = "horizontal",
                o = ["horizontal", "vertical"],
                u = (0, s.forwardRef)((e, t) => {
                    let {
                        decorative: n,
                        orientation: o = i,
                        ...u
                    } = e, d = l(o) ? o : i;
                    return (0, s.createElement)(a.WV.div, (0, r.Z)({
                        "data-orientation": d
                    }, n ? {
                        role: "none"
                    } : {
                        "aria-orientation": "vertical" === d ? d : void 0,
                        role: "separator"
                    }, u, {
                        ref: t
                    }))
                });

            function l(e) {
                return o.includes(e)
            }
            u.propTypes = {
                orientation(e, t, n) {
                    let r = e[t],
                        s = String(r);
                    return r && !l(r) ? Error(`Invalid prop \`orientation\` of value \`${s}\` supplied to \`${n}\`, expected one of:
  - horizontal
  - vertical

Defaulting to \`${i}\`.`) : null
                }
            };
            let d = u
        },
        98482: function(e, t, n) {
            "use strict";
            n.d(t, {
                g7: function() {
                    return a
                }
            });
            var r = n(2265),
                s = n(57437),
                a = r.forwardRef((e, t) => {
                    let {
                        children: n,
                        ...a
                    } = e, o = r.Children.toArray(n), l = o.find(u);
                    if (l) {
                        let e = l.props.children,
                            n = o.map(t => t !== l ? t : r.Children.count(e) > 1 ? r.Children.only(null) : r.isValidElement(e) ? e.props.children : null);
                        return (0, s.jsx)(i, { ...a,
                            ref: t,
                            children: r.isValidElement(e) ? r.cloneElement(e, void 0, n) : null
                        })
                    }
                    return (0, s.jsx)(i, { ...a,
                        ref: t,
                        children: n
                    })
                });
            a.displayName = "Slot";
            var i = r.forwardRef((e, t) => {
                let {
                    children: n,
                    ...s
                } = e;
                if (r.isValidElement(n)) {
                    let e, a;
                    let i = (e = Object.getOwnPropertyDescriptor(n.props, "ref") ? .get) && "isReactWarning" in e && e.isReactWarning ? n.ref : (e = Object.getOwnPropertyDescriptor(n, "ref") ? .get) && "isReactWarning" in e && e.isReactWarning ? n.props.ref : n.props.ref || n.ref;
                    return r.cloneElement(n, { ... function(e, t) {
                            let n = { ...t
                            };
                            for (let r in t) {
                                let s = e[r],
                                    a = t[r];
                                /^on[A-Z]/.test(r) ? s && a ? n[r] = (...e) => {
                                    a(...e), s(...e)
                                } : s && (n[r] = s) : "style" === r ? n[r] = { ...s,
                                    ...a
                                } : "className" === r && (n[r] = [s, a].filter(Boolean).join(" "))
                            }
                            return { ...e,
                                ...n
                            }
                        }(s, n.props),
                        ref: t ? function(...e) {
                            return t => e.forEach(e => {
                                "function" == typeof e ? e(t) : null != e && (e.current = t)
                            })
                        }(t, i) : i
                    })
                }
                return r.Children.count(n) > 1 ? r.Children.only(null) : null
            });
            i.displayName = "SlotClone";
            var o = ({
                children: e
            }) => (0, s.jsx)(s.Fragment, {
                children: e
            });

            function u(e) {
                return r.isValidElement(e) && e.type === o
            }
        },
        21636: function(e, t, n) {
            "use strict";
            n.d(t, {
                Gm: function() {
                    return s
                },
                Qy: function() {
                    return o
                },
                ZF: function() {
                    return u
                }
            });
            var r = n(45345);

            function s(e) {
                return {
                    onFetch: (t, n) => {
                        let s = async () => {
                            let n;
                            let s = t.options,
                                o = t.fetchOptions ? .meta ? .fetchMore ? .direction,
                                u = t.state.data ? .pages || [],
                                l = t.state.data ? .pageParams || [],
                                d = !1,
                                c = e => {
                                    Object.defineProperty(e, "signal", {
                                        enumerable: !0,
                                        get: () => (t.signal.aborted ? d = !0 : t.signal.addEventListener("abort", () => {
                                            d = !0
                                        }), t.signal)
                                    })
                                },
                                h = (0, r.cG)(t.options, t.fetchOptions),
                                f = async (e, n, s) => {
                                    if (d) return Promise.reject();
                                    if (null == n && e.pages.length) return Promise.resolve(e);
                                    let a = {
                                        queryKey: t.queryKey,
                                        pageParam: n,
                                        direction: s ? "backward" : "forward",
                                        meta: t.options.meta
                                    };
                                    c(a);
                                    let i = await h(a),
                                        {
                                            maxPages: o
                                        } = t.options,
                                        u = s ? r.Ht : r.VX;
                                    return {
                                        pages: u(e.pages, i, o),
                                        pageParams: u(e.pageParams, n, o)
                                    }
                                };
                            if (o && u.length) {
                                let e = "backward" === o,
                                    t = {
                                        pages: u,
                                        pageParams: l
                                    },
                                    r = (e ? i : a)(s, t);
                                n = await f(t, r, e)
                            } else {
                                n = await f({
                                    pages: [],
                                    pageParams: []
                                }, l[0] ? ? s.initialPageParam);
                                let t = e ? ? u.length;
                                for (let e = 1; e < t; e++) {
                                    let e = a(s, n);
                                    if (null == e) break;
                                    n = await f(n, e)
                                }
                            }
                            return n
                        };
                        t.options.persister ? t.fetchFn = () => t.options.persister ? .(s, {
                            queryKey: t.queryKey,
                            meta: t.options.meta,
                            signal: t.signal
                        }, n) : t.fetchFn = s
                    }
                }
            }

            function a(e, {
                pages: t,
                pageParams: n
            }) {
                let r = t.length - 1;
                return t.length > 0 ? e.getNextPageParam(t[r], t, n[r], n) : void 0
            }

            function i(e, {
                pages: t,
                pageParams: n
            }) {
                return t.length > 0 ? e.getPreviousPageParam ? .(t[0], t, n[0], n) : void 0
            }

            function o(e, t) {
                return !!t && null != a(e, t)
            }

            function u(e, t) {
                return !!t && !!e.getPreviousPageParam && null != i(e, t)
            }
        },
        63611: function(e, t, n) {
            "use strict";
            n.d(t, {
                c: function() {
                    return a
                }
            });
            var r = n(86900),
                s = n(21636),
                a = class extends r.z {
                    constructor(e, t) {
                        super(e, t)
                    }
                    bindMethods() {
                        super.bindMethods(), this.fetchNextPage = this.fetchNextPage.bind(this), this.fetchPreviousPage = this.fetchPreviousPage.bind(this)
                    }
                    setOptions(e, t) {
                        super.setOptions({ ...e,
                            behavior: (0, s.Gm)()
                        }, t)
                    }
                    getOptimisticResult(e) {
                        return e.behavior = (0, s.Gm)(), super.getOptimisticResult(e)
                    }
                    fetchNextPage(e) {
                        return this.fetch({ ...e,
                            meta: {
                                fetchMore: {
                                    direction: "forward"
                                }
                            }
                        })
                    }
                    fetchPreviousPage(e) {
                        return this.fetch({ ...e,
                            meta: {
                                fetchMore: {
                                    direction: "backward"
                                }
                            }
                        })
                    }
                    createResult(e, t) {
                        let {
                            state: n
                        } = e, r = super.createResult(e, t), {
                            isFetching: a,
                            isRefetching: i,
                            isError: o,
                            isRefetchError: u
                        } = r, l = n.fetchMeta ? .fetchMore ? .direction, d = o && "forward" === l, c = a && "forward" === l, h = o && "backward" === l, f = a && "backward" === l;
                        return { ...r,
                            fetchNextPage: this.fetchNextPage,
                            fetchPreviousPage: this.fetchPreviousPage,
                            hasNextPage: (0, s.Qy)(t, n.data),
                            hasPreviousPage: (0, s.ZF)(t, n.data),
                            isFetchNextPageError: d,
                            isFetchingNextPage: c,
                            isFetchPreviousPageError: h,
                            isFetchingPreviousPage: f,
                            isRefetchError: u && !d && !h,
                            isRefetching: i && !c && !f
                        }
                    }
                }
        },
        54114: function(e, t, n) {
            "use strict";
            n.d(t, {
                S: function() {
                    return v
                }
            });
            var r = n(45345),
                s = n(21733),
                a = n(18238),
                i = n(24112),
                o = class extends i.l {
                    constructor(e = {}) {
                        super(), this.config = e, this.#e = new Map
                    }#
                    e;
                    build(e, t, n) {
                        let a = t.queryKey,
                            i = t.queryHash ? ? (0, r.Rm)(a, t),
                            o = this.get(i);
                        return o || (o = new s.A({
                            cache: this,
                            queryKey: a,
                            queryHash: i,
                            options: e.defaultQueryOptions(t),
                            state: n,
                            defaultOptions: e.getQueryDefaults(a)
                        }), this.add(o)), o
                    }
                    add(e) {
                        this.#e.has(e.queryHash) || (this.#e.set(e.queryHash, e), this.notify({
                            type: "added",
                            query: e
                        }))
                    }
                    remove(e) {
                        let t = this.#e.get(e.queryHash);
                        t && (e.destroy(), t === e && this.#e.delete(e.queryHash), this.notify({
                            type: "removed",
                            query: e
                        }))
                    }
                    clear() {
                        a.V.batch(() => {
                            this.getAll().forEach(e => {
                                this.remove(e)
                            })
                        })
                    }
                    get(e) {
                        return this.#e.get(e)
                    }
                    getAll() {
                        return [...this.#e.values()]
                    }
                    find(e) {
                        let t = {
                            exact: !0,
                            ...e
                        };
                        return this.getAll().find(e => (0, r._x)(t, e))
                    }
                    findAll(e = {}) {
                        let t = this.getAll();
                        return Object.keys(e).length > 0 ? t.filter(t => (0, r._x)(e, t)) : t
                    }
                    notify(e) {
                        a.V.batch(() => {
                            this.listeners.forEach(t => {
                                t(e)
                            })
                        })
                    }
                    onFocus() {
                        a.V.batch(() => {
                            this.getAll().forEach(e => {
                                e.onFocus()
                            })
                        })
                    }
                    onOnline() {
                        a.V.batch(() => {
                            this.getAll().forEach(e => {
                                e.onOnline()
                            })
                        })
                    }
                },
                u = n(2894),
                l = class extends i.l {
                    constructor(e = {}) {
                        super(), this.config = e, this.#t = new Map, this.#n = Date.now()
                    }#
                    t;#
                    n;
                    build(e, t, n) {
                        let r = new u.m({
                            mutationCache: this,
                            mutationId: ++this.#n,
                            options: e.defaultMutationOptions(t),
                            state: n
                        });
                        return this.add(r), r
                    }
                    add(e) {
                        let t = d(e),
                            n = this.#t.get(t) ? ? [];
                        n.push(e), this.#t.set(t, n), this.notify({
                            type: "added",
                            mutation: e
                        })
                    }
                    remove(e) {
                        let t = d(e);
                        if (this.#t.has(t)) {
                            let n = this.#t.get(t) ? .filter(t => t !== e);
                            n && (0 === n.length ? this.#t.delete(t) : this.#t.set(t, n))
                        }
                        this.notify({
                            type: "removed",
                            mutation: e
                        })
                    }
                    canRun(e) {
                        let t = this.#t.get(d(e)) ? .find(e => "pending" === e.state.status);
                        return !t || t === e
                    }
                    runNext(e) {
                        let t = this.#t.get(d(e)) ? .find(t => t !== e && t.state.isPaused);
                        return t ? .continue() ? ? Promise.resolve()
                    }
                    clear() {
                        a.V.batch(() => {
                            this.getAll().forEach(e => {
                                this.remove(e)
                            })
                        })
                    }
                    getAll() {
                        return [...this.#t.values()].flat()
                    }
                    find(e) {
                        let t = {
                            exact: !0,
                            ...e
                        };
                        return this.getAll().find(e => (0, r.X7)(t, e))
                    }
                    findAll(e = {}) {
                        return this.getAll().filter(t => (0, r.X7)(e, t))
                    }
                    notify(e) {
                        a.V.batch(() => {
                            this.listeners.forEach(t => {
                                t(e)
                            })
                        })
                    }
                    resumePausedMutations() {
                        let e = this.getAll().filter(e => e.state.isPaused);
                        return a.V.batch(() => Promise.all(e.map(e => e.continue().catch(r.ZT))))
                    }
                };

            function d(e) {
                return e.options.scope ? .id ? ? String(e.mutationId)
            }
            var c = n(3392),
                h = n(57853),
                f = n(21636),
                v = class {#
                    r;#
                    s;#
                    a;#
                    i;#
                    o;#
                    u;#
                    l;#
                    d;
                    constructor(e = {}) {
                        this.#r = e.queryCache || new o, this.#s = e.mutationCache || new l, this.#a = e.defaultOptions || {}, this.#i = new Map, this.#o = new Map, this.#u = 0
                    }
                    mount() {
                        this.#u++, 1 === this.#u && (this.#l = c.j.subscribe(async e => {
                            e && (await this.resumePausedMutations(), this.#r.onFocus())
                        }), this.#d = h.N.subscribe(async e => {
                            e && (await this.resumePausedMutations(), this.#r.onOnline())
                        }))
                    }
                    unmount() {
                        this.#u--, 0 === this.#u && (this.#l ? .(), this.#l = void 0, this.#d ? .(), this.#d = void 0)
                    }
                    isFetching(e) {
                        return this.#r.findAll({ ...e,
                            fetchStatus: "fetching"
                        }).length
                    }
                    isMutating(e) {
                        return this.#s.findAll({ ...e,
                            status: "pending"
                        }).length
                    }
                    getQueryData(e) {
                        let t = this.defaultQueryOptions({
                            queryKey: e
                        });
                        return this.#r.get(t.queryHash) ? .state.data
                    }
                    ensureQueryData(e) {
                        let t = this.getQueryData(e.queryKey);
                        if (void 0 === t) return this.fetchQuery(e); {
                            let n = this.defaultQueryOptions(e),
                                s = this.#r.build(this, n);
                            return e.revalidateIfStale && s.isStaleByTime((0, r.KC)(n.staleTime, s)) && this.prefetchQuery(n), Promise.resolve(t)
                        }
                    }
                    getQueriesData(e) {
                        return this.#r.findAll(e).map(({
                            queryKey: e,
                            state: t
                        }) => [e, t.data])
                    }
                    setQueryData(e, t, n) {
                        let s = this.defaultQueryOptions({
                                queryKey: e
                            }),
                            a = this.#r.get(s.queryHash),
                            i = a ? .state.data,
                            o = (0, r.SE)(t, i);
                        if (void 0 !== o) return this.#r.build(this, s).setData(o, { ...n,
                            manual: !0
                        })
                    }
                    setQueriesData(e, t, n) {
                        return a.V.batch(() => this.#r.findAll(e).map(({
                            queryKey: e
                        }) => [e, this.setQueryData(e, t, n)]))
                    }
                    getQueryState(e) {
                        let t = this.defaultQueryOptions({
                            queryKey: e
                        });
                        return this.#r.get(t.queryHash) ? .state
                    }
                    removeQueries(e) {
                        let t = this.#r;
                        a.V.batch(() => {
                            t.findAll(e).forEach(e => {
                                t.remove(e)
                            })
                        })
                    }
                    resetQueries(e, t) {
                        let n = this.#r,
                            r = {
                                type: "active",
                                ...e
                            };
                        return a.V.batch(() => (n.findAll(e).forEach(e => {
                            e.reset()
                        }), this.refetchQueries(r, t)))
                    }
                    cancelQueries(e = {}, t = {}) {
                        let n = {
                            revert: !0,
                            ...t
                        };
                        return Promise.all(a.V.batch(() => this.#r.findAll(e).map(e => e.cancel(n)))).then(r.ZT).catch(r.ZT)
                    }
                    invalidateQueries(e = {}, t = {}) {
                        return a.V.batch(() => {
                            if (this.#r.findAll(e).forEach(e => {
                                    e.invalidate()
                                }), "none" === e.refetchType) return Promise.resolve();
                            let n = { ...e,
                                type: e.refetchType ? ? e.type ? ? "active"
                            };
                            return this.refetchQueries(n, t)
                        })
                    }
                    refetchQueries(e = {}, t) {
                        let n = { ...t,
                            cancelRefetch: t ? .cancelRefetch ? ? !0
                        };
                        return Promise.all(a.V.batch(() => this.#r.findAll(e).filter(e => !e.isDisabled()).map(e => {
                            let t = e.fetch(void 0, n);
                            return n.throwOnError || (t = t.catch(r.ZT)), "paused" === e.state.fetchStatus ? Promise.resolve() : t
                        }))).then(r.ZT)
                    }
                    fetchQuery(e) {
                        let t = this.defaultQueryOptions(e);
                        void 0 === t.retry && (t.retry = !1);
                        let n = this.#r.build(this, t);
                        return n.isStaleByTime((0, r.KC)(t.staleTime, n)) ? n.fetch(t) : Promise.resolve(n.state.data)
                    }
                    prefetchQuery(e) {
                        return this.fetchQuery(e).then(r.ZT).catch(r.ZT)
                    }
                    fetchInfiniteQuery(e) {
                        return e.behavior = (0, f.Gm)(e.pages), this.fetchQuery(e)
                    }
                    prefetchInfiniteQuery(e) {
                        return this.fetchInfiniteQuery(e).then(r.ZT).catch(r.ZT)
                    }
                    resumePausedMutations() {
                        return h.N.isOnline() ? this.#s.resumePausedMutations() : Promise.resolve()
                    }
                    getQueryCache() {
                        return this.#r
                    }
                    getMutationCache() {
                        return this.#s
                    }
                    getDefaultOptions() {
                        return this.#a
                    }
                    setDefaultOptions(e) {
                        this.#a = e
                    }
                    setQueryDefaults(e, t) {
                        this.#i.set((0, r.Ym)(e), {
                            queryKey: e,
                            defaultOptions: t
                        })
                    }
                    getQueryDefaults(e) {
                        let t = [...this.#i.values()],
                            n = {};
                        return t.forEach(t => {
                            (0, r.to)(e, t.queryKey) && (n = { ...n,
                                ...t.defaultOptions
                            })
                        }), n
                    }
                    setMutationDefaults(e, t) {
                        this.#o.set((0, r.Ym)(e), {
                            mutationKey: e,
                            defaultOptions: t
                        })
                    }
                    getMutationDefaults(e) {
                        let t = [...this.#o.values()],
                            n = {};
                        return t.forEach(t => {
                            (0, r.to)(e, t.mutationKey) && (n = { ...n,
                                ...t.defaultOptions
                            })
                        }), n
                    }
                    defaultQueryOptions(e) {
                        if (e._defaulted) return e;
                        let t = { ...this.#a.queries,
                            ...this.getQueryDefaults(e.queryKey),
                            ...e,
                            _defaulted: !0
                        };
                        return t.queryHash || (t.queryHash = (0, r.Rm)(t.queryKey, t)), void 0 === t.refetchOnReconnect && (t.refetchOnReconnect = "always" !== t.networkMode), void 0 === t.throwOnError && (t.throwOnError = !!t.suspense), !t.networkMode && t.persister && (t.networkMode = "offlineFirst"), !0 !== t.enabled && t.queryFn === r.CN && (t.enabled = !1), t
                    }
                    defaultMutationOptions(e) {
                        return e ? ._defaulted ? e : { ...this.#a.mutations,
                            ...e ? .mutationKey && this.getMutationDefaults(e.mutationKey),
                            ...e,
                            _defaulted : !0
                        }
                    }
                    clear() {
                        this.#r.clear(), this.#s.clear()
                    }
                }
        },
        3204: function(e, t, n) {
            "use strict";
            n.d(t, {
                t: function() {
                    return r
                }
            });
            var r = function() {
                return null
            }
        },
        47225: function(e, t, n) {
            "use strict";

            function r(e) {
                return e
            }
            n.d(t, {
                t: function() {
                    return r
                }
            })
        },
        52274: function(e, t, n) {
            "use strict";

            function r(e) {
                return e
            }
            n.d(t, {
                C: function() {
                    return r
                }
            })
        },
        2868: function(e, t, n) {
            "use strict";
            n.d(t, {
                useInfiniteQuery: function() {
                    return a
                }
            });
            var r = n(63611),
                s = n(99285);

            function a(e, t) {
                return (0, s.r)(e, r.c, t)
            }
        },
        77712: function(e, t, n) {
            "use strict";
            n.d(t, {
                j: function() {
                    return a
                }
            });
            let r = e => "boolean" == typeof e ? "".concat(e) : 0 === e ? "0" : e,
                s = function() {
                    for (var e, t, n = 0, r = ""; n < arguments.length;)(e = arguments[n++]) && (t = function e(t) {
                        var n, r, s = "";
                        if ("string" == typeof t || "number" == typeof t) s += t;
                        else if ("object" == typeof t) {
                            if (Array.isArray(t))
                                for (n = 0; n < t.length; n++) t[n] && (r = e(t[n])) && (s && (s += " "), s += r);
                            else
                                for (n in t) t[n] && (s && (s += " "), s += n)
                        }
                        return s
                    }(e)) && (r && (r += " "), r += t);
                    return r
                },
                a = (e, t) => n => {
                    var a;
                    if ((null == t ? void 0 : t.variants) == null) return s(e, null == n ? void 0 : n.class, null == n ? void 0 : n.className);
                    let {
                        variants: i,
                        defaultVariants: o
                    } = t, u = Object.keys(i).map(e => {
                        let t = null == n ? void 0 : n[e],
                            s = null == o ? void 0 : o[e];
                        if (null === t) return null;
                        let a = r(t) || r(s);
                        return i[e][a]
                    }), l = n && Object.entries(n).reduce((e, t) => {
                        let [n, r] = t;
                        return void 0 === r || (e[n] = r), e
                    }, {});
                    return s(e, u, null == t ? void 0 : null === (a = t.compoundVariants) || void 0 === a ? void 0 : a.reduce((e, t) => {
                        let {
                            class: n,
                            className: r,
                            ...s
                        } = t;
                        return Object.entries(s).every(e => {
                            let [t, n] = e;
                            return Array.isArray(n) ? n.includes({ ...o,
                                ...l
                            }[t]) : ({ ...o,
                                ...l
                            })[t] === n
                        }) ? [...e, n, r] : e
                    }, []), null == n ? void 0 : n.class, null == n ? void 0 : n.className)
                }
        }
    },
    function(e) {
        e.O(0, [329, 3954, 2972, 5819, 2957, 3085, 1229, 9763, 4588, 5378, 602, 9027, 8208, 5875, 2855, 3513, 2201, 7399, 3080, 5220, 5041, 357, 9167, 9121, 4012, 2341, 4611, 5825, 2971, 2117, 1744], function() {
            return e(e.s = 63317)
        }), _N_E = e.O()
    }
]);