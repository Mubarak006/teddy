"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5825], {
        69007: function(e, t, a) {
            a.d(t, {
                Aw: function() {
                    return m
                },
                DU: function() {
                    return g
                },
                O2: function() {
                    return u
                },
                Wd: function() {
                    return v
                },
                Yo: function() {
                    return d
                },
                r: function() {
                    return c
                },
                yv: function() {
                    return f
                }
            });
            var r = a(8234),
                n = a(31229);
            let s = e => "".concat("cb_conv", "___").concat(e),
                l = e => "".concat("cb_c_", "___").concat(e),
                o = e => "".concat("cb_anon", "___").concat(e),
                i = e => "".concat("cb_user", "___").concat(e),
                d = e => {
                    var t, a;
                    return null !== (a = null === (t = window.localStorage.getItem(s(e))) || void 0 === t ? void 0 : t.split(",")) && void 0 !== a ? a : []
                },
                c = e => window.localStorage.getItem(i(e)),
                u = (e, t) => {
                    {
                        let a = i(e);
                        window.localStorage.setItem(a, t)
                    }
                },
                m = (e, t) => {
                    {
                        let a = new Set([t, ...d(e)]);
                        window.localStorage.setItem(s(e), Array.from(a).join(","))
                    }
                },
                h = n.z.object({
                    ignoreForm: n.z.boolean(),
                    savedToDB: n.z.boolean(),
                    data: n.z.object({
                        chatbotId: n.z.string(),
                        customerEmail: n.z.string().nullish(),
                        customerName: n.z.string().nullish(),
                        customerPhone: n.z.string().nullish(),
                        conversationId: n.z.string().nullish()
                    }).nullish()
                }).partial().nullish(),
                x = n.z.null().or(n.z.string().transform(e => JSON.parse(e)).catch(() => null).pipe(h)),
                f = e => {
                    {
                        let t = l(e);
                        return x.parse(window.localStorage.getItem(t))
                    }
                },
                p = (e, t) => {
                    {
                        let a = o(e);
                        window.localStorage.setItem(a, t)
                    }
                },
                g = e => {
                    {
                        let t = o(e),
                            a = window.localStorage.getItem(t);
                        if (a) return a;
                        let n = (0, r.D)();
                        return p(e, n), n
                    }
                },
                v = (e, t) => {
                    {
                        let a = h.safeParse(t);
                        if (a.success) {
                            let t = l(e),
                                r = f(e);
                            window.localStorage.setItem(t, JSON.stringify({ ...r,
                                ...a.data
                            }))
                        } else console.warn(a.error.issues)
                    }
                }
        },
        45729: function(e, t, a) {
            a.d(t, {
                Fv: function() {
                    return l
                },
                No: function() {
                    return n
                },
                PV: function() {
                    return d
                },
                d7: function() {
                    return c
                },
                dJ: function() {
                    return u
                },
                pC: function() {
                    return s
                },
                pH: function() {
                    return o
                },
                rJ: function() {
                    return i
                }
            });
            var r = a(43061);
            let n = async e => {
                    let {
                        conversationId: t,
                        chatbotId: a,
                        userId: n,
                        userHash: s
                    } = e, l = new URL("/api/chat/".concat(a, "/conversations/").concat(t), window.location.origin);
                    try {
                        let e = await fetch(l, {
                            headers: {
                                "user-id": n,
                                ...s ? {
                                    "user-hash": s
                                } : {}
                            }
                        });
                        if (!e.ok) return {
                            data: null,
                            error: Error("Failed to fetch conversation")
                        };
                        let t = await e.json(),
                            a = r.Yo.safeParse(t);
                        if (!a.success) return {
                            data: null,
                            error: a.error.flatten()
                        };
                        return {
                            data: a.data,
                            error: null
                        }
                    } catch (e) {
                        return {
                            data: null,
                            error: Error("Failed to fetch conversation")
                        }
                    }
                },
                s = async e => {
                    let {
                        userId: t,
                        userHash: a,
                        conversationIds: n,
                        chatbotId: s,
                        page: l,
                        limit: o
                    } = e, i = new URL("/api/chat/".concat(s, "/conversations/user/").concat(t, "?page=").concat(l, "&limit=").concat(o).concat((null == n ? void 0 : n.length) ? "&conversationIds=".concat(n.join(",")) : ""), window.location.origin);
                    try {
                        let e = await fetch(i, {
                            headers: { ...a ? {
                                    "user-hash": a
                                } : {}
                            }
                        });
                        if (!e.ok) return {
                            data: null,
                            error: Error("Failed to fetch conversation")
                        };
                        let t = await e.json(),
                            n = r.Tu.safeParse(t);
                        if (!n.success) return {
                            data: null,
                            error: n.error.flatten()
                        };
                        return {
                            data: n.data.data,
                            totalCount: n.data.count,
                            error: null
                        }
                    } catch (e) {
                        return {
                            data: null,
                            error: Error("Failed to fetch conversations")
                        }
                    }
                },
                l = async e => {
                    let {
                        messageId: t,
                        conversationId: a,
                        chatbotId: r,
                        feedback: n,
                        userId: s,
                        userHash: l
                    } = e, o = new URL("/api/chat/".concat(r, "/conversations/").concat(a, "/feedback"), window.location.origin);
                    try {
                        let e = await fetch(o, {
                            method: "POST",
                            headers: {
                                "user-id": s,
                                ...l ? {
                                    "user-hash": l
                                } : {}
                            },
                            body: JSON.stringify({
                                messageId: t,
                                feedback: n
                            })
                        });
                        if (!e.ok) return {
                            error: e.statusText
                        };
                        return {
                            error: null
                        }
                    } catch (e) {
                        return {
                            error: e
                        }
                    }
                },
                o = async e => {
                    let {
                        messageId: t,
                        conversationId: a,
                        chatbotId: r,
                        userId: n,
                        userHash: s
                    } = e, l = new URL("/api/chat/".concat(r, "/conversations/").concat(a, "/truncate"), window.location.origin);
                    try {
                        let e = await fetch(l, {
                            method: "POST",
                            headers: {
                                "user-id": n,
                                ...s ? {
                                    "user-hash": s
                                } : {}
                            },
                            body: JSON.stringify({
                                messageId: t
                            })
                        });
                        if (!e.ok) return {
                            error: e.statusText
                        };
                        return {
                            error: null
                        }
                    } catch (e) {
                        return {
                            error: e
                        }
                    }
                },
                i = async e => {
                    let {
                        toolResult: t,
                        toolCall: a,
                        conversationId: r,
                        chatbotId: n,
                        userId: s,
                        userHash: l
                    } = e, o = new URL("/api/chat/".concat(n, "/conversations/").concat(r, "/tool-result"), window.location.origin);
                    try {
                        let e = await fetch(o, {
                            method: "POST",
                            headers: {
                                "user-id": s,
                                ...l ? {
                                    "user-hash": l
                                } : {}
                            },
                            body: JSON.stringify({
                                toolResult: t,
                                toolCall: a
                            })
                        });
                        if (!e.ok) return {
                            error: e.statusText
                        };
                        return {
                            error: null
                        }
                    } catch (e) {
                        return {
                            error: e
                        }
                    }
                },
                d = async e => {
                    let {
                        message: t,
                        userId: a,
                        userHash: r,
                        conversationId: n,
                        chatbotId: s
                    } = e, l = new URL("/api/chat/".concat(s, "/conversations/").concat(n, "/livechat"), window.location.origin);
                    try {
                        let e = await fetch(l, {
                            method: "POST",
                            body: JSON.stringify({
                                message: t
                            }),
                            headers: {
                                "user-id": a,
                                ...r ? {
                                    "user-hash": r
                                } : {}
                            }
                        });
                        if (!e.ok) return {
                            error: e.statusText
                        };
                        return {
                            error: null
                        }
                    } catch (e) {
                        return {
                            error: e
                        }
                    }
                },
                c = async e => {
                    let {
                        collectedLeads: t,
                        conversationId: a,
                        chatbotId: r,
                        userId: n,
                        userHash: s
                    } = e, l = new URL("/api/fe/add-collected-customer-information", window.location.origin);
                    try {
                        let e = await fetch(l, {
                            method: "POST",
                            headers: {
                                "user-id": n,
                                ...s ? {
                                    "user-hash": s
                                } : {}
                            },
                            body: JSON.stringify({
                                conversationId: a,
                                chatbotId: r,
                                customerEmail: t.email,
                                customerName: t.name,
                                customerPhone: t.phone
                            })
                        });
                        if (!e.ok) return {
                            error: e.statusText
                        };
                        return {
                            error: null
                        }
                    } catch (e) {
                        return {
                            error: e
                        }
                    }
                },
                u = async e => {
                    let {
                        conversationId: t,
                        chatbotId: a,
                        userId: r,
                        userHash: n,
                        activityState: s
                    } = e, l = new URL("/api/chat/".concat(a, "/conversations/").concat(t, "/activity-state"), window.location.origin);
                    try {
                        let e = await fetch(l, {
                            method: "POST",
                            headers: {
                                "user-id": r,
                                ...n ? {
                                    "user-hash": n
                                } : {}
                            },
                            body: JSON.stringify({
                                activityState: s
                            })
                        });
                        if (!e.ok) return {
                            error: e.statusText
                        };
                        return {
                            error: null
                        }
                    } catch (e) {
                        return {
                            error: e
                        }
                    }
                }
        },
        39984: function(e, t, a) {
            a.d(t, {
                T2: function() {
                    return eg
                },
                xO: function() {
                    return ef
                },
                yH: function() {
                    return ex
                },
                uq: function() {
                    return eh
                }
            });
            var r = a(57437),
                n = a(34662),
                s = a(2265),
                l = a(67948);

            function o(e) {
                return e.children ? (0, r.jsx)(l.am, {
                    className: "border border-red-500 bg-red-50 text-red-500 text-sm group-data-[theme=dark]:bg-red-500/10 group-data-[theme=dark]:text-red-500",
                    children: e.children
                }) : null
            }
            var i = a(51945),
                d = a(2030),
                c = a(79820),
                u = a(43061),
                m = a(83535),
                h = a(12381),
                x = a(19163),
                f = a(32660);

            function p(e) {
                let {
                    slots: t,
                    onTimeSelect: a,
                    onDateReset: n
                } = e;
                return (0, r.jsxs)("div", {
                    className: "flex h-full flex-col gap-3",
                    children: [(0, r.jsxs)(h.z, {
                        onClick: n,
                        variant: "link",
                        className: "-mt-3 self-start p-0 text-zinc-800 group-data-[theme=dark]:text-zinc-400 hover:no-underline",
                        children: [(0, r.jsx)(f.Z, {
                            className: "mr-1 h-4 w-4"
                        }), " Back"]
                    }), (0, r.jsx)("div", {
                        className: "flex-1 overflow-y-auto",
                        children: (0, r.jsx)("div", {
                            className: "flex flex-col gap-3",
                            children: t.map(e => (0, r.jsx)(h.z, {
                                onClick: () => a(e),
                                variant: "outline",
                                className: "w-full rounded-md border-zinc-300 text-black group-data-[theme=dark]:border-zinc-700 group-data-[theme=dark]:hover:border-zinc-600 group-data-[theme=dark]:hover:bg-zinc-800 group-data-[theme=dark]:hover:text-white group-data-[theme=dark]:text-white",
                                children: (0, x.pc)(e)
                            }, e))
                        })
                    })]
                })
            }
            var g = a(13590),
                v = a(29501),
                b = a(31229),
                w = a(80670),
                j = a(40279),
                y = a(75060),
                N = a(23675),
                k = a(68245),
                z = a(32060);
            a(25566), b.z.object({
                status: b.z.string(),
                data: b.z.array(b.z.object({
                    id: b.z.number(),
                    slug: b.z.string(),
                    bookingFields: b.z.array(u.fo).transform(e => e.filter(e => !e.hidden)).transform(e => e.filter(e => "location" !== e.slug)).transform(e => e.filter(e => e.type !== u.UT.UNKNOWN))
                }))
            });
            let T = async (e, t, a, r, n, s) => {
                let l = {
                        method: "POST",
                        headers: {
                            "cal-api-version": "2024-08-13",
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            start: e,
                            eventTypeId: Number.parseInt(t, 10),
                            attendee: {
                                name: r,
                                email: a,
                                timeZone: n
                            },
                            bookingFieldsResponses: s
                        })
                    },
                    o = await fetch("https://api.cal.com/v2/bookings", l);
                if (!o.ok) {
                    var i;
                    let e = await o.json(),
                        t = (null == e ? void 0 : null === (i = e.error) || void 0 === i ? void 0 : i.code) === "BAD_REQUEST" ? "Please ensure all information is correct and try submitting your booking again." : "";
                    return console.log(t), {
                        status: "error",
                        error: t
                    }
                }
                return {
                    status: "success",
                    error: null
                }
            };

            function C(e) {
                let {
                    bookingField: t,
                    field: a
                } = e;
                return (0, r.jsx)(N.g, {
                    rows: 3,
                    value: a.value || "",
                    onChange: e => a.onChange(e.target.value),
                    placeholder: t.placeholder,
                    className: "text-zinc-800 focus:border-zinc-400 group-data-[theme=dark]:border-zinc-700 group-data-[theme=dark]:bg-black group-data-[theme=dark]:text-zinc-200 focus-visible:ring-0 group-data-[theme=dark]:focus-visible:ring-offset-0"
                })
            }

            function I(e) {
                let {
                    field: t,
                    bookingField: a
                } = e;
                return (0, r.jsx)(k.ZP, {
                    checked: t.value,
                    onChange: t.onChange,
                    className: "!accent-black -ml-2"
                })
            }

            function _(e) {
                var t;
                let {
                    field: a,
                    bookingField: n
                } = e;
                return (0, r.jsxs)(z.h_, {
                    children: [(0, r.jsx)(z.$F, {
                        asChild: !0,
                        className: "w-full",
                        children: (0, r.jsx)(h.z, {
                            variant: "outline",
                            className: "block w-full overflow-hidden text-ellipsis whitespace-nowrap rounded-md",
                            children: (Array.isArray(a.value) ? a.value.join(", ") : a.value) || n.placeholder || "Select an option"
                        })
                    }), (0, r.jsx)(z.AW, {
                        className: "max-h-48 w-56 overflow-y-auto",
                        align: "start",
                        children: null === (t = n.options) || void 0 === t ? void 0 : t.map(e => (0, r.jsx)(z.bO, {
                            checked: Array.isArray(a.value) ? a.value.includes(e) : a.value === e,
                            onCheckedChange: t => {
                                if (n.type === u.UT.MULTISELECT) {
                                    let r = t ? [...a.value || [], e] : a.value.filter(t => t !== e);
                                    a.onChange(r)
                                } else a.onChange(t ? e : "")
                            },
                            children: e
                        }, e))
                    })]
                })
            }

            function S(e) {
                let {
                    field: t,
                    bookingField: a
                } = e;
                return (0, r.jsx)(j.I, { ...t,
                    value: Array.isArray(t.value) ? t.value.join(", ") : "",
                    onChange: e => t.onChange(e.target.value ? e.target.value.split(",").map(e => e.trim()) : []),
                    placeholder: a.placeholder,
                    className: "text-zinc-800 focus:border-zinc-400 group-data-[theme=dark]:border-zinc-700 group-data-[theme=dark]:bg-black group-data-[theme=dark]:text-zinc-200 focus-visible:ring-0"
                })
            }

            function E(e) {
                var t;
                let {
                    bookingField: a,
                    field: n
                } = e, s = {
                    [u.UT.TEXTAREA]: C,
                    [u.UT.BOOLEAN]: I,
                    [u.UT.CHECKBOX]: a.options ? _ : I,
                    [u.UT.RADIO]: _,
                    [u.UT.SELECT]: _,
                    [u.UT.MULTISELECT]: _,
                    [u.UT.MULTIEMAIL]: S
                };
                return (0, r.jsxs)(w.xJ, {
                    children: [(0, r.jsxs)(y._, {
                        className: "text-zinc-800 group-data-[theme=dark]:text-zinc-200",
                        children: [a.label, a.required && (0, r.jsx)("span", {
                            className: "ml-0.5",
                            children: "*"
                        })]
                    }), (null !== (t = s[a.type]) && void 0 !== t ? t : function(e) {
                        let {
                            field: t,
                            bookingField: a
                        } = e;
                        return (0, r.jsx)(j.I, { ...t,
                            value: t.value,
                            onChange: e => t.onChange(a.type === u.UT.NUMBER ? Number(e.target.value) : e.target.value),
                            type: a.type,
                            placeholder: a.placeholder,
                            className: "text-zinc-800 focus:border-zinc-400 group-data-[theme=dark]:border-zinc-700 group-data-[theme=dark]:bg-black group-data-[theme=dark]:text-zinc-200 focus-visible:ring-0"
                        })
                    })({
                        field: n,
                        bookingField: a
                    }), (0, r.jsx)(w.zG, {})]
                })
            }

            function L(e) {
                let {
                    selectedTime: t,
                    onCancel: a,
                    timezone: n,
                    eventTypeId: s,
                    bookingFields: l,
                    onError: o,
                    onSuccess: i
                } = e, d = b.z.object(l.reduce((e, t) => {
                    let a;
                    switch (t.type) {
                        case u.UT.EMAIL:
                            a = b.z.string().email("Invalid email address");
                            break;
                        case u.UT.PHONE:
                            a = b.z.string().regex(/^\+[1-9]\d{1,14}$/, "Invalid phone number, please enter a valid phone number with country code");
                            break;
                        case u.UT.NUMBER:
                            a = b.z.number();
                            break;
                        case u.UT.BOOLEAN:
                            a = t.required ? b.z.literal(!0, {
                                errorMap: () => ({
                                    message: "This field is required"
                                })
                            }) : b.z.boolean();
                            break;
                        case u.UT.CHECKBOX:
                            a = t.options ? b.z.string() : t.required ? b.z.literal(!0, {
                                errorMap: () => ({
                                    message: "You must accept the terms & conditions"
                                })
                            }) : b.z.boolean();
                            break;
                        case u.UT.MULTIEMAIL:
                            a = b.z.array(b.z.string()).min(t.required ? 1 : 0, "This field is required").refine(e => e.every(e => b.z.string().email().safeParse(e).success), {
                                message: "Enter valid email addresses separated by commas",
                                path: []
                            });
                            break;
                        case u.UT.MULTISELECT:
                            a = b.z.array(b.z.string());
                            break;
                        default:
                            a = b.z.string()
                    }
                    return t.required ? (a instanceof b.z.ZodString || a instanceof b.z.ZodArray) && (a = a.min(1, "This field is required")) : a = a.optional(), e[t.slug] = a, e
                }, {})), c = (0, v.cI)({
                    resolver: (0, g.F)(d),
                    defaultValues: l.reduce((e, t) => {
                        switch (t.type) {
                            case u.UT.CHECKBOX:
                                e[t.slug] = !!t.options && "";
                                break;
                            case u.UT.BOOLEAN:
                                e[t.slug] = !1;
                                break;
                            case u.UT.MULTISELECT:
                            case u.UT.MULTIEMAIL:
                                e[t.slug] = [];
                                break;
                            default:
                                e[t.slug] = ""
                        }
                        return e
                    }, {})
                }), m = async e => {
                    let {
                        name: a,
                        email: r,
                        ...l
                    } = e, d = await T(new Date(t).toISOString(), s, r, a, n, l);
                    "success" === d.status ? await i() : o(d.error)
                };
                return (0, r.jsx)(w.l0, { ...c,
                    children: (0, r.jsxs)("form", {
                        onSubmit: c.handleSubmit(m),
                        className: "flex h-full flex-col gap-3",
                        children: [(0, r.jsxs)("div", {
                            className: "flex flex-1 flex-col gap-3 overflow-y-auto",
                            children: [(0, r.jsxs)("p", {
                                className: "font-medium text-zinc-800 group-data-[theme=dark]:text-zinc-200",
                                children: ["You are booking a slot at", " ", (0, x.pc)(t), " on", " ", (0, x.n4)(t)]
                            }), l.map(e => (0, r.jsx)(w.Wi, {
                                name: e.slug,
                                control: c.control,
                                render: t => {
                                    let {
                                        field: a
                                    } = t;
                                    return (0, r.jsx)(E, {
                                        bookingField: e,
                                        field: a
                                    })
                                }
                            }, e.slug))]
                        }), (0, r.jsxs)("div", {
                            className: "flex gap-3",
                            children: [(0, r.jsx)(h.z, {
                                type: "button",
                                onClick: a,
                                variant: "outline",
                                className: "flex-1 rounded-md border-zinc-300 text-black group-data-[theme=dark]:border-zinc-700 group-data-[theme=dark]:hover:border-zinc-600 group-data-[theme=dark]:hover:bg-zinc-800 group-data-[theme=dark]:hover:text-white group-data-[theme=dark]:text-white",
                                children: "Cancel"
                            }), (0, r.jsx)(h.z, {
                                type: "submit",
                                variant: "default",
                                className: "flex-1 group-data-[theme=dark]:bg-zinc-100 group-data-[theme=dark]:hover:bg-zinc-200 group-data-[theme=dark]:text-zinc-900",
                                disabled: c.formState.isSubmitting,
                                loading: c.formState.isSubmitting,
                                children: "Confirm"
                            })]
                        })]
                    })
                })
            }

            function D(e) {
                let {
                    success: t,
                    onRetry: a,
                    selectedTime: n,
                    errorText: s
                } = e;
                return t ? (0, r.jsx)("div", {
                    className: "w-72",
                    children: (0, r.jsxs)("p", {
                        className: "text-sm text-zinc-500 group-data-[theme=dark]:text-zinc-400",
                        children: ["Your appointment has been booked successfully on", " ", (0, x.n4)(n), " at", " ", (0, x.pc)(n)]
                    })
                }) : (0, r.jsxs)("div", {
                    className: "flex h-32 w-60 flex-col justify-between",
                    children: [(0, r.jsx)("div", {
                        className: "flex-1",
                        children: (0, r.jsx)("p", {
                            className: "text-center text-sm text-zinc-500 group-data-[theme=dark]:text-zinc-400",
                            children: s || (0, r.jsxs)(r.Fragment, {
                                children: ["Could not book the meeting. ", (0, r.jsx)("br", {}), "This time slot is now not available. Try another time slot."]
                            })
                        })
                    }), (0, r.jsx)(h.z, {
                        onClick: a,
                        children: "Try again"
                    })]
                })
            }
            var O = a(92451),
                R = a(10407),
                U = a(1441),
                A = a(81201);

            function P(e) {
                let {
                    className: t,
                    classNames: a,
                    showOutsideDays: n = !0,
                    ...s
                } = e;
                return (0, r.jsx)(U._W, {
                    showOutsideDays: n,
                    className: (0, A.cn)("p-3", t),
                    classNames: {
                        months: "flex flex-col sm:flex-row space-y-4 sm:space-x-4 sm:space-y-0",
                        month: "space-y-4",
                        caption: "flex justify-center pt-1 relative items-center",
                        caption_label: "text-sm font-medium",
                        nav: "space-x-1 flex items-center",
                        nav_button: (0, A.cn)((0, h.d)({
                            variant: "outline"
                        }), "h-7 w-7 bg-transparent p-0 opacity-50 hover:opacity-100"),
                        nav_button_previous: "absolute left-1",
                        nav_button_next: "absolute right-1",
                        table: "w-full border-collapse space-y-1",
                        head_row: "flex",
                        head_cell: "text-zinc-500 rounded-md w-9 font-normal text-[0.8rem] dark:text-zinc-400",
                        row: "flex w-full mt-2",
                        cell: "h-9 w-9 text-center text-sm p-0 relative [&:has([aria-selected].day-range-end)]:rounded-r-md [&:has([aria-selected].day-outside)]:bg-zinc-100/50 [&:has([aria-selected])]:bg-zinc-100 first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md focus-within:relative focus-within:z-20 dark:[&:has([aria-selected].day-outside)]:bg-zinc-800/50 dark:[&:has([aria-selected])]:bg-zinc-800",
                        day: (0, A.cn)((0, h.d)({
                            variant: "ghost"
                        }), "h-9 w-9 p-0 font-normal aria-selected:opacity-100"),
                        day_range_end: "day-range-end",
                        day_selected: "bg-zinc-900 text-zinc-50 hover:bg-zinc-900 hover:text-zinc-50 focus:bg-zinc-900 focus:text-zinc-50 dark:bg-zinc-50 dark:text-zinc-900 dark:hover:bg-zinc-50 dark:hover:text-zinc-900 dark:focus:bg-zinc-50 dark:focus:text-zinc-900",
                        day_today: "bg-zinc-100 text-zinc-900 dark:bg-zinc-800 dark:text-zinc-50",
                        day_outside: "day-outside text-zinc-500 opacity-50 aria-selected:bg-zinc-100/50 aria-selected:text-zinc-500 aria-selected:opacity-30 dark:text-zinc-400 dark:aria-selected:bg-zinc-800/50 dark:aria-selected:text-zinc-400",
                        day_disabled: "text-zinc-500 opacity-50 dark:text-zinc-400",
                        day_range_middle: "aria-selected:bg-zinc-100 aria-selected:text-zinc-900 dark:aria-selected:bg-zinc-800 dark:aria-selected:text-zinc-50",
                        day_hidden: "invisible",
                        ...a
                    },
                    components: {
                        IconLeft: e => {
                            let { ...t
                            } = e;
                            return (0, r.jsx)(O.Z, {
                                className: "h-4 w-4"
                            })
                        },
                        IconRight: e => {
                            let { ...t
                            } = e;
                            return (0, r.jsx)(R.Z, {
                                className: "h-4 w-4"
                            })
                        }
                    },
                    ...s
                })
            }
            P.displayName = "Calendar";
            var M = a(16357);

            function F(e) {
                let {
                    dates: t,
                    onSelect: a
                } = e;
                return (0, r.jsx)(P, {
                    mode: "single",
                    fromMonth: t[0],
                    toMonth: t[t.length - 1],
                    onSelect: e => {
                        e && a((0, x.ie)(e))
                    },
                    disabled: e => !t.some(t => (0, M.K)(t, e)),
                    classNames: {
                        months: "text-black group-data-[theme=dark]:text-white",
                        day_today: "",
                        day_disabled: "disabled:!opacity-50 group-data-[theme=dark]:disabled:!opacity-80",
                        nav_button_previous: "absolute left-1 disabled:!opacity-0",
                        nav_button_next: "absolute right-1 disabled:!opacity-0",
                        head_cell: "text-black rounded-md w-9 font-normal text-[0.8rem] group-data-[theme=dark]:text-white"
                    },
                    showOutsideDays: !1
                })
            }

            function Z(e) {
                let {
                    message: t,
                    variant: a
                } = e;
                return (0, r.jsx)(c.Zb, {
                    className: (0, A.cn)("rounded-lg group-data-[theme=dark]:bg-black", "error" === a ? "border-red-500 group-data-[theme=dark]:border-red-800" : "border-zinc-300 group-data-[theme=dark]:border-zinc-700"),
                    children: (0, r.jsx)(c.aY, {
                        className: (0, A.cn)("p-3 text-sm", "error" === a ? "text-red-500 group-data-[theme=dark]:text-red-300" : "text-zinc-500 group-data-[theme=dark]:text-zinc-400"),
                        children: t
                    })
                })
            }

            function Y(e) {
                var t;
                let {
                    result: a,
                    messageId: l,
                    toolCallId: o
                } = e;
                if ("error" === a.status) return (0, r.jsx)(Z, {
                    message: "Something went wrong. Please try again.",
                    variant: "error"
                });
                if (!a.data || 0 === Object.keys(a.data.slots).length) return (0, r.jsx)(Z, {
                    message: "No slots found.",
                    variant: "info"
                });
                let i = (0, m.m)(),
                    [d, h] = (0, s.useState)(""),
                    [x, f] = (0, s.useState)(null !== (t = a.data.appointmentBookingDate) && void 0 !== t ? t : ""),
                    [g, v] = (0, s.useState)(a.data.appointmentBookingDate ? "success" : null),
                    [b, w] = (0, s.useState)(null),
                    {
                        slots: j,
                        dates: y
                    } = (0, s.useMemo)(() => {
                        let e = Object.entries(a.data.slots).reduce((e, t) => {
                            let [a, r] = t, n = r.filter(e => new Date(e) >= new Date);
                            return n.length > 0 && (e[a] = n), e
                        }, {});
                        return {
                            slots: e,
                            dates: Object.keys(e).filter(e => new Date("".concat(e, "T23:59:59")) >= new Date).map(e => new Date("".concat(e, "T00:00:00")))
                        }
                    }, [a.data.slots]),
                    N = (0, s.useCallback)(async () => {
                        v("success");
                        let e = {
                            status: "success",
                            data: {
                                slots: j,
                                appointmentBookingDate: x,
                                timezone: a.data.timezone,
                                eventTypeId: a.data.eventTypeId,
                                bookingFields: a.data.bookingFields
                            }
                        };
                        (null == i ? void 0 : i.saveToolResult) && (null == i || i.saveToolResult({
                            toolResult: {
                                id: l,
                                role: u.WU.TOOL,
                                actionType: n.ww.CALCOM_GET_SLOTS,
                                content: [{
                                    type: "tool-result",
                                    toolName: "CalCom_Get_Slots",
                                    toolCallId: o,
                                    result: e
                                }]
                            }
                        }))
                    }, [i, l, a, x, j, o]);
                return (0, r.jsx)(c.Zb, {
                    className: "max-w-[350px] rounded-lg border-zinc-300 group-data-[theme=dark]:border-zinc-700 group-data-[theme=dark]:bg-black",
                    children: (0, r.jsx)(c.aY, {
                        className: "p-3 text-sm text-zinc-500 group-data-[theme=dark]:text-zinc-400",
                        children: g ? (0, r.jsx)(D, {
                            success: "success" === g,
                            onRetry: () => {
                                v(null), f(""), h("")
                            },
                            selectedTime: x,
                            errorText: b
                        }) : d ? (0, r.jsx)("div", {
                            className: "p-3",
                            children: (0, r.jsx)("div", {
                                className: "h-[282px] w-[252px]",
                                children: (0, r.jsx)("div", {
                                    className: "flex h-full flex-col gap-3",
                                    children: x ? (0, r.jsx)(L, {
                                        selectedTime: x,
                                        timezone: a.data.timezone,
                                        eventTypeId: a.data.eventTypeId,
                                        bookingFields: a.data.bookingFields,
                                        onCancel: () => f(""),
                                        onError: e => {
                                            v("error"), w(e)
                                        },
                                        onSuccess: N
                                    }) : (0, r.jsx)(p, {
                                        slots: j[d],
                                        onTimeSelect: f,
                                        onDateReset: () => h("")
                                    })
                                })
                            })
                        }) : (0, r.jsx)(F, {
                            dates: y,
                            onSelect: h
                        })
                    })
                })
            }

            function B(e) {
                let {
                    selectedTime: t
                } = e;
                return (0, r.jsx)("div", {
                    className: "flex flex-col gap-3",
                    children: (0, r.jsxs)("p", {
                        className: "font-medium text-zinc-600 group-data-[theme=dark]:text-zinc-400",
                        children: ["You attempted to book a slot at", " ", (0, x.pc)(t), " on", " ", (0, x.n4)(t), "."]
                    })
                })
            }

            function J(e) {
                var t, a, l;
                let {
                    result: o,
                    messageId: i,
                    toolCallId: d
                } = e;
                if ("error" === o.status) return (0, r.jsx)(Z, {
                    message: "Something went wrong. Please try again.",
                    variant: "error"
                });
                if (!o.data || 0 === Object.keys(o.data.slots).length) return (0, r.jsx)(Z, {
                    message: "No slots found.",
                    variant: "info"
                });
                let h = (0, m.m)(),
                    [x, f] = (0, s.useState)(""),
                    [g, v] = (0, s.useState)(null !== (l = null === (t = o.data) || void 0 === t ? void 0 : t.appointmentBookingDate) && void 0 !== l ? l : ""),
                    {
                        slots: b,
                        dates: w
                    } = (0, s.useMemo)(() => {
                        var e, t;
                        let a = Object.entries(null !== (t = null == o ? void 0 : null === (e = o.data) || void 0 === e ? void 0 : e.slots) && void 0 !== t ? t : {}).reduce((e, t) => {
                            let [a, r] = t, n = r.filter(e => new Date(e.startTime) >= new Date);
                            return n.length > 0 && (e[a] = n), e
                        }, {});
                        return {
                            slots: a,
                            dates: Object.keys(a).filter(e => new Date("".concat(e, "T23:59:59")) >= new Date).map(e => new Date("".concat(e, "T00:00:00")))
                        }
                    }, [null === (a = o.data) || void 0 === a ? void 0 : a.slots]),
                    j = (0, s.useCallback)(e => {
                        var t, a, r, s;
                        let l = { ...o,
                            data: {
                                slots: b,
                                appointmentBookingDate: e,
                                timezone: null !== (r = null === (t = o.data) || void 0 === t ? void 0 : t.timezone) && void 0 !== r ? r : "",
                                eventTypeURI: null !== (s = null === (a = o.data) || void 0 === a ? void 0 : a.eventTypeURI) && void 0 !== s ? s : ""
                            }
                        };
                        (null == h ? void 0 : h.saveToolResult) && (null == h || h.saveToolResult({
                            toolResult: {
                                id: i,
                                role: u.WU.TOOL,
                                actionType: n.ww.CALENDLY_GET_SLOTS,
                                content: [{
                                    type: "tool-result",
                                    toolName: "Calendly_Get_Slots",
                                    toolCallId: d,
                                    result: l
                                }]
                            }
                        }))
                    }, [h, i, o, b, d]);
                return (0, r.jsx)(c.Zb, {
                    className: "max-w-[350px] rounded-lg border-zinc-300 group-data-[theme=dark]:border-zinc-700 group-data-[theme=dark]:bg-black",
                    children: (0, r.jsx)(c.aY, {
                        className: "p-3 text-sm text-zinc-500 group-data-[theme=dark]:text-zinc-400",
                        children: g ? (0, r.jsx)("div", {
                            className: "w-[252px]",
                            children: (0, r.jsx)(B, {
                                selectedTime: g
                            })
                        }) : x ? (0, r.jsx)("div", {
                            className: "p-3",
                            children: (0, r.jsx)("div", {
                                className: "h-[282px] w-[252px]",
                                children: (0, r.jsx)("div", {
                                    className: "flex h-full flex-col gap-3",
                                    children: (0, r.jsx)(p, {
                                        slots: b[x].map(e => e.startTime),
                                        onTimeSelect: e => {
                                            var t;
                                            window.open(null === (t = b[x].find(t => t.startTime === e)) || void 0 === t ? void 0 : t.schedulingUrl, "_blank"), j(e), v(e)
                                        },
                                        onDateReset: () => f("")
                                    })
                                })
                            })
                        }) : (0, r.jsx)(F, {
                            dates: w,
                            onSelect: f
                        })
                    })
                })
            }
            var q = a(82137);
            let H = e => {
                let {
                    url: t,
                    buttonText: a
                } = e;
                return (0, r.jsxs)(l.am, {
                    className: "w-full max-w-[min(100%,320px)] p-4",
                    children: [(0, r.jsx)("a", {
                        target: "_blank",
                        rel: "noreferrer",
                        className: (0, A.cn)((0, h.d)({
                            variant: "default"
                        }), "w-full group-data-[theme=dark]:hidden"),
                        href: t,
                        children: a
                    }), (0, r.jsx)("a", {
                        target: "_blank",
                        rel: "noreferrer",
                        className: (0, A.cn)((0, h.d)({
                            variant: "secondary"
                        }), "hidden w-full group-data-[theme=dark]:inline-flex"),
                        href: t,
                        children: a
                    })]
                })
            };
            var V = a(10064),
                G = a(12465),
                K = a(25109),
                W = a(40753),
                X = a(91668),
                $ = a(71488),
                Q = a(92438),
                ee = a(31047),
                et = a(33245),
                ea = a(22135),
                er = a(88318),
                en = a(42746);

            function es(e) {
                var t, a;
                let {
                    subscription: n
                } = e, [l, o] = (0, s.useState)(!0);
                if ("error" === n.status) return (0, r.jsx)(el, {});
                let i = (0, s.useCallback)(e => {
                        let {
                            text: t,
                            icon: a
                        } = e;
                        return (0, r.jsxs)("div", {
                            className: "flex items-center gap-1",
                            children: [a || null, (0, r.jsx)("p", {
                                children: t
                            })]
                        })
                    }, []),
                    d = (0, s.useMemo)(() => {
                        var e, t, a, s, l, o, d, c, u, m, h, x, f, p, g, v;
                        let b = {
                                badgeStyle: "bg-red-50 group-data-[theme=dark]:bg-red-950 border-red-400 data-[theme=dark]:border-red-800 text-red-700 group-data-[theme=dark]:text-red-300"
                            },
                            w = {
                                badgeStyle: "bg-green-50 group-data-[theme=dark]:bg-green-950 border-green-400 data-[theme=dark]:border-green-800 text-green-700 group-data-[theme=dark]:text-green-300"
                            },
                            j = {
                                cardSecondaryText: (null === (e = n.data) || void 0 === e ? void 0 : e.defaultPayment) ? null === (t = n.data) || void 0 === t ? void 0 : t.defaultPayment : (0, r.jsxs)("div", {
                                    className: "flex items-center gap-1 text-red-700",
                                    children: [(0, r.jsx)(Q.Z, {
                                        className: "h-4 w-4"
                                    }), (0, r.jsx)("p", {
                                        children: "Unavailable"
                                    })]
                                })
                            };
                        switch (null === (a = n.data) || void 0 === a ? void 0 : a.status) {
                            case W.T.ACTIVE:
                                {
                                    let e = new Date((null === (s = n.data) || void 0 === s ? void 0 : s.currentPeriodStart) * 1e3),
                                        t = new Date((null === (l = n.data) || void 0 === l ? void 0 : l.currentPeriodEnd) * 1e3);
                                    return { ...j,
                                        badge: {
                                            text: "ACTIVE",
                                            ...w
                                        },
                                        cardMainText: i({
                                            text: "".concat(e.toLocaleDateString(), " - ").concat(t.toLocaleDateString()),
                                            icon: (0, r.jsx)(ee.Z, {
                                                className: "h-4 w-4"
                                            })
                                        }),
                                        infoText: "".concat(null === (o = n.data) || void 0 === o ? void 0 : o.id, " is active")
                                    }
                                }
                            case W.T.CANCELED:
                                {
                                    let e = new Date(null !== (u = null === (d = n.data) || void 0 === d ? void 0 : d.canceledAt) && void 0 !== u ? u : 0);
                                    return { ...j,
                                        badge: {
                                            text: "CANCELED",
                                            ...b
                                        },
                                        cardMainText: i({
                                            text: e.toLocaleDateString(),
                                            icon: void 0
                                        }),
                                        infoText: "".concat(null === (c = n.data) || void 0 === c ? void 0 : c.id, " is canceled")
                                    }
                                }
                            case W.T.TRIALING:
                                {
                                    let e = new Date(null !== (x = null === (m = n.data) || void 0 === m ? void 0 : m.trialPeriodEnd) && void 0 !== x ? x : 0);
                                    return { ...j,
                                        badge: {
                                            text: "TRIALING",
                                            ...w
                                        },
                                        cardMainText: i({
                                            text: e.toLocaleDateString(),
                                            icon: void 0
                                        }),
                                        infoText: "you are in a trial period for ".concat(null === (h = n.data) || void 0 === h ? void 0 : h.id)
                                    }
                                }
                            case W.T.PAST_DUE:
                                return { ...j,
                                    badge: {
                                        text: "PAST DUE",
                                        ...b
                                    },
                                    cardMainText: i({
                                        text: "Payment Failed",
                                        icon: void 0
                                    }),
                                    infoText: "".concat(null === (f = n.data) || void 0 === f ? void 0 : f.id, " is past due")
                                };
                            case W.T.INCOMPLETE:
                                return { ...j,
                                    badge: {
                                        text: "INCOMPLETE",
                                        badgeStyle: "bg-amber-50 group-data-[theme=dark]:bg-amber-900/85 border-green-400 group-data-[theme=dark]:border-amber-600 text-amber-700 group-data-[theme=dark]:text-amber-300"
                                    },
                                    cardMainText: i({
                                        text: "Initial payment attempt failed",
                                        icon: void 0
                                    }),
                                    infoText: "No payment was made for ".concat(null === (p = n.data) || void 0 === p ? void 0 : p.id)
                                };
                            case W.T.INCOMPLETE_EXPIRED:
                                return { ...j,
                                    badge: {
                                        text: "EXPIRED",
                                        ...b
                                    },
                                    cardMainText: i({
                                        text: "Initial payment attempt failed",
                                        icon: void 0
                                    }),
                                    infoText: "No payment was made for ".concat(null === (g = n.data) || void 0 === g ? void 0 : g.id)
                                };
                            case W.T.UNPAID:
                                return { ...j,
                                    badge: {
                                        text: "UNPAID",
                                        ...b
                                    },
                                    cardMainText: i({
                                        text: "Payment failed",
                                        icon: void 0
                                    }),
                                    infoText: "".concat(null === (v = n.data) || void 0 === v ? void 0 : v.id, " is unpaid")
                                };
                            default:
                                return
                        }
                    }, []);
                if (!d) return null;
                let c = (0, s.useMemo)(() => {
                        var e, t;
                        let a = null !== (t = null === (e = n.data) || void 0 === e ? void 0 : e.items.reduce((e, t) => {
                                var a, r;
                                return e + (null !== (a = t.unit_amount) && void 0 !== a ? a : 0) * (null !== (r = t.quantity) && void 0 !== r ? r : 0) / 100
                            }, 0)) && void 0 !== t ? t : 0,
                            r = (0, en.x6)(Number.parseFloat(a.toFixed(2))).split("."),
                            s = r[1] ? r[1].padEnd(2, "0") : "00";
                        return "".concat(r[0], ".").concat(s)
                    }, [null === (t = n.data) || void 0 === t ? void 0 : t.items]),
                    u = (0, s.useCallback)(() => {
                        var e;
                        return l ? null : (0, r.jsx)("div", {
                            className: "flex h-auto w-full flex-col rounded-2xl bg-white group-data-[theme=dark]:bg-black",
                            children: (0, r.jsx)("div", {
                                className: "mt-4 flex flex-col gap-3 pb-4 text-zinc-950 group-data-[theme=dark]:text-zinc-50",
                                children: null === (e = n.data) || void 0 === e ? void 0 : e.items.map(e => (0, r.jsxs)("div", {
                                    className: "mr-4 ml-4 flex justify-between",
                                    children: [(0, r.jsx)("p", {
                                        className: "overflow-hidden text-ellipsis text-nowrap pr-1",
                                        children: e.name
                                    }), (0, r.jsxs)("p", {
                                        children: ["x", e.quantity]
                                    })]
                                }, e.name))
                            })
                        })
                    }, [l]);
                return (0, r.jsxs)("div", {
                    className: "flex w-full flex-col items-center rounded-2xl bg-zinc-100 group-data-[theme=dark]:bg-zinc-900",
                    children: [(0, r.jsxs)("div", {
                        className: "mt-1 flex w-full flex-col gap-1 pr-1 pl-1",
                        children: [(0, r.jsx)("div", {
                            className: "h-[161px] w-full rounded-2xl bg-white group-data-[theme=dark]:bg-black",
                            children: (0, r.jsxs)("div", {
                                className: "m-4 flex flex-col gap-4",
                                children: [(0, r.jsxs)("div", {
                                    className: "flex items-center justify-between",
                                    children: [(0, r.jsx)("div", {
                                        className: (0, A.cn)("flex h-[20px] items-center justify-center rounded-full border p-2 font-bold text-[10px]", d.badge.badgeStyle),
                                        children: d.badge.text
                                    }), (0, r.jsx)(X.pn, {
                                        children: (0, r.jsxs)($.u, {
                                            children: [(0, r.jsx)($.aJ, {
                                                children: (0, r.jsx)("div", {
                                                    className: "hover:cursor-pointer",
                                                    children: (0, r.jsx)(et.Z, {
                                                        className: "h-4 w-4 text-zinc-500"
                                                    })
                                                })
                                            }), (0, r.jsx)($._v, {
                                                children: d.cardMainText
                                            })]
                                        })
                                    })]
                                }), (0, r.jsxs)("div", {
                                    children: [(0, r.jsxs)("p", {
                                        className: "font-semibold text-[16px] text-zinc-950 group-data-[theme=dark]:text-zinc-50",
                                        children: [c, " ", null === (a = n.data) || void 0 === a ? void 0 : a.currency.toUpperCase()]
                                    }), (0, r.jsx)("div", {
                                        className: "flex flex-col gap-1 text-sm text-zinc-600 group-data-[theme=dark]:text-zinc-400",
                                        children: d.cardMainText
                                    })]
                                }), (0, r.jsx)("hr", {
                                    className: "border-zinc-300 border-t-[2px] border-dotted group-data-[theme=dark]:border-zinc-800"
                                }), (0, r.jsxs)("div", {
                                    className: "flex justify-between text-sm text-zinc-600 group-data-[theme=dark]:text-zinc-400",
                                    children: [(0, r.jsx)("p", {
                                        children: "Payment Details:"
                                    }), d.cardSecondaryText]
                                })]
                            })
                        }), (0, r.jsx)(u, {})]
                    }), (0, r.jsxs)(h.z, {
                        onClick: () => o(!l),
                        className: "flex flex-auto items-center justify-center border-none bg-transparent font-medium text-purple-500 text-sm shadow-none hover:bg-transparent",
                        children: [l ? (0, r.jsx)("p", {
                            children: "View Items"
                        }) : (0, r.jsx)("p", {
                            children: "Close"
                        }), (0, r.jsx)("span", {
                            children: l ? (0, r.jsx)(R.Z, {
                                className: "h-4 w-4"
                            }) : (0, r.jsx)(ea.Z, {
                                className: "h-4 w-4"
                            })
                        })]
                    })]
                })
            }

            function el() {
                return (0, r.jsx)("div", {
                    className: "flex min-h-[137px] w-[308px] flex-col items-center rounded-2xl bg-zinc-100 group-data-[theme=dark]:bg-zinc-900",
                    children: (0, r.jsx)("div", {
                        className: "mt-1 flex w-[300px] flex-col gap-1",
                        children: (0, r.jsx)("div", {
                            className: "h-[129px] w-full rounded-2xl bg-white group-data-[theme=dark]:bg-black",
                            children: (0, r.jsxs)("div", {
                                className: "m-4 flex flex-col gap-4",
                                children: [(0, r.jsx)("div", {
                                    className: "flex items-center justify-between",
                                    children: (0, r.jsx)(er.Z, {
                                        className: "h-6 w-6 text-zinc-500"
                                    })
                                }), (0, r.jsxs)("div", {
                                    children: [(0, r.jsx)("p", {
                                        className: "font-semibold text-sm group-data-[theme=dark]:text-zinc-50",
                                        children: "No subscriptions"
                                    }), (0, r.jsx)("p", {
                                        className: "font-normal text-xs text-zinc-600",
                                        children: "We couldn't find any active subscriptions associated with your account."
                                    })]
                                })]
                            })
                        })
                    })
                })
            }
            var eo = a(69174),
                ei = a(27399),
                ed = a(27648);
            let ec = {
                paid: "bg-green-50 border border-green-400 text-green-700 group-data-[theme=dark]:bg-[#052E16] group-data-[theme=dark]:text-green-300 group-data-[theme=dark]:border-green-800",
                open: "bg-red-50 border border-red-400 text-red-700 group-data-[theme=dark]:bg-[#2E050F] group-data-[theme=dark]:text-red-300 group-data-[theme=dark]:border-red-800",
                uncollectible: "bg-red-50 border border-red-400 text-red-700 group-data-[theme=dark]:bg-red-900 group-data-[theme=dark]:text-red-300 group-data-[theme=dark]:border-red-800",
                void: "bg-gray-50 border border-gray-400 text-gray-700 group-data-[theme=dark]:bg-gray-900 group-data-[theme=dark]:text-gray-300 group-data-[theme=dark]:border-gray-800",
                draft: "bg-yellow-50 border border-yellow-400 text-yellow-700 group-data-[theme=dark]:bg-yellow-900 group-data-[theme=dark]:text-yellow-300 group-data-[theme=dark]:border-yellow-800"
            };

            function eu(e) {
                let {
                    result: t
                } = e;
                return "error" === t.status ? (0, r.jsx)(c.Zb, {
                    className: "w-full border-red-500 group-data-[theme=dark]:border-red-800",
                    children: (0, r.jsx)(c.aY, {
                        className: "p-3 text-red-500 text-sm group-data-[theme=dark]:text-red-300",
                        children: t.error
                    })
                }) : t.data && 0 !== t.data.invoices.length ? (0, r.jsx)("div", {
                    className: "flex w-full flex-col gap-2 overflow-y-auto",
                    children: t.data.invoices.map(e => (0, r.jsxs)("div", {
                        className: "rounded-[20px] bg-zinc-100 p-1 group-data-[theme=dark]:bg-zinc-800/80",
                        children: [(0, r.jsxs)("div", {
                            className: "rounded-2xl bg-white p-4 group-data-[theme=dark]:bg-zinc-900",
                            children: [(0, r.jsxs)("div", {
                                className: "mb-4 flex items-center justify-between",
                                children: [(0, r.jsx)(eo.Ct, {
                                    variant: "outline",
                                    className: (0, A.cn)("rounded-full px-3 py-1 text-xs", ec[e.status]),
                                    children: e.status && ("open" === e.status ? "UNPAID" : e.status.toUpperCase())
                                }), (0, r.jsx)(ei.Z, {
                                    content: e.id,
                                    children: (0, r.jsx)(et.Z, {
                                        className: "h-4 w-4 text-zinc-400 group-data-[theme=dark]:text-zinc-500"
                                    })
                                })]
                            }), (0, r.jsxs)("div", {
                                className: "flex flex-col gap-1",
                                children: [(0, r.jsxs)("span", {
                                    className: "font-medium text-zinc-800 group-data-[theme=dark]:text-zinc-200",
                                    children: [(e.amount_due / 100).toFixed(2), " ", e.currency.toUpperCase()]
                                }), (0, r.jsxs)("div", {
                                    className: "flex items-center text-sm text-zinc-500 group-data-[theme=dark]:text-zinc-400",
                                    children: [(0, r.jsx)(ee.Z, {
                                        className: "mr-1 h-3 w-3"
                                    }), new Date(1e3 * e.created).toLocaleDateString()]
                                })]
                            })]
                        }), e.hosted_invoice_url && (0, r.jsxs)(ed.default, {
                            href: e.hosted_invoice_url,
                            target: "_blank",
                            rel: "noopener noreferrer",
                            className: (0, A.cn)("w-full py-2 group-data-[theme=dark]:hover:bg-transparent", (0, h.d)({
                                variant: "ghost"
                            })),
                            children: [(0, r.jsx)("span", {
                                className: "font-medium text-sm text-zinc-800 group-data-[theme=dark]:text-zinc-200",
                                children: "open" === e.status ? "Pay Now" : "View Invoice"
                            }), (0, r.jsx)(R.Z, {
                                className: "ml-1 h-4 w-4 text-zinc-800 group-data-[theme=dark]:text-zinc-200"
                            })]
                        })]
                    }, e.id))
                }) : (0, r.jsx)(c.Zb, {
                    className: "w-full border-zinc-300 group-data-[theme=dark]:border-zinc-700",
                    children: (0, r.jsx)(c.aY, {
                        className: "p-3 text-sm text-zinc-500 group-data-[theme=dark]:text-zinc-400",
                        children: "No invoices found."
                    })
                })
            }

            function em(e) {
                var t, a, n, s;
                let {
                    result: l
                } = e;
                return "error" === l.status ? null : (0, r.jsxs)("div", {
                    className: "w-full max-w-lg",
                    children: [(0, r.jsx)("div", {
                        className: "rounded-t-lg border border-gray-200 border-b-0 bg-zinc-50 px-4 py-3",
                        children: (0, r.jsx)("h2", {
                            className: "font-inter font-normal text-xs text-zinc-600 leading-[14.52px] tracking-[-0.02em]",
                            children: null === (a = l.data) || void 0 === a ? void 0 : null === (t = a.ticket) || void 0 === t ? void 0 : t.subject
                        })
                    }), (0, r.jsx)("div", {
                        className: "rounded-b-lg border border-gray-200 border-t-0 bg-white p-4",
                        children: (0, r.jsx)("div", {
                            className: "whitespace-pre-wrap font-inter font-normal text-sm text-zinc-900 leading-5 tracking-[-0.02em]",
                            children: null === (s = l.data) || void 0 === s ? void 0 : null === (n = s.ticket) || void 0 === n ? void 0 : n.description
                        })
                    })]
                })
            }

            function eh(e) {
                return e.reduce((e, t) => {
                    if (0 === e.length) e.push([t]);
                    else {
                        let a = e[e.length - 1],
                            r = a[a.length - 1],
                            {
                                textMessage: n,
                                toolResultsMessages: s
                            } = function(e) {
                                let t;
                                let a = [];
                                if (e.toolInvocations)
                                    for (let t of e.toolInvocations) {
                                        let r = structuredClone(e);
                                        r.id = t.toolCallId, r.content = "", r.toolInvocations = [t], a.push(r)
                                    }
                                return e.content && ((t = structuredClone(e)).toolInvocations = void 0), {
                                    toolResultsMessages: a,
                                    textMessage: t
                                }
                            }(t);
                        if ("assistant" === t.role && (r.toolInvocations || "assistant" === r.role)) {
                            if ("assistant" === t.role) {
                                let e = a.findLastIndex(e => e.content);
                                n && a.splice(e + 1, 0, n), a.push(...s)
                            } else a.push(t)
                        } else "user" === t.role && "user" === r.role ? a.push(t) : n ? e.push([n, ...s]) : s.length > 0 && e.push(s)
                    }
                    return e
                }, [])
            }

            function ex(e) {
                return e.reduce((e, t) => {
                    if (0 === e.length) return e.push([t]), e;
                    let a = e[e.length - 1],
                        r = a[a.length - 1];
                    return t.role === r.role ? a.push(t) : e.push([t]), e
                }, [])
            }
            let ef = s.memo(e => {
                    let t = e.message;
                    switch (t.role) {
                        case "data":
                        case "system":
                            return null;
                        case "user":
                            if (t.content) return (0, r.jsx)("div", {
                                className: "relative flex w-full flex-col items-end gap-2",
                                children: (0, r.jsx)(l.cA, {
                                    chatbotStyles: e.chatbotStyles,
                                    children: t.content.trim()
                                })
                            });
                            break;
                        case "assistant":
                            var a, n;
                            return (0, r.jsxs)(r.Fragment, {
                                children: [t.content && (0, r.jsx)(d.r, {
                                    shouldAnimate: e.shouldAnimate,
                                    children: (0, r.jsx)(l.am, {
                                        children: (0, r.jsx)(i.V, {
                                            shouldAnimate: e.shouldAnimate,
                                            children: t.content
                                        })
                                    })
                                }), null === (a = t.toolInvocations) || void 0 === a ? void 0 : a.filter(e => "result" === e.state).map(a => (0, r.jsx)(ep, {
                                    messageId: t.id,
                                    toolCallId: a.toolCallId,
                                    toolName: a.toolName,
                                    result: a.result,
                                    chatbotActions: e.chatbotActions
                                }, a.toolCallId)), null === (n = t.toolInvocations) || void 0 === n ? void 0 : n.filter(e => "result" === e.state).filter(t => "Sunshine_Live_Chat" === t.toolName && e.showToolCalls).map(t => (0, r.jsx)(ev, {
                                    toolName: t.toolName,
                                    chatbotActions: e.chatbotActions
                                }, t.toolCallId))]
                            })
                    }
                }),
                ep = e => {
                    var t;
                    let a = null === (t = e.chatbotActions) || void 0 === t ? void 0 : t.find(t => t.name === e.toolName);
                    if (!a) return null;
                    switch (a.type) {
                        case n.ww.CUSTOM_BUTTON:
                            return (0, r.jsx)(H, {
                                url: e.result.data.url,
                                buttonText: e.result.data.buttonText
                            });
                        case n.ww.COLLECT_LEADS:
                            return (0, r.jsx)(q.U, {
                                messageId: e.messageId,
                                toolCallId: e.toolCallId,
                                result: e.result
                            });
                        case n.ww.SHOPIFY_SHOW_PRODUCT:
                            if ("error" !== e.result.status) return (0, r.jsx)(K.o, {
                                result: e.result
                            });
                            break;
                        case n.ww.SHOPIFY_SHOW_ORDER:
                            if ("error" !== e.result.status) return (0, r.jsx)(G.A, {
                                result: e.result
                            });
                            break;
                        case n.ww.STRIPE_GET_SUBSCRIPTION:
                            return (0, r.jsx)(es, {
                                subscription: e.result
                            });
                        case n.ww.STRIPE_GET_INVOICES:
                            return (0, r.jsx)(eu, {
                                result: e.result
                            });
                        case n.ww.CALENDLY_GET_SLOTS:
                            return (0, r.jsx)(J, {
                                result: e.result,
                                messageId: e.messageId,
                                toolCallId: e.toolCallId
                            });
                        case n.ww.CALCOM_GET_SLOTS:
                            return (0, r.jsx)(Y, {
                                result: e.result,
                                messageId: e.messageId,
                                toolCallId: e.toolCallId
                            });
                        case n.ww.ZENDESK_CREATE_TICKET:
                            if ("error" !== e.result.status) return (0, r.jsx)(em, {
                                result: e.result
                            })
                    }
                },
                eg = e => {
                    let {
                        error: t
                    } = e;
                    try {
                        var a;
                        let e = JSON.parse(t.message);
                        return (0, r.jsx)(o, {
                            children: null !== (a = e.text) && void 0 !== a ? a : e.message
                        })
                    } catch (e) {
                        return (0, r.jsx)(o, {
                            children: "An error has occurred. Please try again."
                        })
                    }
                },
                ev = e => {
                    var t;
                    let a = null === (t = e.chatbotActions) || void 0 === t ? void 0 : t.find(t => t.name === e.toolName);
                    return a ? (0, r.jsx)(V.Ri, {
                        actionType: a.type,
                        toolName: e.toolName
                    }) : null
                }
        },
        83535: function(e, t, a) {
            a.d(t, {
                m: function() {
                    return s
                },
                p: function() {
                    return n
                }
            });
            var r = a(2265);
            let n = (0, r.createContext)(null);

            function s() {
                return (0, r.useContext)(n)
            }
        },
        47325: function(e, t, a) {
            a.d(t, {
                C: function() {
                    return i
                }
            });
            var r = a(57437),
                n = a(49322),
                s = a(92934),
                l = a(67948),
                o = a(82137);

            function i(e) {
                let {
                    result: t
                } = e;
                return "pending" === t.status ? (0, r.jsx)(o.l, {
                    fields: t.___config.fields,
                    onSubmit: e.onSubmit,
                    onDismiss: e.onDismiss,
                    preview: e.preview
                }) : "ignored" === t.status ? (0, r.jsx)(l.am, {
                    className: "border-4 border-zinc-100 bg-white text-zinc-700 group-data-[theme=dark]:border-zinc-900 group-data-[theme=dark]:bg-black group-data-[theme=dark]:text-zinc-200",
                    children: (0, r.jsxs)("div", {
                        className: "flex h-5 items-center gap-2",
                        children: [(0, r.jsx)(n.Z, {
                            className: "h-5 w-5 fill-zinc-900 stroke-zinc-100 group-data-[theme=dark]:fill-zinc-400 group-data-[theme=dark]:stroke-zinc-800"
                        }), (0, r.jsx)("p", {
                            className: "text-sm",
                            children: t.displayMessage.title
                        })]
                    })
                }) : (0, r.jsx)(l.am, {
                    className: "border-4 border-zinc-100 bg-white text-zinc-700 group-data-[theme=dark]:border-zinc-900 group-data-[theme=dark]:bg-black group-data-[theme=dark]:text-zinc-200",
                    children: (0, r.jsxs)("div", {
                        className: "flex flex-col",
                        children: [(0, r.jsxs)("div", {
                            className: "flex items-center gap-2",
                            children: [(0, r.jsx)(s.Z, {
                                className: "h-6 w-6 fill-green-600 stroke-white group-data-[theme=dark]:stroke-black"
                            }), (0, r.jsx)("h4", {
                                className: "font-semibold",
                                children: t.displayMessage.title
                            })]
                        }), t.displayMessage.description && (0, r.jsx)("p", {
                            className: "mt-4 text-sm",
                            children: t.displayMessage.description
                        })]
                    })
                })
            }
        },
        82137: function(e, t, a) {
            a.d(t, {
                U: function() {
                    return g
                },
                l: function() {
                    return f
                }
            });
            var r = a(57437),
                n = a(12381),
                s = a(40279),
                l = a(75060),
                o = a(48249),
                i = a(34662),
                d = a(8234),
                c = a(32489),
                u = a(2265),
                m = a(67948),
                h = a(83535),
                x = a(47325);

            function f(e) {
                return e.preview ? (0, r.jsx)(m.Mp, {
                    avatarUrl: e.avatarURL,
                    children: (0, r.jsx)(m.am, {
                        className: "w-full max-w-[min(100%,320px)] p-0",
                        children: (0, r.jsx)("div", {
                            className: "w-full",
                            children: (0, r.jsx)(p, { ...e
                            })
                        })
                    })
                }) : (0, r.jsx)(m.Mp, {
                    avatarUrl: e.avatarURL,
                    children: (0, r.jsx)(m.am, {
                        className: "w-full max-w-[min(100%,320px)] p-0",
                        children: (0, r.jsx)("form", {
                            onSubmit: e.onSubmit,
                            className: "w-full",
                            children: (0, r.jsx)(p, { ...e
                            })
                        })
                    })
                })
            }

            function p(e) {
                let t = (0, u.useCallback)(() => {
                        var t;
                        null === (t = e.onDismiss) || void 0 === t || t.call(e)
                    }, [e.onDismiss]),
                    a = Object.values(e.fields).filter(e => e.enabled);
                return (0, r.jsx)(r.Fragment, {
                    children: (0, r.jsxs)("div", {
                        className: "rounded-t-[20px] rounded-br-[20px] border-2 border-zinc-100 bg-white p-5 pt-4 group-data-[theme=dark]:border-zinc-800 group-data-[theme=dark]:bg-black",
                        children: [(0, r.jsx)("div", {
                            className: "flex items-center justify-end",
                            children: (0, r.jsx)(c.Z, {
                                className: "h-5 w-5 cursor-pointer text-zinc-400 group-data-[theme=dark]:hover:text-zinc-500 group-data-[theme=dark]:text-zinc-600 hover:text-zinc-500",
                                onClick: t
                            })
                        }), (0, r.jsx)("div", {
                            className: "space-y-4",
                            children: a.map(t => (0, r.jsxs)("div", {
                                children: [(0, r.jsxs)(l._, {
                                    className: "text-sm text-zinc-600 group-data-[theme=dark]:text-zinc-400",
                                    htmlFor: t.name,
                                    children: [t.displayName, t.required && (0, r.jsx)("span", {
                                        children: "\xa0*"
                                    })]
                                }), (0, r.jsx)(s.I, {
                                    id: t.name,
                                    required: !e.preview && t.required,
                                    name: t.name,
                                    placeholder: t.placeholder,
                                    className: "mt-3 px-4 py-[10px] group-data-[theme=dark]:border-zinc-700 group-data-[theme=dark]:bg-black placeholder:text-sm"
                                })]
                            }, t.name))
                        }), (0, r.jsx)(n.z, {
                            type: e.preview ? "button" : "submit",
                            className: "mt-8 w-full group-data-[theme=dark]:hidden",
                            children: "Submit"
                        }), (0, r.jsx)(n.z, {
                            type: e.preview ? "button" : "submit",
                            variant: "secondary",
                            className: "mt-8 hidden w-full group-data-[theme=dark]:flex",
                            children: "Submit"
                        })]
                    })
                })
            }

            function g(e) {
                var t, a, n, s, l, c;
                let m = (0, h.m)(),
                    f = (0, o.j)({
                        conversationId: null == m ? void 0 : m.conversationId,
                        chatbotId: null == m ? void 0 : m.chatbot.id,
                        userId: null !== (l = null !== (s = null == m ? void 0 : null === (t = m.user) || void 0 === t ? void 0 : t.user_id) && void 0 !== s ? s : null == m ? void 0 : null === (a = m.user) || void 0 === a ? void 0 : a.anon_user_id) && void 0 !== l ? l : "",
                        userHash: null !== (c = null == m ? void 0 : null === (n = m.user) || void 0 === n ? void 0 : n.user_hash) && void 0 !== c ? c : void 0
                    }),
                    [p, g] = (0, u.useState)(e.result),
                    v = (0, u.useCallback)(async t => {
                        if ("pending" !== p.status) return;
                        t.preventDefault();
                        let a = new FormData(t.target),
                            r = {};
                        for (let e of Object.values(p.___config.fields)) {
                            let t = a.get(e.name);
                            t && "string" == typeof t && (r[e.name] = t)
                        }
                        let n = {
                            status: "success",
                            fields: r,
                            displayMessage: {
                                title: p.___config.successMessage.title,
                                description: p.___config.successMessage.description
                            }
                        };
                        g(n), (null == m ? void 0 : m.saveToolResult) && (await f.mutateAsync(r), m.saveToolResult({
                            toolResult: {
                                id: (0, d.D)(),
                                role: "tool",
                                actionType: i.ww.COLLECT_LEADS,
                                content: [{
                                    result: n,
                                    toolCallId: e.toolCallId,
                                    type: "tool-result",
                                    toolName: "Collect_Leads"
                                }]
                            }
                        }))
                    }, [m, e.toolCallId, p, f]),
                    b = (0, u.useCallback)(() => {
                        if ("pending" !== p.status) return;
                        let t = {
                            status: "ignored",
                            displayMessage: {
                                title: p.___config.ignoredMessage
                            }
                        };
                        g(t), (null == m ? void 0 : m.saveToolResult) && m.saveToolResult({
                            toolResult: {
                                id: (0, d.D)(),
                                role: "tool",
                                actionType: i.ww.COLLECT_LEADS,
                                content: [{
                                    result: t,
                                    toolCallId: e.toolCallId,
                                    type: "tool-result",
                                    toolName: "Collect_Leads"
                                }]
                            }
                        })
                    }, [m, e.toolCallId, p]);
                return (0, r.jsx)(x.C, {
                    onDismiss: b,
                    onSubmit: v,
                    result: p
                })
            }
        },
        12465: function(e, t, a) {
            a.d(t, {
                A: function() {
                    return i
                }
            });
            var r = a(57437),
                n = a(79820),
                s = a(90636),
                l = a(88588),
                o = a(27648);

            function i(e) {
                var t;
                let {
                    result: a
                } = e;
                return "error" === a.status ? null : (0, r.jsx)(l.E.div, {
                    initial: {
                        opacity: 0,
                        y: 10
                    },
                    animate: {
                        opacity: 1,
                        y: 0
                    },
                    transition: {
                        duration: .5,
                        delay: .5
                    },
                    className: "w-full",
                    children: (0, r.jsxs)(s.lr, {
                        className: "w-full",
                        children: [(0, r.jsx)(s.KI, {
                            className: "w-3/4",
                            children: null === (t = a.data) || void 0 === t ? void 0 : t.orders.map(e => {
                                var t, l, i, d, c;
                                return (0, r.jsx)(s.d$, {
                                    className: "basis-10/12 lg:basis-1/2 md:basis-1/2 sm:basis-3/6",
                                    children: (0, r.jsx)("div", {
                                        children: (0, r.jsxs)(n.Zb, {
                                            className: "rounded-lg border-none bg-zinc-100 p-1 group-data-[theme=dark]:bg-zinc-900",
                                            children: [" ", (0, r.jsxs)(n.aY, {
                                                className: "relative p-0 transition-all",
                                                children: [(0, r.jsx)(o.default, {
                                                    href: "https://shopify.com/".concat(null === (l = a.data) || void 0 === l ? void 0 : null === (t = l.shop) || void 0 === t ? void 0 : t.id, "/account/orders/").concat(e.id),
                                                    className: "absolute inset-0 z-10",
                                                    target: "_blank",
                                                    children: (0, r.jsx)("span", {
                                                        className: "sr-only",
                                                        children: "View Order"
                                                    })
                                                }), (0, r.jsx)("div", {
                                                    className: "w-full",
                                                    children: (0, r.jsx)("img", {
                                                        src: null === (i = e.lineItems[0].image) || void 0 === i ? void 0 : i.url,
                                                        alt: "img",
                                                        className: "w-full rounded-lg object-cover"
                                                    })
                                                }), (0, r.jsxs)("div", {
                                                    className: "space-y-2 p-4",
                                                    children: [(0, r.jsxs)("div", {
                                                        className: "space-y-0.5",
                                                        children: [(0, r.jsx)("p", {
                                                            className: "line-clamp-1 font-normal text-sm text-zinc-600 capitalize group-data-[theme=dark]:text-zinc-400",
                                                            children: 1 === e.lineItems.length ? "".concat(e.lineItems.length, " item") : "".concat(e.lineItems.length, " items")
                                                        }), (0, r.jsxs)("h3", {
                                                            className: "line-clamp-1 font-semibold text-sm text-zinc-950 group-data-[theme=dark]:text-zinc-100",
                                                            children: ["Order ", e.name]
                                                        })]
                                                    }), (0, r.jsx)("p", {
                                                        className: "font-semibold text-sm text-zinc-950 group-data-[theme=dark]:text-zinc-100",
                                                        children: new Intl.NumberFormat(void 0, {
                                                            style: "currency",
                                                            currency: null === (d = a.data) || void 0 === d ? void 0 : d.shop.currencyCode
                                                        }).format(Number.parseFloat(null !== (c = e.totalPrice) && void 0 !== c ? c : "0"))
                                                    })]
                                                })]
                                            })]
                                        })
                                    })
                                }, e.id)
                            })
                        }), (0, r.jsx)(s.am, {
                            className: "left-2 bg-white disabled:hidden group-data-[theme=dark]:border-zinc-800 group-data-[theme=dark]:bg-zinc-950 group-data-[theme=dark]:text-zinc-400"
                        }), (0, r.jsx)(s.Pz, {
                            className: "right-2 bg-white disabled:hidden group-data-[theme=dark]:border-zinc-800 group-data-[theme=dark]:bg-zinc-950 group-data-[theme=dark]:text-zinc-400"
                        })]
                    })
                })
            }
        },
        25109: function(e, t, a) {
            a.d(t, {
                o: function() {
                    return i
                }
            });
            var r = a(57437),
                n = a(79820),
                s = a(90636),
                l = a(88588),
                o = a(27648);

            function i(e) {
                var t, a;
                let {
                    result: i
                } = e;
                return "error" === i.status ? null : (0, r.jsx)(l.E.div, {
                    initial: {
                        opacity: 0,
                        y: 10
                    },
                    animate: {
                        opacity: 1,
                        y: 0
                    },
                    transition: {
                        duration: .5,
                        delay: .5
                    },
                    className: "w-full",
                    children: (0, r.jsxs)(s.lr, {
                        className: "w-full",
                        children: [(0, r.jsx)(s.KI, {
                            className: "w-3/4",
                            children: null == i ? void 0 : null === (a = i.data) || void 0 === a ? void 0 : null === (t = a.products) || void 0 === t ? void 0 : t.map(e => {
                                var t, a, l;
                                return (0, r.jsx)(s.d$, {
                                    className: "basis-10/12 lg:basis-1/2 md:basis-1/2 sm:basis-3/6",
                                    children: (0, r.jsx)("div", {
                                        children: (0, r.jsx)(n.Zb, {
                                            className: "rounded-lg border-none bg-zinc-100 p-1 group-data-[theme=dark]:bg-zinc-900",
                                            children: (0, r.jsxs)(n.aY, {
                                                className: "relative p-0 transition-all",
                                                children: [(0, r.jsx)(o.default, {
                                                    href: "https://".concat(null === (t = i.data) || void 0 === t ? void 0 : t.shop.myshopifyDomain, "/products/").concat(e.handle),
                                                    className: "absolute inset-0 z-10",
                                                    target: "_blank",
                                                    children: (0, r.jsx)("span", {
                                                        className: "sr-only",
                                                        children: "View Product"
                                                    })
                                                }), (0, r.jsx)("div", {
                                                    className: "w-full",
                                                    children: (0, r.jsx)("img", {
                                                        src: null === (a = e.image) || void 0 === a ? void 0 : a.originalSrc,
                                                        alt: "img",
                                                        className: "w-full rounded-lg object-cover"
                                                    })
                                                }), (0, r.jsxs)("div", {
                                                    className: "space-y-2 p-4",
                                                    children: [(0, r.jsxs)("div", {
                                                        className: "space-y-0.5",
                                                        children: [(0, r.jsx)("h3", {
                                                            className: "line-clamp-1 font-semibold text-sm text-zinc-950 group-data-[theme=dark]:text-zinc-100",
                                                            children: e.title
                                                        }), (0, r.jsx)("p", {
                                                            className: "line-clamp-1 font-normal text-sm text-zinc-600 capitalize group-data-[theme=dark]:text-zinc-400",
                                                            children: e.productType
                                                        })]
                                                    }), (0, r.jsx)("p", {
                                                        className: "font-semibold text-sm text-zinc-950 group-data-[theme=dark]:text-zinc-100",
                                                        children: new Intl.NumberFormat(void 0, {
                                                            style: "currency",
                                                            currency: null === (l = i.data) || void 0 === l ? void 0 : l.shop.currencyCode
                                                        }).format(Number.parseFloat(e.variants[0].price))
                                                    })]
                                                })]
                                            })
                                        })
                                    })
                                }, e.handle)
                            })
                        }), (0, r.jsx)(s.am, {
                            className: "left-2 bg-white disabled:hidden group-data-[theme=dark]:border-zinc-800 group-data-[theme=dark]:bg-zinc-950 group-data-[theme=dark]:text-zinc-400"
                        }), (0, r.jsx)(s.Pz, {
                            className: "right-2 bg-white disabled:hidden group-data-[theme=dark]:border-zinc-800 group-data-[theme=dark]:bg-zinc-950 group-data-[theme=dark]:text-zinc-400"
                        })]
                    })
                })
            }
        },
        90636: function(e, t, a) {
            a.d(t, {
                KI: function() {
                    return h
                },
                Pz: function() {
                    return p
                },
                am: function() {
                    return f
                },
                d$: function() {
                    return x
                },
                lr: function() {
                    return m
                }
            });
            var r = a(57437),
                n = a(2265),
                s = a(9467),
                l = a(32660),
                o = a(76858),
                i = a(12381),
                d = a(81201);
            let c = n.createContext(null);

            function u() {
                let e = n.useContext(c);
                if (!e) throw Error("useCarousel must be used within a <Carousel />");
                return e
            }
            let m = n.forwardRef((e, t) => {
                let {
                    orientation: a = "horizontal",
                    opts: l,
                    setApi: o,
                    plugins: i,
                    className: u,
                    children: m,
                    ...h
                } = e, [x, f] = (0, s.Z)({ ...l,
                    axis: "horizontal" === a ? "x" : "y"
                }, i), [p, g] = n.useState(!1), [v, b] = n.useState(!1), w = n.useCallback(e => {
                    e && (g(e.canScrollPrev()), b(e.canScrollNext()))
                }, []), j = n.useCallback(() => {
                    null == f || f.scrollPrev()
                }, [f]), y = n.useCallback(() => {
                    null == f || f.scrollNext()
                }, [f]), N = n.useCallback(e => {
                    "ArrowLeft" === e.key ? (e.preventDefault(), j()) : "ArrowRight" === e.key && (e.preventDefault(), y())
                }, [j, y]);
                return n.useEffect(() => {
                    f && o && o(f)
                }, [f, o]), n.useEffect(() => {
                    if (f) return w(f), f.on("reInit", w), f.on("select", w), () => {
                        null == f || f.off("select", w)
                    }
                }, [f, w]), (0, r.jsx)(c.Provider, {
                    value: {
                        carouselRef: x,
                        api: f,
                        opts: l,
                        orientation: a || ((null == l ? void 0 : l.axis) === "y" ? "vertical" : "horizontal"),
                        scrollPrev: j,
                        scrollNext: y,
                        canScrollPrev: p,
                        canScrollNext: v
                    },
                    children: (0, r.jsx)("div", {
                        ref: t,
                        onKeyDownCapture: N,
                        className: (0, d.cn)("relative", u),
                        role: "region",
                        "aria-roledescription": "carousel",
                        ...h,
                        children: m
                    })
                })
            });
            m.displayName = "Carousel";
            let h = n.forwardRef((e, t) => {
                let {
                    className: a,
                    visible: n = !1,
                    ...s
                } = e, {
                    carouselRef: l,
                    orientation: o
                } = u();
                return (0, r.jsx)("div", {
                    ref: l,
                    className: (0, d.cn)("overflow-visible", !n && "overflow-hidden"),
                    children: (0, r.jsx)("div", {
                        ref: t,
                        className: (0, d.cn)("flex", "horizontal" === o ? "-ml-4" : "-mt-4 flex-col", a),
                        ...s
                    })
                })
            });
            h.displayName = "CarouselContent";
            let x = n.forwardRef((e, t) => {
                let {
                    className: a,
                    ...n
                } = e, {
                    orientation: s
                } = u();
                return (0, r.jsx)("div", {
                    ref: t,
                    role: "group",
                    "aria-roledescription": "slide",
                    className: (0, d.cn)("min-w-0 shrink-0 grow-0 basis-full", "horizontal" === s ? "pl-4" : "pt-4", a),
                    ...n
                })
            });
            x.displayName = "CarouselItem";
            let f = n.forwardRef((e, t) => {
                let {
                    className: a,
                    variant: n = "outline",
                    size: s = "icon",
                    ...o
                } = e, {
                    orientation: c,
                    scrollPrev: m,
                    canScrollPrev: h
                } = u();
                return (0, r.jsxs)(i.z, {
                    ref: t,
                    variant: n,
                    size: s,
                    className: (0, d.cn)("absolute  h-8 w-8 rounded-full disabled:cursor-not-allowed disabled:opacity-50", "horizontal" === c ? "-left-12 top-1/2 -translate-y-1/2" : "-top-12 left-1/2 -translate-x-1/2 rotate-90", a),
                    disabled: !h,
                    onClick: m,
                    ...o,
                    children: [(0, r.jsx)(l.Z, {
                        className: "h-4 w-4"
                    }), (0, r.jsx)("span", {
                        className: "sr-only",
                        children: "Previous slide"
                    })]
                })
            });
            f.displayName = "CarouselPrevious";
            let p = n.forwardRef((e, t) => {
                let {
                    className: a,
                    variant: n = "outline",
                    size: s = "icon",
                    ...l
                } = e, {
                    orientation: c,
                    scrollNext: m,
                    canScrollNext: h
                } = u();
                return (0, r.jsxs)(i.z, {
                    ref: t,
                    variant: n,
                    size: s,
                    className: (0, d.cn)("absolute h-8 w-8 rounded-full disabled:cursor-not-allowed disabled:opacity-50", "horizontal" === c ? "-right-12 top-1/2 -translate-y-1/2" : "-bottom-12 left-1/2 -translate-x-1/2 rotate-90", a),
                    disabled: !h,
                    onClick: m,
                    ...l,
                    children: [(0, r.jsx)(o.Z, {
                        className: "h-4 w-4"
                    }), (0, r.jsx)("span", {
                        className: "sr-only",
                        children: "Next slide"
                    })]
                })
            });
            p.displayName = "CarouselNext"
        },
        68245: function(e, t, a) {
            a.d(t, {
                I0: function() {
                    return i
                },
                XZ: function() {
                    return d
                }
            });
            var r = a(57437),
                n = a(16140),
                s = a(30401),
                l = a(2265),
                o = a(81201);
            let i = l.forwardRef((e, t) => {
                let {
                    className: a,
                    ...l
                } = e;
                return (0, r.jsx)(n.fC, {
                    ref: t,
                    className: (0, o.cn)("peer h-4 w-4 shrink-0 rounded-sm border border-zinc-200 border-zinc-900 ring-offset-white disabled:cursor-not-allowed data-[state=checked]:bg-zinc-900 data-[state=checked]:text-zinc-50 disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-950 focus-visible:ring-offset-2", a),
                    ...l,
                    children: (0, r.jsx)(n.z$, {
                        className: (0, o.cn)("flex items-center justify-center text-current"),
                        children: (0, r.jsx)(s.Z, {
                            className: "h-4 w-4 stroke-[3px]"
                        })
                    })
                })
            });
            i.displayName = n.fC.displayName;
            let d = l.forwardRef((e, t) => {
                let {
                    label: a,
                    ...n
                } = e;
                return (0, r.jsxs)("div", {
                    className: "inline-flex items-center space-x-2",
                    children: [(0, r.jsx)(i, {
                        ref: t,
                        ...n
                    }), a && (0, r.jsx)("label", {
                        htmlFor: n.id,
                        className: "font-medium text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
                        children: a
                    })]
                })
            });
            t.ZP = d
        },
        32060: function(e, t, a) {
            a.d(t, {
                $F: function() {
                    return u
                },
                AW: function() {
                    return h
                },
                Ju: function() {
                    return p
                },
                Qk: function() {
                    return m
                },
                VD: function() {
                    return g
                },
                Xi: function() {
                    return x
                },
                bO: function() {
                    return f
                },
                h_: function() {
                    return c
                }
            });
            var r = a(57437),
                n = a(2265),
                s = a(28119),
                l = a(10407),
                o = a(30401),
                i = a(40519),
                d = a(81201);
            let c = s.fC,
                u = s.xz,
                m = s.ZA;
            s.Uv, s.Tr, s.Ee, n.forwardRef((e, t) => {
                let {
                    className: a,
                    inset: n,
                    children: o,
                    ...i
                } = e;
                return (0, r.jsxs)(s.fF, {
                    ref: t,
                    className: (0, d.cn)("flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-zinc-100 data-[state=open]:bg-zinc-100 dark:focus:bg-zinc-800 dark:data-[state=open]:bg-zinc-800", n && "pl-8", a),
                    ...i,
                    children: [o, (0, r.jsx)(l.Z, {
                        className: "ml-auto h-4 w-4"
                    })]
                })
            }).displayName = s.fF.displayName, n.forwardRef((e, t) => {
                let {
                    className: a,
                    ...n
                } = e;
                return (0, r.jsx)(s.tu, {
                    ref: t,
                    className: (0, d.cn)("z-50 min-w-[8rem] overflow-hidden rounded-md border border-zinc-200 bg-white p-1 text-zinc-950 shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-50", a),
                    ...n
                })
            }).displayName = s.tu.displayName;
            let h = n.forwardRef((e, t) => {
                let {
                    className: a,
                    sideOffset: n = 4,
                    ...l
                } = e;
                return (0, r.jsx)(s.Uv, {
                    children: (0, r.jsx)(s.VY, {
                        ref: t,
                        sideOffset: n,
                        className: (0, d.cn)("z-50 min-w-[8rem] overflow-hidden rounded-md border border-zinc-200 bg-white p-1 text-zinc-950 shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-50", a),
                        ...l
                    })
                })
            });
            h.displayName = s.VY.displayName;
            let x = n.forwardRef((e, t) => {
                let {
                    className: a,
                    inset: n,
                    ...l
                } = e;
                return (0, r.jsx)(s.ck, {
                    ref: t,
                    className: (0, d.cn)("relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-zinc-100 focus:text-zinc-900 data-[disabled]:pointer-events-none data-[disabled]:opacity-50 dark:focus:bg-zinc-800 dark:focus:text-zinc-50", n && "pl-8", a),
                    ...l
                })
            });
            x.displayName = s.ck.displayName;
            let f = n.forwardRef((e, t) => {
                let {
                    className: a,
                    children: n,
                    checked: l,
                    ...i
                } = e;
                return (0, r.jsxs)(s.oC, {
                    ref: t,
                    className: (0, d.cn)("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-zinc-100 focus:text-zinc-900 data-[disabled]:pointer-events-none data-[disabled]:opacity-50 dark:focus:bg-zinc-800 dark:focus:text-zinc-50", a),
                    checked: l,
                    ...i,
                    children: [(0, r.jsx)("span", {
                        className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                        children: (0, r.jsx)(s.wU, {
                            children: (0, r.jsx)(o.Z, {
                                className: "h-4 w-4"
                            })
                        })
                    }), n]
                })
            });
            f.displayName = s.oC.displayName, n.forwardRef((e, t) => {
                let {
                    className: a,
                    children: n,
                    ...l
                } = e;
                return (0, r.jsxs)(s.Rk, {
                    ref: t,
                    className: (0, d.cn)("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-zinc-100 focus:text-zinc-900 data-[disabled]:pointer-events-none data-[disabled]:opacity-50 dark:focus:bg-zinc-800 dark:focus:text-zinc-50", a),
                    ...l,
                    children: [(0, r.jsx)("span", {
                        className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                        children: (0, r.jsx)(s.wU, {
                            children: (0, r.jsx)(i.Z, {
                                className: "h-2 w-2 fill-current"
                            })
                        })
                    }), n]
                })
            }).displayName = s.Rk.displayName;
            let p = n.forwardRef((e, t) => {
                let {
                    className: a,
                    inset: n,
                    ...l
                } = e;
                return (0, r.jsx)(s.__, {
                    ref: t,
                    className: (0, d.cn)("px-2 py-1.5 text-sm font-semibold", n && "pl-8", a),
                    ...l
                })
            });
            p.displayName = s.__.displayName;
            let g = n.forwardRef((e, t) => {
                let {
                    className: a,
                    ...n
                } = e;
                return (0, r.jsx)(s.Z0, {
                    ref: t,
                    className: (0, d.cn)("-mx-1 my-1 h-px bg-zinc-100 dark:bg-zinc-800", a),
                    ...n
                })
            });
            g.displayName = s.Z0.displayName
        },
        80670: function(e, t, a) {
            a.d(t, {
                NI: function() {
                    return p
                },
                Wi: function() {
                    return u
                },
                l0: function() {
                    return d
                },
                lX: function() {
                    return f
                },
                pf: function() {
                    return g
                },
                xJ: function() {
                    return x
                },
                zG: function() {
                    return v
                }
            });
            var r = a(57437),
                n = a(2265),
                s = a(98482),
                l = a(75060),
                o = a(29501),
                i = a(81201);
            let d = o.RV,
                c = n.createContext({}),
                u = e => {
                    let { ...t
                    } = e;
                    return (0, r.jsx)(c.Provider, {
                        value: {
                            name: t.name
                        },
                        children: (0, r.jsx)(o.Qr, { ...t
                        })
                    })
                },
                m = () => {
                    let e = n.useContext(c),
                        t = n.useContext(h),
                        {
                            getFieldState: a,
                            formState: r
                        } = (0, o.Gc)(),
                        s = a(e.name, r);
                    if (!e) throw Error("useFormField should be used within <FormField>");
                    let {
                        id: l
                    } = t;
                    return {
                        id: l,
                        name: e.name,
                        formItemId: "".concat(l, "-form-item"),
                        formDescriptionId: "".concat(l, "-form-item-description"),
                        formMessageId: "".concat(l, "-form-item-message"),
                        ...s
                    }
                },
                h = n.createContext({}),
                x = n.forwardRef((e, t) => {
                    let {
                        className: a,
                        ...s
                    } = e, l = n.useId();
                    return (0, r.jsx)(h.Provider, {
                        value: {
                            id: l
                        },
                        children: (0, r.jsx)("div", {
                            ref: t,
                            className: (0, i.cn)("space-y-2", a),
                            ...s
                        })
                    })
                });
            x.displayName = "FormItem";
            let f = n.forwardRef((e, t) => {
                let {
                    className: a,
                    ...n
                } = e, {
                    error: s,
                    formItemId: o
                } = m();
                return (0, r.jsx)(l._, {
                    ref: t,
                    className: (0, i.cn)(s && "text-red-500 dark:text-red-900", a),
                    htmlFor: o,
                    ...n
                })
            });
            f.displayName = "FormLabel";
            let p = n.forwardRef((e, t) => {
                let { ...a
                } = e, {
                    error: n,
                    formItemId: l,
                    formDescriptionId: o,
                    formMessageId: i
                } = m();
                return (0, r.jsx)(s.g7, {
                    ref: t,
                    id: l,
                    "aria-describedby": n ? "".concat(o, " ").concat(i) : "".concat(o),
                    "aria-invalid": !!n,
                    ...a
                })
            });
            p.displayName = "FormControl";
            let g = n.forwardRef((e, t) => {
                let {
                    className: a,
                    ...n
                } = e, {
                    formDescriptionId: s
                } = m();
                return (0, r.jsx)("p", {
                    ref: t,
                    id: s,
                    className: (0, i.cn)("text-[0.8rem] text-zinc-500 dark:text-zinc-400", a),
                    ...n
                })
            });
            g.displayName = "FormDescription";
            let v = n.forwardRef((e, t) => {
                let {
                    className: a,
                    children: n,
                    ...s
                } = e, {
                    error: l,
                    formMessageId: o
                } = m(), d = l ? String(null == l ? void 0 : l.message) : n;
                return d ? (0, r.jsx)("p", {
                    ref: t,
                    id: o,
                    className: (0, i.cn)("text-sm font-medium text-red-500 dark:text-red-900", a),
                    ...s,
                    children: d
                }) : null
            });
            v.displayName = "FormMessage"
        },
        75060: function(e, t, a) {
            a.d(t, {
                _: function() {
                    return d
                }
            });
            var r = a(57437),
                n = a(2265),
                s = a(6394),
                l = a(77712),
                o = a(81201);
            let i = (0, l.j)("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"),
                d = n.forwardRef((e, t) => {
                    let {
                        className: a,
                        ...n
                    } = e;
                    return (0, r.jsx)(s.f, {
                        ref: t,
                        className: (0, o.cn)(i(), a),
                        ...n
                    })
                });
            d.displayName = s.f.displayName
        },
        23675: function(e, t, a) {
            a.d(t, {
                E: function() {
                    return o
                },
                g: function() {
                    return l
                }
            });
            var r = a(57437),
                n = a(2265),
                s = a(81201);
            let l = n.forwardRef((e, t) => {
                let {
                    className: a,
                    ...n
                } = e;
                return (0, r.jsx)("textarea", {
                    className: (0, s.cn)("flex min-h-[80px] w-full rounded-md border border-zinc-200 bg-white px-3 py-2 text-sm ring-offset-white disabled:cursor-not-allowed sm:overscroll-contain dark:border-zinc-800 dark:bg-zinc-950 dark:placeholder:text-zinc-400 placeholder:text-zinc-500 disabled:opacity-50 focus-visible:outline-none dark:focus-visible:ring-zinc-300 focus-visible:ring-2 focus-visible:ring-violet-500 dark:ring-offset-zinc-950 focus-visible:ring-offset-1", a),
                    ref: t,
                    ...n
                })
            });
            l.displayName = "Textarea";
            let o = () => {
                let e = n.useRef(null),
                    t = () => {
                        e.current && (e.current.style.height = "auto", e.current.style.height = "".concat(e.current.scrollHeight, "px"))
                    };
                return n.useEffect(() => {
                    let a = e.current;
                    if (a) return t(), a.addEventListener("input", t), window.addEventListener("resize", t), () => {
                        a.removeEventListener("input", t), window.removeEventListener("resize", t)
                    }
                }, []), n.useEffect(() => {
                    let t = e.current,
                        a = () => {
                            document.activeElement.blur()
                        };
                    return null == t || t.addEventListener("touchmove", a), () => {
                        null == t || t.removeEventListener("touchmove", a)
                    }
                }, []), {
                    ref: e,
                    resize: t
                }
            }
        },
        48249: function(e, t, a) {
            a.d(t, {
                j: function() {
                    return s
                }
            });
            var r = a(45729),
                n = a(21770);

            function s(e) {
                return (0, n.useMutation)({
                    mutationKey: ["save-collected-leads"],
                    mutationFn: async t => {
                        if (!e.conversationId || !e.chatbotId) throw Error("conversationId and chatbotId are required");
                        let {
                            error: a
                        } = await (0, r.d7)({
                            conversationId: e.conversationId,
                            chatbotId: e.chatbotId,
                            collectedLeads: t,
                            userId: e.userId,
                            userHash: e.userHash
                        });
                        if (a) throw a
                    }
                })
            }
        },
        19163: function(e, t, a) {
            function r(e) {
                return new Date(e).toLocaleDateString("en-US", {
                    month: "short",
                    day: "2-digit",
                    year: "numeric"
                })
            }

            function n(e) {
                return "".concat(e.getFullYear(), "-").concat(String(e.getMonth() + 1).padStart(2, "0"), "-").concat(String(e.getDate()).padStart(2, "0"))
            }

            function s(e) {
                return e.split("T")[1].split(":").slice(0, 2).join(":")
            }

            function l(e) {
                return new Date(e).toLocaleDateString("en-US", {
                    weekday: "long",
                    year: "numeric",
                    month: "long",
                    day: "numeric"
                })
            }
            a.d(t, {
                ie: function() {
                    return n
                },
                n4: function() {
                    return l
                },
                p6: function() {
                    return r
                },
                pc: function() {
                    return s
                }
            })
        },
        8234: function(e, t, a) {
            a.d(t, {
                D: function() {
                    return n
                }
            });
            var r = a(49360);
            let n = () => (0, r.Z)()
        }
    }
]);