"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [8208], {
        60703: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return R
                }
            });
            var r = n(33509),
                o = n(2265),
                u = n(85770),
                i = n(17325),
                l = (0, n(31412)._)(),
                a = function() {},
                c = o.forwardRef(function(e, t) {
                    var n = o.useRef(null),
                        u = o.useState({
                            onScrollCapture: a,
                            onWheelCapture: a,
                            onTouchMoveCapture: a
                        }),
                        c = u[0],
                        s = u[1],
                        d = e.forwardProps,
                        f = e.children,
                        v = e.className,
                        m = e.removeScrollBar,
                        p = e.enabled,
                        h = e.shards,
                        E = e.sideCar,
                        b = e.noIsolation,
                        y = e.inert,
                        w = e.allowPinchZoom,
                        g = e.as,
                        C = (0, r._T)(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noIsolation", "inert", "allowPinchZoom", "as"]),
                        L = (0, i.q)([n, t]),
                        T = (0, r.pi)((0, r.pi)({}, C), c);
                    return o.createElement(o.Fragment, null, p && o.createElement(E, {
                        sideCar: l,
                        removeScrollBar: m,
                        shards: h,
                        noIsolation: b,
                        inert: y,
                        setCallbacks: s,
                        allowPinchZoom: !!w,
                        lockRef: n
                    }), d ? o.cloneElement(o.Children.only(f), (0, r.pi)((0, r.pi)({}, T), {
                        ref: L
                    })) : o.createElement(void 0 === g ? "div" : g, (0, r.pi)({}, T, {
                        className: v,
                        ref: L
                    }), f))
                });
            c.defaultProps = {
                enabled: !0,
                removeScrollBar: !0,
                inert: !1
            }, c.classNames = {
                fullWidth: u.zi,
                zeroRight: u.pF
            };
            var s = n(49085),
                d = n(5517),
                f = n(18704),
                v = !1;
            if ("undefined" != typeof window) try {
                var m = Object.defineProperty({}, "passive", {
                    get: function() {
                        return v = !0, !0
                    }
                });
                window.addEventListener("test", m, m), window.removeEventListener("test", m, m)
            } catch (e) {
                v = !1
            }
            var p = !!v && {
                    passive: !1
                },
                h = function(e, t) {
                    var n = window.getComputedStyle(e);
                    return "hidden" !== n[t] && !(n.overflowY === n.overflowX && "TEXTAREA" !== e.tagName && "visible" === n[t])
                },
                E = function(e, t) {
                    var n = t;
                    do {
                        if ("undefined" != typeof ShadowRoot && n instanceof ShadowRoot && (n = n.host), b(e, n)) {
                            var r = y(e, n);
                            if (r[1] > r[2]) return !0
                        }
                        n = n.parentNode
                    } while (n && n !== document.body);
                    return !1
                },
                b = function(e, t) {
                    return "v" === e ? h(t, "overflowY") : h(t, "overflowX")
                },
                y = function(e, t) {
                    return "v" === e ? [t.scrollTop, t.scrollHeight, t.clientHeight] : [t.scrollLeft, t.scrollWidth, t.clientWidth]
                },
                w = function(e, t, n, r, o) {
                    var u, i = (u = window.getComputedStyle(t).direction, "h" === e && "rtl" === u ? -1 : 1),
                        l = i * r,
                        a = n.target,
                        c = t.contains(a),
                        s = !1,
                        d = l > 0,
                        f = 0,
                        v = 0;
                    do {
                        var m = y(e, a),
                            p = m[0],
                            h = m[1] - m[2] - i * p;
                        (p || h) && b(e, a) && (f += h, v += p), a = a.parentNode
                    } while (!c && a !== document.body || c && (t.contains(a) || t === a));
                    return d && (o && 0 === f || !o && l > f) ? s = !0 : !d && (o && 0 === v || !o && -l > v) && (s = !0), s
                },
                g = function(e) {
                    return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0]
                },
                C = function(e) {
                    return [e.deltaX, e.deltaY]
                },
                L = function(e) {
                    return e && "current" in e ? e.current : e
                },
                T = 0,
                P = [],
                k = (0, s.L)(l, function(e) {
                    var t = o.useRef([]),
                        n = o.useRef([0, 0]),
                        u = o.useRef(),
                        i = o.useState(T++)[0],
                        l = o.useState(function() {
                            return (0, f.Ws)()
                        })[0],
                        a = o.useRef(e);
                    o.useEffect(function() {
                        a.current = e
                    }, [e]), o.useEffect(function() {
                        if (e.inert) {
                            document.body.classList.add("block-interactivity-".concat(i));
                            var t = (0, r.ev)([e.lockRef.current], (e.shards || []).map(L), !0).filter(Boolean);
                            return t.forEach(function(e) {
                                    return e.classList.add("allow-interactivity-".concat(i))
                                }),
                                function() {
                                    document.body.classList.remove("block-interactivity-".concat(i)), t.forEach(function(e) {
                                        return e.classList.remove("allow-interactivity-".concat(i))
                                    })
                                }
                        }
                    }, [e.inert, e.lockRef.current, e.shards]);
                    var c = o.useCallback(function(e, t) {
                            if ("touches" in e && 2 === e.touches.length) return !a.current.allowPinchZoom;
                            var r, o = g(e),
                                i = n.current,
                                l = "deltaX" in e ? e.deltaX : i[0] - o[0],
                                c = "deltaY" in e ? e.deltaY : i[1] - o[1],
                                s = e.target,
                                d = Math.abs(l) > Math.abs(c) ? "h" : "v";
                            if ("touches" in e && "h" === d && "range" === s.type) return !1;
                            var f = E(d, s);
                            if (!f) return !0;
                            if (f ? r = d : (r = "v" === d ? "h" : "v", f = E(d, s)), !f) return !1;
                            if (!u.current && "changedTouches" in e && (l || c) && (u.current = r), !r) return !0;
                            var v = u.current || r;
                            return w(v, t, e, "h" === v ? l : c, !0)
                        }, []),
                        s = o.useCallback(function(e) {
                            if (P.length && P[P.length - 1] === l) {
                                var n = "deltaY" in e ? C(e) : g(e),
                                    r = t.current.filter(function(t) {
                                        var r;
                                        return t.name === e.type && t.target === e.target && (r = t.delta)[0] === n[0] && r[1] === n[1]
                                    })[0];
                                if (r && r.should) {
                                    e.cancelable && e.preventDefault();
                                    return
                                }
                                if (!r) {
                                    var o = (a.current.shards || []).map(L).filter(Boolean).filter(function(t) {
                                        return t.contains(e.target)
                                    });
                                    (o.length > 0 ? c(e, o[0]) : !a.current.noIsolation) && e.cancelable && e.preventDefault()
                                }
                            }
                        }, []),
                        v = o.useCallback(function(e, n, r, o) {
                            var u = {
                                name: e,
                                delta: n,
                                target: r,
                                should: o
                            };
                            t.current.push(u), setTimeout(function() {
                                t.current = t.current.filter(function(e) {
                                    return e !== u
                                })
                            }, 1)
                        }, []),
                        m = o.useCallback(function(e) {
                            n.current = g(e), u.current = void 0
                        }, []),
                        h = o.useCallback(function(t) {
                            v(t.type, C(t), t.target, c(t, e.lockRef.current))
                        }, []),
                        b = o.useCallback(function(t) {
                            v(t.type, g(t), t.target, c(t, e.lockRef.current))
                        }, []);
                    o.useEffect(function() {
                        return P.push(l), e.setCallbacks({
                                onScrollCapture: h,
                                onWheelCapture: h,
                                onTouchMoveCapture: b
                            }), document.addEventListener("wheel", s, p), document.addEventListener("touchmove", s, p), document.addEventListener("touchstart", m, p),
                            function() {
                                P = P.filter(function(e) {
                                    return e !== l
                                }), document.removeEventListener("wheel", s, p), document.removeEventListener("touchmove", s, p), document.removeEventListener("touchstart", m, p)
                            }
                    }, []);
                    var y = e.removeScrollBar,
                        k = e.inert;
                    return o.createElement(o.Fragment, null, k ? o.createElement(l, {
                        styles: "\n  .block-interactivity-".concat(i, " {pointer-events: none;}\n  .allow-interactivity-").concat(i, " {pointer-events: all;}\n")
                    }) : null, y ? o.createElement(d.jp, {
                        gapMode: "margin"
                    }) : null)
                }),
                S = o.forwardRef(function(e, t) {
                    return o.createElement(c, (0, r.pi)({}, e, {
                        ref: t,
                        sideCar: k
                    }))
                });
            S.classNames = c.classNames;
            var R = S
        },
        15278: function(e, t, n) {
            let r;
            n.d(t, {
                XB: function() {
                    return f
                }
            });
            var o = n(1119),
                u = n(2265),
                i = n(6741),
                l = n(82912),
                a = n(98575),
                c = n(26606);
            let s = "dismissableLayer.update",
                d = (0, u.createContext)({
                    layers: new Set,
                    layersWithOutsidePointerEventsDisabled: new Set,
                    branches: new Set
                }),
                f = (0, u.forwardRef)((e, t) => {
                    var n;
                    let {
                        disableOutsidePointerEvents: f = !1,
                        onEscapeKeyDown: p,
                        onPointerDownOutside: h,
                        onFocusOutside: E,
                        onInteractOutside: b,
                        onDismiss: y,
                        ...w
                    } = e, g = (0, u.useContext)(d), [C, L] = (0, u.useState)(null), T = null !== (n = null == C ? void 0 : C.ownerDocument) && void 0 !== n ? n : null == globalThis ? void 0 : globalThis.document, [, P] = (0, u.useState)({}), k = (0, a.e)(t, e => L(e)), S = Array.from(g.layers), [R] = [...g.layersWithOutsidePointerEventsDisabled].slice(-1), W = S.indexOf(R), D = C ? S.indexOf(C) : -1, N = g.layersWithOutsidePointerEventsDisabled.size > 0, O = D >= W, F = function(e, t = null == globalThis ? void 0 : globalThis.document) {
                        let n = (0, c.W)(e),
                            r = (0, u.useRef)(!1),
                            o = (0, u.useRef)(() => {});
                        return (0, u.useEffect)(() => {
                            let e = e => {
                                    if (e.target && !r.current) {
                                        let r = {
                                            originalEvent: e
                                        };

                                        function u() {
                                            m("dismissableLayer.pointerDownOutside", n, r, {
                                                discrete: !0
                                            })
                                        }
                                        "touch" === e.pointerType ? (t.removeEventListener("click", o.current), o.current = u, t.addEventListener("click", o.current, {
                                            once: !0
                                        })) : u()
                                    } else t.removeEventListener("click", o.current);
                                    r.current = !1
                                },
                                u = window.setTimeout(() => {
                                    t.addEventListener("pointerdown", e)
                                }, 0);
                            return () => {
                                window.clearTimeout(u), t.removeEventListener("pointerdown", e), t.removeEventListener("click", o.current)
                            }
                        }, [t, n]), {
                            onPointerDownCapture: () => r.current = !0
                        }
                    }(e => {
                        let t = e.target,
                            n = [...g.branches].some(e => e.contains(t));
                        !O || n || (null == h || h(e), null == b || b(e), e.defaultPrevented || null == y || y())
                    }, T), I = function(e, t = null == globalThis ? void 0 : globalThis.document) {
                        let n = (0, c.W)(e),
                            r = (0, u.useRef)(!1);
                        return (0, u.useEffect)(() => {
                            let e = e => {
                                e.target && !r.current && m("dismissableLayer.focusOutside", n, {
                                    originalEvent: e
                                }, {
                                    discrete: !1
                                })
                            };
                            return t.addEventListener("focusin", e), () => t.removeEventListener("focusin", e)
                        }, [t, n]), {
                            onFocusCapture: () => r.current = !0,
                            onBlurCapture: () => r.current = !1
                        }
                    }(e => {
                        let t = e.target;
                        [...g.branches].some(e => e.contains(t)) || (null == E || E(e), null == b || b(e), e.defaultPrevented || null == y || y())
                    }, T);
                    return ! function(e, t = null == globalThis ? void 0 : globalThis.document) {
                        let n = (0, c.W)(e);
                        (0, u.useEffect)(() => {
                            let e = e => {
                                "Escape" === e.key && n(e)
                            };
                            return t.addEventListener("keydown", e), () => t.removeEventListener("keydown", e)
                        }, [n, t])
                    }(e => {
                        D !== g.layers.size - 1 || (null == p || p(e), !e.defaultPrevented && y && (e.preventDefault(), y()))
                    }, T), (0, u.useEffect)(() => {
                        if (C) return f && (0 === g.layersWithOutsidePointerEventsDisabled.size && (r = T.body.style.pointerEvents, T.body.style.pointerEvents = "none"), g.layersWithOutsidePointerEventsDisabled.add(C)), g.layers.add(C), v(), () => {
                            f && 1 === g.layersWithOutsidePointerEventsDisabled.size && (T.body.style.pointerEvents = r)
                        }
                    }, [C, T, f, g]), (0, u.useEffect)(() => () => {
                        C && (g.layers.delete(C), g.layersWithOutsidePointerEventsDisabled.delete(C), v())
                    }, [C, g]), (0, u.useEffect)(() => {
                        let e = () => P({});
                        return document.addEventListener(s, e), () => document.removeEventListener(s, e)
                    }, []), (0, u.createElement)(l.WV.div, (0, o.Z)({}, w, {
                        ref: k,
                        style: {
                            pointerEvents: N ? O ? "auto" : "none" : void 0,
                            ...e.style
                        },
                        onFocusCapture: (0, i.M)(e.onFocusCapture, I.onFocusCapture),
                        onBlurCapture: (0, i.M)(e.onBlurCapture, I.onBlurCapture),
                        onPointerDownCapture: (0, i.M)(e.onPointerDownCapture, F.onPointerDownCapture)
                    }))
                });

            function v() {
                let e = new CustomEvent(s);
                document.dispatchEvent(e)
            }

            function m(e, t, n, {
                discrete: r
            }) {
                let o = n.originalEvent.target,
                    u = new CustomEvent(e, {
                        bubbles: !1,
                        cancelable: !0,
                        detail: n
                    });
                t && o.addEventListener(e, t, {
                    once: !0
                }), r ? (0, l.jH)(o, u) : o.dispatchEvent(u)
            }
        },
        86097: function(e, t, n) {
            n.d(t, {
                EW: function() {
                    return u
                }
            });
            var r = n(2265);
            let o = 0;

            function u() {
                (0, r.useEffect)(() => {
                    var e, t;
                    let n = document.querySelectorAll("[data-radix-focus-guard]");
                    return document.body.insertAdjacentElement("afterbegin", null !== (e = n[0]) && void 0 !== e ? e : i()), document.body.insertAdjacentElement("beforeend", null !== (t = n[1]) && void 0 !== t ? t : i()), o++, () => {
                        1 === o && document.querySelectorAll("[data-radix-focus-guard]").forEach(e => e.remove()), o--
                    }
                }, [])
            }

            function i() {
                let e = document.createElement("span");
                return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.cssText = "outline: none; opacity: 0; position: fixed; pointer-events: none", e
            }
        },
        99103: function(e, t, n) {
            let r;
            n.d(t, {
                M: function() {
                    return f
                }
            });
            var o = n(1119),
                u = n(2265),
                i = n(98575),
                l = n(82912),
                a = n(26606);
            let c = "focusScope.autoFocusOnMount",
                s = "focusScope.autoFocusOnUnmount",
                d = {
                    bubbles: !1,
                    cancelable: !0
                },
                f = (0, u.forwardRef)((e, t) => {
                    let {
                        loop: n = !1,
                        trapped: r = !1,
                        onMountAutoFocus: f,
                        onUnmountAutoFocus: E,
                        ...b
                    } = e, [y, w] = (0, u.useState)(null), g = (0, a.W)(f), C = (0, a.W)(E), L = (0, u.useRef)(null), T = (0, i.e)(t, e => w(e)), P = (0, u.useRef)({
                        paused: !1,
                        pause() {
                            this.paused = !0
                        },
                        resume() {
                            this.paused = !1
                        }
                    }).current;
                    (0, u.useEffect)(() => {
                        if (r) {
                            function e(e) {
                                if (P.paused || !y) return;
                                let t = e.target;
                                y.contains(t) ? L.current = t : p(L.current, {
                                    select: !0
                                })
                            }

                            function t(e) {
                                if (P.paused || !y) return;
                                let t = e.relatedTarget;
                                null === t || y.contains(t) || p(L.current, {
                                    select: !0
                                })
                            }
                            document.addEventListener("focusin", e), document.addEventListener("focusout", t);
                            let n = new MutationObserver(function(e) {
                                if (document.activeElement === document.body)
                                    for (let t of e) t.removedNodes.length > 0 && p(y)
                            });
                            return y && n.observe(y, {
                                childList: !0,
                                subtree: !0
                            }), () => {
                                document.removeEventListener("focusin", e), document.removeEventListener("focusout", t), n.disconnect()
                            }
                        }
                    }, [r, y, P.paused]), (0, u.useEffect)(() => {
                        if (y) {
                            h.add(P);
                            let e = document.activeElement;
                            if (!y.contains(e)) {
                                let t = new CustomEvent(c, d);
                                y.addEventListener(c, g), y.dispatchEvent(t), t.defaultPrevented || (function(e, {
                                    select: t = !1
                                } = {}) {
                                    let n = document.activeElement;
                                    for (let r of e)
                                        if (p(r, {
                                                select: t
                                            }), document.activeElement !== n) return
                                }(v(y).filter(e => "A" !== e.tagName), {
                                    select: !0
                                }), document.activeElement === e && p(y))
                            }
                            return () => {
                                y.removeEventListener(c, g), setTimeout(() => {
                                    let t = new CustomEvent(s, d);
                                    y.addEventListener(s, C), y.dispatchEvent(t), t.defaultPrevented || p(null != e ? e : document.body, {
                                        select: !0
                                    }), y.removeEventListener(s, C), h.remove(P)
                                }, 0)
                            }
                        }
                    }, [y, g, C, P]);
                    let k = (0, u.useCallback)(e => {
                        if (!n && !r || P.paused) return;
                        let t = "Tab" === e.key && !e.altKey && !e.ctrlKey && !e.metaKey,
                            o = document.activeElement;
                        if (t && o) {
                            let t = e.currentTarget,
                                [r, u] = function(e) {
                                    let t = v(e);
                                    return [m(t, e), m(t.reverse(), e)]
                                }(t);
                            r && u ? e.shiftKey || o !== u ? e.shiftKey && o === r && (e.preventDefault(), n && p(u, {
                                select: !0
                            })) : (e.preventDefault(), n && p(r, {
                                select: !0
                            })) : o === t && e.preventDefault()
                        }
                    }, [n, r, P.paused]);
                    return (0, u.createElement)(l.WV.div, (0, o.Z)({
                        tabIndex: -1
                    }, b, {
                        ref: T,
                        onKeyDown: k
                    }))
                });

            function v(e) {
                let t = [],
                    n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
                        acceptNode: e => {
                            let t = "INPUT" === e.tagName && "hidden" === e.type;
                            return e.disabled || e.hidden || t ? NodeFilter.FILTER_SKIP : e.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
                        }
                    });
                for (; n.nextNode();) t.push(n.currentNode);
                return t
            }

            function m(e, t) {
                for (let n of e)
                    if (! function(e, {
                            upTo: t
                        }) {
                            if ("hidden" === getComputedStyle(e).visibility) return !0;
                            for (; e && (void 0 === t || e !== t);) {
                                if ("none" === getComputedStyle(e).display) return !0;
                                e = e.parentElement
                            }
                            return !1
                        }(n, {
                            upTo: t
                        })) return n
            }

            function p(e, {
                select: t = !1
            } = {}) {
                if (e && e.focus) {
                    var n;
                    let r = document.activeElement;
                    e.focus({
                        preventScroll: !0
                    }), e !== r && (n = e) instanceof HTMLInputElement && "select" in n && t && e.select()
                }
            }
            let h = (r = [], {
                add(e) {
                    let t = r[0];
                    e !== t && (null == t || t.pause()), (r = E(r, e)).unshift(e)
                },
                remove(e) {
                    var t;
                    null === (t = (r = E(r, e))[0]) || void 0 === t || t.resume()
                }
            });

            function E(e, t) {
                let n = [...e],
                    r = n.indexOf(t);
                return -1 !== r && n.splice(r, 1), n
            }
        },
        83832: function(e, t, n) {
            n.d(t, {
                h: function() {
                    return l
                }
            });
            var r = n(1119),
                o = n(2265),
                u = n(54887),
                i = n(82912);
            let l = (0, o.forwardRef)((e, t) => {
                var n;
                let {
                    container: l = null == globalThis ? void 0 : null === (n = globalThis.document) || void 0 === n ? void 0 : n.body,
                    ...a
                } = e;
                return l ? u.createPortal((0, o.createElement)(i.WV.div, (0, r.Z)({}, a, {
                    ref: t
                })), l) : null
            })
        }
    }
]);