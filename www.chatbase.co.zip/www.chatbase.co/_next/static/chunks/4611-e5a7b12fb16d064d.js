"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4611], {
        53206: function(e, t, r) {
            r.d(t, {
                Z: function() {
                    return a
                }
            });
            var l = r(57437);

            function a() {
                return (0, l.jsxs)("div", {
                    className: "relative inline-flex items-center justify-center gap-[6px]",
                    children: [(0, l.jsx)("span", {
                        className: "sr-only",
                        children: "Loading..."
                    }), (0, l.jsx)("div", {
                        className: "size-[7px] animate-bounce rounded-full bg-zinc-500 [animation-delay:-0.3s]"
                    }), (0, l.jsx)("div", {
                        className: "size-[7px] animate-bounce rounded-full bg-zinc-500 [animation-delay:-0.15s]"
                    }), (0, l.jsx)("div", {
                        className: "size-[7px] animate-bounce rounded-full bg-zinc-500"
                    })]
                })
            }
        },
        51945: function(e, t, r) {
            r.d(t, {
                V: function() {
                    return q
                }
            });
            var l = r(57437),
                a = r(89882),
                s = r(2265),
                n = r(99604),
                c = r(43343),
                i = r(88062),
                o = r(43014),
                d = r(8431),
                h = r(35494),
                u = r(3773),
                f = r(88308),
                x = r(53206);
            r(2446);
            var m = r(81315),
                p = r(46882),
                w = r(81201);

            function v(e) {
                var t, r, a;
                let {
                    node: s,
                    ...n
                } = e, c = null !== (r = n.href) && void 0 !== r ? r : "", i = null !== (a = null === (t = n.children) || void 0 === t ? void 0 : t.toString()) && void 0 !== a ? a : "";
                return /^[\d\s()+.-]+$/.test(i) && !c.startsWith("tel:") ? (0, l.jsx)("a", { ...n,
                    target: "_self",
                    href: "tel:".concat(i)
                }) : (0, l.jsx)("a", { ...n
                })
            }
            var g = r(2030);
            let j = (0, s.memo)(n.U, (e, t) => e.children === t.children && e.className === t.className),
                N = e => e.replace(RegExp("\\\\\\[(.*?)\\\\\\]", "gs"), (e, t) => "$$".concat(t, "$$")).replace(RegExp("\\\\\\((.*?)\\\\\\)", "gs"), (e, t) => "$$".concat(t, "$$"));

            function k(e) {
                let {
                    children: t
                } = e;
                return s.Children.map(t, e => "string" == typeof e ? (function(e) {
                    try {
                        let t = [],
                            r = e.split(" ");
                        for (let e = 0; e < r.length; e++) t.push("".concat(r[e], " "));
                        return t
                    } catch (t) {
                        return console.log(t, "error", [e]), []
                    }
                })(e).map((e, t) => (0, l.jsx)("span", {
                    className: "animate-fadeIn",
                    children: e
                }, "chunk-".concat(e.trim(), "-").concat(t))) : e)
            }

            function C(e) {
                let t = k({
                    children: e.children
                });
                return (0, l.jsx)("p", {
                    children: t
                })
            }

            function b(e) {
                let t = k({
                    children: e.children
                });
                return (0, l.jsx)("li", {
                    children: t
                })
            }

            function _(e) {
                let {
                    children: t,
                    ...r
                } = e, a = k({
                    children: t
                });
                return (0, l.jsx)(g.I, {
                    children: a
                })
            }

            function T(e) {
                let t = k({
                    children: e.children
                });
                return (0, l.jsx)("strong", {
                    children: t
                })
            }

            function S() {
                return e => {
                    (0, p.Vn)(e, "listItem", e => {
                        let t = [];
                        for (let r of e.children) "paragraph" === r.type || "heading" === r.type ? t.push(...r.children) : t.push(r);
                        e.children = t
                    })
                }
            }
            let q = (0, s.memo)(e => {
                let [t, r, s] = (0, a.el)(e.content);
                if (e.children || t) {
                    var n;
                    let r = N(null !== (n = null != t ? t : e.children) && void 0 !== n ? n : ""),
                        a = (0, f.l)().use(h.Z).parse(r);
                    return (0, l.jsx)(l.Fragment, {
                        children: e.shouldAnimate ? (0, l.jsx)("div", {
                            className: "prose-zinc prose group-data-[theme=dark]:prose-invert w-full text-sm [&_table]:block [&_.katex-html]:overflow-x-auto [&_table]:overflow-x-auto",
                            children: a.children.map((t, r) => (0, l.jsx)(j, {
                                className: (0, w.cn)(e.className),
                                remarkPlugins: [
                                    [m.Z, {
                                        singleDollarTextMath: !1
                                    }],
                                    [d.Z, {
                                        singleTilde: !1
                                    }], S
                                ],
                                rehypePlugins: [o.Z, i.Z, [c.Z, {
                                    target: "_blank",
                                    rel: ["noopener", "noreferrer"],
                                    protocols: ["http", "https", "tel"]
                                }]],
                                components: {
                                    p: C,
                                    code: _,
                                    strong: T,
                                    li: b,
                                    a: v
                                },
                                children: (0, f.l)().use(u.Z).stringify(t)
                            }, t.type + r))
                        }) : (0, l.jsx)(j, {
                            className: "prose-zinc prose group-data-[theme=dark]:prose-invert w-full text-sm [&_table]:block [&_.katex-html]:overflow-x-auto [&_table]:overflow-x-auto",
                            remarkPlugins: [
                                [m.Z, {
                                    singleDollarTextMath: !1
                                }],
                                [d.Z, {
                                    singleTilde: !1
                                }], S
                            ],
                            rehypePlugins: [o.Z, i.Z, [c.Z, {
                                target: "_blank",
                                rel: ["noopener", "noreferrer"],
                                protocols: ["http", "https", "tel"]
                            }]],
                            components: {
                                a: v
                            },
                            children: r
                        })
                    })
                }
                if (s) return (0, l.jsx)(x.Z, {})
            })
        },
        67948: function(e, t, r) {
            r.d(t, {
                Mp: function() {
                    return d
                },
                am: function() {
                    return o
                },
                cA: function() {
                    return x
                },
                eY: function() {
                    return h
                },
                fy: function() {
                    return f
                },
                lF: function() {
                    return u
                }
            });
            var l = r(57437),
                a = r(96246),
                s = r(81201),
                n = r(2265),
                c = r(29155);

            function i(e) {
                let {
                    className: t,
                    ...r
                } = e;
                return (0, l.jsx)("div", {
                    className: (0, s.cn)("hyphens-auto text-wrap break-words rounded-[20px] text-left text-sm leading-5 antialiased", e.className),
                    ...r,
                    children: e.children
                })
            }

            function o(e) {
                return (0, l.jsx)(i, {
                    className: (0, s.cn)("relative inline-block max-w-full rounded-r-[20px] rounded-l px-5 py-4 only:rounded-[20px] last:rounded-tl first:rounded-tl-[20px] first:rounded-bl only:rounded-bl last:rounded-bl-[20px]", "bg-zinc-200/50 text-zinc-800 group-data-[theme=dark]:bg-zinc-800/80 group-data-[theme=dark]:text-zinc-300", e.className),
                    children: e.children
                })
            }

            function d(e) {
                return (0, l.jsxs)("div", {
                    "data-loading-assistant": e.isLoading,
                    className: "flex w-full items-end pr-3",
                    children: [e.avatarUrl && (0, l.jsx)(a.Avatar, {
                        className: "mr-2 h-8 w-8 flex-shrink-0 flex-grow-0 border-zinc-800 group-data-[theme=dark]:border",
                        children: (0, l.jsx)("img", {
                            src: e.avatarUrl,
                            alt: "Chatbot Avatar"
                        })
                    }), (0, l.jsx)("div", {
                        className: "group/message flex w-full max-w-[min(calc(100%-40px),65ch)] flex-col items-start",
                        children: e.children
                    })]
                })
            }

            function h(e) {
                return (0, l.jsxs)(i, {
                    className: (0, s.cn)("relative inline-block max-w-full rounded-r-[20px] rounded-l px-5 py-4 only:rounded-[20px] last:rounded-tl first:rounded-tl-[20px] first:rounded-bl only:rounded-bl last:rounded-bl-[20px]", "bg-zinc-200/50 text-zinc-800 group-data-[theme=dark]:bg-zinc-800/80 group-data-[theme=dark]:text-zinc-300", e.className),
                    children: [e.agentName && (0, l.jsx)("span", {
                        className: "mb-2 font-medium text-xs text-zinc-500 group-data-[theme=dark]:text-zinc-400",
                        children: e.agentName
                    }), e.children]
                })
            }

            function u(e) {
                return (0, l.jsxs)("div", {
                    className: "flex w-full items-end pr-3",
                    children: [e.agentAvatarUrl && (0, l.jsx)(a.Avatar, {
                        className: "mr-2 h-8 w-8 flex-shrink-0 flex-grow-0 border-zinc-800 group-data-[theme=dark]:border",
                        children: (0, l.jsx)("img", {
                            src: e.agentAvatarUrl,
                            alt: "Agent Avatar"
                        })
                    }), (0, l.jsx)("div", {
                        className: "relative flex w-fit max-w-full flex-col items-baseline gap-2",
                        children: e.children
                    })]
                })
            }
            let f = n.memo(d, (e, t) => !t.isLast && e.isLast === t.isLast);

            function x(e) {
                var t, r;
                let a = (null === (t = e.chatbotStyles) || void 0 === t ? void 0 : t.theme) === "dark",
                    n = a ? 1 : 0,
                    o = (0, c.Z)("#27272A"),
                    d = (null === (r = e.chatbotStyles) || void 0 === r ? void 0 : r.user_message_color) ? e.chatbotStyles.user_message_color : a ? "#000000" : "#18181B",
                    h = (0, c.Z)(d),
                    u = h.getBrightness(),
                    f = o.getBrightness();
                n = a ? u < f ? 1 : 0 : u - f > 215 ? 1 : 0;
                let x = (a = h.isDark()) ? "#ffffff" : "#000000";
                return (0, l.jsx)(i, {
                    "data-user": !0,
                    className: (0, s.cn)("ml-auto px-4 py-2", "whitespace-pre border-zinc-200 font-sans", "max-w-[min(calc(100%-40px),65ch)] group-data-[theme=dark]:border-zinc-800", "rounded-r last:rounded-tr first:rounded-tr-[20px] only:rounded-tr-[20px] first:rounded-br only:rounded-br last:rounded-br-[20px]", e.className),
                    style: {
                        backgroundColor: d,
                        borderWidth: n,
                        color: x
                    },
                    children: e.children
                })
            }
        },
        2030: function(e, t, r) {
            r.d(t, {
                I: function() {
                    return c
                },
                r: function() {
                    return n
                }
            });
            var l = r(57437),
                a = r(2265);
            let s = () => {
                    var e;
                    let [t, r] = (0, a.useState)(0), l = (0, a.useRef)(null);
                    return (0, a.useEffect)(() => {
                        let e = setTimeout(() => {
                            var e;
                            r((null === (e = l.current) || void 0 === e ? void 0 : e.scrollHeight) || 0)
                        }, 10);
                        return () => {
                            clearTimeout(e)
                        }
                    }, [null === (e = l.current) || void 0 === e ? void 0 : e.scrollHeight]), {
                        height: t,
                        elementRef: l
                    }
                },
                n = e => {
                    let {
                        children: t,
                        shouldAnimate: r
                    } = e, {
                        height: a,
                        elementRef: n
                    } = s();
                    return (0, l.jsx)("div", {
                        className: "max-w-full overflow-hidden",
                        ref: n,
                        style: r ? {
                            transition: "height 0.1s linear",
                            height: "".concat(a, "px")
                        } : {},
                        children: t
                    })
                },
                c = e => {
                    let {
                        children: t
                    } = e, {
                        height: r,
                        elementRef: a
                    } = s();
                    return (0, l.jsx)("code", {
                        className: "max-w-full overflow-hidden",
                        ref: a,
                        style: {
                            transition: "height 0.1s linear",
                            height: "".concat(r, "px")
                        },
                        children: t
                    })
                }
        },
        10064: function(e, t, r) {
            r.d(t, {
                Ri: function() {
                    return j
                },
                lG: function() {
                    return k
                }
            });
            var l = r(57437),
                a = r(81201),
                s = r(67948),
                n = r(88374),
                c = r(16616),
                i = r(10126),
                o = r(21851),
                d = r(58639),
                h = r(58666),
                u = r(79820),
                f = r(34662),
                x = r(25235),
                m = r(51989),
                p = r(565),
                w = r(82182),
                v = r(98627),
                g = r(53315);
            let j = e => {
                    let t = "".concat(e.actionType === f.ww.CUSTOM_ACTION ? e.toolName : N(e.actionType), " Action has been called");
                    return (0, l.jsx)(s.am, {
                        className: "my-1 min-w-56 max-w-full p-1",
                        children: (0, l.jsx)(u.Zb, {
                            className: "group/card h-14 w-fit min-w-52 rounded-2xl border-none shadow-none",
                            children: (0, l.jsx)(u.Ol, {
                                className: "flex h-full w-full flex-row items-center justify-between gap-2 space-y-0 px-4 py-2",
                                children: (0, l.jsxs)(u.ll, {
                                    className: "flex w-full items-center font-medium text-sm tracking-tight",
                                    children: [(0, l.jsx)("div", {
                                        className: "mr-2 flex h-8 w-8 min-w-8 items-center justify-center rounded-full border bg-white shadow-sm",
                                        children: (0, l.jsx)(k, {
                                            actionType: e.actionType,
                                            className: "size-5"
                                        })
                                    }), (0, l.jsx)("div", {
                                        className: "w-fit",
                                        children: t
                                    })]
                                })
                            })
                        })
                    })
                },
                N = e => {
                    var t;
                    return null !== (t = ({
                        [f.ww.COLLECT_LEADS]: "Collect Leads",
                        [f.ww.CUSTOM_BUTTON]: "Custom Button",
                        [f.ww.TAVILY_WEB_SEARCH]: "Web Search",
                        [f.ww.SLACK_NOTIFY]: "Send Message",
                        [f.ww.CALCOM_GET_SLOTS]: "Get Available Slots",
                        [f.ww.CALENDLY_GET_SLOTS]: "Get Available Slots",
                        [f.ww.SHOPIFY_SHOW_PRODUCT]: "Get Products",
                        [f.ww.SHOPIFY_SHOW_ORDER]: "Get Orders",
                        [f.ww.STRIPE_GET_INVOICES]: "Get Invoices",
                        [f.ww.STRIPE_GET_SUBSCRIPTION]: "Get Subscription",
                        [f.ww.CUSTOM_ACTION]: "Custom Action",
                        [f.ww.CHATBASE_UPDATE_CHATBOT_SETTINGS]: "Update Chatbot Settings",
                        [f.ww.ZENDESK_CREATE_TICKET]: "Create Zendesk Ticket",
                        [f.ww.SUNSHINE_LIVE_CHAT]: "Connect to Zendesk Live Agent"
                    })[e]) && void 0 !== t ? t : "Unknown Action"
                };

            function k(e) {
                switch (e.actionType) {
                    case f.ww.COLLECT_LEADS:
                        return (0, l.jsx)(m.N, {
                            className: (0, a.cn)("fill-pink-600", e.className)
                        });
                    case f.ww.CUSTOM_BUTTON:
                        return (0, l.jsx)(g.Z, {
                            viewBox: "2 2 20 21",
                            className: e.className
                        });
                    case f.ww.CUSTOM_ACTION:
                        return (0, l.jsx)(d.x, {
                            viewBox: "45 140 900 900",
                            className: (0, a.cn)("fill-violet-600", e.className)
                        });
                    case f.ww.CALCOM_GET_SLOTS:
                        return (0, l.jsx)(n.Z, {
                            className: (0, a.cn)("aspect-video w-16 p-1", e.className)
                        });
                    case f.ww.CALENDLY_GET_SLOTS:
                        return (0, l.jsx)(c.Z, {
                            className: e.className
                        });
                    case f.ww.SHOPIFY_SHOW_PRODUCT:
                    case f.ww.SHOPIFY_SHOW_ORDER:
                        return (0, l.jsx)(o.Z, {
                            className: e.className
                        });
                    case f.ww.STRIPE_GET_INVOICES:
                    case f.ww.STRIPE_GET_SUBSCRIPTION:
                        return (0, l.jsx)(h._, {
                            className: e.className
                        });
                    case f.ww.CHATBASE_UPDATE_CHATBOT_SETTINGS:
                        return (0, l.jsx)(i.W, {
                            className: e.className
                        });
                    case f.ww.SLACK_NOTIFY:
                        return (0, l.jsx)(p.Z, {
                            className: e.className
                        });
                    case f.ww.TAVILY_WEB_SEARCH:
                        return (0, l.jsx)(x, {
                            viewBox: "2 2 20 20",
                            className: e.className
                        });
                    case f.ww.ZENDESK_CREATE_TICKET:
                        return (0, l.jsx)(v.Z, {
                            className: e.className
                        });
                    case f.ww.SUNSHINE_LIVE_CHAT:
                        return (0, l.jsx)(w.Z, {
                            className: e.className
                        })
                }
            }
        },
        88374: function(e, t, r) {
            var l = r(57437);
            t.Z = e => {
                let {
                    size: t = 24,
                    color: r = "none",
                    strokeWidth: a = .5,
                    absoluteStrokeWidth: s,
                    ...n
                } = e, c = s ? Number(a) : 64 * Number(a) / Number(t);
                return (0, l.jsxs)("svg", {
                    width: t,
                    height: t,
                    viewBox: "0 0 40 40",
                    fill: "none",
                    stroke: r,
                    strokeWidth: c,
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeMiterlimit: "10",
                    strokeDasharray: "0",
                    strokeDashoffset: "0",
                    strokeOpacity: "1",
                    ...n,
                    children: [(0, l.jsx)("title", {
                        children: "CalcomLogo"
                    }), (0, l.jsx)("title", {
                        children: "Cal.com logo"
                    }), (0, l.jsx)("rect", {
                        width: "40",
                        height: "40",
                        rx: "20",
                        fill: "#09090B"
                    }), (0, l.jsx)("rect", {
                        x: "0.5",
                        y: "0.5",
                        stroke: "#E4E4E7"
                    }), (0, l.jsx)("path", {
                        d: "M13.133 25.3016C9.63485 25.3016 7 22.6185 7 19.3059C7 15.9824 9.50031 13.2771 13.133 13.2771C15.0615 13.2771 16.3957 13.8513 17.4385 15.1653L15.7566 16.5234C15.0503 15.7946 14.1982 15.4303 13.133 15.4303C10.7673 15.4303 9.46667 17.1859 9.46667 19.3059C9.46667 21.426 10.8906 23.1485 13.133 23.1485C14.187 23.1485 15.084 22.7841 15.7903 22.0554L17.4497 23.4687C16.4518 24.7275 15.084 25.3016 13.133 25.3016Z",
                        fill: "white"
                    }), (0, l.jsx)("path", {
                        d: "M24.6928 16.4781H26.9576V25.0907H24.6928V23.832C24.2219 24.7264 23.437 25.3226 21.9346 25.3226C19.5352 25.3226 17.6179 23.302 17.6179 20.8176C17.6179 18.3332 19.5352 16.3125 21.9346 16.3125C23.4258 16.3125 24.2219 16.9088 24.6928 17.8032V16.4781ZM24.7601 20.8176C24.7601 19.4705 23.807 18.3552 22.3046 18.3552C20.8582 18.3552 19.9164 19.4815 19.9164 20.8176C19.9164 22.1205 20.8582 23.2799 22.3046 23.2799C23.7958 23.2799 24.7601 22.1536 24.7601 20.8176Z",
                        fill: "white"
                    }), (0, l.jsx)("path", {
                        d: "M28.561 13H30.8259V25.0798H28.561V13Z",
                        fill: "white"
                    })]
                })
            }
        },
        16616: function(e, t, r) {
            var l = r(57437);
            t.Z = e => {
                let {
                    size: t = 24,
                    color: r = "#006aff",
                    strokeWidth: a = .5,
                    absoluteStrokeWidth: s,
                    ...n
                } = e, c = s ? Number(a) : 64 * Number(a) / Number(t);
                return (0, l.jsxs)("svg", {
                    width: 40,
                    height: 40,
                    viewBox: "30 255 130 135",
                    fill: r,
                    stroke: r,
                    strokeWidth: c,
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeMiterlimit: "10",
                    strokeDasharray: "0",
                    strokeDashoffset: "0",
                    strokeOpacity: "1",
                    ...n,
                    children: [(0, l.jsx)("title", {
                        children: "Calendly Icon"
                    }), (0, l.jsx)("path", {
                        fill: "#006BFF",
                        d: "M120.4,343.1c-4.1,3.7-9.3,8.3-18.7,8.3H96c-6.8,0-13-2.5-17.4-6.9c-4.3-4.4-6.7-10.4-6.7-16.9v-7.7 c0-6.5,2.4-12.5,6.7-16.9c4.4-4.5,10.6-6.9,17.4-6.9h5.6c9.4,0,14.6,4.6,18.7,8.3c4.3,3.8,8,7.1,17.9,7.1c1.5,0,3-0.1,4.5-0.4l0-0.1 c-0.6-1.5-1.3-2.9-2.1-4.3l-6.6-11.5c-6.1-10.5-17.3-17-29.5-17H91.4c-12.2,0-23.4,6.5-29.5,17l-6.6,11.5c-6.1,10.5-6.1,23.5,0,34 l6.6,11.5c6.1,10.5,17.3,17,29.5,17h13.2c12.2,0,23.4-6.5,29.5-17l6.6-11.5c0.8-1.4,1.5-2.8,2.1-4.3l0-0.1c-1.5-0.2-3-0.4-4.5-0.4 C128.4,336,124.7,339.3,120.4,343.1"
                    }), (0, l.jsx)("path", {
                        fill: "#006BFF",
                        d: "M101.7,303H96c-10.3,0-17.1,7.4-17.1,16.8v7.7c0,9.5,6.8,16.8,17.1,16.8h5.6c15.1,0,13.9-15.4,36.7-15.4 c2.2,0,4.3,0.2,6.4,0.6c0.7-3.9,0.7-7.9,0-11.8c-2.1,0.4-4.3,0.6-6.4,0.6C115.5,318.4,116.7,303,101.7,303"
                    }), (0, l.jsx)("path", {
                        fill: "#006BFF",
                        d: "M157.8,335.2c-3.9-2.8-8.3-4.8-13.1-5.6c0,0,0,0.1,0,0.1c-0.4,2.3-1,4.5-1.9,6.6c3.9,0.6,7.6,2.1,10.8,4.5 c0,0,0,0.1,0,0.1c-9.5,30.8-42.1,48-72.9,38.5s-48-42.1-38.5-72.9s42.1-48,72.9-38.5c18.4,5.7,32.8,20.1,38.5,38.5c0,0,0,0.1,0,0.1 c-3.2,2.3-6.9,3.8-10.8,4.4c0.9,2.1,1.5,4.4,1.9,6.6c0,0,0,0.1,0,0.1c4.7-0.9,9.2-2.8,13.1-5.6c3.7-2.8,3-5.9,2.4-7.7 c-10.6-34.5-47.2-53.8-81.7-43.2c-34.5,10.6-53.8,47.2-43.2,81.7s47.2,53.8,81.7,43.2c20.6-6.4,36.8-22.5,43.2-43.2 C160.8,341.1,161.6,338,157.8,335.2"
                    }), (0, l.jsx)("path", {
                        fill: "#0AE8F0",
                        d: "M142.8,311c-1.5,0.2-3,0.4-4.5,0.4c-9.9,0-13.6-3.3-17.9-7.1c-4.2-3.7-9.3-8.3-18.7-8.3H96 c-6.8,0-13,2.5-17.4,6.9c-4.3,4.4-6.7,10.4-6.7,16.9v7.7c0,6.5,2.4,12.5,6.7,16.9c4.4,4.5,10.6,6.9,17.4,6.9h5.6 c9.4,0,14.6-4.6,18.7-8.3c4.3-3.8,8-7.1,17.9-7.1c1.5,0,3,0.1,4.5,0.4c0.9-2.1,1.5-4.4,1.9-6.6c0,0,0-0.1,0-0.1 c-2.1-0.4-4.3-0.6-6.4-0.6c-22.8,0-21.6,15.4-36.7,15.4H96c-10.3,0-17.1-7.4-17.1-16.9v-7.7c0-9.5,6.8-16.8,17.1-16.8h5.6 c15.1,0,13.9,15.4,36.7,15.4c2.2,0,4.3-0.2,6.4-0.6c0,0,0-0.1,0-0.1C144.3,315.4,143.7,313.2,142.8,311"
                    }), (0, l.jsx)("path", {
                        fill: "#0AE8F0",
                        d: "M142.8,311c-1.5,0.2-3,0.4-4.5,0.4c-9.9,0-13.6-3.3-17.9-7.1c-4.2-3.7-9.3-8.3-18.7-8.3H96 c-6.8,0-13,2.5-17.4,6.9c-4.3,4.4-6.7,10.4-6.7,16.9v7.7c0,6.5,2.4,12.5,6.7,16.9c4.4,4.5,10.6,6.9,17.4,6.9h5.6 c9.4,0,14.6-4.6,18.7-8.3c4.3-3.8,8-7.1,17.9-7.1c1.5,0,3,0.1,4.5,0.4c0.9-2.1,1.5-4.4,1.9-6.6c0,0,0-0.1,0-0.1 c-2.1-0.4-4.3-0.6-6.4-0.6c-22.8,0-21.6,15.4-36.7,15.4H96c-10.3,0-17.1-7.4-17.1-16.9v-7.7c0-9.5,6.8-16.8,17.1-16.8h5.6 c15.1,0,13.9,15.4,36.7,15.4c2.2,0,4.3-0.2,6.4-0.6c0,0,0-0.1,0-0.1C144.3,315.4,143.7,313.2,142.8,311"
                    })]
                })
            }
        },
        10126: function(e, t, r) {
            r.d(t, {
                W: function() {
                    return n
                }
            });
            var l = r(57437),
                a = r(77712),
                s = r(81201);
            let n = e => {
                let {
                    size: t = 24,
                    variant: r = "black",
                    strokeWidth: n = .5,
                    absoluteStrokeWidth: c,
                    showText: i = !1,
                    className: o,
                    ...d
                } = e, h = c ? Number(n) : 64 * Number(n) / Number(t), u = (0, a.j)("h-7", {
                    variants: {
                        showText: {
                            true: "aspect-video w-32",
                            false: "w-7"
                        }
                    }
                });
                return (0, l.jsxs)("svg", {
                    width: t,
                    height: t,
                    viewBox: i ? "0 0 504 109" : "0 0 109 109",
                    fill: "none",
                    strokeWidth: h,
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeMiterlimit: "10",
                    strokeDasharray: "0",
                    strokeDashoffset: "0",
                    strokeOpacity: "1",
                    className: (0, s.cn)(u({
                        showText: i
                    }), o),
                    ...d,
                    children: [(0, l.jsx)("title", {
                        children: "Chatbase.co"
                    }), (0, l.jsx)("rect", {
                        width: "109",
                        height: "109",
                        fill: "black" === r ? "#09090B" : "white",
                        rx: "28"
                    }), (0, l.jsx)("path", {
                        fill: "black" === r ? "white" : "#09090B",
                        d: "M84.5 46.5H66.9a12 12 0 0 0-1-4 9.1 9.1 0 0 0-5.5-5 13 13 0 0 0-4.5-.8c-3 0-5.4.7-7.4 2.1-2 1.4-3.6 3.5-4.6 6.1-1 2.7-1.5 5.9-1.5 9.6 0 4 .5 7.2 1.5 9.9 1.1 2.6 2.6 4.6 4.6 6 2 1.3 4.4 2 7.3 2 1.6 0 3-.3 4.3-.7 1.2-.4 2.3-1 3.3-1.8 1-.7 1.7-1.7 2.3-2.8.6-1 1-2.3 1.2-3.7l17.6.1a24 24 0 0 1-2.3 8.3 27 27 0 0 1-14.5 13.5 32.5 32.5 0 0 1-12.3 2.2c-5.9 0-11.2-1.3-15.8-3.8a27.5 27.5 0 0 1-11-11.2c-2.8-4.9-4.1-10.9-4.1-18 0-7.2 1.4-13.2 4.1-18 2.8-5 6.5-8.7 11.1-11.2a35.8 35.8 0 0 1 26.8-2.1c3.4 1 6.4 2.7 9 4.8a24 24 0 0 1 6.2 7.8c1.5 3.1 2.5 6.7 2.8 10.7Z"
                    }), i && (0, l.jsx)("path", {
                        fill: "black" === r ? "#09090B" : "white",
                        d: "M195 43.7h-9.8a14.8 14.8 0 0 0-6-9.5c-1.5-1.1-3.2-2-5-2.5a20 20 0 0 0-16 1.9 19 19 0 0 0-7 8.2c-1.6 3.6-2.5 8-2.5 13.1 0 5.2.9 9.6 2.6 13.2 1.7 3.6 4 6.3 7 8.1 3 1.9 6.3 2.8 10 2.8 2 0 4-.3 5.8-.8a17 17 0 0 0 5-2.5 15.2 15.2 0 0 0 6-9.4h10a25.9 25.9 0 0 1-9 15.5c-2.3 2-5 3.4-8 4.4-3 1-6.3 1.6-9.9 1.6a27.7 27.7 0 0 1-25.4-15.3c-2.5-4.9-3.8-10.8-3.8-17.6 0-6.8 1.3-12.7 3.8-17.6A27.5 27.5 0 0 1 168.2 22c3.5 0 6.7.5 9.7 1.5a25.6 25.6 0 0 1 14 11 26 26 0 0 1 3.2 9.2ZM210.2 58.4V87h-9.5V23h9.3v23.8h.6c1.2-2.6 3-4.6 5.3-6.2 2.3-1.5 5.4-2.2 9.2-2.2 3.3 0 6.2.6 8.7 2 2.5 1.4 4.5 3.4 5.9 6 1.4 2.7 2 6 2 10V87h-9.4V57.5c0-3.5-1-6.3-2.8-8.2a10 10 0 0 0-7.7-3c-2.2 0-4.2.5-6 1.5-1.8 1-3.1 2.3-4.2 4.1-1 1.8-1.4 4-1.4 6.5ZM263.2 88c-3 0-5.8-.6-8.3-1.7a14 14 0 0 1-6-5 14.1 14.1 0 0 1-2.1-8c0-2.6.5-4.9 1.6-6.6 1-1.8 2.4-3.2 4.2-4.2 1.8-1 3.8-1.8 6-2.3 2.3-.5 4.5-1 6.9-1.2l7-.8c1.9-.2 3.2-.6 4-1.1.9-.5 1.3-1.3 1.3-2.4v-.3c0-2.7-.8-4.8-2.4-6.3-1.5-1.5-3.8-2.3-6.9-2.3-3.2 0-5.7.7-7.6 2.1-1.8 1.4-3 3-3.7 4.6l-9-2c1.1-2.9 2.7-5.2 4.7-7 2-1.9 4.4-3.2 7-4a28 28 0 0 1 14.7-.5c2.2.4 4.2 1.2 6.1 2.4 2 1.2 3.5 2.9 4.7 5 1.3 2.3 1.9 5.1 1.9 8.6v32H278v-6.6h-.4c-.6 1.2-1.5 2.4-2.7 3.5a14.7 14.7 0 0 1-4.8 3c-1.9.7-4.2 1.1-6.9 1.1Zm2.1-7.5c2.6 0 4.9-.5 6.7-1.5 1.9-1 3.3-2.4 4.3-4 1-1.7 1.5-3.5 1.5-5.4v-6.2a5 5 0 0 1-2 1l-3.2.7a388 388 0 0 1-6.5.9c-1.9.2-3.6.6-5 1.1a8.7 8.7 0 0 0-3.7 2.4c-.9 1-1.3 2.3-1.3 4 0 2.3.8 4 2.6 5.2 1.7 1.2 4 1.8 6.6 1.8ZM317.3 38.9v7.5h-26.6v-7.5h26.6Zm-19.5-11.5h9.5v45.4c0 1.8.3 3.2.8 4.1.6 1 1.3 1.5 2.2 1.9a11.2 11.2 0 0 0 4.9.3l1.3-.3 1.7 7.8-2.4.6a18.8 18.8 0 0 1-10.7-1 12 12 0 0 1-5.3-4.2c-1.3-2-2-4.3-2-7.2V27.4ZM324.2 87V22.8h9.5v23.8h.6a26 26 0 0 1 2.4-3.5c1-1.3 2.5-2.5 4.3-3.4 1.8-1 4.3-1.5 7.3-1.5 4 0 7.4 1 10.5 3 3.1 1.9 5.5 4.7 7.3 8.4 1.8 3.7 2.7 8.1 2.7 13.3a31 31 0 0 1-2.7 13.4 19 19 0 0 1-17.7 11.5c-3 0-5.4-.5-7.3-1.5-1.8-1-3.3-2.1-4.4-3.4a26 26 0 0 1-2.4-3.5h-.8v7.4h-9.3Zm9.3-24c0 3.3.5 6.3 1.5 8.8 1 2.5 2.5 4.5 4.3 6 2 1.4 4.2 2.1 7 2.1s5.2-.7 7-2.2c2-1.5 3.4-3.6 4.4-6.1 1-2.6 1.5-5.5 1.5-8.7 0-3.2-.5-6-1.5-8.5a13 13 0 0 0-4.3-6 11.4 11.4 0 0 0-7.1-2.2c-2.8 0-5.1.7-7 2.1a12.9 12.9 0 0 0-4.3 5.9 24 24 0 0 0-1.5 8.7ZM388.2 88c-3 0-5.8-.6-8.3-1.7a14 14 0 0 1-6-5 14.1 14.1 0 0 1-2.1-8c0-2.6.5-4.9 1.6-6.6 1-1.8 2.4-3.2 4.2-4.2 1.8-1 3.8-1.8 6-2.3 2.3-.5 4.5-1 6.8-1.2l7.2-.8c1.8-.2 3.1-.6 4-1.1.7-.5 1.2-1.3 1.2-2.4v-.3c0-2.7-.8-4.8-2.4-6.3-1.5-1.5-3.8-2.3-6.9-2.3-3.2 0-5.7.7-7.6 2.1-1.8 1.4-3 3-3.7 4.6l-9-2c1.1-2.9 2.7-5.2 4.7-7 2-1.9 4.4-3.2 7-4a28 28 0 0 1 14.7-.5c2.2.4 4.2 1.2 6.1 2.4 2 1.2 3.5 2.9 4.7 5 1.3 2.3 1.9 5.1 1.9 8.6v32H403v-6.6h-.4c-.6 1.2-1.5 2.4-2.7 3.5a14.7 14.7 0 0 1-4.8 3c-1.9.7-4.2 1.1-6.9 1.1Zm2-7.5c2.7 0 5-.5 6.8-1.5 1.9-1 3.3-2.4 4.3-4 1-1.7 1.5-3.5 1.5-5.4v-6.2a5 5 0 0 1-2 1l-3.2.7a388 388 0 0 1-6.5.9c-1.9.2-3.6.6-5 1.1a8.7 8.7 0 0 0-3.7 2.4c-.9 1-1.3 2.3-1.3 4 0 2.3.8 4 2.6 5.2 1.7 1.2 4 1.8 6.6 1.8ZM456 50.6l-8.5 1.5c-.4-1-1-2-1.7-3-.8-1-1.8-1.9-3.2-2.5-1.3-.6-2.9-1-4.9-1-2.7 0-4.9.7-6.7 1.9-1.8 1.1-2.7 2.6-2.7 4.5 0 1.6.6 2.9 1.8 3.9 1.2 1 3.2 1.8 5.9 2.4l7.7 1.7c4.5 1 7.8 2.6 10 4.8A11 11 0 0 1 457 73c0 3-.8 5.5-2.5 7.7-1.7 2.3-4 4-7 5.3-3 1.3-6.5 2-10.4 2-5.5 0-10-1.2-13.4-3.5a14.5 14.5 0 0 1-6.3-9.9l9.2-1.4a8.6 8.6 0 0 0 3.5 5.4c1.8 1.2 4 1.8 7 1.8a13 13 0 0 0 7.4-2c1.9-1.2 2.8-2.8 2.8-4.7 0-1.5-.6-2.7-1.7-3.7-1.2-1-2.9-1.8-5.2-2.4l-8.3-1.7a20 20 0 0 1-10-5c-2.2-2.2-3.3-5-3.3-8.4 0-2.8.8-5.3 2.4-7.4 1.6-2.2 3.9-3.8 6.7-5 2.8-1.2 6-1.8 9.7-1.8 5.3 0 9.4 1 12.5 3.3 3 2.3 5 5.3 6 9ZM483 88c-4.7 0-8.8-1.1-12.3-3.1s-6.1-5-8-8.6c-1.9-3.7-2.8-8-2.8-13s1-9.3 2.8-13c1.9-3.8 4.5-6.8 7.9-8.9a24.2 24.2 0 0 1 19.9-1.8 19.4 19.4 0 0 1 11.7 11.7c1.2 3 1.8 6.8 1.8 11.1v3.3h-38.7v-7h29.4c0-2.4-.5-4.6-1.5-6.5-1-2-2.5-3.4-4.3-4.6-1.8-1-4-1.6-6.4-1.6a12.5 12.5 0 0 0-11.6 7c-1 2-1.5 4.2-1.5 6.6v5.5c0 3.2.5 6 1.7 8.2 1.1 2.2 2.8 4 4.8 5.1 2.1 1.2 4.5 1.8 7.3 1.8 1.8 0 3.4-.3 5-.8a10 10 0 0 0 6.3-6.1l8.9 1.6a16 16 0 0 1-3.9 6.9c-1.8 2-4.1 3.4-7 4.5-2.7 1-5.9 1.6-9.4 1.6Z"
                    }), (0, l.jsx)("mask", {
                        id: "chatbase-logo-mask",
                        width: "44",
                        height: "66",
                        x: "21",
                        y: "23",
                        maskUnits: "userSpaceOnUse",
                        style: {
                            maskType: "alpha"
                        },
                        children: (0, l.jsx)("path", {
                            fill: "#A1A1AA",
                            d: "M41.5 23 51 37.5 62.5 71 65 87l-31.5 2L21 71l3.5-35 17-13Z"
                        })
                    }), (0, l.jsx)("g", {
                        mask: "url(#chatbase-logo-mask)",
                        children: (0, l.jsx)("path", {
                            fill: "#B2AEB9",
                            opacity: "black" === r ? 1 : .2,
                            d: "M84.5 46.5H66.9a12 12 0 0 0-1-4 9.1 9.1 0 0 0-5.5-5 13 13 0 0 0-4.5-.8c-3 0-5.4.7-7.4 2.1-2 1.4-3.6 3.5-4.6 6.1-1 2.7-1.5 5.9-1.5 9.6 0 4 .5 7.2 1.5 9.9 1.1 2.6 2.6 4.6 4.6 6 2 1.3 4.4 2 7.3 2 1.6 0 3-.3 4.3-.7 1.2-.4 2.3-1 3.3-1.8 1-.7 1.7-1.7 2.3-2.8.6-1 1-2.3 1.2-3.7l17.6.1a24 24 0 0 1-2.3 8.3 27 27 0 0 1-14.5 13.5 32.5 32.5 0 0 1-12.3 2.2c-5.9 0-11.2-1.3-15.8-3.8a27.5 27.5 0 0 1-11-11.2c-2.8-4.9-4.1-10.9-4.1-18 0-7.2 1.4-13.2 4.1-18 2.8-5 6.5-8.7 11.1-11.2a35.8 35.8 0 0 1 26.8-2.1c3.4 1 6.4 2.7 9 4.8a24 24 0 0 1 6.2 7.8c1.5 3.1 2.5 6.7 2.8 10.7Z"
                        })
                    })]
                })
            }
        },
        51989: function(e, t, r) {
            r.d(t, {
                N: function() {
                    return a
                }
            });
            var l = r(57437);
            let a = e => (0, l.jsxs)("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                ...e,
                children: [(0, l.jsx)("title", {
                    children: "Three People Standing"
                }), (0, l.jsx)("path", {
                    d: "M5.26 3.97a1 1 0 0 0-.52-1.94A5.11 5.11 0 0 0 1 7a5.11 5.11 0 0 0 3.74 4.97 1 1 0 0 0 .52-1.94A3.11 3.11 0 0 1 3 7c0-1.48.98-2.7 2.26-3.03Zm14-1.94a1 1 0 0 0-.52 1.94A3.11 3.11 0 0 1 21 7a3.1 3.1 0 0 1-2.26 3.03 1 1 0 0 0 .52 1.94A5.11 5.11 0 0 0 23 7a5.11 5.11 0 0 0-3.74-4.97ZM12 2a5 5 0 1 0 0 10 5 5 0 0 0 0-10ZM8.75 14A4.75 4.75 0 0 0 4 18.75C4 20.55 5.46 22 7.25 22h9.5c1.8 0 3.25-1.46 3.25-3.25A4.75 4.75 0 0 0 15.25 14h-6.5Zm-6.13 2.63a1 1 0 0 0-1.55-1.26 4.73 4.73 0 0 0-1.07 3c0 1.03.48 1.95 1.22 2.54a1 1 0 1 0 1.25-1.56 1.25 1.25 0 0 1-.47-.98c0-.66.23-1.26.62-1.74Zm20.31-.89a1 1 0 1 0-1.55 1.27c.39.47.62 1.08.62 1.74 0 .4-.18.75-.47.98a1 1 0 0 0 1.25 1.56A3.25 3.25 0 0 0 24 18.75a4.7 4.7 0 0 0-1.07-3Z"
                })]
            })
        },
        21851: function(e, t, r) {
            var l = r(57437);
            t.Z = function(e) {
                let {
                    className: t,
                    ...r
                } = e;
                return (0, l.jsxs)("svg", {
                    viewBox: "-30 0 292 287",
                    xmlns: "http://www.w3.org/2000/svg",
                    preserveAspectRatio: "xMidYMid",
                    className: t,
                    ...r,
                    children: [(0, l.jsx)("title", {
                        children: "Shopify"
                    }), (0, l.jsx)("g", {
                        id: "SVGRepo_bgCarrier",
                        strokeWidth: "0"
                    }), (0, l.jsx)("g", {
                        id: "SVGRepo_tracerCarrier",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), (0, l.jsxs)("g", {
                        id: "SVGRepo_iconCarrier",
                        children: [(0, l.jsx)("path", {
                            d: "M223.774 57.34c-.201-1.46-1.48-2.268-2.537-2.357-1.055-.088-23.383-1.743-23.383-1.743s-15.507-15.395-17.209-17.099c-1.703-1.703-5.029-1.185-6.32-.805-.19.056-3.388 1.043-8.678 2.68-5.18-14.906-14.322-28.604-30.405-28.604-.444 0-.901.018-1.358.044C129.31 3.407 123.644.779 118.75.779c-37.465 0-55.364 46.835-60.976 70.635-14.558 4.511-24.9 7.718-26.221 8.133-8.126 2.549-8.383 2.805-9.45 10.462C21.3 95.806.038 260.235.038 260.235l165.678 31.042 89.77-19.42S223.973 58.8 223.775 57.34zM156.49 40.848l-14.019 4.339c.005-.988.01-1.96.01-3.023 0-9.264-1.286-16.723-3.349-22.636 8.287 1.04 13.806 10.469 17.358 21.32zm-27.638-19.483c2.304 5.773 3.802 14.058 3.802 25.238 0 .572-.005 1.095-.01 1.624-9.117 2.824-19.024 5.89-28.953 8.966 5.575-21.516 16.025-31.908 25.161-35.828zm-11.131-10.537c1.617 0 3.246.549 4.805 1.622-12.007 5.65-24.877 19.88-30.312 48.297l-22.886 7.088C75.694 46.16 90.81 10.828 117.72 10.828z",
                            fill: "#95BF46"
                        }), (0, l.jsx)("path", {
                            d: "M221.237 54.983c-1.055-.088-23.383-1.743-23.383-1.743s-15.507-15.395-17.209-17.099c-.637-.634-1.496-.959-2.394-1.099l-12.527 256.233 89.762-19.418S223.972 58.8 223.774 57.34c-.201-1.46-1.48-2.268-2.537-2.357",
                            fill: "#5E8E3E"
                        }), (0, l.jsx)("path", {
                            d: "M135.242 104.585l-11.069 32.926s-9.698-5.176-21.586-5.176c-17.428 0-18.305 10.937-18.305 13.693 0 15.038 39.2 20.8 39.2 56.024 0 27.713-17.577 45.558-41.277 45.558-28.44 0-42.984-17.7-42.984-17.7l7.615-25.16s14.95 12.835 27.565 12.835c8.243 0 11.596-6.49 11.596-11.232 0-19.616-32.16-20.491-32.16-52.724 0-27.129 19.472-53.382 58.778-53.382 15.145 0 22.627 4.338 22.627 4.338",
                            fill: "#FFF"
                        })]
                    })]
                })
            }
        },
        565: function(e, t, r) {
            var l = r(57437);
            t.Z = e => {
                let {
                    size: t = 24,
                    color: r = "none",
                    strokeWidth: a = .5,
                    absoluteStrokeWidth: s,
                    ...n
                } = e, c = s ? Number(a) : 64 * Number(a) / Number(t);
                return (0, l.jsxs)("svg", {
                    width: t,
                    height: t,
                    viewBox: "0 0 60 60",
                    fill: r,
                    stroke: r,
                    strokeWidth: c,
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeMiterlimit: "10",
                    strokeDasharray: "0",
                    strokeDashoffset: "0",
                    strokeOpacity: "1",
                    ...n,
                    children: [(0, l.jsx)("title", {
                        children: "SlackIcon"
                    }), (0, l.jsx)("path", {
                        d: "M22,12 a6,6 0 1 1 6,-6 v6z M22,16 a6,6 0 0 1 0,12 h-16 a6,6 0 1 1 0,-12",
                        fill: "#36C5F0"
                    }), (0, l.jsx)("path", {
                        d: "M48,22 a6,6 0 1 1 6,6 h-6z M32,6 a6,6 0 1 1 12,0v16a6,6 0 0 1 -12,0z",
                        fill: "#2EB67D"
                    }), (0, l.jsx)("path", {
                        d: "M38,48 a6,6 0 1 1 -6,6 v-6z M54,32 a6,6 0 0 1 0,12 h-16 a6,6 0 1 1 0,-12",
                        fill: "#ECB22E"
                    }), (0, l.jsx)("path", {
                        d: "M12,38 a6,6 0 1 1 -6,-6 h6z M16,38 a6,6 0 1 1 12,0v16a6,6 0 0 1 -12,0z",
                        fill: "#E01E5A"
                    })]
                })
            }
        },
        82182: function(e, t, r) {
            var l = r(57437);
            t.Z = e => {
                let {
                    size: t = 24,
                    color: r = "#03363d",
                    ...a
                } = e;
                return (0, l.jsxs)("svg", {
                    width: t,
                    height: t,
                    viewBox: "0 0 64 64",
                    fill: "none",
                    ...a,
                    children: [(0, l.jsx)("title", {
                        children: "Sunshine Icon"
                    }), (0, l.jsx)("path", {
                        d: "m48.201554 35.4957912c1.415664-3.239532 2.141244-6.737976 2.1288755-10.27296-.0356555-13.84344-11.2857995-25.036164-25.1292395-25.00075219-13.84344.03558019-25.037208 11.28676819-25.00179619 25.13020819.00948019 3.496356.74967619 6.950952 2.17369219 10.143504z",
                        fill: "#eec83d",
                        transform: "scale(1.25) translate(0, 4.5)"
                    })]
                })
            }
        },
        58639: function(e, t, r) {
            r.d(t, {
                x: function() {
                    return a
                }
            });
            var l = r(57437);
            let a = e => (0, l.jsxs)("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "30 30 1200 1200",
                ...e,
                children: [(0, l.jsx)("title", {
                    children: "Webhooks Icon"
                }), (0, l.jsx)("path", {
                    d: "M482 226h-1l-10 2q-33 4 -64.5 18.5t-55.5 38.5q-41 37 -57 91q-9 30 -8 63t12 63q17 45 52 78l13 12l-83 135q-26 -1 -45 7q-30 13 -45 40q-7 15 -9 31t2 32q8 30 33 48q15 10 33 14.5t36 2t34.5 -12.5t27.5 -25q12 -17 14.5 -39t-5.5 -41q-1 -5 -7 -14l-3 -6l118 -192 q6 -9 8 -14l-10 -3q-9 -2 -13 -4q-23 -10 -41.5 -27.5t-28.5 -39.5q-17 -36 -9 -75q4 -23 17 -43t31 -34q37 -27 82 -27q27 -1 52.5 9.5t44.5 30.5q17 16 26.5 38.5t10.5 45.5q0 17 -6 42l70 19l8 1q14 -43 7 -86q-4 -33 -19.5 -63.5t-39.5 -53.5q-42 -42 -103 -56 q-6 -2 -18 -4l-14 -2h-37zM500 350q-17 0 -34 7t-30.5 20.5t-19.5 31.5q-8 20 -4 44q3 18 14 34t28 25q24 15 56 13q3 4 5 8l112 191q3 6 6 9q27 -26 58.5 -35.5t65 -3.5t58.5 26q32 25 43.5 61.5t0.5 73.5q-8 28 -28.5 50t-48.5 33q-31 13 -66.5 8.5t-63.5 -24.5 q-4 -3 -13 -10l-5 -6q-4 3 -11 10l-47 46q23 23 52 38.5t61 21.5l22 4h39l28 -5q64 -13 110 -60q22 -22 36.5 -50.5t19.5 -59.5q5 -36 -2 -71.5t-25 -64.5t-44 -51t-57 -35q-34 -14 -70.5 -16t-71.5 7l-17 5l-81 -137q13 -19 16 -37q5 -32 -13 -60q-16 -25 -44 -35 q-17 -6 -35 -6zM218 614q-58 13 -100 53q-47 44 -61 105l-4 24v37l2 11q2 13 4 20q7 31 24.5 59t42.5 49q50 41 115 49q38 4 76 -4.5t70 -28.5q53 -34 78 -91q7 -17 14 -45q6 -1 18 0l125 2q14 0 20 1q11 20 25 31t31.5 16t35.5 4q28 -3 50 -20q27 -21 32 -54 q2 -17 -1.5 -33t-13.5 -30q-16 -22 -41 -32q-17 -7 -35.5 -6.5t-35.5 7.5q-28 12 -43 37l-3 6q-14 0 -42 -1l-113 -1q-15 -1 -43 -1l-50 -1l3 17q8 43 -13 81q-14 27 -40 45t-57 22q-35 6 -70 -7.5t-57 -42.5q-28 -35 -27 -79q1 -37 23 -69q13 -19 32 -32t41 -19l9 -3z"
                })]
            })
        },
        98627: function(e, t, r) {
            var l = r(57437);
            t.Z = e => {
                let {
                    size: t = 24,
                    color: r = "#03363d",
                    strokeWidth: a = .5,
                    absoluteStrokeWidth: s,
                    ...n
                } = e, c = s ? Number(a) : 64 * Number(a) / Number(t);
                return (0, l.jsxs)("svg", {
                    width: t,
                    height: t,
                    viewBox: "0 0 1393 1055.77",
                    fill: r,
                    stroke: r,
                    strokeWidth: c,
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeMiterlimit: "10",
                    strokeDasharray: "0",
                    strokeDashoffset: "0",
                    strokeOpacity: "1",
                    ...n,
                    children: [(0, l.jsx)("title", {
                        children: "Zendesk Icon"
                    }), (0, l.jsx)("path", {
                        d: "M643.51 278.74v777H0zm0-278.74c0 177.57-143.84 321.41-321.41 321.41S0 177.57 0 0zm106 1055.77c0-177.57 143.84-321.41 321.41-321.41s321.41 143.84 321.41 321.41zm0-278.74V0H1393z"
                    })]
                })
            }
        },
        58666: function(e, t, r) {
            r.d(t, {
                _: function() {
                    return a
                }
            });
            var l = r(57437);
            let a = e => {
                let {
                    size: t = 24,
                    color: r = "#6772e6",
                    strokeWidth: a = .5,
                    absoluteStrokeWidth: s,
                    ...n
                } = e;
                return (0, l.jsxs)("svg", {
                    width: "100%",
                    height: "100%",
                    viewBox: "0 0 28.87 28.87",
                    fill: "none",
                    ...n,
                    children: [(0, l.jsx)("title", {
                        children: "Stripe Logo"
                    }), (0, l.jsx)("g", {
                        id: "Layer_2",
                        children: (0, l.jsxs)("g", {
                            id: "Layer_1-2",
                            children: [(0, l.jsx)("rect", {
                                width: "28.87",
                                height: "28.87",
                                rx: "6.48",
                                ry: "6.48",
                                style: {
                                    fill: "#6772e5"
                                }
                            }), (0, l.jsx)("path", {
                                d: "M13.3 11.2c0-.69.57-1 1.49-1a9.84 9.84 0 0 1 4.37 1.13V7.24a11.6 11.6 0 0 0-4.36-.8c-3.56 0-5.94 1.86-5.94 5 0 4.86 6.68 4.07 6.68 6.17 0 .81-.71 1.07-1.68 1.07A11.06 11.06 0 0 1 9 17.25v4.19a12.19 12.19 0 0 0 4.8 1c3.65 0 6.17-1.8 6.17-5 .03-5.21-6.67-4.27-6.67-6.24z",
                                style: {
                                    fill: "#fff",
                                    fillRule: "evenodd"
                                }
                            })]
                        })
                    })]
                })
            }
        },
        96246: function(e, t, r) {
            r.d(t, {
                Avatar: function() {
                    return c
                },
                F: function() {
                    return i
                },
                Q: function() {
                    return o
                }
            });
            var l = r(57437),
                a = r(2265),
                s = r(70650),
                n = r(81201);
            let c = a.forwardRef((e, t) => {
                let {
                    className: r,
                    ...a
                } = e;
                return (0, l.jsx)(s.fC, {
                    ref: t,
                    className: (0, n.cn)("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", r),
                    ...a
                })
            });
            c.displayName = s.fC.displayName;
            let i = a.forwardRef((e, t) => {
                let {
                    className: r,
                    ...a
                } = e;
                return (0, l.jsx)(s.Ee, {
                    ref: t,
                    className: (0, n.cn)("aspect-square h-full w-full", r),
                    ...a
                })
            });
            i.displayName = s.Ee.displayName;
            let o = a.forwardRef((e, t) => {
                let {
                    className: r,
                    ...a
                } = e;
                return (0, l.jsx)(s.NY, {
                    ref: t,
                    className: (0, n.cn)("flex h-full w-full items-center justify-center rounded-full bg-zinc-100 dark:bg-zinc-800", r),
                    ...a
                })
            });
            o.displayName = s.NY.displayName
        }
    }
]);